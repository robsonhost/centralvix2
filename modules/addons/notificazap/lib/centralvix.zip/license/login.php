<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';

license_session_start();

if (license_is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';
$warning = '';
$locked = license_is_locked();
$savedUser = license_saved_username();

if (isset($_GET['logout'])) {
    $success = 'Sessão encerrada com segurança.';
}

if (isset($_GET['expired'])) {
    $warning = 'Sua sessão expirou. Faça login novamente.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['_csrf'] ?? '';

    if (!license_verify_csrf($csrf)) {
        $error = 'Requisição inválida. Recarregue a página e tente novamente.';
    } elseif ($locked) {
        $minutes = (int) ceil(license_lock_remaining() / 60);
        $error = "Acesso bloqueado temporariamente. Aguarde {$minutes} minuto(s).";
    } else {
        $username = (string) ($_POST['username'] ?? '');
        $password = (string) ($_POST['password'] ?? '');
        $remember = !empty($_POST['remember']);

        $result = license_attempt_login($username, $password);

        if ($result['success']) {
            if ($remember) {
                license_remember_username($username);
            } else {
                license_forget_username();
            }

            header('Location: index.php');
            exit;
        }

        $error = $result['message'];
        $locked = !empty($result['locked']);
    }
}

$csrfToken = license_csrf_token();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <meta name="description" content="CentralVix License Manager — Painel exclusivo para licenciamento e revenda do sistema.">
    <title>Login · CentralVix License Manager</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/login.css?v=20260616">
</head>
<body class="cv-login-body">

<div class="cv-login-bg"></div>
<div class="cv-login-grid"></div>
<div class="cv-login-orb cv-login-orb--1"></div>
<div class="cv-login-orb cv-login-orb--2"></div>

<div class="cv-watermark-grid" aria-hidden="true">
    <?php for ($r = 0; $r < 6; $r++): ?>
        <?php for ($c = 0; $c < 4; $c++): ?>
            <span style="top:<?= ($r * 18 - 5) ?>%;left:<?= ($c * 28 - 8) ?>%">CENTRALVIX</span>
        <?php endfor; ?>
    <?php endfor; ?>
</div>

<div class="cv-login-shell">
    <section class="cv-login-brand">
        <div class="cv-brand-badge">
            <i class="fas fa-certificate"></i>
            License Manager Pro · Uso do Licenciador
        </div>

        <div class="cv-brand-logo">
            <div class="icon"><i class="fas fa-shield-halved"></i></div>
            <div>
                <h1>CENTRALVIX</h1>
                <p>Sistema de licenciamento para revenda SaaS</p>
            </div>
        </div>

        <p class="cv-brand-lead">
            Painel exclusivo para você gerenciar licenças, domínios, ativações e clientes
            que alugam o código CentralVix. Profissional, seguro e pronto para escala.
        </p>

        <div class="cv-feature-list">
            <div class="cv-feature-item">
                <div class="fi"><i class="fas fa-key"></i></div>
                <div>
                    <strong>Geração e controle de licenças</strong>
                    <span>Chaves CVIX com planos, validade, limites e bloqueio por domínio/IP.</span>
                </div>
            </div>
            <div class="cv-feature-item">
                <div class="fi"><i class="fas fa-server"></i></div>
                <div>
                    <strong>Ativações em tempo real</strong>
                    <span>Monitore instalações ativas, logs de validação e tentativas suspeitas.</span>
                </div>
            </div>
            <div class="cv-feature-item">
                <div class="fi"><i class="fab fa-whatsapp"></i></div>
                <div>
                    <strong>Entrega automática</strong>
                    <span>Envie licenças por WhatsApp direto do painel após a geração.</span>
                </div>
            </div>
            <div class="cv-feature-item">
                <div class="fi"><i class="fas fa-box-open"></i></div>
                <div>
                    <strong>Distribuição sem o painel</strong>
                    <span>O pacote entregue ao cliente não inclui este painel — apenas o sistema licenciado.</span>
                </div>
            </div>
        </div>

        <div class="cv-brand-tags">
            <span><i class="fas fa-lock"></i> Anti-pirataria</span>
            <span><i class="fas fa-globe"></i> Multi-domínio</span>
            <span><i class="fas fa-chart-line"></i> Dashboard</span>
            <span><i class="fas fa-code"></i> API REST</span>
        </div>
    </section>

    <section class="cv-login-form-wrap">
        <div class="cv-login-card">
            <div class="cv-login-card-header">
                <h2>Acesso ao painel</h2>
                <p>Entre com suas credenciais de administrador licenciador</p>
            </div>

            <?php if ($success): ?>
            <div class="cv-alert cv-alert--success" role="status">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
            <?php endif; ?>

            <?php if ($warning): ?>
            <div class="cv-alert cv-alert--warning" role="status">
                <i class="fas fa-clock"></i>
                <span><?= htmlspecialchars($warning) ?></span>
            </div>
            <?php endif; ?>

            <?php if ($error): ?>
            <div class="cv-alert cv-alert--error" role="alert">
                <i class="fas fa-exclamation-triangle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
            <?php endif; ?>

            <?php if ($locked && $_SERVER['REQUEST_METHOD'] !== 'POST'): ?>
            <div class="cv-alert cv-alert--warning" role="alert">
                <i class="fas fa-shield-alt"></i>
                <span>Bloqueio temporário ativo. Aguarde <?= (int) ceil(license_lock_remaining() / 60) ?> minuto(s).</span>
            </div>
            <?php endif; ?>

            <form method="POST" id="loginForm" autocomplete="on" novalidate>
                <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrfToken) ?>">

                <div class="cv-field">
                    <label for="username"><i class="fas fa-user"></i> Usuário</label>
                    <div class="cv-input-wrap">
                        <input
                            type="text"
                            id="username"
                            name="username"
                            value="<?= htmlspecialchars((string) ($_POST['username'] ?? $savedUser)) ?>"
                            placeholder="admin"
                            required
                            autofocus
                            autocomplete="username"
                            <?= $locked ? 'disabled' : '' ?>
                        >
                    </div>
                </div>

                <div class="cv-field">
                    <label for="password"><i class="fas fa-lock"></i> Senha</label>
                    <div class="cv-input-wrap">
                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Sua senha segura"
                            required
                            autocomplete="current-password"
                            <?= $locked ? 'disabled' : '' ?>
                        >
                        <button type="button" class="cv-toggle-pass" id="togglePassword" aria-label="Mostrar senha">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="cv-login-options">
                    <label class="cv-check">
                        <input type="checkbox" name="remember" value="1" <?= $savedUser !== '' ? 'checked' : '' ?>>
                        Lembrar usuário
                    </label>
                    <span class="cv-secure-note"><i class="fas fa-shield-alt"></i> Conexão protegida</span>
                </div>

                <button type="submit" class="cv-btn-login" id="loginSubmit" <?= $locked ? 'disabled' : '' ?>>
                    <i class="fas fa-sign-in-alt"></i>
                    Entrar no License Manager
                </button>
            </form>

            <div class="cv-trust-row">
                <div class="cv-trust-item">
                    <i class="fas fa-user-shield"></i>
                    <span>Sessão segura</span>
                </div>
                <div class="cv-trust-item">
                    <i class="fas fa-ban"></i>
                    <span>Anti brute-force</span>
                </div>
                <div class="cv-trust-item">
                    <i class="fas fa-fingerprint"></i>
                    <span>Validação CSRF</span>
                </div>
            </div>

            <div class="cv-licensor-badge">
                <strong>CENTRALVIX</strong> — Este painel não faz parte do pacote entregue aos clientes finais.
                Mantenha-o apenas no seu ambiente de licenciador.
            </div>

            <div class="cv-login-footer">
                <div class="brand-mark">C E N T R A L V I X</div>
                <p>CentralVix License System &copy; <?= date('Y') ?> · Todos os direitos reservados</p>
            </div>
        </div>
    </section>
</div>

<script src="assets/js/login.js?v=20260616"></script>
</body>
</html>
