# CentralVix — Painel de Licenças (Licenciador)

Este diretório `/license` é **exclusivo do licenciador** (você).

## Para revenda / aluguel do sistema

Ao empacotar o CentralVix para clientes finais:

1. **NÃO inclua** a pasta `license/` no ZIP entregue ao cliente
2. Mantenha este painel apenas em **centralvix.com.br/license** (seu servidor)
3. O cliente recebe o sistema Laravel + validação de licença via API remota

## Acesso

- URL: `https://centralvix.com.br/license/login.php`
- Credenciais padrão: configuradas em `config.php` (`ADMIN_USER` / `ADMIN_PASS`)

## Segurança

- CSRF no login
- Bloqueio após 5 tentativas (15 minutos)
- Sessão com timeout de 8 horas
- Cookie HttpOnly + SameSite Strict

## Marca

Interface com watermark **CENTRALVIX** — identidade visual do licenciador.

© CentralVix 2026
