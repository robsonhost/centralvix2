<?php
// Configuração do Banco de Dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'centralvixcom_teste');
define('DB_USER', 'centralvixcom_teste');
define('DB_PASS', 'me825Ps2pTj2YQWb');

// Credenciais de Admin do Painel de Licenças
define('ADMIN_USER', 'admin');
// Hash fixo da senha: CentralVix@2026!
define('ADMIN_PASS', '$2y$10$uwic05A6996tsZEZ.mownuh0TWBLMXXNgMkT9KF2yEVie0sb7teMa');

// Chave de Criptografia (MUDE ISSO!)
define('ENCRYPTION_KEY', 'cvix_' . md5(__DIR__ . 'salt_2026_secret'));

// Configurações
define('LICENSE_PREFIX', 'CVIX');
define('MAX_ACTIVATION_CHECKS', 1000);
define('CHECK_INTERVAL_HOURS', 24);

// Evolution API (WhatsApp) - lê do .env do Laravel se existir
$envFile = dirname(__DIR__) . '/.env';
if (file_exists($envFile)) {
    $envContent = file_get_contents($envFile);
    preg_match('/EVOLUTION_GO_URL=(.+)/', $envContent, $m1);
    preg_match('/EVOLUTION_GO_API_KEY=(.+)/', $envContent, $m2);
    preg_match('/EVOLUTION_GO_INSTANCE=(.+)/', $envContent, $m3);
    define('EVOLUTION_API_URL', trim($m1[1] ?? 'https://v2.gestaovix.com.br'));
    define('EVOLUTION_API_KEY', trim($m2[1] ?? ''));
    define('EVOLUTION_INSTANCE', trim($m3[1] ?? 'centralvix'));
} else {
    define('EVOLUTION_API_URL', 'https://v2.gestaovix.com.br');
    define('EVOLUTION_API_KEY', '');
    define('EVOLUTION_INSTANCE', 'centralvix');
}

try {
    $db = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}
