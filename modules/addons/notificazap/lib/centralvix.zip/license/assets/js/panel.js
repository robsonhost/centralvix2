/**
 * CentralVix License Manager - Panel JS
 * AJAX + Modals para todas as ações
 */
const LicensePanel = {
    apiUrl: 'api.php',
    licenses: [],
    stats: {},
    charts: { plan: null, status: null },

    init() {
        this.bindNavigation();
        this.bindModals();
        this.bindForms();
        this.loadDashboard();
        this.loadLicenses();

        window.addEventListener('resize', () => {
            if (this.charts.plan) this.charts.plan.resize();
            if (this.charts.status) this.charts.status.resize();
        });
    },

    // ─── API ───────────────────────────────────────────
    async request(action, options = {}) {
        const url = `${this.apiUrl}?action=${action}`;
        const config = {
            method: options.method || 'GET',
            headers: { 'Content-Type': 'application/json' },
        };
        if (options.body) config.body = JSON.stringify(options.body);

        this.showLoading(true);
        try {
            const res = await fetch(url, config);
            const data = await res.json();
            this.showLoading(false);
            if (!data.success && data.message === 'Unauthorized') {
                window.location.href = 'login.php?expired=1';
                return null;
            }
            return data;
        } catch (err) {
            this.showLoading(false);
            this.toast('Erro de conexão com o servidor', 'error');
            return null;
        }
    },

    // ─── Navigation ──────────────────────────────────
    bindNavigation() {
        document.querySelectorAll('[data-page]').forEach(el => {
            el.addEventListener('click', () => this.navigateTo(el.dataset.page));
        });
    },

    navigateTo(page) {
        document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        const section = document.getElementById(`page-${page}`);
        const nav = document.querySelector(`[data-page="${page}"]`);
        if (section) section.classList.add('active');
        if (nav) nav.classList.add('active');
        this.closeMobileMenu();

        switch (page) {
            case 'dashboard': this.loadDashboard(); break;
            case 'licenses': this.loadLicenses(); break;
            case 'activations': this.loadActivations(); break;
            case 'logs': this.loadLogs(); break;
        }
    },

    // ─── Dashboard ───────────────────────────────────
    async loadDashboard() {
        const data = await this.request('get_stats');
        if (!data?.success) return;
        this.stats = data.stats;
        this.updateStatCards(data.stats);
        this.renderCharts(data.stats);
    },

    updateStatCards(s) {
        const map = {
            statTotal: s.total,
            statActive: s.active,
            statExpired: s.expired,
            statSuspended: s.suspended,
        };
        Object.entries(map).forEach(([id, val]) => {
            const el = document.getElementById(id);
            if (el) el.textContent = val ?? 0;
        });
    },

    renderCharts(s) {
        if (typeof Chart === 'undefined') return;

        const planCtx = document.getElementById('planChart');
        const statusCtx = document.getElementById('statusChart');
        if (!planCtx || !statusCtx) return;

        if (this.charts.plan) this.charts.plan.destroy();
        if (this.charts.status) this.charts.status.destroy();

        const chartDefaults = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#8b9cb3', boxWidth: 12, padding: 14, font: { size: 11 } },
                },
            },
        };

        this.charts.plan = new Chart(planCtx, {
            type: 'doughnut',
            data: {
                labels: ['Trial', 'Basic', 'Professional', 'Enterprise', 'Lifetime'],
                datasets: [{
                    data: [s.trial || 0, s.basic || 0, s.professional || 0, s.enterprise || 0, s.lifetime || 0],
                    backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899'],
                    borderWidth: 0,
                    hoverOffset: 6,
                }],
            },
            options: {
                ...chartDefaults,
                cutout: '65%',
                plugins: {
                    ...chartDefaults.plugins,
                    legend: { ...chartDefaults.plugins.legend, position: 'bottom' },
                },
            },
        });

        this.charts.status = new Chart(statusCtx, {
            type: 'bar',
            data: {
                labels: ['Ativas', 'Expiradas', 'Suspensas', 'Canceladas'],
                datasets: [{
                    data: [s.active || 0, s.expired || 0, s.suspended || 0, s.cancelled || 0],
                    backgroundColor: ['#10b981', '#ef4444', '#f59e0b', '#6b7280'],
                    borderRadius: 6,
                    maxBarThickness: 48,
                }],
            },
            options: {
                ...chartDefaults,
                plugins: { legend: { display: false } },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { color: '#8b9cb3', stepSize: 1, font: { size: 11 } },
                        grid: { color: '#2d3f56' },
                    },
                    x: {
                        ticks: { color: '#8b9cb3', font: { size: 11 } },
                        grid: { display: false },
                    },
                },
            },
        });
    },

    // ─── Licenses ────────────────────────────────────
    async loadLicenses() {
        const data = await this.request('list_licenses');
        if (!data?.success) return;
        this.licenses = data.licenses;
        this.renderLicensesTable(this.licenses);
    },

    filterLicenses() {
        const search = (document.getElementById('searchLicenses')?.value || '').toLowerCase();
        const status = document.getElementById('filterStatus')?.value || '';
        const plan = document.getElementById('filterPlan')?.value || '';

        const filtered = this.licenses.filter(l => {
            const matchSearch = !search ||
                l.client_name.toLowerCase().includes(search) ||
                l.client_email.toLowerCase().includes(search) ||
                l.license_key.toLowerCase().includes(search) ||
                (l.domain || '').toLowerCase().includes(search);
            const matchStatus = !status || l.status === status;
            const matchPlan = !plan || l.plan_type === plan;
            return matchSearch && matchStatus && matchPlan;
        });
        this.renderLicensesTable(filtered);
    },

    renderLicensesTable(licenses) {
        const tbody = document.getElementById('licensesTableBody');
        if (!tbody) return;

        if (!licenses.length) {
            tbody.innerHTML = `<tr><td colspan="7" class="empty-state"><i class="fas fa-key"></i><p>Nenhuma licença encontrada</p></td></tr>`;
            return;
        }

        tbody.innerHTML = licenses.map(l => `
            <tr>
                <td>
                    <strong>${this.esc(l.client_name)}</strong><br>
                    <small style="color:var(--text-secondary)">${this.esc(l.client_email)}</small>
                </td>
                <td><span class="license-key" onclick="LicensePanel.copyKey('${this.esc(l.license_key)}')" title="Clique para copiar">${this.esc(l.license_key)}</span></td>
                <td>${this.esc(l.domain || l.ip_address || '-')}</td>
                <td><span class="badge badge-${l.plan_type}">${l.plan_type.toUpperCase()}</span></td>
                <td><span class="badge badge-${l.status}">${l.status.toUpperCase()}</span></td>
                <td>${l.expires_at ? this.formatDate(l.expires_at) : '<span style="color:var(--success)">Vitalícia</span>'}</td>
                <td>
                    <div class="action-btns">
                        <button class="btn btn-ghost btn-sm btn-icon" onclick="LicensePanel.viewLicense(${l.id})" title="Visualizar"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-ghost btn-sm btn-icon" onclick="LicensePanel.editLicense(${l.id})" title="Editar"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-ghost btn-sm btn-icon" onclick="LicensePanel.openRenewModal(${l.id})" title="Renovar"><i class="fas fa-redo"></i></button>
                        <button class="btn btn-ghost btn-sm btn-icon" onclick="LicensePanel.openWhatsAppModal(${l.id})" title="WhatsApp"><i class="fab fa-whatsapp" style="color:#25d366"></i></button>
                        ${l.status === 'active'
                            ? `<button class="btn btn-ghost btn-sm btn-icon" onclick="LicensePanel.openStatusModal(${l.id},'suspend')" title="Suspender"><i class="fas fa-pause" style="color:var(--warning)"></i></button>`
                            : `<button class="btn btn-ghost btn-sm btn-icon" onclick="LicensePanel.openStatusModal(${l.id},'activate')" title="Ativar"><i class="fas fa-play" style="color:var(--success)"></i></button>`
                        }
                        <button class="btn btn-ghost btn-sm btn-icon" onclick="LicensePanel.openDeleteModal(${l.id})" title="Excluir"><i class="fas fa-trash" style="color:var(--danger)"></i></button>
                    </div>
                </td>
            </tr>
        `).join('');
    },

    // ─── View License ────────────────────────────────
    async viewLicense(id) {
        const data = await this.request(`get_license&id=${id}`);
        if (!data?.success) return;
        const l = data.license;

        document.getElementById('viewModalBody').innerHTML = `
            <div class="detail-grid">
                <div class="detail-item"><label>Cliente</label><div class="value">${this.esc(l.client_name)}</div></div>
                <div class="detail-item"><label>E-mail</label><div class="value">${this.esc(l.client_email)}</div></div>
                <div class="detail-item detail-full"><label>Chave da Licença</label><div class="value"><span class="license-key" onclick="LicensePanel.copyKey('${this.esc(l.license_key)}')">${this.esc(l.license_key)}</span></div></div>
                <div class="detail-item"><label>Domínio</label><div class="value">${this.esc(l.domain || 'Qualquer')}</div></div>
                <div class="detail-item"><label>IP</label><div class="value">${this.esc(l.ip_address || 'Qualquer')}</div></div>
                <div class="detail-item"><label>Plano</label><div class="value"><span class="badge badge-${l.plan_type}">${l.plan_type.toUpperCase()}</span></div></div>
                <div class="detail-item"><label>Status</label><div class="value"><span class="badge badge-${l.status}">${l.status.toUpperCase()}</span></div></div>
                <div class="detail-item"><label>Max Clientes</label><div class="value">${l.max_clients == 0 ? 'Ilimitado' : l.max_clients}</div></div>
                <div class="detail-item"><label>Max Serviços</label><div class="value">${l.max_services == 0 ? 'Ilimitado' : l.max_services}</div></div>
                <div class="detail-item"><label>Criada em</label><div class="value">${this.formatDate(l.issued_at)}</div></div>
                <div class="detail-item"><label>Expira em</label><div class="value">${l.expires_at ? this.formatDate(l.expires_at) : 'Nunca (Vitalícia)'}</div></div>
                <div class="detail-item"><label>Última Verificação</label><div class="value">${l.last_check ? this.formatDate(l.last_check) : 'Nunca'}</div></div>
                <div class="detail-item"><label>Verificações</label><div class="value">${l.check_count || 0}</div></div>
                ${l.notes ? `<div class="detail-item detail-full"><label>Notas</label><div class="value">${this.esc(l.notes)}</div></div>` : ''}
            </div>
        `;
        this.openModal('viewModal');
    },

    // ─── Edit License ────────────────────────────────
    async editLicense(id) {
        const data = await this.request(`get_license&id=${id}`);
        if (!data?.success) return;
        const l = data.license;

        document.getElementById('editLicenseId').value = l.id;
        document.getElementById('editClientName').value = l.client_name;
        document.getElementById('editClientEmail').value = l.client_email;
        document.getElementById('editDomain').value = l.domain || '';
        document.getElementById('editIp').value = l.ip_address || '';
        document.getElementById('editPlanType').value = l.plan_type;
        document.getElementById('editMaxClients').value = l.max_clients;
        document.getElementById('editMaxServices').value = l.max_services;
        document.getElementById('editNotes').value = l.notes || '';
        this.openModal('editModal');
    },

    async saveEdit() {
        const body = {
            id: document.getElementById('editLicenseId').value,
            client_name: document.getElementById('editClientName').value,
            client_email: document.getElementById('editClientEmail').value,
            domain: document.getElementById('editDomain').value,
            ip_address: document.getElementById('editIp').value,
            plan_type: document.getElementById('editPlanType').value,
            max_clients: document.getElementById('editMaxClients').value,
            max_services: document.getElementById('editMaxServices').value,
            notes: document.getElementById('editNotes').value,
        };

        const data = await this.request('update_license', { method: 'POST', body });
        if (data?.success) {
            this.closeModal('editModal');
            this.toast('Licença atualizada com sucesso!', 'success');
            this.loadLicenses();
            this.loadDashboard();
        } else {
            this.toast(data?.message || 'Erro ao atualizar', 'error');
        }
    },

    // ─── Create License ──────────────────────────────
    bindForms() {
        document.getElementById('createForm')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.createLicense();
        });

        document.getElementById('searchLicenses')?.addEventListener('input', () => this.filterLicenses());
        document.getElementById('filterStatus')?.addEventListener('change', () => this.filterLicenses());
        document.getElementById('filterPlan')?.addEventListener('change', () => this.filterLicenses());

        document.getElementById('editPlanType')?.addEventListener('change', (e) => {
            const days = document.getElementById('createValidityDays');
            if (days) days.disabled = e.target.value === 'lifetime';
        });
        document.getElementById('createPlanType')?.addEventListener('change', (e) => {
            const days = document.getElementById('createValidityDays');
            if (days) {
                days.disabled = e.target.value === 'lifetime';
                if (e.target.value === 'trial') days.value = 30;
                else if (e.target.value === 'lifetime') days.value = 0;
                else days.value = 365;
            }
        });
    },

    async createLicense() {
        const body = {
            client_name: document.getElementById('createClientName').value,
            client_email: document.getElementById('createClientEmail').value,
            client_whatsapp: document.getElementById('createWhatsapp').value,
            domain: document.getElementById('createDomain').value,
            ip_address: document.getElementById('createIp').value,
            plan_type: document.getElementById('createPlanType').value,
            validity_days: parseInt(document.getElementById('createValidityDays').value) || 365,
            max_clients: parseInt(document.getElementById('createMaxClients').value) || 0,
            max_services: parseInt(document.getElementById('createMaxServices').value) || 0,
            notes: document.getElementById('createNotes').value,
            send_whatsapp: document.getElementById('createSendWhatsapp')?.checked || false,
        };

        const data = await this.request('generate_license', { method: 'POST', body });
        if (data?.success) {
            this.closeModal('createModal');
            this.showSuccessModal(data.license_key, data.license);
            document.getElementById('createForm').reset();
            this.loadLicenses();
            this.loadDashboard();
        } else {
            this.toast(data?.message || 'Erro ao gerar licença', 'error');
        }
    },

    showSuccessModal(key, license) {
        document.getElementById('successKey').textContent = key;
        document.getElementById('successClient').textContent = license?.client_name || '';
        document.getElementById('successEmail').textContent = license?.client_email || '';
        this.openModal('successModal');
    },

    // ─── Status Change ───────────────────────────────
    openStatusModal(id, action) {
        document.getElementById('statusLicenseId').value = id;
        document.getElementById('statusAction').value = action;
        const titles = { suspend: 'Suspender Licença', activate: 'Ativar Licença', cancel: 'Cancelar Licença' };
        const msgs = {
            suspend: 'Tem certeza que deseja <strong>suspender</strong> esta licença? O cliente não poderá mais utilizá-la.',
            activate: 'Deseja <strong>reativar</strong> esta licença?',
            cancel: 'Deseja <strong>cancelar</strong> permanentemente esta licença?',
        };
        document.getElementById('statusModalTitle').textContent = titles[action] || 'Alterar Status';
        document.getElementById('statusModalMsg').innerHTML = msgs[action] || '';
        document.getElementById('statusConfirmBtn').className = action === 'activate' ? 'btn btn-success' : 'btn btn-warning';
        this.openModal('statusModal');
    },

    async confirmStatusChange() {
        const body = {
            id: document.getElementById('statusLicenseId').value,
            action: document.getElementById('statusAction').value,
        };
        const data = await this.request('change_status', { method: 'POST', body });
        if (data?.success) {
            this.closeModal('statusModal');
            this.toast('Status alterado com sucesso!', 'success');
            this.loadLicenses();
            this.loadDashboard();
        } else {
            this.toast(data?.message || 'Erro', 'error');
        }
    },

    // ─── Renew ───────────────────────────────────────
    openRenewModal(id) {
        document.getElementById('renewLicenseId').value = id;
        document.getElementById('renewDays').value = 365;
        this.openModal('renewModal');
    },

    async confirmRenew() {
        const body = {
            id: document.getElementById('renewLicenseId').value,
            days: parseInt(document.getElementById('renewDays').value) || 365,
        };
        const data = await this.request('renew_license', { method: 'POST', body });
        if (data?.success) {
            this.closeModal('renewModal');
            this.toast(`Licença renovada até ${this.formatDate(data.expires_at)}`, 'success');
            this.loadLicenses();
        } else {
            this.toast(data?.message || 'Erro ao renovar', 'error');
        }
    },

    // ─── Delete ──────────────────────────────────────
    openDeleteModal(id) {
        document.getElementById('deleteLicenseId').value = id;
        this.openModal('deleteModal');
    },

    async confirmDelete() {
        const body = { id: document.getElementById('deleteLicenseId').value };
        const data = await this.request('delete_license', { method: 'POST', body });
        if (data?.success) {
            this.closeModal('deleteModal');
            this.toast('Licença excluída', 'success');
            this.loadLicenses();
            this.loadDashboard();
        } else {
            this.toast(data?.message || 'Erro ao excluir', 'error');
        }
    },

    // ─── WhatsApp ────────────────────────────────────
    async openWhatsAppModal(id) {
        const data = await this.request(`get_license&id=${id}`);
        if (!data?.success) return;
        const l = data.license;
        document.getElementById('waLicenseId').value = l.id;
        document.getElementById('waPhone').value = l.client_whatsapp || '';
        document.getElementById('waPreview').textContent = this.buildWhatsAppMessage(l);
        this.openModal('whatsappModal');
    },

    buildWhatsAppMessage(l) {
        return `🔐 *CentralVix - Sua Licença*\n\n` +
            `Olá *${l.client_name}*!\n\n` +
            `Sua licença foi gerada com sucesso:\n\n` +
            `🔑 *Chave:* ${l.license_key}\n` +
            `📦 *Plano:* ${l.plan_type.toUpperCase()}\n` +
            `📅 *Validade:* ${l.expires_at ? this.formatDate(l.expires_at) : 'Vitalícia'}\n` +
            `${l.domain ? `🌐 *Domínio:* ${l.domain}\n` : ''}` +
            `\nAcesse o sistema e insira sua chave de licença.\n\n` +
            `_CentralVix License System_`;
    },

    async sendWhatsApp() {
        const body = {
            id: document.getElementById('waLicenseId').value,
            phone: document.getElementById('waPhone').value,
            message: document.getElementById('waPreview').textContent,
        };
        if (!body.phone) {
            this.toast('Informe o número do WhatsApp', 'warning');
            return;
        }
        const data = await this.request('send_whatsapp', { method: 'POST', body });
        if (data?.success) {
            this.closeModal('whatsappModal');
            this.toast('Mensagem enviada via WhatsApp!', 'success');
        } else {
            this.toast(data?.message || 'Erro ao enviar WhatsApp', 'error');
        }
    },

    // ─── Activations & Logs ──────────────────────────
    async loadActivations() {
        const data = await this.request('list_activations');
        const container = document.getElementById('activationsContent');
        if (!container) return;
        if (!data?.success || !data.activations?.length) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-server"></i><p>Nenhuma ativação ativa</p></div>';
            return;
        }
        container.innerHTML = `<div class="panel-body"><table class="data-table"><thead><tr>
            <th>Cliente</th><th>Licença</th><th>Domínio</th><th>IP</th><th>PHP</th><th>Último Acesso</th>
        </tr></thead><tbody>${data.activations.map(a => `
            <tr>
                <td>${this.esc(a.client_name)}</td>
                <td><span class="license-key">${this.esc(a.license_key)}</span></td>
                <td>${this.esc(a.domain || '-')}</td>
                <td>${this.esc(a.ip_address || '-')}</td>
                <td>${this.esc(a.php_version || '-')}</td>
                <td>${a.last_seen ? this.formatDate(a.last_seen) : '-'}</td>
            </tr>
        `).join('')}</tbody></table></div>`;
    },

    async loadLogs() {
        const data = await this.request('list_logs');
        const container = document.getElementById('logsContent');
        if (!container) return;
        if (!data?.success || !data.logs?.length) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-list"></i><p>Nenhum log encontrado</p></div>';
            return;
        }
        const statusClass = { success: 'badge-active', failed: 'badge-expired', blocked: 'badge-suspended' };
        container.innerHTML = `<div class="panel-body"><table class="data-table"><thead><tr>
            <th>Data/Hora</th><th>Cliente</th><th>Tipo</th><th>Status</th><th>Domínio/IP</th><th>Mensagem</th>
        </tr></thead><tbody>${data.logs.map(log => `
            <tr>
                <td>${this.formatDate(log.checked_at)}</td>
                <td>${this.esc(log.client_name)}</td>
                <td>${this.esc(log.check_type)}</td>
                <td><span class="badge ${statusClass[log.status] || ''}">${log.status}</span></td>
                <td>${this.esc(log.domain || log.ip_address || '-')}</td>
                <td style="color:var(--text-secondary)">${this.esc(log.error_message || 'OK')}</td>
            </tr>
        `).join('')}</tbody></table></div>`;
    },

    // ─── Modals ──────────────────────────────────────
    bindModals() {
        document.querySelectorAll('[data-close-modal]').forEach(el => {
            el.addEventListener('click', () => this.closeModal(el.dataset.closeModal));
        });
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) this.closeModal(overlay.id);
            });
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal-overlay.active').forEach(m => this.closeModal(m.id));
                this.closeMobileMenu();
            }
        });

        document.getElementById('mobileMenuBtn')?.addEventListener('click', () => this.toggleMobileMenu());
        document.getElementById('sidebarOverlay')?.addEventListener('click', () => this.closeMobileMenu());
    },

    toggleMobileMenu() {
        document.querySelector('.sidebar')?.classList.toggle('mobile-open');
        document.getElementById('sidebarOverlay')?.classList.toggle('active');
    },

    closeMobileMenu() {
        document.querySelector('.sidebar')?.classList.remove('mobile-open');
        document.getElementById('sidebarOverlay')?.classList.remove('active');
    },

    openModal(id) {
        document.getElementById(id)?.classList.add('active');
        document.body.style.overflow = 'hidden';
    },

    closeModal(id) {
        document.getElementById(id)?.classList.remove('active');
        if (!document.querySelector('.modal-overlay.active')) {
            document.body.style.overflow = '';
        }
    },

    // ─── Utilities ───────────────────────────────────
    showLoading(show) {
        document.getElementById('loadingOverlay')?.classList.toggle('active', show);
    },

    toast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        if (!container) return;
        const icons = { success: 'check-circle', error: 'exclamation-circle', warning: 'exclamation-triangle', info: 'info-circle' };
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `<i class="fas fa-${icons[type]}"></i> ${message}`;
        container.appendChild(toast);
        setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 4000);
    },

    copyKey(key) {
        navigator.clipboard.writeText(key).then(() => this.toast('Chave copiada!', 'success'));
    },

    copySuccessKey() {
        const key = document.getElementById('successKey')?.textContent;
        if (key) this.copyKey(key);
    },

    formatDate(d) {
        if (!d) return '-';
        const dt = new Date(d);
        return dt.toLocaleDateString('pt-BR') + ' ' + dt.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    },

    esc(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    },
};

document.addEventListener('DOMContentLoaded', () => LicensePanel.init());
