<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';

license_require_auth();

$welcomeFlash = !empty($_SESSION['welcome_flash']);
unset($_SESSION['welcome_flash']);
$adminUser = (string) ($_SESSION['license_user'] ?? 'admin');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CentralVix License Manager</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/panel.css?v=20260616">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>

<div class="cv-panel-watermark" aria-hidden="true">CENTRALVIX</div>

<div class="mobile-header">
    <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="Menu"><i class="fas fa-bars"></i></button>
    <span class="brand"><i class="fas fa-shield-halved"></i> CENTRALVIX</span>
    <div style="width:40px"></div>
</div>
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-brand">
            <h1><i class="fas fa-shield-halved"></i> CENTRALVIX</h1>
            <p>License Manager Pro</p>
            <div class="sidebar-licensor-tag">Painel do Licenciador</div>
        </div>
        <nav class="sidebar-nav">
            <button class="nav-item active" data-page="dashboard"><i class="fas fa-chart-line"></i><span>Dashboard</span></button>
            <button class="nav-item" data-page="licenses"><i class="fas fa-key"></i><span>Licenças</span></button>
            <button class="nav-item" data-page="activations"><i class="fas fa-server"></i><span>Ativações</span></button>
            <button class="nav-item" data-page="logs"><i class="fas fa-list-alt"></i><span>Logs</span></button>
        </nav>
        <div class="sidebar-footer">
            <div class="sidebar-user">
                <i class="fas fa-user-circle"></i>
                <div>
                    <strong><?= htmlspecialchars($adminUser) ?></strong>
                    <span>Sessão ativa</span>
                </div>
            </div>
            <a href="logout.php" class="btn btn-danger" style="width:100%;justify-content:center">
                <i class="fas fa-sign-out-alt"></i> Sair
            </a>
            <div class="sidebar-brand-mark">CENTRALVIX</div>
        </div>
    </aside>

    <!-- Main -->
    <main class="main-content">

        <!-- DASHBOARD -->
        <section id="page-dashboard" class="page-section active">
            <div class="page-header">
                <h2><i class="fas fa-chart-line" style="color:var(--accent)"></i> Dashboard</h2>
                <button class="btn btn-primary" onclick="LicensePanel.openModal('createModal')">
                    <i class="fas fa-plus"></i> Nova Licença
                </button>
            </div>

            <div class="stats-grid">
                <div class="stat-card info">
                    <div class="label">Total</div>
                    <div class="value" id="statTotal">0</div>
                    <i class="fas fa-key icon"></i>
                </div>
                <div class="stat-card success">
                    <div class="label">Ativas</div>
                    <div class="value" id="statActive">0</div>
                    <i class="fas fa-check-circle icon"></i>
                </div>
                <div class="stat-card danger">
                    <div class="label">Expiradas</div>
                    <div class="value" id="statExpired">0</div>
                    <i class="fas fa-exclamation-triangle icon"></i>
                </div>
                <div class="stat-card warning">
                    <div class="label">Suspensas</div>
                    <div class="value" id="statSuspended">0</div>
                    <i class="fas fa-pause-circle icon"></i>
                </div>
            </div>

            <div class="charts-row">
                <div class="chart-panel">
                    <h3><i class="fas fa-chart-pie"></i> Licenças por Plano</h3>
                    <div class="chart-wrap">
                        <canvas id="planChart"></canvas>
                    </div>
                </div>
                <div class="chart-panel">
                    <h3><i class="fas fa-chart-bar"></i> Status das Licenças</h3>
                    <div class="chart-wrap">
                        <canvas id="statusChart"></canvas>
                    </div>
                </div>
            </div>
        </section>

        <!-- LICENSES -->
        <section id="page-licenses" class="page-section">
            <div class="page-header">
                <h2><i class="fas fa-key" style="color:var(--accent)"></i> Licenças</h2>
                <button class="btn btn-primary" onclick="LicensePanel.openModal('createModal')">
                    <i class="fas fa-plus"></i> Gerar Licença
                </button>
            </div>

            <div class="panel">
                <div class="panel-header">
                    <div class="toolbar">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchLicenses" placeholder="Buscar por cliente, e-mail, chave ou domínio...">
                        </div>
                        <select id="filterStatus" class="filter-select">
                            <option value="">Todos os Status</option>
                            <option value="active">Ativas</option>
                            <option value="expired">Expiradas</option>
                            <option value="suspended">Suspensas</option>
                            <option value="cancelled">Canceladas</option>
                        </select>
                        <select id="filterPlan" class="filter-select">
                            <option value="">Todos os Planos</option>
                            <option value="trial">Trial</option>
                            <option value="basic">Basic</option>
                            <option value="professional">Professional</option>
                            <option value="enterprise">Enterprise</option>
                            <option value="lifetime">Lifetime</option>
                        </select>
                        <button class="btn btn-ghost" onclick="LicensePanel.loadLicenses()">
                            <i class="fas fa-sync-alt"></i> Atualizar
                        </button>
                    </div>
                </div>
                <div class="panel-body" style="overflow-x:auto">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Cliente</th>
                                <th>Chave</th>
                                <th>Domínio/IP</th>
                                <th>Plano</th>
                                <th>Status</th>
                                <th>Expira</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody id="licensesTableBody">
                            <tr><td colspan="7" class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Carregando...</p></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <!-- ACTIVATIONS -->
        <section id="page-activations" class="page-section">
            <div class="page-header">
                <h2><i class="fas fa-server" style="color:var(--accent)"></i> Ativações Ativas</h2>
            </div>
            <div class="panel" id="activationsContent">
                <div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Carregando...</p></div>
            </div>
        </section>

        <!-- LOGS -->
        <section id="page-logs" class="page-section">
            <div class="page-header">
                <h2><i class="fas fa-list-alt" style="color:var(--accent)"></i> Logs de Validação</h2>
            </div>
            <div class="panel" id="logsContent">
                <div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Carregando...</p></div>
            </div>
        </section>

    </main>
</div>

<!-- ═══ MODAL: Criar Licença ═══ -->
<div class="modal-overlay" id="createModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <h3><i class="fas fa-plus-circle" style="color:var(--accent)"></i> Gerar Nova Licença</h3>
            <button class="modal-close" data-close-modal="createModal"><i class="fas fa-times"></i></button>
        </div>
        <form id="createForm">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Nome do Cliente <span class="required">*</span></label>
                        <input type="text" id="createClientName" class="form-control" required placeholder="João da Silva">
                    </div>
                    <div class="form-group">
                        <label>E-mail <span class="required">*</span></label>
                        <input type="email" id="createClientEmail" class="form-control" required placeholder="cliente@email.com">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>WhatsApp</label>
                        <input type="text" id="createWhatsapp" class="form-control" placeholder="27999999999">
                        <div class="form-hint">Para envio automático da licença</div>
                    </div>
                    <div class="form-group">
                        <label>Plano</label>
                        <select id="createPlanType" class="form-control">
                            <option value="trial">Trial (30 dias)</option>
                            <option value="basic">Basic</option>
                            <option value="professional" selected>Professional</option>
                            <option value="enterprise">Enterprise</option>
                            <option value="lifetime">Lifetime (Vitalícia)</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Domínio</label>
                        <input type="text" id="createDomain" class="form-control" placeholder="exemplo.com.br">
                        <div class="form-hint">Vazio = qualquer domínio</div>
                    </div>
                    <div class="form-group">
                        <label>IP</label>
                        <input type="text" id="createIp" class="form-control" placeholder="192.168.1.1">
                        <div class="form-hint">Vazio = qualquer IP</div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Validade (dias)</label>
                        <input type="number" id="createValidityDays" class="form-control" value="365" min="0">
                    </div>
                    <div class="form-group">
                        <label>Max Clientes</label>
                        <input type="number" id="createMaxClients" class="form-control" value="0" min="0">
                        <div class="form-hint">0 = ilimitado</div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Max Serviços</label>
                        <input type="number" id="createMaxServices" class="form-control" value="0" min="0">
                        <div class="form-hint">0 = ilimitado</div>
                    </div>
                    <div class="form-group" style="display:flex;align-items:flex-end">
                        <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                            <input type="checkbox" id="createSendWhatsapp" checked>
                            Enviar licença via WhatsApp
                        </label>
                    </div>
                </div>
                <div class="form-group">
                    <label>Notas</label>
                    <textarea id="createNotes" class="form-control" rows="2" placeholder="Observações internas..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" data-close-modal="createModal">Cancelar</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-key"></i> Gerar Licença</button>
            </div>
        </form>
    </div>
</div>

<!-- ═══ MODAL: Visualizar ═══ -->
<div class="modal-overlay" id="viewModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <h3><i class="fas fa-eye" style="color:var(--accent)"></i> Detalhes da Licença</h3>
            <button class="modal-close" data-close-modal="viewModal"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body" id="viewModalBody"></div>
        <div class="modal-footer">
            <button class="btn btn-ghost" data-close-modal="viewModal">Fechar</button>
        </div>
    </div>
</div>

<!-- ═══ MODAL: Editar ═══ -->
<div class="modal-overlay" id="editModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <h3><i class="fas fa-edit" style="color:var(--warning)"></i> Editar Licença</h3>
            <button class="modal-close" data-close-modal="editModal"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="editLicenseId">
            <div class="form-row">
                <div class="form-group">
                    <label>Nome do Cliente <span class="required">*</span></label>
                    <input type="text" id="editClientName" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>E-mail <span class="required">*</span></label>
                    <input type="email" id="editClientEmail" class="form-control" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Domínio</label>
                    <input type="text" id="editDomain" class="form-control">
                </div>
                <div class="form-group">
                    <label>IP</label>
                    <input type="text" id="editIp" class="form-control">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Plano</label>
                    <select id="editPlanType" class="form-control">
                        <option value="trial">Trial</option>
                        <option value="basic">Basic</option>
                        <option value="professional">Professional</option>
                        <option value="enterprise">Enterprise</option>
                        <option value="lifetime">Lifetime</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Max Clientes</label>
                    <input type="number" id="editMaxClients" class="form-control" min="0">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Max Serviços</label>
                    <input type="number" id="editMaxServices" class="form-control" min="0">
                </div>
            </div>
            <div class="form-group">
                <label>Notas</label>
                <textarea id="editNotes" class="form-control" rows="2"></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" data-close-modal="editModal">Cancelar</button>
            <button class="btn btn-primary" onclick="LicensePanel.saveEdit()"><i class="fas fa-save"></i> Salvar</button>
        </div>
    </div>
</div>

<!-- ═══ MODAL: Sucesso (Licença Gerada) ═══ -->
<div class="modal-overlay" id="successModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-check-circle" style="color:var(--success)"></i> Licença Gerada!</h3>
            <button class="modal-close" data-close-modal="successModal"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body" style="text-align:center">
            <div style="font-size:3rem;color:var(--success);margin-bottom:16px"><i class="fas fa-key"></i></div>
            <p style="color:var(--text-secondary);margin-bottom:8px">Licença criada para <strong id="successClient"></strong></p>
            <p style="color:var(--text-secondary);margin-bottom:20px" id="successEmail"></p>
            <div class="license-key" id="successKey" style="font-size:1.1rem;padding:12px 20px;display:inline-block;cursor:pointer" onclick="LicensePanel.copySuccessKey()" title="Clique para copiar"></div>
            <p style="color:var(--text-secondary);font-size:0.8rem;margin-top:12px"><i class="fas fa-copy"></i> Clique na chave para copiar</p>
        </div>
        <div class="modal-footer" style="justify-content:center">
            <button class="btn btn-primary" onclick="LicensePanel.copySuccessKey()"><i class="fas fa-copy"></i> Copiar Chave</button>
            <button class="btn btn-ghost" data-close-modal="successModal">Fechar</button>
        </div>
    </div>
</div>

<!-- ═══ MODAL: Alterar Status ═══ -->
<div class="modal-overlay" id="statusModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="statusModalTitle">Alterar Status</h3>
            <button class="modal-close" data-close-modal="statusModal"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="statusLicenseId">
            <input type="hidden" id="statusAction">
            <p id="statusModalMsg" style="color:var(--text-secondary)"></p>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" data-close-modal="statusModal">Cancelar</button>
            <button class="btn btn-warning" id="statusConfirmBtn" onclick="LicensePanel.confirmStatusChange()">Confirmar</button>
        </div>
    </div>
</div>

<!-- ═══ MODAL: Renovar ═══ -->
<div class="modal-overlay" id="renewModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-redo" style="color:var(--success)"></i> Renovar Licença</h3>
            <button class="modal-close" data-close-modal="renewModal"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="renewLicenseId">
            <div class="form-group">
                <label>Adicionar dias de validade</label>
                <input type="number" id="renewDays" class="form-control" value="365" min="1">
                <div class="form-hint">A nova data será calculada a partir da expiração atual (ou hoje, se já expirou)</div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" data-close-modal="renewModal">Cancelar</button>
            <button class="btn btn-success" onclick="LicensePanel.confirmRenew()"><i class="fas fa-redo"></i> Renovar</button>
        </div>
    </div>
</div>

<!-- ═══ MODAL: Excluir ═══ -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-trash" style="color:var(--danger)"></i> Excluir Licença</h3>
            <button class="modal-close" data-close-modal="deleteModal"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="deleteLicenseId">
            <p style="color:var(--text-secondary)">Tem certeza que deseja <strong style="color:var(--danger)">excluir permanentemente</strong> esta licença? Esta ação não pode ser desfeita.</p>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" data-close-modal="deleteModal">Cancelar</button>
            <button class="btn btn-danger" onclick="LicensePanel.confirmDelete()"><i class="fas fa-trash"></i> Excluir</button>
        </div>
    </div>
</div>

<!-- ═══ MODAL: WhatsApp ═══ -->
<div class="modal-overlay" id="whatsappModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fab fa-whatsapp" style="color:#25d366"></i> Enviar via WhatsApp</h3>
            <button class="modal-close" data-close-modal="whatsappModal"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="waLicenseId">
            <div class="form-group">
                <label>Número WhatsApp</label>
                <input type="text" id="waPhone" class="form-control" placeholder="27999999999">
                <div class="form-hint">Com DDD, sem espaços. Ex: 27999999999</div>
            </div>
            <div class="form-group">
                <label>Pré-visualização da Mensagem</label>
                <pre id="waPreview" style="background:var(--bg-secondary);border:1px solid var(--border);border-radius:8px;padding:14px;font-size:0.85rem;white-space:pre-wrap;color:var(--text-secondary)"></pre>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" data-close-modal="whatsappModal">Cancelar</button>
            <button class="btn btn-success" onclick="LicensePanel.sendWhatsApp()" style="background:#25d366">
                <i class="fab fa-whatsapp"></i> Enviar
            </button>
        </div>
    </div>
</div>

<!-- Loading & Toast -->
<div class="loading-overlay" id="loadingOverlay"><div class="spinner"></div></div>
<div class="toast-container" id="toastContainer"></div>

<script src="assets/js/panel.js?v=20260616"></script>
<?php if ($welcomeFlash): ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    if (typeof LicensePanel !== 'undefined') {
        LicensePanel.toast('Bem-vindo ao CentralVix License Manager!', 'success');
    }
});
</script>
<?php endif; ?>
</body>
</html>
