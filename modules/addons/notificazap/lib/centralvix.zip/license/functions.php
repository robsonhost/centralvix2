<?php

function generateLicenseKey(): string
{
    $parts = [
        LICENSE_PREFIX,
        strtoupper(bin2hex(random_bytes(4))),
        strtoupper(bin2hex(random_bytes(4))),
        strtoupper(bin2hex(random_bytes(4))),
    ];
    return implode('-', $parts);
}

function getLicenseStats(PDO $db): array
{
    $stmt = $db->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) as expired,
            SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
            SUM(CASE WHEN plan_type = 'trial' THEN 1 ELSE 0 END) as trial,
            SUM(CASE WHEN plan_type = 'basic' THEN 1 ELSE 0 END) as basic,
            SUM(CASE WHEN plan_type = 'professional' THEN 1 ELSE 0 END) as professional,
            SUM(CASE WHEN plan_type = 'enterprise' THEN 1 ELSE 0 END) as enterprise,
            SUM(CASE WHEN plan_type = 'lifetime' THEN 1 ELSE 0 END) as lifetime
        FROM system_licenses
    ");

    return $stmt->fetch() ?: [];
}

function getAllLicenses(PDO $db): array
{
    $stmt = $db->query("SELECT * FROM system_licenses ORDER BY created_at DESC");
    return $stmt->fetchAll();
}

function getLicenseById(PDO $db, int $id): ?array
{
    $stmt = $db->prepare("SELECT * FROM system_licenses WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $id]);
    $license = $stmt->fetch();
    return $license ?: null;
}

function createLicense(PDO $db, array $data): array
{
    $licenseKey = generateLicenseKey();

    $expiresAt = null;
    $validityDays = (int) ($data['validity_days'] ?? 365);
    if ($validityDays > 0 && ($data['plan_type'] ?? '') !== 'lifetime') {
        $expiresAt = date('Y-m-d H:i:s', strtotime("+{$validityDays} days"));
    }

    $stmt = $db->prepare("
        INSERT INTO system_licenses 
        (license_key, client_name, client_email, domain, ip_address, max_clients, max_services, plan_type, status, issued_at, expires_at, notes, created_at, updated_at)
        VALUES 
        (:license_key, :client_name, :client_email, :domain, :ip_address, :max_clients, :max_services, :plan_type, 'active', NOW(), :expires_at, :notes, NOW(), NOW())
    ");

    $notes = $data['notes'] ?? '';
    if (!empty($data['client_whatsapp'])) {
        $notes = trim('WhatsApp: ' . $data['client_whatsapp'] . ($notes ? "\n" . $notes : ''));
    }

    $stmt->execute([
        ':license_key' => $licenseKey,
        ':client_name' => $data['client_name'],
        ':client_email' => $data['client_email'],
        ':domain' => !empty($data['domain']) ? $data['domain'] : null,
        ':ip_address' => !empty($data['ip_address']) ? $data['ip_address'] : null,
        ':max_clients' => (int) ($data['max_clients'] ?? 0),
        ':max_services' => (int) ($data['max_services'] ?? 0),
        ':plan_type' => $data['plan_type'] ?? 'trial',
        ':expires_at' => $expiresAt,
        ':notes' => !empty($notes) ? $notes : null,
    ]);

    $id = (int) $db->lastInsertId();
    $license = getLicenseById($db, $id);

    if (!empty($data['send_whatsapp']) && !empty($data['client_whatsapp'])) {
        sendWhatsAppMessage($data['client_whatsapp'], buildWhatsAppLicenseMessage($license));
    }

    return [
        'id' => $id,
        'license_key' => $licenseKey,
        'license' => $license,
    ];
}

function updateLicense(PDO $db, int $id, array $data): bool
{
    $license = getLicenseById($db, $id);
    if (!$license) {
        return false;
    }

    $stmt = $db->prepare("
        UPDATE system_licenses SET
            client_name = :client_name,
            client_email = :client_email,
            domain = :domain,
            ip_address = :ip_address,
            max_clients = :max_clients,
            max_services = :max_services,
            plan_type = :plan_type,
            notes = :notes,
            updated_at = NOW()
        WHERE id = :id
    ");

    return $stmt->execute([
        ':id' => $id,
        ':client_name' => $data['client_name'],
        ':client_email' => $data['client_email'],
        ':domain' => !empty($data['domain']) ? $data['domain'] : null,
        ':ip_address' => !empty($data['ip_address']) ? $data['ip_address'] : null,
        ':max_clients' => (int) ($data['max_clients'] ?? 0),
        ':max_services' => (int) ($data['max_services'] ?? 0),
        ':plan_type' => $data['plan_type'] ?? $license['plan_type'],
        ':notes' => !empty($data['notes']) ? $data['notes'] : null,
    ]);
}

function deleteLicense(PDO $db, int $id): bool
{
    $stmt = $db->prepare("DELETE FROM system_licenses WHERE id = :id");
    return $stmt->execute([':id' => $id]);
}

function changeLicenseStatus(PDO $db, int $id, string $action): bool
{
    $statusMap = [
        'suspend' => 'suspended',
        'activate' => 'active',
        'cancel' => 'cancelled',
        'expire' => 'expired',
    ];

    if (!isset($statusMap[$action])) {
        return false;
    }

    $stmt = $db->prepare("UPDATE system_licenses SET status = :status, updated_at = NOW() WHERE id = :id");
    return $stmt->execute([':id' => $id, ':status' => $statusMap[$action]]);
}

function renewLicense(PDO $db, int $id, int $days): ?string
{
    $license = getLicenseById($db, $id);
    if (!$license) {
        return null;
    }

    $baseDate = ($license['expires_at'] && strtotime($license['expires_at']) > time())
        ? $license['expires_at']
        : date('Y-m-d H:i:s');

    $newExpiry = date('Y-m-d H:i:s', strtotime($baseDate . " +{$days} days"));

    $stmt = $db->prepare("
        UPDATE system_licenses 
        SET expires_at = :expires_at, status = 'active', updated_at = NOW() 
        WHERE id = :id
    ");
    $stmt->execute([':id' => $id, ':expires_at' => $newExpiry]);

    return $newExpiry;
}

function validateLicenseKey(PDO $db, string $licenseKey, ?string $domain = null, ?string $ip = null): array
{
    $stmt = $db->prepare("SELECT * FROM system_licenses WHERE license_key = :license_key LIMIT 1");
    $stmt->execute([':license_key' => $licenseKey]);
    $license = $stmt->fetch();

    if (!$license) {
        return ['valid' => false, 'message' => 'Licença não encontrada'];
    }

    if ($license['status'] !== 'active') {
        logLicenseCheck($db, $license['id'], 'validation', 'blocked', $ip, $domain, 'License not active: ' . $license['status']);
        return ['valid' => false, 'message' => 'Licença ' . $license['status']];
    }

    if ($license['expires_at'] && strtotime($license['expires_at']) < time()) {
        $db->prepare("UPDATE system_licenses SET status = 'expired' WHERE id = :id")->execute([':id' => $license['id']]);
        logLicenseCheck($db, $license['id'], 'validation', 'blocked', $ip, $domain, 'License expired');
        return ['valid' => false, 'message' => 'Licença expirada em ' . $license['expires_at']];
    }

    if ($license['domain'] && $domain && $license['domain'] !== $domain) {
        logLicenseCheck($db, $license['id'], 'validation', 'blocked', $ip, $domain, 'Domain mismatch');
        return ['valid' => false, 'message' => 'Domínio não autorizado'];
    }

    if ($license['ip_address'] && $ip && $license['ip_address'] !== $ip) {
        logLicenseCheck($db, $license['id'], 'validation', 'blocked', $ip, $domain, 'IP mismatch');
        return ['valid' => false, 'message' => 'IP não autorizado'];
    }

    $db->prepare("UPDATE system_licenses SET last_check = NOW(), check_count = check_count + 1 WHERE id = :id")
        ->execute([':id' => $license['id']]);

    logLicenseCheck($db, $license['id'], 'validation', 'success', $ip, $domain, null);

    return ['valid' => true, 'license' => $license, 'message' => 'Licença válida'];
}

function logLicenseCheck(PDO $db, ?int $licenseId, string $checkType, string $status, ?string $ip, ?string $domain, ?string $errorMessage): void
{
    if (!$licenseId) {
        return;
    }

    $stmt = $db->prepare("
        INSERT INTO license_checks 
        (license_id, check_type, status, ip_address, domain, error_message, checked_at)
        VALUES (:license_id, :check_type, :status, :ip_address, :domain, :error_message, NOW())
    ");

    $stmt->execute([
        ':license_id' => $licenseId,
        ':check_type' => $checkType,
        ':status' => $status,
        ':ip_address' => $ip,
        ':domain' => $domain,
        ':error_message' => $errorMessage,
    ]);
}

function getActivations(PDO $db): array
{
    $stmt = $db->query("
        SELECT a.*, l.license_key, l.client_name 
        FROM license_activations a
        JOIN system_licenses l ON a.license_id = l.id
        WHERE a.is_active = 1
        ORDER BY a.last_seen DESC
        LIMIT 50
    ");
    return $stmt->fetchAll();
}

function getLogs(PDO $db, int $limit = 100): array
{
    $stmt = $db->query("
        SELECT c.*, l.license_key, l.client_name 
        FROM license_checks c
        JOIN system_licenses l ON c.license_id = l.id
        ORDER BY c.checked_at DESC
        LIMIT " . intval($limit)
    );
    return $stmt->fetchAll();
}

function getServerInfo(): array
{
    return [
        'hostname' => gethostname(),
        'php_version' => PHP_VERSION,
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'ip' => $_SERVER['SERVER_ADDR'] ?? 'Unknown',
    ];
}

function extractWhatsAppFromNotes(?string $notes): string
{
    if (!$notes || !preg_match('/WhatsApp:\s*(\d+)/', $notes, $m)) {
        return '';
    }
    return $m[1];
}

function enrichLicense(array $license): array
{
    $license['client_whatsapp'] = extractWhatsAppFromNotes($license['notes'] ?? '');
    return $license;
}

function buildWhatsAppLicenseMessage(array $license): string
{
    $expires = $license['expires_at']
        ? date('d/m/Y', strtotime($license['expires_at']))
        : 'Vitalícia';

    $msg = "🔐 *CentralVix - Sua Licença*\n\n";
    $msg .= "Olá *{$license['client_name']}*!\n\n";
    $msg .= "Sua licença foi gerada com sucesso:\n\n";
    $msg .= "🔑 *Chave:* {$license['license_key']}\n";
    $msg .= "📦 *Plano:* " . strtoupper($license['plan_type']) . "\n";
    $msg .= "📅 *Validade:* {$expires}\n";
    if (!empty($license['domain'])) {
        $msg .= "🌐 *Domínio:* {$license['domain']}\n";
    }
    $msg .= "\nAcesse o sistema e insira sua chave de licença.\n\n";
    $msg .= "_CentralVix License System_";

    return $msg;
}

function sendWhatsAppMessage(string $phone, string $message): array
{
    $phone = preg_replace('/\D/', '', $phone);
    if (strlen($phone) < 10) {
        return ['success' => false, 'message' => 'Número de WhatsApp inválido'];
    }

    if (strlen($phone) <= 11) {
        $phone = '55' . $phone;
    }

    if (!defined('EVOLUTION_API_URL') || !defined('EVOLUTION_API_KEY') || !defined('EVOLUTION_INSTANCE')) {
        return ['success' => false, 'message' => 'WhatsApp API não configurada'];
    }

    $url = rtrim(EVOLUTION_API_URL, '/') . '/message/sendText/' . EVOLUTION_INSTANCE;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'apikey: ' . EVOLUTION_API_KEY,
        ],
        CURLOPT_POSTFIELDS => json_encode([
            'number' => $phone,
            'text' => $message,
        ]),
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'message' => 'Erro cURL: ' . $error];
    }

    if ($httpCode >= 200 && $httpCode < 300) {
        return ['success' => true, 'message' => 'Enviado com sucesso'];
    }

    return ['success' => false, 'message' => 'Erro HTTP ' . $httpCode . ': ' . $response];
}

function jsonResponse(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
