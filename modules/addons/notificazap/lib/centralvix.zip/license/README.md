# Painel de Licenças Pro - CentralVix

## Upload (pasta `license/`)

```
license/
├── index.php          ← Painel principal (modais + AJAX)
├── login.php          ← Login profissional
├── api.php            ← API REST (todas as ações)
├── functions.php      ← Lógica de negócio
├── config.php         ← Config + WhatsApp Evolution API
├── logout.php
├── assets/
│   ├── css/panel.css  ← CSS3 customizado
│   └── js/panel.js    ← JavaScript AJAX + Modais
```

## SQL obrigatório

Execute `EXECUTAR-TUDO-FINAL.sql` no phpMyAdmin (cria `system_licenses`).

## Acesso

- URL: `https://seudominio.com/license/`
- Usuário: `admin`
- Senha: `CentralVix@2026!`

## Funcionalidades

### Modais (todas as ações)
| Ação | Modal |
|------|-------|
| Gerar licença | Modal de criação com formulário completo |
| Visualizar | Modal com todos os detalhes |
| Editar | Modal de edição |
| Excluir | Modal de confirmação |
| Suspender/Ativar | Modal de confirmação |
| Renovar | Modal com dias de validade |
| WhatsApp | Modal com preview e envio |
| Sucesso | Modal com chave gerada + copiar |

### AJAX (sem reload de página)
- Listagem de licenças
- Busca e filtros em tempo real
- Dashboard com gráficos Chart.js
- Ativações e logs
- Todas as ações CRUD

### WhatsApp
- Lê credenciais do `.env` do Laravel (Evolution API)
- Envio automático ao gerar licença
- Envio manual via modal
- Preview da mensagem antes de enviar

### Tecnologias
- HTML5 semântico
- CSS3 (variáveis, grid, flexbox, animações, backdrop-filter)
- JavaScript ES6+ (fetch API, async/await)
- Chart.js para gráficos
- Font Awesome 6
