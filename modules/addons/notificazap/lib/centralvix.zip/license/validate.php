<?php
/**
 * CentralVix License Validator
 * ESTE ARQUIVO É PROTEGIDO E OFUSCADO
 * NÃO MODIFIQUE OU O SISTEMA DEIXARÁ DE FUNCIONAR
 */

namespace CentralVix\License;

class Validator {
    private static $__k;
    private static $__db;
    private static $__cache = [];
    
    private static function __init() {
        if (!self::$__db) {
            $__c = require __DIR__ . '/../config/database.php';
            self::$__db = new \PDO(
                "mysql:host={$__c['connections']['mysql']['host']};dbname={$__c['connections']['mysql']['database']};charset=utf8mb4",
                $__c['connections']['mysql']['username'],
                $__c['connections']['mysql']['password'],
                [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION]
            );
        }
    }
    
    public static function check() {
        $__h = md5(__FILE__ . __DIR__);
        
        if (isset(self::$__cache[$__h]) && (time() - self::$__cache[$__h]['time']) < 3600) {
            return self::$__cache[$__h]['valid'];
        }
        
        self::__init();
        
        $__d = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';
        $__i = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';
        
        try {
            $__s = self::$__db->prepare("
                SELECT * FROM system_licenses 
                WHERE (domain = :domain OR ip_address = :ip OR (domain IS NULL AND ip_address IS NULL))
                AND status = 'active'
                AND (expires_at IS NULL OR expires_at > NOW())
                LIMIT 1
            ");
            
            $__s->execute([':domain' => $__d, ':ip' => $__i]);
            $__l = $__s->fetch(\PDO::FETCH_ASSOC);
            
            if (!$__l) {
                self::__fail('LICENSE_NOT_FOUND');
                return false;
            }
            
            // Atualiza heartbeat
            $__u = self::$__db->prepare("UPDATE system_licenses SET last_check = NOW(), check_count = check_count + 1 WHERE id = :id");
            $__u->execute([':id' => $__l['id']]);
            
            // Log check
            $__lc = self::$__db->prepare("INSERT INTO license_checks (license_id, check_type, status, ip_address, domain, checked_at) VALUES (:lid, 'heartbeat', 'success', :ip, :domain, NOW())");
            $__lc->execute([':lid' => $__l['id'], ':ip' => $__i, ':domain' => $__d]);
            
            self::$__cache[$__h] = ['valid' => true, 'time' => time(), 'data' => $__l];
            return true;
            
        } catch (\Exception $e) {
            self::__fail('DB_ERROR: ' . $e->getMessage());
            return false;
        }
    }
    
    public static function getLicense() {
        if (!self::check()) {
            return null;
        }
        
        $__h = md5(__FILE__ . __DIR__);
        return self::$__cache[$__h]['data'] ?? null;
    }
    
    public static function getInfo() {
        $__l = self::getLicense();
        if (!$__l) {
            return [
                'valid' => false,
                'message' => 'Licença inválida ou expirada'
            ];
        }
        
        return [
            'valid' => true,
            'client_name' => $__l['client_name'],
            'plan_type' => $__l['plan_type'],
            'expires_at' => $__l['expires_at'],
            'max_clients' => $__l['max_clients'],
            'max_services' => $__l['max_services'],
            'issued_at' => $__l['issued_at'],
            'status' => $__l['status']
        ];
    }
    
    private static function __fail($reason) {
        if (php_sapi_name() === 'cli') {
            die("\n❌ LICENSE ERROR: " . $reason . "\n\n");
        }
        
        http_response_code(503);
        
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>License Error</title>';
        echo '<style>body{background:#1a1a1a;color:#fff;font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}';
        echo '.box{background:#2d2d2d;padding:3rem;border-radius:1rem;text-align:center;max-width:500px}';
        echo 'h1{color:#ef4444;margin:0 0 1rem}p{color:#9ca3af;line-height:1.6}</style></head><body>';
        echo '<div class="box"><h1>❌ Erro de Licença</h1>';
        echo '<p>Este sistema requer uma licença válida para funcionar.</p>';
        echo '<p>Entre em contato com o suporte: <strong>suporte@centralvix.com.br</strong></p>';
        echo '<p><small>Error Code: ' . htmlspecialchars($reason) . '</small></p></div></body></html>';
        
        exit(1);
    }
}

// Auto-check em cada requisição
if (php_sapi_name() !== 'cli') {
    register_shutdown_function(function() {
        if (!Validator::check()) {
            Validator::__fail('AUTO_CHECK_FAILED');
        }
    });
}
