<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/functions.php';

license_session_start();

header('Content-Type: application/json');

$action = $_GET['action'] ?? $_POST['action'] ?? '';

$protectedActions = [
    'get_stats', 'list_licenses', 'get_license', 'generate_license',
    'update_license', 'delete_license', 'change_status', 'renew_license',
    'send_whatsapp', 'list_activations', 'list_logs',
];

if (in_array($action, $protectedActions, true) && !license_is_logged_in()) {
    jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {

    case 'get_stats':
        jsonResponse(['success' => true, 'stats' => getLicenseStats($db)]);
        break;

    case 'list_licenses':
        jsonResponse(['success' => true, 'licenses' => getAllLicenses($db)]);
        break;

    case 'get_license':
        $id = (int) ($_GET['id'] ?? $input['id'] ?? 0);
        $license = getLicenseById($db, $id);
        if (!$license) {
            jsonResponse(['success' => false, 'message' => 'Licença não encontrada'], 404);
        }
        jsonResponse(['success' => true, 'license' => enrichLicense($license)]);
        break;

    case 'generate_license':
        if (empty($input['client_name']) || empty($input['client_email'])) {
            jsonResponse(['success' => false, 'message' => 'Nome e e-mail são obrigatórios']);
        }
        $result = createLicense($db, $input);
        jsonResponse([
            'success' => true,
            'license_key' => $result['license_key'],
            'license_id' => $result['id'],
            'license' => enrichLicense($result['license']),
        ]);
        break;

    case 'update_license':
        $id = (int) ($input['id'] ?? 0);
        if (!$id || empty($input['client_name']) || empty($input['client_email'])) {
            jsonResponse(['success' => false, 'message' => 'Dados inválidos']);
        }
        $ok = updateLicense($db, $id, $input);
        jsonResponse($ok
            ? ['success' => true, 'message' => 'Licença atualizada']
            : ['success' => false, 'message' => 'Licença não encontrada']
        );
        break;

    case 'delete_license':
        $id = (int) ($input['id'] ?? 0);
        if (!$id) {
            jsonResponse(['success' => false, 'message' => 'ID inválido']);
        }
        $ok = deleteLicense($db, $id);
        jsonResponse($ok
            ? ['success' => true, 'message' => 'Licença excluída']
            : ['success' => false, 'message' => 'Erro ao excluir']
        );
        break;

    case 'change_status':
        $id = (int) ($input['id'] ?? 0);
        $statusAction = $input['action'] ?? '';
        if (!$id || !$statusAction) {
            jsonResponse(['success' => false, 'message' => 'Dados inválidos']);
        }
        $ok = changeLicenseStatus($db, $id, $statusAction);
        jsonResponse($ok
            ? ['success' => true, 'message' => 'Status alterado']
            : ['success' => false, 'message' => 'Ação inválida']
        );
        break;

    case 'renew_license':
        $id = (int) ($input['id'] ?? 0);
        $days = (int) ($input['days'] ?? 365);
        if (!$id) {
            jsonResponse(['success' => false, 'message' => 'ID inválido']);
        }
        $expiresAt = renewLicense($db, $id, $days);
        jsonResponse($expiresAt
            ? ['success' => true, 'expires_at' => $expiresAt, 'message' => 'Licença renovada']
            : ['success' => false, 'message' => 'Licença não encontrada']
        );
        break;

    case 'send_whatsapp':
        $id = (int) ($input['id'] ?? 0);
        $phone = $input['phone'] ?? '';
        $license = getLicenseById($db, $id);
        if (!$license) {
            jsonResponse(['success' => false, 'message' => 'Licença não encontrada']);
        }
        $message = $input['message'] ?? buildWhatsAppLicenseMessage($license);
        $result = sendWhatsAppMessage($phone, $message);
        jsonResponse([
            'success' => $result['success'],
            'message' => $result['message'],
        ]);
        break;

    case 'validate':
        $licenseKey = $_POST['license_key'] ?? $input['license_key'] ?? '';
        $domain = $_POST['domain'] ?? $input['domain'] ?? ($_SERVER['HTTP_HOST'] ?? null);
        $ip = $_POST['ip'] ?? $input['ip'] ?? ($_SERVER['REMOTE_ADDR'] ?? null);

        if (!$licenseKey) {
            jsonResponse(['valid' => false, 'message' => 'License key is required']);
        }

        $result = validateLicenseKey($db, $licenseKey, $domain, $ip);

        if ($result['valid']) {
            $serverInfo = getServerInfo();
            $stmt = $db->prepare("
                INSERT INTO license_activations 
                (license_id, domain, ip_address, server_hostname, php_version, server_software, activated_at, last_seen, created_at)
                VALUES (:license_id, :domain, :ip, :hostname, :php_version, :server_software, NOW(), NOW(), NOW())
                ON DUPLICATE KEY UPDATE last_seen = NOW()
            ");
            $stmt->execute([
                ':license_id' => $result['license']['id'],
                ':domain' => $domain,
                ':ip' => $ip,
                ':hostname' => $serverInfo['hostname'],
                ':php_version' => $serverInfo['php_version'],
                ':server_software' => $serverInfo['server_software'],
            ]);
        }

        jsonResponse($result);
        break;

    case 'list_activations':
        jsonResponse(['success' => true, 'activations' => getActivations($db)]);
        break;

    case 'list_logs':
        jsonResponse(['success' => true, 'logs' => getLogs($db, 100)]);
        break;

    default:
        jsonResponse(['success' => false, 'message' => 'Ação inválida: ' . $action], 400);
}
