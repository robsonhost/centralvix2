<?php

declare(strict_types=1);

const LICENSE_SESSION_TIMEOUT = 28800; // 8 horas
const LICENSE_MAX_LOGIN_ATTEMPTS = 5;
const LICENSE_LOCKOUT_SECONDS = 900; // 15 minutos

function license_session_start(): void
{
    if (session_status() !== PHP_SESSION_NONE) {
        return;
    }

    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/license/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);

    session_name('CVIX_LICENSE_SESS');
    session_start();
}

function license_fingerprint(): string
{
    return hash('sha256', (string) ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|' . (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
}

function license_csrf_token(): string
{
    if (empty($_SESSION['license_csrf'])) {
        $_SESSION['license_csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['license_csrf'];
}

function license_verify_csrf(?string $token): bool
{
    return is_string($token)
        && $token !== ''
        && isset($_SESSION['license_csrf'])
        && hash_equals($_SESSION['license_csrf'], $token);
}

function license_is_logged_in(): bool
{
    if (empty($_SESSION['license_admin'])) {
        return false;
    }

    if (!empty($_SESSION['login_time']) && (time() - (int) $_SESSION['login_time']) > LICENSE_SESSION_TIMEOUT) {
        license_logout(false);
        return false;
    }

    if (!empty($_SESSION['login_fp']) && $_SESSION['login_fp'] !== license_fingerprint()) {
        license_logout(false);
        return false;
    }

    return true;
}

function license_require_auth(): void
{
    license_session_start();

    if (empty($_SESSION['license_admin'])) {
        header('Location: login.php');
        exit;
    }

    if (!empty($_SESSION['login_time']) && (time() - (int) $_SESSION['login_time']) > LICENSE_SESSION_TIMEOUT) {
        license_logout(false);
        header('Location: login.php?expired=1');
        exit;
    }

    if (!empty($_SESSION['login_fp']) && $_SESSION['login_fp'] !== license_fingerprint()) {
        license_logout(false);
        header('Location: login.php');
        exit;
    }

    $_SESSION['last_activity'] = time();
}

function license_logout(bool $redirect = true): void
{
    if (session_status() === PHP_SESSION_NONE) {
        license_session_start();
    }

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    if ($redirect) {
        header('Location: login.php?logout=1');
        exit;
    }
}

function license_login_attempts(): int
{
    return (int) ($_SESSION['login_attempts'] ?? 0);
}

function license_is_locked(): bool
{
    return !empty($_SESSION['login_locked_until']) && time() < (int) $_SESSION['login_locked_until'];
}

function license_lock_remaining(): int
{
    if (!license_is_locked()) {
        return 0;
    }

    return max(0, (int) $_SESSION['login_locked_until'] - time());
}

function license_record_failed_login(): void
{
    $_SESSION['login_attempts'] = license_login_attempts() + 1;

    if ($_SESSION['login_attempts'] >= LICENSE_MAX_LOGIN_ATTEMPTS) {
        $_SESSION['login_locked_until'] = time() + LICENSE_LOCKOUT_SECONDS;
    }
}

function license_reset_login_attempts(): void
{
    unset($_SESSION['login_attempts'], $_SESSION['login_locked_until']);
}

function license_attempt_login(string $username, string $password): array
{
    license_session_start();

    if (license_is_locked()) {
        $minutes = (int) ceil(license_lock_remaining() / 60);

        return [
            'success' => false,
            'message' => "Muitas tentativas. Aguarde {$minutes} minuto(s) e tente novamente.",
            'locked'  => true,
        ];
    }

    $username = trim($username);

    if ($username === '' || $password === '') {
        return ['success' => false, 'message' => 'Informe usuário e senha.'];
    }

    if ($username === ADMIN_USER && password_verify($password, ADMIN_PASS)) {
        session_regenerate_id(true);

        $_SESSION['license_admin'] = true;
        $_SESSION['license_user']  = ADMIN_USER;
        $_SESSION['login_time']    = time();
        $_SESSION['last_activity'] = time();
        $_SESSION['login_fp']      = license_fingerprint();
        $_SESSION['welcome_flash'] = true;

        license_reset_login_attempts();
        license_csrf_token();

        return ['success' => true];
    }

    license_record_failed_login();
    $remaining = max(0, LICENSE_MAX_LOGIN_ATTEMPTS - license_login_attempts());

    if (license_is_locked()) {
        return [
            'success' => false,
            'message' => 'Conta temporariamente bloqueada por excesso de tentativas. Aguarde 15 minutos.',
            'locked'  => true,
        ];
    }

    return [
        'success'   => false,
        'message'   => $remaining > 0
            ? "Credenciais inválidas. Restam {$remaining} tentativa(s)."
            : 'Credenciais inválidas.',
        'remaining' => $remaining,
    ];
}

function license_remember_username(string $username): void
{
    setcookie(
        'cvix_license_user',
        $username,
        time() + (86400 * 30),
        '/license/',
        '',
        isset($_SERVER['HTTPS']),
        true
    );
}

function license_forget_username(): void
{
    setcookie('cvix_license_user', '', time() - 3600, '/license/', '', isset($_SERVER['HTTPS']), true);
}

function license_saved_username(): string
{
    return trim((string) ($_COOKIE['cvix_license_user'] ?? ''));
}
