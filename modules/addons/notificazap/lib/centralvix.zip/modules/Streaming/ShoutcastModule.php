<?php

namespace Modules\Streaming;

use App\Models\Server;
use App\Models\Service;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Shoutcast / Icecast streaming audio module.
 * Configuração via module_config: port, max_listeners, bitrate, autodj
 */
class ShoutcastModule
{
    private ?string $lastGeneratedPassword = null;

    public function __construct(private Server $server) {}

    public function create(Service $service): bool
    {
        $password = Str::password(14);
        $username = $this->generateUsername($service);
        $this->lastGeneratedPassword = $password;

        $config = (array) ($service->product?->module_config ?? []);
        $port = (int) ($config['port'] ?? $this->allocatePort());
        $maxListeners = (int) ($config['max_listeners'] ?? 50);
        $bitrate = (int) ($config['bitrate'] ?? 128);

        $apiResult = $this->apiRequest('POST', '/streams/create', [
            'username' => $username,
            'password' => $password,
            'port' => $port,
            'max_listeners' => $maxListeners,
            'bitrate' => $bitrate,
            'title' => $service->domain ?? $service->name,
        ]);

        $service->update([
            'username' => $username,
            'password' => encrypt($password),
            'module_data' => array_merge((array) $service->module_data, [
                'stream_type' => 'shoutcast',
                'port' => $port,
                'max_listeners' => $maxListeners,
                'bitrate' => $bitrate,
                'stream_url' => $apiResult['stream_url'] ?? "http://{$this->server->hostname}:{$port}/stream",
                'admin_url' => $apiResult['admin_url'] ?? $this->panelBaseUrl() . "/admin/{$username}",
                'server_hostname' => $this->server->hostname,
                'provisioned_at' => now()->toIso8601String(),
            ]),
        ]);

        Log::info('Shoutcast stream provisioned', ['service_id' => $service->id, 'username' => $username, 'port' => $port]);

        return true;
    }

    public function suspend(Service $service): bool
    {
        return $this->apiRequest('POST', '/streams/suspend', ['username' => $service->username]) !== null
            || $this->markLocal($service, 'suspended');
    }

    public function unsuspend(Service $service): bool
    {
        return $this->apiRequest('POST', '/streams/unsuspend', ['username' => $service->username]) !== null
            || $this->markLocal($service, 'active');
    }

    public function terminate(Service $service): bool
    {
        $this->apiRequest('POST', '/streams/delete', ['username' => $service->username]);

        return true;
    }

    public function getLastGeneratedPassword(): ?string
    {
        return $this->lastGeneratedPassword;
    }

    private function generateUsername(Service $service): string
    {
        $base = Str::slug(Str::before($service->domain ?? $service->name, '.'), '');
        $base = substr(preg_replace('/[^a-z0-9]/', '', strtolower($base)) ?: 'stream', 0, 8);

        return $base . random_int(100, 999);
    }

    private function allocatePort(): int
    {
        return random_int(8000, 8999);
    }

    private function panelBaseUrl(): string
    {
        $secure = (bool) ($this->server->secure ?? true);
        $port = (int) ($this->server->port ?? ($secure ? 8443 : 8080));
        $protocol = $secure ? 'https' : 'http';

        return "{$protocol}://{$this->server->hostname}:{$port}";
    }

    private function apiRequest(string $method, string $path, array $params = []): ?array
    {
        $token = $this->server->getDecryptedApiToken();
        if (!$token) {
            return null;
        }

        try {
            $response = Http::withToken($token)
                ->timeout(30)
                ->send($method, $this->panelBaseUrl() . $path, ['json' => $params]);

            if ($response->successful()) {
                return $response->json();
            }
        } catch (\Throwable $e) {
            Log::warning('Shoutcast API unavailable, using local provisioning', ['error' => $e->getMessage()]);
        }

        return null;
    }

    private function markLocal(Service $service, string $status): bool
    {
        $service->update([
            'module_data' => array_merge((array) $service->module_data, ['stream_status' => $status]),
        ]);

        return true;
    }
}
