<?php

namespace Modules\Streaming;

use App\Models\Server;
use App\Models\Service;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Centova Cast streaming video/radio module.
 */
class CentovaCastModule
{
    private ?string $lastGeneratedPassword = null;

    public function __construct(private Server $server) {}

    public function create(Service $service): bool
    {
        $password = Str::password(16);
        $username = $this->generateUsername($service);
        $this->lastGeneratedPassword = $password;

        $config = (array) ($service->product?->module_config ?? []);
        $plan = $config['plan'] ?? 'default';
        $maxBitrate = (int) ($config['max_bitrate'] ?? 256);
        $maxListeners = (int) ($config['max_listeners'] ?? 100);

        $apiResult = $this->apiRequest('POST', '/api/v1/accounts', [
            'username' => $username,
            'password' => $password,
            'plan' => $plan,
            'maxbitrate' => $maxBitrate,
            'maxlisteners' => $maxListeners,
            'title' => $service->domain ?? $service->name,
        ]);

        $hostname = $this->server->hostname;
        $port = $apiResult['port'] ?? random_int(9000, 9999);

        $service->update([
            'username' => $username,
            'password' => encrypt($password),
            'module_data' => array_merge((array) $service->module_data, [
                'stream_type' => 'centovacast',
                'plan' => $plan,
                'port' => $port,
                'max_bitrate' => $maxBitrate,
                'max_listeners' => $maxListeners,
                'stream_url' => $apiResult['stream_url'] ?? "http://{$hostname}:{$port}/stream",
                'panel_url' => $apiResult['panel_url'] ?? $this->panelBaseUrl(),
                'server_hostname' => $hostname,
                'provisioned_at' => now()->toIso8601String(),
            ]),
        ]);

        Log::info('Centova Cast stream provisioned', ['service_id' => $service->id, 'username' => $username]);

        return true;
    }

    public function suspend(Service $service): bool
    {
        $this->apiRequest('POST', "/api/v1/accounts/{$service->username}/suspend");

        return true;
    }

    public function unsuspend(Service $service): bool
    {
        $this->apiRequest('POST', "/api/v1/accounts/{$service->username}/unsuspend");

        return true;
    }

    public function terminate(Service $service): bool
    {
        $this->apiRequest('DELETE', "/api/v1/accounts/{$service->username}");

        return true;
    }

    public function getLastGeneratedPassword(): ?string
    {
        return $this->lastGeneratedPassword;
    }

    private function generateUsername(Service $service): string
    {
        $base = Str::slug(Str::before($service->domain ?? $service->name, '.'), '');
        $base = substr(preg_replace('/[^a-z0-9]/', '', strtolower($base)) ?: 'cast', 0, 10);

        return $base . random_int(10, 99);
    }

    private function panelBaseUrl(): string
    {
        $secure = (bool) ($this->server->secure ?? true);
        $port = (int) ($this->server->port ?? 2199);
        $protocol = $secure ? 'https' : 'http';

        return "{$protocol}://{$this->server->hostname}:{$port}";
    }

    private function apiRequest(string $method, string $path, array $params = []): ?array
    {
        $token = $this->server->getDecryptedApiToken();
        if (!$token) {
            return null;
        }

        try {
            $request = Http::withHeaders(['X-API-Key' => $token])->timeout(30);
            $url = $this->panelBaseUrl() . $path;

            $response = match (strtoupper($method)) {
                'GET' => $request->get($url, $params),
                'DELETE' => $request->delete($url, $params),
                default => $request->post($url, $params),
            };

            if ($response->successful()) {
                return $response->json();
            }
        } catch (\Throwable $e) {
            Log::warning('Centova Cast API unavailable, using local provisioning', ['error' => $e->getMessage()]);
        }

        return null;
    }
}
