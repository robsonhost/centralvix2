<?php

namespace Modules\Billing\Gateways;

use App\Models\Invoice;
use App\Models\PaymentGateway;
use Illuminate\Support\Facades\Http;

class AsaasGateway
{
    private string $apiKey;
    private string $baseUrl;

    public function __construct(private PaymentGateway $gateway)
    {
        $this->apiKey  = $gateway->settings['api_key'] ?? '';
        $this->baseUrl = $gateway->test_mode
            ? 'https://sandbox.asaas.com/api/v3'
            : 'https://api.asaas.com/api/v3';
    }

    public function charge(Invoice $invoice, array $paymentData = []): array
    {
        try {
            $customer = $this->findOrCreateCustomer($invoice);

            $payload = [
                'customer'    => $customer,
                'billingType' => strtoupper($paymentData['billing_type'] ?? 'PIX'),
                'value'       => (float) $invoice->total,
                'dueDate'     => $invoice->date_due->format('Y-m-d'),
                'description' => 'Fatura #' . $invoice->invoice_number,
                'externalReference' => (string) $invoice->id,
            ];

            $response = Http::withHeaders([
                'access_token' => $this->apiKey,
                'Content-Type' => 'application/json',
            ])->post($this->baseUrl . '/payments', $payload);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'success'        => true,
                    'transaction_id' => $data['id'] ?? null,
                    'payment_url'    => $data['invoiceUrl'] ?? null,
                    'pix_qrcode'     => $data['pixQrCodeImage'] ?? null,
                    'pix_key'        => $data['pixCopiaECola'] ?? null,
                    'response'       => $data,
                ];
            }

            return ['success' => false, 'error' => $response->json('errors.0.description', 'Erro desconhecido'), 'response' => $response->json()];
        } catch (\Exception $e) {
            logger()->error('Asaas charge failed: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function handleWebhook(array $payload): ?array
    {
        $event = $payload['event'] ?? '';
        $payment = $payload['payment'] ?? null;

        if (!$payment) return null;

        if (in_array($event, ['PAYMENT_RECEIVED', 'PAYMENT_CONFIRMED'])) {
            return [
                'invoice_id'     => $payment['externalReference'] ?? null,
                'transaction_id' => $payment['id'] ?? null,
                'amount'         => $payment['value'] ?? 0,
            ];
        }

        return null;
    }

    public function refund(string $transactionId, float $amount): bool
    {
        try {
            $response = Http::withHeaders(['access_token' => $this->apiKey])
                ->post($this->baseUrl . "/payments/{$transactionId}/refund", [
                    'value' => $amount,
                ]);
            return $response->successful();
        } catch (\Exception $e) {
            logger()->error('Asaas refund failed: ' . $e->getMessage());
            return false;
        }
    }

    private function findOrCreateCustomer(Invoice $invoice): string
    {
        $client = $invoice->client;

        $search = Http::withHeaders(['access_token' => $this->apiKey])
            ->get($this->baseUrl . '/customers', ['email' => $client->email]);

        if ($search->successful() && ($search->json('totalCount') ?? 0) > 0) {
            return $search->json('data.0.id');
        }

        $payload = [
            'name'     => $client->display_name,
            'email'    => $client->email,
            'phone'    => $client->phone,
            'mobilePhone' => $client->mobile,
            'externalReference' => (string) $client->id,
        ];

        if ($client->cpf)  $payload['cpfCnpj'] = preg_replace('/\D/', '', $client->cpf);
        if ($client->cnpj) $payload['cpfCnpj'] = preg_replace('/\D/', '', $client->cnpj);
        if ($client->zip)  $payload['postalCode'] = preg_replace('/\D/', '', $client->zip);
        if ($client->address_number) $payload['addressNumber'] = $client->address_number;

        $response = Http::withHeaders(['access_token' => $this->apiKey, 'Content-Type' => 'application/json'])
            ->post($this->baseUrl . '/customers', $payload);

        return $response->json('id');
    }
}
