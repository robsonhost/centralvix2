<?php

namespace Modules\Billing\Gateways;

use App\Models\Invoice;
use App\Models\PaymentGateway;
use Illuminate\Support\Facades\Http;

class StripeGateway
{
    private string $secretKey;
    private string $webhookSecret;
    private string $baseUrl = 'https://api.stripe.com/v1';

    public function __construct(private PaymentGateway $gateway)
    {
        $this->secretKey     = $gateway->settings['secret_key'] ?? '';
        $this->webhookSecret = $gateway->settings['webhook_secret'] ?? '';
    }

    public function charge(Invoice $invoice, array $paymentData = []): array
    {
        try {
            // Create a payment intent
            $response = Http::asForm()
                ->withBasicAuth($this->secretKey, '')
                ->post($this->baseUrl . '/payment_intents', [
                    'amount'      => (int) round($invoice->total * 100), // Stripe uses cents
                    'currency'    => strtolower($invoice->client->currency ?? 'brl'),
                    'description' => 'Fatura #' . $invoice->invoice_number,
                    'metadata'    => ['invoice_id' => $invoice->id],
                    'payment_method_types[]' => 'card',
                ]);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'success'         => false, // Needs client-side confirmation
                    'requires_action' => true,
                    'client_secret'   => $data['client_secret'] ?? null,
                    'transaction_id'  => $data['id'] ?? null,
                    'response'        => $data,
                ];
            }

            return ['success' => false, 'error' => $response->json('error.message', 'Erro'), 'response' => $response->json()];
        } catch (\Exception $e) {
            logger()->error('Stripe charge failed: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function handleWebhook(array $payload): ?array
    {
        $event = $payload['type'] ?? '';
        $object = $payload['data']['object'] ?? null;

        if (!$object) return null;

        if ($event === 'payment_intent.succeeded') {
            $invoiceId = $object['metadata']['invoice_id'] ?? null;
            return [
                'invoice_id'     => $invoiceId,
                'transaction_id' => $object['id'] ?? null,
                'amount'         => ($object['amount_received'] ?? 0) / 100,
            ];
        }

        return null;
    }

    public function refund(string $transactionId, float $amount): bool
    {
        try {
            $response = Http::asForm()
                ->withBasicAuth($this->secretKey, '')
                ->post($this->baseUrl . '/refunds', [
                    'payment_intent' => $transactionId,
                    'amount'         => (int) round($amount * 100),
                ]);
            return $response->successful();
        } catch (\Exception $e) {
            logger()->error('Stripe refund failed: ' . $e->getMessage());
            return false;
        }
    }
}
