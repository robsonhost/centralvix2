<?php

namespace Modules\Billing\Gateways;

use App\Models\Invoice;
use App\Models\PaymentGateway;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Gateway Efí (ex-Gerencianet) — PIX + Boleto + Cartão
 * Docs: https://dev.efipay.com.br/
 */
class EfiGateway
{
    private string $clientId;
    private string $clientSecret;
    private string $baseUrl;
    private ?string $pixKey;

    public function __construct(private PaymentGateway $gateway)
    {
        $settings          = $gateway->settings ?? [];
        $this->clientId    = $settings['client_id']     ?? env('EFI_CLIENT_ID', '');
        $this->clientSecret = $settings['client_secret'] ?? env('EFI_CLIENT_SECRET', '');
        $this->pixKey      = $settings['pix_key']       ?? env('EFI_PIX_KEY', '');
        $this->baseUrl     = $gateway->test_mode
            ? 'https://sandbox.efipay.com.br/v1'
            : 'https://api.efipay.com.br/v1';
    }

    public function charge(Invoice $invoice, array $paymentData = []): array
    {
        $method = $paymentData['method'] ?? 'pix';

        return match ($method) {
            'pix'    => $this->chargePix($invoice),
            'boleto' => $this->chargeBoleto($invoice),
            default  => $this->chargePix($invoice),
        };
    }

    private function chargePix(Invoice $invoice): array
    {
        try {
            $token = $this->getAccessToken();
            if (!$token) return ['success' => false, 'error' => 'Auth failed'];

            $client = $invoice->client;
            $cpfCnpj = preg_replace('/\D/', '', $client->cpf ?? $client->cnpj ?? '');
            $isCompany = strlen($cpfCnpj) > 11;

            $payload = [
                'calendario' => ['expiracao' => 3600],
                'devedor'    => [
                    'cpf'  => !$isCompany ? $cpfCnpj : null,
                    'cnpj' => $isCompany ? $cpfCnpj : null,
                    'nome' => $client->display_name,
                ],
                'valor'    => ['original' => number_format($invoice->total, 2, '.', '')],
                'chave'    => $this->pixKey,
                'infoAdicionais' => [
                    ['nome' => 'Fatura', 'valor' => $invoice->invoice_number],
                ],
            ];

            // Remove null keys
            $payload['devedor'] = array_filter($payload['devedor']);

            $response = Http::withToken($token)->post($this->baseUrl . '/pix/cob', $payload);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'success'        => true,
                    'transaction_id' => $data['txid'] ?? null,
                    'pix_key'        => $data['pixCopiaECola'] ?? null,
                    'pix_qrcode'     => $data['loc']['id'] ?? null,
                    'status'         => 'pending',
                    'response'       => $data,
                ];
            }

            return ['success' => false, 'error' => $response->body(), 'response' => $response->json()];
        } catch (\Exception $e) {
            logger()->error('Efi PIX charge failed: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    private function chargeBoleto(Invoice $invoice): array
    {
        try {
            $token  = $this->getAccessToken();
            $client = $invoice->client;

            $payload = [
                'items'    => [[
                    'name'  => 'Fatura #' . $invoice->invoice_number,
                    'value' => (int) round($invoice->total * 100),
                    'amount'=> 1,
                ]],
                'customer' => [
                    'name'          => $client->display_name,
                    'cpf'           => preg_replace('/\D/', '', $client->cpf ?? ''),
                    'email'         => $client->email,
                    'phone_number'  => preg_replace('/\D/', '', $client->phone ?? ''),
                ],
                'expire_at' => $invoice->date_due->format('Y-m-d'),
            ];

            $response = Http::withToken($token)->post($this->baseUrl . '/charge', $payload);

            if ($response->successful()) {
                $data   = $response->json();
                $chargeId = $data['data']['charge_id'] ?? null;

                return [
                    'success'        => true,
                    'transaction_id' => (string) $chargeId,
                    'boleto_url'     => $data['data']['link'] ?? null,
                    'boleto_barcode' => $data['data']['barcode'] ?? null,
                    'response'       => $data,
                ];
            }

            return ['success' => false, 'error' => $response->body()];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function handleWebhook(array $payload): ?array
    {
        $type = $payload['event'] ?? $payload['tipo'] ?? '';
        $data = $payload['pix'] ?? $payload['data'] ?? [];

        if ($type === 'pix' && is_array($data)) {
            $pix = $data[0] ?? $data;
            $txid = $pix['txid'] ?? null;
            $valor = (float) ($pix['valor'] ?? 0);

            // Find invoice by txid stored in transaction
            if ($txid) {
                return [
                    'transaction_id' => $txid,
                    'amount'         => $valor,
                    'invoice_id'     => null, // must be looked up via transaction
                ];
            }
        }

        return null;
    }

    public function refund(string $transactionId, float $amount): bool
    {
        try {
            $token    = $this->getAccessToken();
            $response = Http::withToken($token)
                ->put($this->baseUrl . "/pix/{$transactionId}/devolucao/" . Str::random(35), [
                    'valor' => number_format($amount, 2, '.', ''),
                ]);
            return $response->successful();
        } catch (\Exception $e) {
            return false;
        }
    }

    private function getAccessToken(): ?string
    {
        try {
            $response = Http::withBasicAuth($this->clientId, $this->clientSecret)
                ->asForm()
                ->post($this->baseUrl . '/authorize', ['grant_type' => 'client_credentials']);

            return $response->json('access_token');
        } catch (\Exception $e) {
            logger()->error('Efi auth failed: ' . $e->getMessage());
            return null;
        }
    }
}
