<?php

namespace Modules\Billing\Gateways;

use App\Models\Invoice;
use App\Models\PaymentGateway;
use Illuminate\Support\Facades\Http;

/**
 * PayPal Checkout Gateway
 * Docs: https://developer.paypal.com/
 */
class PayPalGateway
{
    private string $clientId;
    private string $clientSecret;
    private string $baseUrl;

    public function __construct(private PaymentGateway $gateway)
    {
        $settings           = $gateway->settings ?? [];
        $this->clientId     = $settings['client_id']     ?? env('PAYPAL_CLIENT_ID', '');
        $this->clientSecret = $settings['client_secret'] ?? env('PAYPAL_CLIENT_SECRET', '');
        $this->baseUrl      = $gateway->test_mode
            ? 'https://api-m.sandbox.paypal.com'
            : 'https://api-m.paypal.com';
    }

    public function charge(Invoice $invoice, array $paymentData = []): array
    {
        try {
            $token = $this->getAccessToken();
            if (!$token) return ['success' => false, 'error' => 'PayPal auth failed'];

            $response = Http::withToken($token)
                ->post($this->baseUrl . '/v2/checkout/orders', [
                    'intent'         => 'CAPTURE',
                    'purchase_units' => [[
                        'amount'      => [
                            'currency_code' => 'BRL',
                            'value'         => number_format($invoice->total, 2, '.', ''),
                        ],
                        'description' => 'Fatura #' . $invoice->invoice_number,
                        'custom_id'   => (string) $invoice->id,
                    ]],
                    'application_context' => [
                        'return_url' => url('/client/invoices/' . $invoice->id),
                        'cancel_url' => url('/client/invoices/' . $invoice->id),
                    ],
                ]);

            if ($response->successful()) {
                $data     = $response->json();
                $orderId  = $data['id'];
                $approvalUrl = collect($data['links'])->firstWhere('rel', 'approve')['href'] ?? null;

                return [
                    'success'        => false, // needs user to approve on PayPal
                    'requires_redirect' => true,
                    'redirect_url'   => $approvalUrl,
                    'transaction_id' => $orderId,
                    'response'       => $data,
                ];
            }

            return ['success' => false, 'error' => $response->body()];
        } catch (\Exception $e) {
            logger()->error('PayPal charge failed: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function captureOrder(string $orderId): array
    {
        try {
            $token = $this->getAccessToken();
            $response = Http::withToken($token)
                ->post($this->baseUrl . "/v2/checkout/orders/{$orderId}/capture");

            if ($response->successful()) {
                $data = $response->json();
                $capture = $data['purchase_units'][0]['payments']['captures'][0] ?? null;

                return [
                    'success'        => $data['status'] === 'COMPLETED',
                    'transaction_id' => $capture['id'] ?? $orderId,
                    'status'         => $data['status'],
                    'response'       => $data,
                ];
            }

            return ['success' => false, 'error' => $response->body()];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function handleWebhook(array $payload): ?array
    {
        $eventType = $payload['event_type'] ?? '';
        $resource  = $payload['resource'] ?? null;

        if ($eventType === 'PAYMENT.CAPTURE.COMPLETED' && $resource) {
            $invoiceId = $resource['custom_id'] ?? null;
            return [
                'invoice_id'     => $invoiceId,
                'transaction_id' => $resource['id'] ?? null,
                'amount'         => (float) ($resource['amount']['value'] ?? 0),
            ];
        }

        return null;
    }

    public function refund(string $captureId, float $amount): bool
    {
        try {
            $token    = $this->getAccessToken();
            $response = Http::withToken($token)
                ->post($this->baseUrl . "/v2/payments/captures/{$captureId}/refund", [
                    'amount' => ['value' => number_format($amount, 2, '.', ''), 'currency_code' => 'BRL'],
                ]);
            return $response->successful();
        } catch (\Exception $e) {
            return false;
        }
    }

    private function getAccessToken(): ?string
    {
        try {
            $response = Http::withBasicAuth($this->clientId, $this->clientSecret)
                ->asForm()
                ->post($this->baseUrl . '/v1/oauth2/token', ['grant_type' => 'client_credentials']);
            return $response->json('access_token');
        } catch (\Exception $e) {
            logger()->error('PayPal auth failed: ' . $e->getMessage());
            return null;
        }
    }
}
