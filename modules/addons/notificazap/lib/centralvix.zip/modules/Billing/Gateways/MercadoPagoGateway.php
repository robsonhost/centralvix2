<?php

namespace Modules\Billing\Gateways;

use App\Models\Invoice;
use App\Models\PaymentGateway;
use Illuminate\Support\Facades\Http;

class MercadoPagoGateway
{
    private string $accessToken;
    private string $baseUrl = 'https://api.mercadopago.com';

    public function __construct(private PaymentGateway $gateway)
    {
        $this->accessToken = $gateway->settings['access_token'] ?? '';
    }

    public function charge(Invoice $invoice, array $paymentData = []): array
    {
        try {
            $client = $invoice->client;

            $payload = [
                'transaction_amount' => (float) $invoice->total,
                'description'        => 'Fatura #' . $invoice->invoice_number,
                'payment_method_id'  => $paymentData['payment_method_id'] ?? 'pix',
                'payer' => [
                    'email'           => $client->email,
                    'first_name'      => $client->firstname,
                    'last_name'       => $client->lastname,
                    'identification'  => [
                        'type'   => $client->cnpj ? 'CNPJ' : 'CPF',
                        'number' => preg_replace('/\D/', '', $client->cpf ?? $client->cnpj ?? ''),
                    ],
                ],
                'external_reference' => (string) $invoice->id,
                'date_of_expiration' => $invoice->date_due->format('Y-m-d') . 'T23:59:59.000-03:00',
            ];

            $response = Http::withToken($this->accessToken)
                ->withHeaders(['X-Idempotency-Key' => 'invoice-' . $invoice->id . '-' . time()])
                ->post($this->baseUrl . '/v1/payments', $payload);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'success'        => true,
                    'transaction_id' => (string) ($data['id'] ?? ''),
                    'status'         => $data['status'] ?? 'pending',
                    'pix_qrcode'     => $data['point_of_interaction']['transaction_data']['qr_code_base64'] ?? null,
                    'pix_key'        => $data['point_of_interaction']['transaction_data']['qr_code'] ?? null,
                    'response'       => $data,
                ];
            }

            return ['success' => false, 'error' => $response->json('message', 'Erro'), 'response' => $response->json()];
        } catch (\Exception $e) {
            logger()->error('MercadoPago charge failed: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function handleWebhook(array $payload): ?array
    {
        $type = $payload['type'] ?? '';
        $data = $payload['data'] ?? null;

        if ($type !== 'payment' || !$data) return null;

        $paymentId = $data['id'] ?? null;
        if (!$paymentId) return null;

        try {
            $response = Http::withToken($this->accessToken)
                ->get($this->baseUrl . '/v1/payments/' . $paymentId);

            if (!$response->successful()) return null;

            $payment = $response->json();

            if (in_array($payment['status'], ['approved', 'authorized'])) {
                return [
                    'invoice_id'     => $payment['external_reference'] ?? null,
                    'transaction_id' => (string) $paymentId,
                    'amount'         => $payment['transaction_amount'] ?? 0,
                ];
            }
        } catch (\Exception $e) {
            logger()->error('MercadoPago webhook failed: ' . $e->getMessage());
        }

        return null;
    }

    public function refund(string $transactionId, float $amount): bool
    {
        try {
            $response = Http::withToken($this->accessToken)
                ->post($this->baseUrl . '/v1/payments/' . $transactionId . '/refunds', [
                    'amount' => $amount,
                ]);
            return $response->successful();
        } catch (\Exception $e) {
            logger()->error('MercadoPago refund failed: ' . $e->getMessage());
            return false;
        }
    }
}
