<?php

namespace Modules\Billing\Gateways;

use App\Models\Invoice;
use App\Models\PaymentGateway;
use Illuminate\Support\Facades\Http;

/**
 * PagSeguro Gateway — PIX + Boleto + Cartão
 * Docs: https://dev.pagseguro.uol.com.br/
 */
class PagSeguroGateway
{
    private string $token;
    private string $baseUrl;

    public function __construct(private PaymentGateway $gateway)
    {
        $settings    = $gateway->settings ?? [];
        $this->token = $settings['token'] ?? env('PAGSEGURO_TOKEN', '');
        $this->baseUrl = $gateway->test_mode
            ? 'https://sandbox.api.pagseguro.com'
            : 'https://api.pagseguro.com';
    }

    public function charge(Invoice $invoice, array $paymentData = []): array
    {
        try {
            $method = $paymentData['method'] ?? 'pix';
            $client = $invoice->client;

            $payload = [
                'reference_id' => 'inv-' . $invoice->id,
                'customer'     => [
                    'name'   => $client->display_name,
                    'email'  => $client->email,
                    'tax_id' => preg_replace('/\D/', '', $client->cpf ?? $client->cnpj ?? ''),
                    'phones' => [[
                        'country' => '55',
                        'area'    => substr(preg_replace('/\D/', '', $client->phone ?? ''), 0, 2),
                        'number'  => substr(preg_replace('/\D/', '', $client->phone ?? ''), 2),
                        'type'    => 'MOBILE',
                    ]],
                ],
                'items' => [[
                    'name'        => 'Fatura #' . $invoice->invoice_number,
                    'quantity'    => 1,
                    'unit_amount' => (int) round($invoice->total * 100),
                ]],
                'qr_codes' => $method === 'pix' ? [[
                    'amount'        => ['value' => (int) round($invoice->total * 100)],
                    'expiration_date' => $invoice->date_due->format('Y-m-d\TH:i:s') . '-03:00',
                ]] : [],
                'charges' => $method !== 'pix' ? [[
                    'reference_id' => 'chg-' . $invoice->id,
                    'description'  => 'Fatura #' . $invoice->invoice_number,
                    'amount'       => [
                        'value'    => (int) round($invoice->total * 100),
                        'currency' => 'BRL',
                    ],
                    'payment_method' => [
                        'type'           => 'BOLETO',
                        'boleto'         => [
                            'due_date'   => $invoice->date_due->format('Y-m-d'),
                            'instruction_lines' => [
                                'line_1' => 'Fatura #' . $invoice->invoice_number,
                                'line_2' => config('app.name'),
                            ],
                        ],
                    ],
                ]] : [],
            ];

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->token,
                'Content-Type'  => 'application/json',
            ])->post($this->baseUrl . '/orders', $payload);

            if ($response->successful()) {
                $data = $response->json();
                $qr   = $data['qr_codes'][0] ?? null;
                $chg  = $data['charges'][0] ?? null;

                return [
                    'success'        => true,
                    'transaction_id' => $data['id'] ?? null,
                    'pix_key'        => $qr['text'] ?? null,
                    'pix_qrcode'     => $qr['links'][0]['href'] ?? null,
                    'boleto_url'     => $chg['links'][0]['href'] ?? null,
                    'response'       => $data,
                ];
            }

            return ['success' => false, 'error' => $response->body(), 'response' => $response->json()];
        } catch (\Exception $e) {
            logger()->error('PagSeguro charge failed: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function handleWebhook(array $payload): ?array
    {
        $event = $payload['type'] ?? '';
        $order = $payload['data'] ?? null;

        if (in_array($event, ['PAYMENT.PAID', 'CHARGE.PAID']) && $order) {
            $refId = $order['reference_id'] ?? '';
            $invoiceId = str_replace('inv-', '', $refId);

            return [
                'invoice_id'     => is_numeric($invoiceId) ? (int) $invoiceId : null,
                'transaction_id' => $order['id'] ?? null,
                'amount'         => ($order['charges'][0]['amount']['value'] ?? 0) / 100,
            ];
        }

        return null;
    }

    public function refund(string $transactionId, float $amount): bool
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->token,
            ])->post($this->baseUrl . "/charges/{$transactionId}/cancel");
            return $response->successful();
        } catch (\Exception $e) {
            return false;
        }
    }
}
