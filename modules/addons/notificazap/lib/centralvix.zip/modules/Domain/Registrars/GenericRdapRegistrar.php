<?php

namespace Modules\Domain\Registrars;

use App\Models\Domain;
use Illuminate\Support\Facades\Http;

/**
 * Generic RDAP-based registrar for availability checks on common TLDs.
 */
class GenericRdapRegistrar
{
    private array $rdapServers = [
        'com'  => 'https://rdap.verisign.com/com/v1/domain/',
        'net'  => 'https://rdap.verisign.com/net/v1/domain/',
        'org'  => 'https://rdap.publicinterestregistry.org/rdap/domain/',
        'info' => 'https://rdap.afilias.net/rdap/info/domain/',
        'biz'  => 'https://rdap.nic.biz/rdap/domain/',
        'io'   => 'https://rdap.nic.io/rdap/domain/',
        'co'   => 'https://rdap.nic.co/rdap/domain/',
    ];

    public function checkAvailability(string $domain): bool
    {
        $domain = strtolower(trim($domain));
        $tld = $this->extractTld($domain);

        if (!$tld) {
            return false;
        }

        $url = $this->rdapServers[$tld] ?? null;

        if (!$url) {
            // Fallback: if domain resolves via DNS, it's taken
            return gethostbyname($domain) === $domain;
        }

        try {
            $response = Http::timeout(10)->get($url . $domain);
            return $response->status() === 404;
        } catch (\Exception $e) {
            logger()->error("RDAP check failed for {$domain}: " . $e->getMessage());
            return false;
        }
    }

    public function register(Domain $domain): bool
    {
        logger()->info("Generic RDAP: registering {$domain->domain} (manual/API pending)");
        return true;
    }

    public function renew(Domain $domain, int $years = 1): bool
    {
        logger()->info("Generic RDAP: renewing {$domain->domain} for {$years} year(s)");
        return true;
    }

    public function getEppCode(Domain $domain): ?string
    {
        return $domain->epp_code;
    }

    public function updateNameservers(Domain $domain, array $nameservers): bool
    {
        logger()->info("Generic RDAP: updating nameservers for {$domain->domain}");
        return true;
    }

    public function getInfo(string $domain): array
    {
        $domain = strtolower(trim($domain));
        $tld = $this->extractTld($domain);
        $url = $this->rdapServers[$tld] ?? null;

        if (!$url) {
            return [];
        }

        try {
            $response = Http::timeout(10)->get($url . $domain);
            if ($response->successful()) {
                return $response->json();
            }
        } catch (\Exception $e) {
            logger()->error("RDAP getInfo failed for {$domain}: " . $e->getMessage());
        }

        return [];
    }

    private function extractTld(string $domain): ?string
    {
        $parts = explode('.', $domain);
        if (count($parts) < 2) {
            return null;
        }
        return end($parts);
    }
}
