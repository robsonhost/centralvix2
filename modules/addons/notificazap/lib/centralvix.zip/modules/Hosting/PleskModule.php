<?php

namespace Modules\Hosting;

use App\Models\Server;
use App\Models\Service;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Plesk Onyx/Obsidian Module
 * Docs: https://docs.plesk.com/en-US/obsidian/api-rpc/
 */
class PleskModule
{
    private string $baseUrl;
    private string $apiKey;

    public function __construct(private Server $server)
    {
        $protocol      = ($server->secure ?? $server->settings['secure'] ?? true) ? 'https' : 'http';
        $port          = $server->port ?? 8443;
        $this->baseUrl = "{$protocol}://{$server->hostname}:{$port}";
        $this->apiKey  = $server->getDecryptedApiToken() ?? $server->api_token ?? '';
    }

    public function create(Service $service): bool
    {
        try {
            $password = Str::password(16);
            $domain   = $service->domain ?? ($service->username . '.hosted.com');
            $username = $this->generateUsername($service);

            $response = $this->request('POST', '/api/v2/webspaces', [
                'name'                  => $domain,
                'displayName'           => $domain,
                'ipAddress'             => $this->server->ip_address,
                'hostingType'           => 'virtual',
                'physicalHostingProps'  => [
                    'ftpLogin'    => $username,
                    'ftpPassword' => $password,
                ],
                'limits'       => $this->getLimits($service),
            ]);

            if ($response && isset($response['id'])) {
                $service->update([
                    'username'    => $username,
                    'password'    => encrypt($password),
                    'module_data' => array_merge((array) $service->module_data, [
                        'plesk_id'    => $response['id'],
                        'domain'      => $domain,
                        'plesk_url'   => $this->baseUrl . '/smb/web/setup',
                        'ip_address'  => $this->server->ip_address,
                    ]),
                ]);
                return true;
            }

            return false;
        } catch (\Exception $e) {
            logger()->error('Plesk create failed: ' . $e->getMessage());
            throw $e;
        }
    }

    public function suspend(Service $service): bool
    {
        $pleskId = $service->module_data['plesk_id'] ?? null;
        if (!$pleskId) return true;

        try {
            $response = $this->request('PUT', "/api/v2/webspaces/{$pleskId}", [
                'active' => false,
            ]);
            return $response !== null;
        } catch (\Exception $e) {
            logger()->error('Plesk suspend failed: ' . $e->getMessage());
            return false;
        }
    }

    public function unsuspend(Service $service): bool
    {
        $pleskId = $service->module_data['plesk_id'] ?? null;
        if (!$pleskId) return true;

        try {
            $response = $this->request('PUT', "/api/v2/webspaces/{$pleskId}", [
                'active' => true,
            ]);
            return $response !== null;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function terminate(Service $service): bool
    {
        $pleskId = $service->module_data['plesk_id'] ?? null;
        if (!$pleskId) return true;

        try {
            $this->request('DELETE', "/api/v2/webspaces/{$pleskId}");
            return true;
        } catch (\Exception $e) {
            logger()->error('Plesk terminate failed: ' . $e->getMessage());
            return true; // mark as terminated even if API fails
        }
    }

    public function changePassword(Service $service, string $newPassword): bool
    {
        $pleskId = $service->module_data['plesk_id'] ?? null;
        if (!$pleskId) return false;

        try {
            $response = $this->request('PUT', "/api/v2/webspaces/{$pleskId}", [
                'physicalHostingProps' => ['ftpPassword' => $newPassword],
            ]);
            if ($response !== null) {
                $service->update(['password' => encrypt($newPassword)]);
                return true;
            }
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }

    private function getLimits(Service $service): array
    {
        $config = $service->product?->module_config ?? [];
        return [
            'diskSpace'    => ($config['disk_mb'] ?? 10240),
            'traffic'      => ($config['traffic_mb'] ?? 102400),
            'mailboxCount' => ($config['mailbox_count'] ?? 10),
            'dbCount'      => ($config['db_count'] ?? 5),
        ];
    }

    private function generateUsername(Service $service): string
    {
        $domain = $service->domain ?? 'user' . $service->id;
        $base   = strtolower(preg_replace('/[^a-z0-9]/', '', explode('.', $domain)[0]));
        return substr($base, 0, 8) . rand(100, 999);
    }

    private function request(string $method, string $endpoint, array $data = []): ?array
    {
        try {
            $response = Http::withHeaders([
                'X-API-Key'    => $this->apiKey,
                'Content-Type' => 'application/json',
            ])
            ->withOptions(['verify' => false])
            ->timeout(30)
            ->{strtolower($method)}($this->baseUrl . $endpoint, $data);

            return $response->successful() ? ($response->json() ?? []) : null;
        } catch (\Exception $e) {
            logger()->error("Plesk {$method} {$endpoint} failed: " . $e->getMessage());
            return null;
        }
    }
}
