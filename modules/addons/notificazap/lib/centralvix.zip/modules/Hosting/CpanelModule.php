<?php

namespace Modules\Hosting;

use App\Models\Server;
use App\Models\Service;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

class CpanelModule
{
    private string $baseUrl;
    private string $token;
    private int $port;
    private bool $secure;
    private bool $verifySsl;
    private ?string $lastError = null;
    private ?int $lastHttpStatus = null;
    private ?string $lastGeneratedPassword = null;

    public function __construct(private Server $server)
    {
        $this->port      = (int) ($server->port ?? 2087);
        $this->secure    = (bool) ($server->secure ?? $server->settings['secure'] ?? true);
        $this->verifySsl = $this->resolveVerifySsl();
        $protocol        = $this->secure ? 'https' : 'http';
        $this->baseUrl   = "{$protocol}://{$server->hostname}:{$this->port}";
        $this->token     = $server->getDecryptedApiToken() ?? $server->api_token ?? '';
    }

    private function resolveVerifySsl(): bool
    {
        if (array_key_exists('verify_ssl', (array) ($this->server->settings ?? []))) {
            return (bool) $this->server->settings['verify_ssl'];
        }

        return filter_var(env('CPANEL_VERIFY_SSL', false), FILTER_VALIDATE_BOOLEAN);
    }

    /**
     * Create a new cPanel account
     */
    public function create(Service $service): bool
    {
        $domain = trim((string) ($service->domain ?? ''));
        if ($domain === '') {
            throw new \InvalidArgumentException('Domínio é obrigatório para provisionar hospedagem cPanel.');
        }

        $password = $this->generatePassword();
        $username = $this->generateUsername($service);
        $this->lastGeneratedPassword = $password;

        $plan = $service->product?->module_config['plan'] ?? 'default';

        $response = $this->request('POST', '/json-api/createacct', [
            'username' => $username,
            'domain'   => $domain,
            'password' => $password,
            'plan'     => $plan,
            'pkgname'  => $plan,
            'featurelist' => $service->product?->module_config['feature_list'] ?? 'default',
            'contactemail' => $service->client->email ?? '',
            'cpmod' => 'paper_lantern',
        ]);

        if ($response && (int) ($response['metadata']['result'] ?? 0) === 1) {
            $service->update([
                'username'    => $username,
                'password'    => encrypt($password),
                'module_data' => array_merge((array) $service->module_data, [
                    'cpanel_user' => $username,
                    'ip'          => $this->server->ip_address,
                    'nameservers' => $this->server->settings['nameservers'] ?? [],
                    'cpanel_url'  => "https://{$domain}:2083",
                    'whm_url'     => $this->baseUrl,
                    'created_at'  => now()->toIso8601String(),
                ]),
            ]);

            Log::info('cPanel account created successfully', ['username' => $username, 'domain' => $domain]);

            return true;
        }

        $reason = $this->lastError
            ?? ($response['metadata']['reason'] ?? 'Falha ao criar conta cPanel no WHM.');

        Log::error('cPanel create failed', ['response' => $response, 'reason' => $reason]);

        throw new \RuntimeException($reason);
    }

    public function getLastGeneratedPassword(): ?string
    {
        return $this->lastGeneratedPassword;
    }

    /**
     * Suspend a cPanel account
     */
    public function suspend(Service $service): bool
    {
        $response = $this->request('POST', '/json-api/suspendacct', [
            'user'   => $service->username,
            'reason' => 'Serviço suspenso por inadimplência ou violação dos termos de uso.',
        ]);
        
        $success = $response && $response['metadata']['result'] === 1;
        
        if ($success) {
            $service->update([
                'module_data' => array_merge((array) $service->module_data, [
                    'suspended_at' => now()->toIso8601String(),
                    'suspend_reason' => 'Inadimplência',
                ])
            ]);
            Log::info("cPanel account suspended", ['username' => $service->username]);
        }
        
        return $success;
    }

    /**
     * Unsuspend a cPanel account
     */
    public function unsuspend(Service $service): bool
    {
        $response = $this->request('POST', '/json-api/unsuspendacct', [
            'user' => $service->username,
        ]);
        
        $success = $response && $response['metadata']['result'] === 1;
        
        if ($success) {
            $moduleData = (array) $service->module_data;
            unset($moduleData['suspended_at'], $moduleData['suspend_reason']);
            $service->update(['module_data' => $moduleData]);
            Log::info("cPanel account unsuspended", ['username' => $service->username]);
        }
        
        return $success;
    }

    /**
     * Terminate/delete a cPanel account
     */
    public function terminate(Service $service): bool
    {
        $response = $this->request('POST', '/json-api/removeacct', [
            'user' => $service->username,
            'keepdns' => 0,
        ]);
        
        if ($response) {
            Log::info("cPanel account terminated", ['username' => $service->username]);
            return true;
        }
        
        return false;
    }

    /**
     * Change account password
     */
    public function changePassword(Service $service, string $newPassword): bool
    {
        $response = $this->request('POST', '/json-api/passwd', [
            'user'   => $service->username,
            'pass'   => $newPassword,
            'db_pass_update' => 1,
        ]);

        if ($response && $response['metadata']['result'] === 1) {
            $service->update(['password' => encrypt($newPassword)]);
            Log::info("cPanel password changed", ['username' => $service->username]);
            return true;
        }

        return false;
    }

    /**
     * Get account statistics and usage
     */
    public function getStats(Service $service): array
    {
        $response = $this->request('GET', '/json-api/domainuserdata', [
            'domain' => $service->domain,
        ]);

        if (!$response) return [];

        return [
            'disk_used'  => $response['data']['userdata']['disk_used'] ?? 0,
            'disk_limit' => $response['data']['userdata']['disk_limit'] ?? 0,
            'bw_used'    => $response['data']['userdata']['bw_used'] ?? 0,
            'bw_limit'   => $response['data']['userdata']['bw_limit'] ?? 0,
            'email_accounts' => $response['data']['userdata']['email_accounts'] ?? 0,
            'databases' => $response['data']['userdata']['mysql_databases'] ?? 0,
        ];
    }

    /**
     * List all DNS zones for an account
     */
    public function listDnsZones(Service $service): array
    {
        $response = $this->request('GET', '/json-api/cpanel', [
            'cpanel_jsonapi_user' => $service->username,
            'cpanel_jsonapi_apiversion' => 2,
            'cpanel_jsonapi_module' => 'ZoneEdit',
            'cpanel_jsonapi_func' => 'fetchzones',
        ]);

        return $response['cpanelresult']['data'] ?? [];
    }

    /**
     * Add DNS record
     */
    public function addDnsRecord(Service $service, array $record): bool
    {
        $response = $this->request('POST', '/json-api/cpanel', [
            'cpanel_jsonapi_user' => $service->username,
            'cpanel_jsonapi_apiversion' => 2,
            'cpanel_jsonapi_module' => 'ZoneEdit',
            'cpanel_jsonapi_func' => 'add_zone_record',
            'domain' => $service->domain,
            'name' => $record['name'] ?? '',
            'type' => $record['type'] ?? 'A',
            'address' => $record['address'] ?? '',
            'ttl' => $record['ttl'] ?? 14400,
        ]);

        return isset($response['cpanelresult']['data'][0]['result']) 
            && $response['cpanelresult']['data'][0]['result'] == 1;
    }

    /**
     * Delete DNS record
     */
    public function deleteDnsRecord(Service $service, int $line): bool
    {
        $response = $this->request('POST', '/json-api/cpanel', [
            'cpanel_jsonapi_user' => $service->username,
            'cpanel_jsonapi_apiversion' => 2,
            'cpanel_jsonapi_module' => 'ZoneEdit',
            'cpanel_jsonapi_func' => 'remove_zone_record',
            'domain' => $service->domain,
            'line' => $line,
        ]);

        return isset($response['cpanelresult']['data'][0]['result']) 
            && $response['cpanelresult']['data'][0]['result'] == 1;
    }

    /**
     * List all accounts on the server
     */
    public function listAccounts(): array
    {
        $this->lastError = null;
        $response = $this->request('GET', '/json-api/listaccts', ['api.version' => 1]);

        return $this->normalizeWhmList($response, 'acct', function (array $row) {
            return [
                'user' => $row['user'] ?? $row['username'] ?? '',
                'domain' => $row['domain'] ?? '',
                'plan' => $row['plan'] ?? $row['package'] ?? '',
                'email' => $row['email'] ?? '',
                'suspended' => (bool) ($row['suspended'] ?? false),
                'diskused' => $row['diskused'] ?? null,
                'disklimit' => $row['disklimit'] ?? null,
            ];
        });
    }

    /**
     * Get account details
     */
    public function getAccountInfo(Service $service): ?array
    {
        $response = $this->request('GET', '/json-api/accountsummary', [
            'user' => $service->username,
        ]);

        return $response['data']['acct'][0] ?? null;
    }

    /**
     * Change account package
     */
    public function changePackage(Service $service, string $package): bool
    {
        $response = $this->request('POST', '/json-api/changepackage', [
            'user' => $service->username,
            'pkg' => $package,
        ]);

        return $response && $response['metadata']['result'] === 1;
    }

    /**
     * List available packages
     */
    public function listPackages(): array
    {
        $this->lastError = null;
        $response = $this->request('GET', '/json-api/listpkgs', ['api.version' => 1]);

        return $this->normalizeWhmList($response, 'pkg', function (array $row) {
            $name = $row['name'] ?? $row['pkgname'] ?? $row['pkg'] ?? '';

            return [
                'name' => $name,
                'quota' => $row['QUOTA'] ?? $row['quota'] ?? '∞',
                'bwlimit' => $row['BWLIMIT'] ?? $row['bwlimit'] ?? '∞',
                'maxpop' => $row['MAXPOP'] ?? $row['maxpop'] ?? '∞',
                'maxsql' => $row['MAXSQL'] ?? $row['maxsql'] ?? '∞',
                'maxftp' => $row['MAXFTP'] ?? $row['maxftp'] ?? '∞',
                'raw' => $row,
            ];
        });
    }

    /**
     * Create a WHM hosting package (plano).
     */
    public function createPackage(array $config): array
    {
        $name = trim($config['name'] ?? '');
        if ($name === '') {
            return ['success' => false, 'message' => 'Nome do pacote é obrigatório.'];
        }

        $params = [
            'api.version' => 1,
            'pkg' => $name,
            'name' => $name,
            'quota' => (int) ($config['quota'] ?? 0),
            'bwlimit' => (int) ($config['bwlimit'] ?? 0),
            'maxftp' => (int) ($config['maxftp'] ?? 5),
            'maxsql' => (int) ($config['maxsql'] ?? 5),
            'maxpop' => (int) ($config['maxpop'] ?? 10),
            'maxsub' => (int) ($config['maxsub'] ?? 5),
            'maxpark' => (int) ($config['maxpark'] ?? 5),
            'maxaddon' => (int) ($config['maxaddon'] ?? 5),
            'hasshell' => (int) ($config['hasshell'] ?? 0),
            'cgi' => 1,
        ];

        $response = $this->request('POST', '/json-api/addpkg', $params);

        if ($response && (int) ($response['metadata']['result'] ?? 0) === 1) {
            return [
                'success' => true,
                'message' => "Pacote \"{$name}\" criado no WHM.",
                'package' => $name,
            ];
        }

        return [
            'success' => false,
            'message' => $this->lastError
                ?? ($response['metadata']['reason'] ?? 'Falha ao criar pacote no WHM.'),
            'details' => ['http_status' => $this->lastHttpStatus],
        ];
    }

    private function normalizeWhmList(?array $response, string $key, callable $mapper): array
    {
        if (!$response) {
            return [];
        }

        if ((int) ($response['metadata']['result'] ?? 0) !== 1) {
            $this->lastError = $response['metadata']['reason'] ?? $this->lastError ?? 'Resposta WHM inválida.';

            return [];
        }

        $items = $response['data'][$key] ?? $response['data']['package'] ?? $response[$key] ?? [];

        if ($items === null || $items === []) {
            return [];
        }

        $items = $this->flattenWhmList($items);

        return array_values(array_filter(array_map(function ($row) use ($mapper) {
            if (!is_array($row)) {
                return null;
            }

            $mapped = $mapper($row);

            if (is_array($mapped) && ($mapped['name'] ?? $mapped['user'] ?? '') === '') {
                return null;
            }

            return $mapped;
        }, $items)));
    }

    private function flattenWhmList(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }

        if ($items === []) {
            return [];
        }

        $keys = array_keys($items);

        if ($keys === range(0, count($items) - 1)) {
            return $items;
        }

        if ($this->isAssocWhmRow($items) && $this->looksLikeWhmEntity($items)) {
            return [$items];
        }

        $values = array_values($items);

        if ($values !== [] && is_array($values[0])) {
            return $values;
        }

        return [$items];
    }

    private function looksLikeWhmEntity(array $row): bool
    {
        foreach (['user', 'username', 'domain', 'name', 'pkgname', 'pkg', 'QUOTA', 'quota', 'plan', 'package'] as $signal) {
            if (array_key_exists($signal, $row)) {
                return true;
            }
        }

        return false;
    }

    private function isAssocWhmRow(array $row): bool
    {
        if ($row === []) {
            return false;
        }

        return array_keys($row) !== range(0, count($row) - 1);
    }

    /**
     * Get server load and statistics
     */
    public function getServerLoad(): array
    {
        $response = $this->request('GET', '/json-api/loadavg');
        
        if (!$response) return [];

        return [
            'one' => $response['data']['one'] ?? 0,
            'five' => $response['data']['five'] ?? 0,
            'fifteen' => $response['data']['fifteen'] ?? 0,
        ];
    }

    /**
     * Test connection to WHM server (retorna diagnóstico detalhado).
     */
    public function testConnection(): array
    {
        $this->lastError = null;
        $this->lastHttpStatus = null;

        if (trim($this->token) === '') {
            return [
                'success' => false,
                'message' => 'Token/API Key não configurado. Gere um token em WHM → Desenvolvimento → Gerenciar tokens de API.',
                'details' => $this->buildFailureDetails([]),
            ];
        }

        $diagnostics = [];

        $tcp = $this->probeTcp();
        $diagnostics['tcp'] = $tcp;

        if (!$tcp['ok']) {
            return [
                'success' => false,
                'message' => $tcp['error'] ?? 'Porta WHM inacessível a partir do servidor CentralVix.',
                'details' => $this->buildFailureDetails($diagnostics),
            ];
        }

        $strategies = [
            ['verify' => false, 'params' => ['api.version' => 1]],
            ['verify' => false, 'params' => []],
        ];

        if ($this->verifySsl) {
            $strategies[] = ['verify' => true, 'params' => ['api.version' => 1]];
        }

        $lastResponse = null;

        foreach ($strategies as $index => $strategy) {
            $response = $this->request('GET', '/json-api/version', $strategy['params'], $strategy['verify']);
            $lastResponse = $response;

            $diagnostics['attempts'][] = [
                'step' => $index + 1,
                'verify_ssl' => $strategy['verify'],
                'http_status' => $this->lastHttpStatus,
                'error' => $this->lastError,
            ];

            if ($version = $this->parseWhmVersion($response)) {
                $sslWarning = $this->secure && !$strategy['verify'];

                return [
                    'success' => true,
                    'message' => $sslWarning
                        ? 'Conexão OK. Certificado SSL do WHM não verificado — mantenha "Verificar certificado SSL" desativado.'
                        : 'Conexão estabelecida com sucesso!',
                    'version' => $version,
                    'hostname' => $this->server->hostname,
                    'port' => $this->port,
                    'verify_ssl' => $strategy['verify'],
                    'ssl_warning' => $sslWarning,
                ];
            }
        }

        $metadataReason = is_array($lastResponse) ? ($lastResponse['metadata']['reason'] ?? null) : null;

        return [
            'success' => false,
            'message' => $this->lastError
                ?? $metadataReason
                ?? 'Falha ao conectar com o servidor WHM.',
            'details' => $this->buildFailureDetails($diagnostics),
            'raw' => $lastResponse,
        ];
    }

    private function buildFailureDetails(array $extra): array
    {
        return array_merge([
            'hostname' => $this->server->hostname,
            'port' => $this->port,
            'url' => $this->baseUrl . '/json-api/version',
            'http_status' => $this->lastHttpStatus,
            'error' => $this->lastError,
            'verify_ssl' => $this->verifySsl,
            'token_configured' => trim($this->token) !== '',
            'hint' => $this->connectionHint(),
        ], $extra);
    }

    private function probeTcp(): array
    {
        $host = $this->server->hostname;
        $port = $this->port;
        $errno = 0;
        $errstr = '';

        $socket = @stream_socket_client(
            "tcp://{$host}:{$port}",
            $errno,
            $errstr,
            12,
            STREAM_CLIENT_CONNECT
        );

        if ($socket) {
            fclose($socket);

            return [
                'ok' => true,
                'message' => "Porta {$port} acessível em {$host}",
            ];
        }

        $message = $errstr ?: "Conexão recusada ou timeout em {$host}:{$port}";

        return [
            'ok' => false,
            'errno' => $errno,
            'error' => $message,
            'hint' => 'O servidor CentralVix não consegue alcançar a porta 2087. Verifique firewall, DNS e se o IP do CentralVix está liberado no WHM.',
        ];
    }

    private function parseWhmVersion(?array $response): ?string
    {
        if (!$response) {
            return null;
        }

        return $response['data']['version']
            ?? $response['data']['versionnum']
            ?? $response['version']
            ?? null;
    }

    private function isSslError(): bool
    {
        $err = strtolower((string) $this->lastError);

        return str_contains($err, 'ssl')
            || str_contains($err, 'certificate')
            || str_contains($err, 'curl error 60')
            || str_contains($err, 'curl error 35')
            || str_contains($err, 'unable to get local issuer');
    }

    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    private function connectionHint(): string
    {
        if ($this->isSslError()) {
            return 'Certificado SSL do WHM inválido ou autoassinado. Desative "Verificar certificado SSL" no formulário do servidor e salve.';
        }
        if ($this->lastHttpStatus === 401 || $this->lastHttpStatus === 403) {
            return 'Token inválido ou sem permissão. Verifique o token WHM e se o IP do CentralVix está liberado em WHM → Restrições de IP da API.';
        }
        if ($this->lastHttpStatus === 400 && str_contains((string) $this->lastError, 'JSON')) {
            return 'Erro de formato na API WHM. Atualize o CentralVix e tente novamente.';
        }
        if ($this->lastHttpStatus === 0 || $this->lastHttpStatus === null) {
            $err = strtolower((string) $this->lastError);
            if (str_contains($err, 'curl error 7') || str_contains($err, 'could not resolve')) {
                return 'Hostname não resolve ou servidor inacessível. Confirme DNS, firewall e se a porta 2087 está aberta.';
            }
            if (str_contains($err, 'timed out') || str_contains($err, 'timeout')) {
                return 'Timeout na conexão. O IP do CentralVix pode estar bloqueado no firewall do WHM.';
            }
        }

        return 'Confirme hostname, porta 2087, token WHM válido e IP do CentralVix liberado no WHM.';
    }

    /**
     * List DNS records for the primary domain zone.
     */
    public function listDnsRecords(Service $service): array
    {
        $response = $this->cpanelApi($service, 'ZoneEdit', 'fetchzone_records', [
            'domain' => $service->domain,
        ]);

        $records = $response['cpanelresult']['data'] ?? [];

        return collect($records)->map(function ($row) {
            return [
                'line' => (int) ($row['line'] ?? $row['Line'] ?? 0),
                'type' => $row['type'] ?? $row['record_type'] ?? '',
                'name' => $row['name'] ?? $row['record'] ?? '',
                'address' => $row['address'] ?? $row['value'] ?? $row['cname'] ?? $row['exchange'] ?? '',
                'ttl' => (int) ($row['ttl'] ?? 14400),
                'raw' => $row,
            ];
        })->filter(fn ($r) => $r['line'] > 0)->values()->all();
    }

    /**
     * List email accounts (POP/IMAP).
     */
    public function listEmailAccounts(Service $service): array
    {
        $response = $this->cpanelApi($service, 'Email', 'listpops');

        $rows = $response['cpanelresult']['data'] ?? [];

        return collect($rows)->map(function ($row) {
            $email = $row['email'] ?? $row['login'] ?? '';

            return [
                'email' => $email,
                'local_part' => $row['user'] ?? strtok($email, '@'),
                'domain' => $row['domain'] ?? '',
                'quota_mb' => (int) ($row['diskquota'] ?? $row['quota'] ?? 0),
                'used_mb' => (int) ($row['diskused'] ?? 0),
            ];
        })->values()->all();
    }

    /**
     * Delete an email account.
     */
    public function deleteEmailAccount(Service $service, string $email): bool
    {
        $local = str_contains($email, '@') ? explode('@', $email, 2)[0] : $email;

        $response = $this->cpanelApi($service, 'Email', 'delpop', [
            'email' => $local,
            'domain' => $service->domain,
        ], 'POST');

        return $this->cpanelSuccess($response);
    }

    /**
     * Change email account password.
     */
    public function changeEmailPassword(Service $service, string $email, string $password): bool
    {
        $local = str_contains($email, '@') ? explode('@', $email, 2)[0] : $email;

        $response = $this->cpanelApi($service, 'Email', 'passwdpop', [
            'email' => $local,
            'domain' => $service->domain,
            'password' => $password,
        ], 'POST');

        return $this->cpanelSuccess($response);
    }

    /**
     * List FTP accounts (inclui conta principal).
     */
    public function listFtpAccounts(Service $service): array
    {
        $response = $this->cpanelApi($service, 'Ftp', 'list_ftp');

        $rows = $response['cpanelresult']['data'] ?? [];

        return collect($rows)->map(function ($row) use ($service) {
            $user = $row['user'] ?? $row['login'] ?? '';

            return [
                'user' => $user,
                'directory' => $row['dir'] ?? $row['homedir'] ?? '/',
                'is_main' => $user === $service->username,
            ];
        })->values()->all();
    }

    /**
     * Create additional FTP account.
     */
    public function createFtpAccount(Service $service, string $user, string $password, string $directory = ''): bool
    {
        $response = $this->cpanelApi($service, 'Ftp', 'add_ftp', array_filter([
            'user' => $user,
            'pass' => $password,
            'quota' => 0,
            'homedir' => $directory ?: 'public_html',
        ]), 'POST');

        return $this->cpanelSuccess($response);
    }

    /**
     * Delete FTP account (não remove a conta principal).
     */
    public function deleteFtpAccount(Service $service, string $user): bool
    {
        if ($user === $service->username) {
            return false;
        }

        $response = $this->cpanelApi($service, 'Ftp', 'delete_ftp', [
            'user' => $user,
            'destroy' => 1,
        ], 'POST');

        return $this->cpanelSuccess($response);
    }

    /**
     * List installed SSL certificates / hosts.
     */
    public function listSslCertificates(Service $service): array
    {
        $response = $this->cpanelApi($service, 'SSL', 'installed_hosts');

        $rows = $response['cpanelresult']['data'] ?? [];

        return collect($rows)->map(function ($row) {
            return [
                'domain' => $row['domain'] ?? $row['servername'] ?? '',
                'issuer' => $row['issuer_organization'] ?? $row['issuer_commonName'] ?? '—',
                'expires' => $row['not_after'] ?? $row['expires'] ?? null,
                'is_self_signed' => (bool) ($row['is_self_signed'] ?? false),
                'status' => $row['status'] ?? 'active',
            ];
        })->values()->all();
    }

    /**
     * Trigger AutoSSL check for the account.
     */
    public function runAutoSsl(Service $service): bool
    {
        $response = $this->cpanelApi($service, 'SSL', 'start_autossl_check', [], 'POST');

        return $this->cpanelSuccess($response);
    }

    /**
     * Create email account
     */
    public function createEmailAccount(Service $service, string $email, string $password, int $quota = 250): bool
    {
        $local = str_contains($email, '@') ? explode('@', $email, 2)[0] : $email;

        $response = $this->cpanelApi($service, 'Email', 'addpop', [
            'email' => $local,
            'password' => $password,
            'quota' => $quota,
        ], 'POST');

        return $this->cpanelSuccess($response);
    }

    /**
     * Create database
     */
    public function createDatabase(Service $service, string $dbName): bool
    {
        $response = $this->request('POST', '/json-api/cpanel', [
            'cpanel_jsonapi_user' => $service->username,
            'cpanel_jsonapi_apiversion' => 2,
            'cpanel_jsonapi_module' => 'Mysql',
            'cpanel_jsonapi_func' => 'createdb',
            'db' => $dbName,
        ]);

        return isset($response['cpanelresult']['data'][0]['result']) 
            && $response['cpanelresult']['data'][0]['result'] == 1;
    }

    /**
     * Create a temporary cPanel login session (SSO via WHM API).
     */
    public function createLoginSession(Service $service, string $serviceType = 'cpaneld'): ?string
    {
        if (!$service->username) {
            return null;
        }

        $response = $this->request('GET', '/json-api/create_user_session', [
            'user' => $service->username,
            'service' => $serviceType,
        ]);

        if ($response && ($response['metadata']['result'] ?? 0) == 1) {
            return $response['data']['url'] ?? null;
        }

        Log::error('cPanel SSO session failed', [
            'username' => $service->username,
            'response' => $response,
        ]);

        return null;
    }

    /**
     * cPanel JSON API v2 wrapper.
     */
    private function cpanelApi(Service $service, string $module, string $func, array $params = [], string $method = 'GET'): ?array
    {
        $payload = array_merge([
            'cpanel_jsonapi_user' => $service->username,
            'cpanel_jsonapi_apiversion' => 2,
            'cpanel_jsonapi_module' => $module,
            'cpanel_jsonapi_func' => $func,
        ], $params);

        return $this->request($method, '/json-api/cpanel', $payload);
    }

    private function cpanelSuccess(?array $response): bool
    {
        return isset($response['cpanelresult']['data'][0]['result'])
            && (int) $response['cpanelresult']['data'][0]['result'] === 1;
    }

    /**
     * Make HTTP request to WHM API
     */
    private function request(string $method, string $endpoint, array $params = [], ?bool $verifySsl = null): ?array
    {
        $verify = $verifySsl ?? $this->verifySsl;

        try {
            $username = trim($this->server->username ?? '') ?: 'root';
            $headers = [
                'Authorization' => 'whm ' . $username . ':' . $this->token,
            ];

            $request = Http::withHeaders($headers)
                ->withOptions([
                    'verify' => $verify,
                    'connect_timeout' => 15,
                    'timeout' => 60,
                ]);

            $url = $this->baseUrl . $endpoint;
            $method = strtoupper($method);

            $response = match ($method) {
                'GET' => $request->get($url, $params),
                'POST' => $request->asForm()->post($url, $params),
                default => $request->asForm()->send($method, $url, ['form_params' => $params]),
            };

            if ($response->successful()) {
                $body = $response->body();
                $json = $response->json();
                if (!is_array($json)) {
                    $this->lastHttpStatus = $response->status();
                    $snippet = trim(preg_replace('/\s+/', ' ', strip_tags($body)));
                    $this->lastError = 'WHM retornou resposta inválida (HTTP '
                        . $response->status() . '): '
                        . substr($snippet, 0, 220);

                    return null;
                }

                return $json;
            }

            $this->lastHttpStatus = $response->status();
            $body = $response->body();
            $json = $response->json();
            if (!is_array($json)) {
                $json = [];
            }
            $this->lastError = $json['metadata']['reason']
                ?? $json['error']
                ?? $json['cpanelresult']['error']
                ?? (strlen($body) > 300 ? substr($body, 0, 300) . '...' : $body)
                ?: "HTTP {$response->status()}";

            Log::error('cPanel API error', [
                'endpoint' => $endpoint,
                'status' => $response->status(),
                'body' => $body,
                'verify_ssl' => $verify,
            ]);

        } catch (\Throwable $e) {
            $this->lastHttpStatus = 0;
            $this->lastError = $e->getMessage();
            Log::error('cPanel request exception', [
                'endpoint' => $endpoint,
                'error' => $e->getMessage(),
                'verify_ssl' => $verify,
            ]);
        }

        return null;
    }

    /**
     * Generate username from service domain
     */
    private function generateUsername(Service $service): string
    {
        $domain = $service->domain ?? ('svc' . $service->id);
        $base   = strtolower(preg_replace('/[^a-z0-9]/', '', explode('.', $domain)[0]));
        return substr($base, 0, 8) . rand(100, 999);
    }

    /**
     * Generate secure random password
     */
    private function generatePassword(int $length = 16): string
    {
        return Str::password($length);
    }
}
