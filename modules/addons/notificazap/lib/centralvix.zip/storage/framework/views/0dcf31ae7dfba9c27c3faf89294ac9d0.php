<script>
(function () {
    var modal = document.getElementById('cx-notify-modal');
    if (!modal) return;

    var messageEl = document.getElementById('cx-notify-message');
    var clientIdEl = document.getElementById('cx-notify-client-id');
    var templateIdEl = document.getElementById('cx-notify-template-id');
    var clientNameEl = document.getElementById('cx-notify-client-name');
    var sendBtn = document.getElementById('cx-notify-send');
    var notifyUrlTemplate = <?php echo json_encode(route('admin.clients.notify', ['client' => '__ID__']), 512) ?>;

    function openModal(btn) {
        clientIdEl.value = btn.dataset.clientId;
        clientNameEl.textContent = btn.dataset.clientName;
        messageEl.value = '';
        templateIdEl.value = '';
        document.querySelectorAll('.cx-template-item').forEach(function (el) { el.classList.remove('bg-primary/10', 'ring-1', 'ring-primary/30'); });
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';
    }

    function closeModal() {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        document.body.style.overflow = '';
    }

    document.querySelectorAll('.cx-notify-btn').forEach(function (btn) {
        btn.addEventListener('click', function () { openModal(btn); });
    });

    document.querySelectorAll('[data-cx-notify-close]').forEach(function (el) {
        el.addEventListener('click', closeModal);
    });

    document.querySelectorAll('.cx-template-item').forEach(function (item) {
        item.addEventListener('click', function () {
            document.querySelectorAll('.cx-template-item').forEach(function (el) { el.classList.remove('bg-primary/10', 'ring-1', 'ring-primary/30'); });
            item.classList.add('bg-primary/10', 'ring-1', 'ring-primary/30');
            messageEl.value = item.dataset.templateMessage;
            templateIdEl.value = item.dataset.templateId;
        });
    });

    document.querySelectorAll('.cx-insert-var').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var v = btn.dataset.var;
            var start = messageEl.selectionStart;
            var end = messageEl.selectionEnd;
            var text = messageEl.value;
            messageEl.value = text.substring(0, start) + v + text.substring(end);
            messageEl.focus();
            messageEl.selectionStart = messageEl.selectionEnd = start + v.length;
        });
    });

    sendBtn?.addEventListener('click', async function () {
        var message = messageEl.value.trim();
        if (message.length < 10) {
            window.cxToast?.warning('Mensagem muito curta', 'Escreva pelo menos 10 caracteres.');
            return;
        }
        var channel = document.querySelector('input[name="cx-notify-channel"]:checked')?.value || 'whatsapp';
        var clientId = clientIdEl.value;
        var label = sendBtn.querySelector('[data-label]');
        sendBtn.disabled = true;
        if (label) label.textContent = 'Enviando…';

        try {
            var url = notifyUrlTemplate.replace('__ID__', encodeURIComponent(clientId));
            var res = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': window.cxCsrf()
                },
                body: JSON.stringify({
                    message: message,
                    template_id: templateIdEl.value || null,
                    channel: channel
                })
            });
            var data = await res.json();
            if (data.success) {
                window.cxToast?.success(data.message);
                closeModal();
            } else {
                window.cxToast?.error(data.message || 'Falha ao enviar.');
            }
        } catch (e) {
            window.cxToast?.error('Erro de conexão ao enviar notificação.');
        } finally {
            sendBtn.disabled = false;
            if (label) label.textContent = 'Enviar Notificação';
        }
    });
})();
</script>
<?php /**PATH /home/centralvixcom/public_html/resources/views/admin/clients/partials/notify-scripts.blade.php ENDPATH**/ ?>