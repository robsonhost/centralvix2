
<?php if($paginator->hasPages()): ?>
<div class="cx-table-footer">
    <p class="text-xs text-muted-foreground">
        Exibindo <strong><?php echo e($paginator->firstItem()); ?></strong>–<strong><?php echo e($paginator->lastItem()); ?></strong>
        de <strong><?php echo e($paginator->total()); ?></strong>
    </p>
    <?php echo e($paginator->withQueryString()->links('pagination.cx-v2')); ?>

</div>
<?php endif; ?>
<?php /**PATH /home/centralvixcom/public_html/resources/views/admin/partials/v2-table-footer.blade.php ENDPATH**/ ?>