
<?php $b = $branding ?? branding(); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="cx-html">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <script>
        (function () {
            try {
                var t = localStorage.getItem('cx-theme');
                var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                if (t === 'dark' || (!t && prefersDark)) {
                    document.documentElement.classList.add('dark');
                }
            } catch (e) {}
        })();
    </script>

    
    <?php echo $__env->make('partials.pwa-meta', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.branding-theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.responsive-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <title><?php echo $__env->yieldContent('title', 'Acesso'); ?> — <?php echo e($b['company_name'] ?? 'CentralVix'); ?></title>

    
    <?php echo $__env->make('partials.cx-assets', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <style>
        .cx-auth-hero {
            background-image: linear-gradient(
                135deg,
                var(--login-gradient-start, oklch(0.55 0.24 275)) 0%,
                var(--login-gradient-end, oklch(0.53 0.24 305)) 100%
            );
        }
        /* Fallback caso o CSS do Vite ainda não tenha sido buildado */
        .cx-app { font-family: 'Inter', ui-sans-serif, system-ui, sans-serif; }
    </style>

    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="cx-app cx-scrollbar min-h-screen antialiased">
    
    <button
        type="button"
        id="cx-theme-toggle"
        class="fixed bottom-4 right-4 z-50 grid size-10 place-items-center rounded-full border bg-card text-foreground shadow-elevated transition hover:bg-accent"
        aria-label="Alternar tema"
        title="Alternar tema claro/escuro"
    >
        <svg data-icon="sun" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="hidden dark:block"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
        <svg data-icon="moon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="block dark:hidden"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
    </button>

    
    <div id="cx-toasts" class="pointer-events-none fixed top-4 right-4 z-[100] flex w-full max-w-sm flex-col gap-2" aria-live="polite" aria-atomic="true"></div>

    
    <main class="relative">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <script>
        (function () {
            // ---------- Dark mode toggle ----------
            var toggle = document.getElementById('cx-theme-toggle');
            if (toggle) {
                toggle.addEventListener('click', function () {
                    var html = document.documentElement;
                    var isDark = html.classList.toggle('dark');
                    try { localStorage.setItem('cx-theme', isDark ? 'dark' : 'light'); } catch (e) {}
                });
            }

            // ---------- Toast API ----------
            var host = document.getElementById('cx-toasts');
            var variants = {
                success: { border: 'var(--success)',     icon: '\u2713' },
                error:   { border: 'var(--destructive)', icon: '\u2715' },
                warning: { border: 'var(--warning)',     icon: '!'      },
                info:    { border: 'var(--info)',        icon: 'i'      }
            };

            function makeToast(opts) {
                opts = opts || {};
                var v = variants[opts.variant] || variants.info;
                var el = document.createElement('div');
                el.className = 'pointer-events-auto animate-cx-slide-in-right rounded-lg border bg-card shadow-elevated px-4 py-3 flex items-start gap-3 text-sm';
                el.style.borderLeft = '4px solid ' + v.border;
                el.setAttribute('role', 'status');

                var badge = document.createElement('div');
                badge.className = 'grid size-6 place-items-center rounded-full text-xs font-bold text-white shrink-0';
                badge.style.background = v.border;
                badge.textContent = v.icon;

                var body = document.createElement('div');
                body.className = 'flex-1 min-w-0';
                if (opts.title) {
                    var t = document.createElement('div');
                    t.className = 'font-semibold text-foreground';
                    t.textContent = opts.title;
                    body.appendChild(t);
                }
                if (opts.description) {
                    var d = document.createElement('div');
                    d.className = 'text-muted-foreground';
                    d.textContent = opts.description;
                    body.appendChild(d);
                }

                var close = document.createElement('button');
                close.type = 'button';
                close.className = 'text-muted-foreground hover:text-foreground shrink-0';
                close.setAttribute('aria-label', 'Fechar');
                close.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
                close.addEventListener('click', function () { remove(); });

                el.appendChild(badge);
                el.appendChild(body);
                el.appendChild(close);
                host.appendChild(el);

                var timer = setTimeout(remove, opts.duration || 4500);
                function remove() {
                    clearTimeout(timer);
                    el.style.transition = 'opacity 180ms ease, transform 180ms ease';
                    el.style.opacity = '0';
                    el.style.transform = 'translateX(12px)';
                    setTimeout(function () { el.remove(); }, 200);
                }
            }

            window.cxToast = makeToast;
            window.cxToast.success = function (title, description) { makeToast({ variant: 'success', title: title, description: description }); };
            window.cxToast.error   = function (title, description) { makeToast({ variant: 'error',   title: title, description: description }); };
            window.cxToast.warning = function (title, description) { makeToast({ variant: 'warning', title: title, description: description }); };
            window.cxToast.info    = function (title, description) { makeToast({ variant: 'info',    title: title, description: description }); };

            // ---------- Flash messages do Laravel -> toast ----------
            <?php if(session('success')): ?>
                window.cxToast.success(<?php echo json_encode(session('success'), 15, 512) ?>);
            <?php endif; ?>
            <?php if(session('error')): ?>
                window.cxToast.error(<?php echo json_encode(session('error'), 15, 512) ?>);
            <?php endif; ?>
            <?php if(session('warning')): ?>
                window.cxToast.warning(<?php echo json_encode(session('warning'), 15, 512) ?>);
            <?php endif; ?>
            <?php if(session('info')): ?>
                window.cxToast.info(<?php echo json_encode(session('info'), 15, 512) ?>);
            <?php endif; ?>

            // ---------- Helper: CSRF header em fetch ----------
            window.cxCsrf = function () {
                var m = document.querySelector('meta[name="csrf-token"]');
                return m ? m.getAttribute('content') : '';
            };
        })();
    </script>

    
    <script src="<?php echo e(url('/js/pwa-register.js')); ?>?v=1"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/centralvixcom/public_html/resources/views/layouts/auth-v2.blade.php ENDPATH**/ ?>