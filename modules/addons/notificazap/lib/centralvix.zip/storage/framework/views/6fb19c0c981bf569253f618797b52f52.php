<?php $__env->startSection('title', 'NFS-e - Notas Fiscais de Serviço'); ?>
<?php $__env->startSection('page-title', 'NFS-e - Notas Fiscais'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="text-foreground font-medium">NFS-e</li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>
<?php echo $__env->make('admin.partials.v2-kit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<div class="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
    <?php
        $statCards = [
            ['label' => 'Total', 'value' => $stats['total'], 'color' => 'purple'],
            ['label' => 'Emitidas', 'value' => $stats['issued'], 'color' => 'green'],
            ['label' => 'Pendentes', 'value' => $stats['pending'], 'color' => 'orange'],
            ['label' => 'Canceladas', 'value' => $stats['cancelled'], 'color' => 'red'],
        ];
        $palettes = [
            'purple' => 'bg-brand-purple/10 text-brand-purple ring-brand-purple/20',
            'green'  => 'bg-brand-green/10 text-brand-green ring-brand-green/20',
            'orange' => 'bg-brand-yellow/15 text-brand-yellow ring-brand-yellow/20',
            'red'    => 'bg-brand-red/10 text-brand-red ring-brand-red/20',
        ];
    ?>
    <?php $__currentLoopData = $statCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="rounded-2xl border bg-card p-4 shadow-card transition hover:-translate-y-0.5 hover:shadow-elevated sm:p-5">
        <div class="flex items-center gap-3">
            <div class="grid size-9 shrink-0 place-items-center rounded-xl ring-1 <?php echo e($palettes[$card['color']]); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg>
            </div>
            <div>
                <p class="text-xs font-medium text-muted-foreground"><?php echo e($card['label']); ?></p>
                <p class="text-xl font-bold text-foreground"><?php echo e(number_format($card['value'], 0, ',', '.')); ?></p>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="mb-6 rounded-2xl border bg-card p-4 shadow-card sm:p-5">
    <div class="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <form method="GET" class="grid flex-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 lg:items-end">
            <div class="sm:col-span-2">
                <label class="mb-1.5 block text-xs font-semibold text-muted-foreground">Buscar</label>
                <input type="text" name="search" class="cx-field" placeholder="Número, chave ou cliente..." value="<?php echo e(request('search')); ?>">
            </div>
            <div>
                <label class="mb-1.5 block text-xs font-semibold text-muted-foreground">Status</label>
                <select name="status" class="cx-field">
                    <option value="">Todos os status</option>
                    <?php $__currentLoopData = ['pending' => 'Pendente', 'processing' => 'Processando', 'issued' => 'Emitida', 'cancelled' => 'Cancelada', 'error' => 'Erro']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($val); ?>" <?php if(request('status') === $val): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="flex gap-2 sm:col-span-2 lg:col-span-3">
                <button type="submit" class="inline-flex items-center gap-2 rounded-lg bg-gradient-primary px-4 py-2 text-sm font-semibold text-white shadow-glow hover:opacity-95">Filtrar</button>
                <?php if(request()->hasAny(['search', 'status'])): ?>
                <a href="<?php echo e(route('admin.nfse.index')); ?>" class="inline-flex items-center gap-2 rounded-lg border bg-card px-4 py-2 text-sm font-semibold hover:bg-accent">Limpar</a>
                <?php endif; ?>
            </div>
        </form>
        <a href="<?php echo e(route('admin.nfse.settings')); ?>" class="inline-flex items-center gap-2 rounded-lg border bg-card px-4 py-2 text-sm font-semibold hover:bg-accent">
            Configurações
        </a>
    </div>
</div>


<div class="overflow-hidden rounded-2xl border bg-card shadow-card">
    <div class="flex items-center justify-between border-b px-5 py-4">
        <h2 class="text-sm font-bold text-foreground">Notas Fiscais</h2>
        <span class="rounded-full bg-muted px-2.5 py-0.5 text-[11px] font-bold text-muted-foreground"><?php echo e($nfses->total()); ?> notas</span>
    </div>

    <?php if($nfses->count() > 0): ?>
    <div class="overflow-x-auto">
        <table class="cx-admin-table w-full min-w-[900px] text-sm">
            <thead>
                <tr class="border-b bg-muted/40 text-left text-xs font-bold uppercase tracking-wide text-muted-foreground">
                    <th class="px-5 py-3">Número</th>
                    <th class="px-5 py-3">Fatura</th>
                    <th class="px-5 py-3">Cliente</th>
                    <th class="px-5 py-3">Valor</th>
                    <th class="px-5 py-3">Emissão</th>
                    <th class="px-5 py-3">Status</th>
                    <th class="px-5 py-3 text-right">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $nfses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nfse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $statusBadge = match($nfse->status) {
                        'pending' => 'cx-badge-pending',
                        'processing' => 'cx-badge-info',
                        'issued' => 'cx-badge-paid',
                        'cancelled', 'error' => 'cx-badge-failed',
                        default => 'cx-badge-muted',
                    };
                    $statusLabels = [
                        'pending' => 'Pendente', 'processing' => 'Processando', 'issued' => 'Emitida',
                        'cancelled' => 'Cancelada', 'error' => 'Erro',
                    ];
                ?>
                <tr class="border-b hover:bg-muted/20">
                    <td class="px-5 py-3">
                        <div class="font-bold text-foreground"><?php echo e($nfse->nfe_number ?? 'Aguardando'); ?></div>
                        <?php if($nfse->nfe_series): ?><div class="text-xs text-muted-foreground">Série: <?php echo e($nfse->nfe_series); ?></div><?php endif; ?>
                    </td>
                    <td class="px-5 py-3">
                        <a href="<?php echo e(route('admin.invoices.show', $nfse->invoice_id)); ?>" class="font-semibold text-primary hover:underline">#<?php echo e($nfse->invoice_id); ?></a>
                    </td>
                    <td class="px-5 py-3">
                        <a href="<?php echo e(route('admin.clients.show', $nfse->client_id)); ?>" class="text-sm hover:text-foreground"><?php echo e($nfse->client->name); ?></a>
                    </td>
                    <td class="px-5 py-3 font-bold">R$ <?php echo e(number_format($nfse->amount, 2, ',', '.')); ?></td>
                    <td class="px-5 py-3 text-xs text-muted-foreground">
                        <?php if($nfse->issued_at): ?>
                        <div><?php echo e($nfse->issued_at->format('d/m/Y H:i')); ?></div>
                        <div><?php echo e($nfse->issued_at->diffForHumans()); ?></div>
                        <?php else: ?> — <?php endif; ?>
                    </td>
                    <td class="px-5 py-3">
                        <span class="inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase <?php echo e($statusBadge); ?>"><?php echo e($statusLabels[$nfse->status] ?? $nfse->status); ?></span>
                    </td>
                    <td class="px-5 py-3 text-right">
                        <div class="inline-flex gap-1">
                            <a href="<?php echo e(route('admin.nfse.show', $nfse)); ?>" class="inline-flex size-8 items-center justify-center rounded-lg border hover:bg-accent" title="Visualizar">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                            </a>
                            <?php if($nfse->isIssued()): ?>
                            <a href="<?php echo e(route('admin.nfse.pdf', $nfse)); ?>" class="inline-flex size-8 items-center justify-center rounded-lg border border-success/30 text-success hover:bg-success/10" title="Download PDF" target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg>
                            </a>
                            <a href="<?php echo e(route('admin.nfse.xml', $nfse)); ?>" class="inline-flex size-8 items-center justify-center rounded-lg border hover:bg-accent" title="Download XML" target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>
                            </a>
                            <?php if($nfse->canCancel()): ?>
                            <button type="button" onclick="cancelNfse(<?php echo e($nfse->id); ?>)" class="inline-flex size-8 items-center justify-center rounded-lg border border-destructive/30 text-destructive hover:bg-destructive/10" title="Cancelar">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg>
                            </button>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo $__env->make('admin.partials.v2-table-footer', ['paginator' => $nfses], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
    <div class="px-6 py-16 text-center">
        <div class="mx-auto mb-4 grid size-16 place-items-center rounded-2xl bg-muted text-muted-foreground">
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg>
        </div>
        <h3 class="text-lg font-bold text-foreground">Nenhuma NFS-e encontrada</h3>
        <p class="mt-1 text-sm text-muted-foreground">As notas fiscais emitidas aparecerão aqui.</p>
        <a href="<?php echo e(route('admin.nfse.settings')); ?>" class="mt-6 inline-flex items-center gap-2 rounded-lg bg-gradient-primary px-4 py-2 text-sm font-semibold text-white shadow-glow hover:opacity-95">
            Configurar NFS-e
        </a>
    </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('admin.partials.v2-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script>
function cancelNfse(nfseId) {
    Swal.fire({
        title: 'Cancelar NFS-e',
        input: 'textarea',
        inputLabel: 'Motivo do Cancelamento (mínimo 15 caracteres)',
        inputPlaceholder: 'Digite o motivo do cancelamento...',
        showCancelButton: true,
        confirmButtonText: 'Cancelar NFS-e',
        cancelButtonText: 'Fechar',
        confirmButtonColor: '#d33',
        preConfirm: (motivo) => {
            if (!motivo || motivo.length < 15) {
                Swal.showValidationMessage('O motivo deve ter no mínimo 15 caracteres');
                return false;
            }
            return motivo;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({ title: 'Cancelando...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

            fetch(`/admin/nfse/${nfseId}/cancel`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ motivo: result.value })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire('Sucesso!', data.message, 'success').then(() => location.reload());
                } else {
                    Swal.fire('Erro', data.message, 'error');
                }
            })
            .catch(() => Swal.fire('Erro', 'Erro ao cancelar NFS-e', 'error'));
        }
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app-v2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/centralvixcom/public_html/resources/views/admin/nfse/index.blade.php ENDPATH**/ ?>