<?php

namespace App\Support;

use App\Models\Product;

class HostingRules
{
    public static function productRequiresDomain(?Product $product): bool
    {
        if (!$product) {
            return false;
        }

        return in_array($product->type, ['hosting', 'reseller', 'streaming_audio', 'streaming_video'], true);
    }

    /**
     * @return array<int, string|\Illuminate\Contracts\Validation\ValidationRule>
     */
    public static function domainValidationRules(?Product $product): array
    {
        if (!self::productRequiresDomain($product)) {
            return ['nullable', 'string', 'max:255'];
        }

        return [
            'required',
            'string',
            'max:255',
            'regex:/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/i',
        ];
    }

    public static function normalizeDomain(?string $domain): ?string
    {
        if ($domain === null) {
            return null;
        }

        $domain = strtolower(trim($domain));
        $domain = preg_replace('/^https?:\/\//', '', $domain);
        $domain = rtrim($domain, '/');

        return $domain !== '' ? $domain : null;
    }
}
