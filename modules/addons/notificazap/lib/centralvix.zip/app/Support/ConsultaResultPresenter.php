<?php

namespace App\Support;

use App\Models\ConsultaLog;
use Illuminate\Support\Str;

/**
 * Normaliza respostas de consultas (confere.link e genéricas) para exibição completa na UI.
 */
class ConsultaResultPresenter
{
    private const META_KEYS = [
        '_demo', '_format', '_html', '_path', '_size', '_filename', 'message', 'consulta', 'categoria', 'parametro', 'consulted_at',
    ];

    private const KNOWN_ROOT_KEYS = [
        'CADASTRAIS', 'ENDERECOS', 'ENDERECO', 'TELEFONES', 'EMAILS', 'EMPRESA', 'SOCIOS',
        'SCORE', 'PONTUACAO', 'DEBITOS', 'PROTESTOS', 'RESULTADO', 'TOTAL',
        'DOCUMENTO', 'NOME', 'RISCO', 'PENDENCIAS_FINANCEIRAS', 'PENDENCIAS',
        'ACOES_JUDICIAIS', 'CHEQUES', 'NOTA', 'INSCRICOES',
        'PARENTES', 'POSSIVEIS_PARENTES', 'VIZINHOS', 'POSSIVEIS_VIZINHOS',
        'REFERENCIA_PROFISSIONAL', 'REFERENCIAS_PROFISSIONAIS', 'HISTORICO_PROFISSIONAL',
        'HISTORICO_ENDERECOS', 'EMPRESAS', 'EMPRESAS_SOCIETARIAS', 'SOCIETARIAS',
        'CONTATOS', 'POSSIVEIS_CONTATOS', 'VEICULOS', 'BENS', 'IMOVEIS',
        'PARTICIPACOES', 'QUADRO_SOCIETARIO', 'SITUACAO_CADASTRAL',
    ];

    private const FIELD_LABELS = [
        'CPF' => 'CPF', 'CNPJ' => 'CNPJ', 'NOME' => 'Nome', 'RAZAO_SOCIAL' => 'Razão Social',
        'FANTASIA' => 'Nome Fantasia', 'NASCIMENTO' => 'Nascimento', 'ABERTURA' => 'Data de Abertura',
        'IDADE' => 'Idade', 'SEXO' => 'Sexo', 'MAE' => 'Mãe', 'PAI' => 'Pai', 'RG' => 'RG',
        'CBO' => 'Profissão (CBO)', 'NIT' => 'NIT', 'TITULO_ELEITOR' => 'Título de Eleitor',
        'SITUACAO' => 'Situação Cadastral', 'NATUREZA_JURIDICA' => 'Natureza Jurídica',
        'ATIVIDADE_PRINCIPAL' => 'Atividade Principal', 'CAPITAL_SOCIAL' => 'Capital Social',
        'PORTE' => 'Porte', 'EMAIL' => 'E-mail', 'TELEFONE' => 'Telefone',
        'ESCOLARIDADE' => 'Escolaridade', 'NACIONALIDADE' => 'Nacionalidade',
        'ORGAO_EMISSOR' => 'Órgão Emissor', 'UF_EMISSOR' => 'UF Emissor', 'ESTADO_EMISSOR' => 'Estado Emissor',
        'REGISTRO_OBITO' => 'Registro de Óbito', 'OBITO' => 'Óbito',
        'CLASSE_ECONOMICA' => 'Classe Econômica', 'RENDA' => 'Renda', 'SALARIO' => 'Faixa Salarial',
        'FAIXA_SALARIAL' => 'Faixa Salarial', 'PROFISSAO' => 'Profissão', 'OCUPACAO' => 'Ocupação',
        'ESTADO_CIVIL' => 'Estado Civil', 'SIGNO' => 'Signo', 'PIS' => 'PIS/PASEP',
        'LOGRADOURO' => 'Logradouro', 'NUMERO' => 'Número', 'COMPLEMENTO' => 'Complemento',
        'BAIRRO' => 'Bairro', 'CIDADE' => 'Cidade', 'UF' => 'UF', 'CEP' => 'CEP',
        'DDD' => 'DDD', 'TIPO' => 'Tipo', 'OPERADORA' => 'Operadora', 'CLASSIFICACAO' => 'Classificação',
        'PARENTESCO' => 'Parentesco', 'RELACAO' => 'Relação', 'VINCULO' => 'Vínculo',
        'EMPRESA' => 'Empresa', 'CARGO' => 'Cargo', 'ADMISSAO' => 'Admissão', 'DEMISSAO' => 'Demissão',
        'RESCISAO' => 'Rescisão', 'ANO_BASE' => 'Ano Base', 'PARTICIPACAO' => 'Participação',
        'QUALIFICACAO' => 'Qualificação', 'VALOR' => 'Valor', 'SCORE' => 'Score',
        'NUMERO' => 'Número', 'NATUREZA' => 'Natureza', 'DATA' => 'Data', 'STATUS' => 'Status',
    ];

    private const SECTION_META = [
        'cadastrais'              => ['title' => 'Dados Cadastrais', 'icon' => 'fa-user-shield'],
        'empresa'                 => ['title' => 'Dados da Empresa', 'icon' => 'fa-building'],
        'enderecos'               => ['title' => 'Endereços', 'icon' => 'fa-map-marker-alt'],
        'historico_enderecos'     => ['title' => 'Histórico de Endereços', 'icon' => 'fa-route'],
        'telefones'               => ['title' => 'Telefones', 'icon' => 'fa-phone'],
        'emails'                  => ['title' => 'E-mails', 'icon' => 'fa-envelope'],
        'parentes'                => ['title' => 'Possíveis Parentes', 'icon' => 'fa-people-roof'],
        'vizinhos'                => ['title' => 'Possíveis Vizinhos', 'icon' => 'fa-house-user'],
        'referencia_profissional' => ['title' => 'Referência Profissional', 'icon' => 'fa-briefcase'],
        'empresas_societarias'    => ['title' => 'Empresas Societárias', 'icon' => 'fa-city'],
        'contatos'                => ['title' => 'Possíveis Contatos', 'icon' => 'fa-address-book'],
        'socios'                  => ['title' => 'Sócios', 'icon' => 'fa-user-tie'],
        'score'                   => ['title' => 'Score de Crédito', 'icon' => 'fa-chart-bar'],
        'pendencias'              => ['title' => 'Pendências Financeiras', 'icon' => 'fa-money-bill-trend-up'],
        'acoes'                   => ['title' => 'Ações Judiciais', 'icon' => 'fa-gavel'],
        'cheques'                 => ['title' => 'Cheques sem Fundo', 'icon' => 'fa-money-check-dollar'],
        'debitos'                 => ['title' => 'Débitos', 'icon' => 'fa-triangle-exclamation'],
        'protestos'               => ['title' => 'Protestos', 'icon' => 'fa-scale-balanced'],
        'inscricoes'              => ['title' => 'Dívida Ativa da União (PGFN)', 'icon' => 'fa-building-columns'],
        'veiculos'                => ['title' => 'Veículos', 'icon' => 'fa-car'],
        'resultado_lista'         => ['title' => 'Resultados encontrados', 'icon' => 'fa-list-ul'],
    ];

    public function __construct(private ConsultaLog $log) {}

    public static function from(ConsultaLog $log): self
    {
        return new self($log);
    }

    public function format(): ?string
    {
        return is_array($this->log->result) ? ($this->log->result['_format'] ?? 'json') : 'json';
    }

    public function isDemo(): bool
    {
        return (bool) ($this->log->result['_demo'] ?? false);
    }

    public function raw(): array
    {
        return is_array($this->log->result) ? $this->log->result : [];
    }

    public function profile(): array
    {
        $r   = $this->raw();
        $cad = is_array($r['CADASTRAIS'] ?? null) ? $r['CADASTRAIS'] : [];

        $name = $cad['NOME'] ?? $r['NOME'] ?? $cad['RAZAO_SOCIAL'] ?? null;
        if (is_array($name) || is_object($name)) {
            $name = $this->formatValue($name);
        }
        $doc  = $cad['CPF'] ?? $cad['CNPJ'] ?? $r['DOCUMENTO'] ?? $this->log->parameter;
        $doc  = is_string($doc) ? trim($doc) : $this->formatValue($doc);

        $initials = '—';
        if ($name) {
            $parts = preg_split('/\s+/', trim($name), -1, PREG_SPLIT_NO_EMPTY);
            $initials = strtoupper(mb_substr($parts[0] ?? 'X', 0, 1) . mb_substr($parts[count($parts) - 1] ?? 'X', 0, 1));
        }

        $badges = [];
        if (! empty($cad['SEXO'])) {
            $sex = strtoupper($this->formatValue($cad['SEXO']));
            $badges[] = [
                'icon'  => str_starts_with($sex, 'M') ? 'fa-mars' : (str_starts_with($sex, 'F') ? 'fa-venus' : 'fa-genderless'),
                'label' => $this->formatValue($cad['SEXO']),
            ];
        }
        if (! empty($cad['IDADE'])) {
            $badges[] = ['icon' => 'fa-cake-candles', 'label' => $this->formatValue($cad['IDADE']) . ' anos'];
        } elseif (! empty($cad['NASCIMENTO'])) {
            $badges[] = ['icon' => 'fa-calendar', 'label' => $this->formatValue($cad['NASCIMENTO'])];
        }
        if (! empty($cad['NACIONALIDADE'])) {
            $badges[] = ['icon' => 'fa-flag', 'label' => $this->formatValue($cad['NACIONALIDADE'])];
        }
        if (! empty($cad['SITUACAO'])) {
            $badges[] = ['icon' => 'fa-circle-check', 'label' => $this->formatValue($cad['SITUACAO'])];
        }

        return [
            'name'     => $name,
            'document' => $this->formatDocument($doc),
            'initials' => $initials,
            'badges'   => $badges,
        ];
    }

    /** Resumo numérico do resultado (sidebar / cards rápidos). */
    public function resultStats(): array
    {
        $r = $this->raw();
        $phones   = $this->normalizeList($r['TELEFONES'] ?? null);
        $emails   = $this->normalizeList($r['EMAILS'] ?? null);
        $addresses = $this->normalizeList($r['ENDERECOS'] ?? null);
        if (empty($addresses) && ! empty($r['ENDERECO']) && is_array($r['ENDERECO'])) {
            $addresses = [$r['ENDERECO']];
        }
        $relatives = $this->firstPresent($r, ['PARENTES', 'POSSIVEIS_PARENTES']) ?? [];
        $sections  = $this->sections();
        $score     = $this->scoreSummary();

        return [
            'sections'   => count($sections),
            'phones'     => count($phones),
            'emails'     => count($emails),
            'addresses'  => count($addresses),
            'relatives'  => count($relatives),
            'score'      => $score['score'] ?? null,
            'risk'       => $score['risk'] ?? null,
            'risk_badge' => $score['risk_badge'] ?? null,
            'has_data'   => ! empty($sections) || ! empty($this->profile()['name']),
        ];
    }

    /** Índice de seções para navegação rápida. */
    public function sectionNav(): array
    {
        $nav = [];
        foreach ($this->sections() as $section) {
            $nav[] = [
                'anchor' => $section['anchor'] ?? ('sec-' . ($section['key'] ?? 'item')),
                'title'  => $section['title'] ?? 'Seção',
                'icon'   => $section['icon'] ?? 'fa-database',
                'count'  => $section['count'] ?? null,
            ];
        }

        return $nav;
    }

    public function scoreSummary(): ?array
    {
        $r = $this->raw();
        $score = $r['SCORE'] ?? $r['PONTUACAO'] ?? null;
        $risco = $r['RISCO'] ?? null;

        if ($score === null && $risco === null && empty($r['DOCUMENTO']) && empty($r['NOME'])) {
            return null;
        }

        $value = null;
        if (is_array($score)) {
            $value = $score['VALOR'] ?? $score['SCORE'] ?? reset($score);
        } elseif ($score !== null) {
            $value = $score;
        }

        $num = is_numeric($value) ? (int) $value : null;
        $color = $num === null ? '#64748b' : ($num >= 700 ? '#16a34a' : ($num >= 400 ? '#f59e0b' : '#dc2626'));

        $doc = $r['DOCUMENTO'] ?? null;
        $nome = $r['NOME'] ?? null;
        if (is_array($nome) || is_object($nome)) {
            $nome = $this->formatValue($nome);
        }

        return [
            'document'    => $doc ? $this->formatDocument((string) $doc) : null,
            'name'        => $nome,
            'score'       => $num,
            'score_color' => $color,
            'risk'        => is_scalar($risco) ? (string) $risco : $this->formatValue($risco),
            'risk_badge'  => $this->riskBadgeClass(is_scalar($risco) ? (string) $risco : null),
        ];
    }

    /** @return list<array<string, mixed>> */
    public function sections(): array
    {
        $r = $this->raw();
        if ($this->format() !== 'json' || empty($r)) {
            return [];
        }

        $sections = [];

        if ($summary = $this->scoreSummary()) {
            if (! empty($r['CADASTRAIS']) || $summary['score'] !== null) {
                // score card handled separately in view when cad exists
            }
        }

        if (! empty($r['RESULTADO']) && is_array($r['RESULTADO'])) {
            $sections[] = $this->tableSection('resultado_lista', $r['RESULTADO'], $r['TOTAL'] ?? null);
        }

        if (! empty($r['CADASTRAIS']) && is_array($r['CADASTRAIS'])) {
            $sections[] = $this->gridSection('cadastrais', $r['CADASTRAIS']);
        }

        if (! empty($r['EMPRESA']) && is_array($r['EMPRESA'])) {
            $sections[] = $this->gridSection('empresa', $r['EMPRESA']);
        }

        $enderecos = $this->normalizeList($r['ENDERECOS'] ?? null);
        if (empty($enderecos) && ! empty($r['ENDERECO']) && is_array($r['ENDERECO'])) {
            $enderecos = [$r['ENDERECO']];
        }
        $historico = $this->normalizeList($r['HISTORICO_ENDERECOS'] ?? null);
        if (! empty($enderecos)) {
            $sections[] = $this->addressesSection('enderecos', $enderecos);
        }
        if (! empty($historico)) {
            $sections[] = $this->tableSection('historico_enderecos', $historico);
        }

        $telefones = $this->normalizeList($r['TELEFONES'] ?? null);
        if (! empty($telefones)) {
            $sections[] = $this->phonesSection($telefones);
        }

        $emails = $this->normalizeList($r['EMAILS'] ?? null);
        if (! empty($emails)) {
            $sections[] = $this->emailsSection($emails);
        }

        foreach ([
            'parentes' => ['PARENTES', 'POSSIVEIS_PARENTES'],
            'vizinhos' => ['VIZINHOS', 'POSSIVEIS_VIZINHOS'],
            'referencia_profissional' => ['REFERENCIA_PROFISSIONAL', 'REFERENCIAS_PROFISSIONAIS', 'HISTORICO_PROFISSIONAL'],
            'empresas_societarias' => ['EMPRESAS', 'EMPRESAS_SOCIETARIAS', 'SOCIETARIAS', 'PARTICIPACOES'],
            'contatos' => ['CONTATOS', 'POSSIVEIS_CONTATOS'],
            'socios' => ['SOCIOS', 'QUADRO_SOCIETARIO'],
            'pendencias' => ['PENDENCIAS_FINANCEIRAS', 'PENDENCIAS'],
            'acoes' => ['ACOES_JUDICIAIS'],
            'cheques' => ['CHEQUES'],
            'debitos' => ['DEBITOS'],
            'protestos' => ['PROTESTOS'],
            'veiculos' => ['VEICULOS', 'BENS', 'IMOVEIS'],
        ] as $key => $aliases) {
            $data = $this->firstPresent($r, $aliases);
            if ($data !== null) {
                $sections[] = $this->tableSection($key, $data);
            }
        }

        $score = $r['SCORE'] ?? $r['PONTUACAO'] ?? null;
        if ($score !== null && empty($r['CADASTRAIS'])) {
            $sections[] = array_merge($this->sectionMeta('score'), [
                'type'  => 'score',
                'score' => is_array($score) ? ($score['VALOR'] ?? $score['SCORE'] ?? reset($score)) : $score,
            ]);
        }

        $inscricoes = $this->normalizeList($r['INSCRICOES'] ?? null);
        if (! empty($inscricoes)) {
            $total = is_string($r['TOTAL'] ?? null) ? $r['TOTAL'] : null;
            $sections[] = array_merge($this->tableSection('inscricoes', $inscricoes), ['total_badge' => $total]);
        }

        foreach ($this->discoverExtraSections($r) as $extra) {
            $sections[] = $extra;
        }

        return $sections;
    }

    public function label(string $key): string
    {
        $key = strtoupper(trim($key));

        return self::FIELD_LABELS[$key]
            ?? Str::headline(strtolower(str_replace('_', ' ', $key)));
    }

    public function formatValue(mixed $value, string $column = ''): string
    {
        if ($value === null || $value === '') {
            return '—';
        }
        if (is_bool($value)) {
            return $value ? 'Sim' : 'Não';
        }
        if (is_array($value) || is_object($value)) {
            return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        $column = strtoupper(trim($column));
        $text   = (string) $value;

        if (in_array($column, ['CPF', 'CNPJ'], true)) {
            return $this->formatDocument($text);
        }

        return $text;
    }

    public function formatDocument(?string $doc): string
    {
        if (! $doc) {
            return '—';
        }

        $digits = preg_replace('/\D+/', '', $doc);

        if (strlen($digits) === 11) {
            return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $digits);
        }

        if (strlen($digits) === 14) {
            return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $digits);
        }

        return trim($doc);
    }

    private function sectionMeta(string $key): array
    {
        $meta = self::SECTION_META[$key] ?? ['title' => Str::headline($key), 'icon' => 'fa-database'];

        return [
            'key'     => $key,
            'anchor'  => 'sec-' . $key,
            'title'   => $meta['title'],
            'icon'    => $meta['icon'],
        ];
    }

    private function gridSection(string $key, array $data): array
    {
        $fields = [];
        foreach ($data as $k => $v) {
            if (is_array($v) || is_object($v)) {
                if ($this->isAssocArray($v) && $this->isScalarMap($v)) {
                    foreach ($v as $sk => $sv) {
                        $fields[] = ['label' => $this->label($k) . ' — ' . $this->label((string) $sk), 'value' => $sv, 'column' => strtoupper((string) $sk)];
                    }
                }
                continue;
            }
            $fields[] = ['label' => $this->label((string) $k), 'value' => $v, 'column' => strtoupper((string) $k)];
        }

        return array_merge($this->sectionMeta($key), ['type' => 'grid', 'fields' => $fields]);
    }

    private function addressesSection(string $key, array $items): array
    {
        return array_merge($this->sectionMeta($key), ['type' => 'addresses', 'items' => $items, 'count' => count($items)]);
    }

    private function phonesSection(array $telefones): array
    {
        $fixos  = [];
        $moveis = [];
        $outros = [];

        foreach ($telefones as $t) {
            if (! is_array($t)) {
                continue;
            }
            $tipo = strtoupper((string) ($t['TIPO'] ?? ''));
            if (str_contains($tipo, 'FIX') || str_contains($tipo, 'RESID')) {
                $fixos[] = $t;
            } elseif (str_contains($tipo, 'MOV') || str_contains($tipo, 'CEL') || str_contains($tipo, 'MOVEL')) {
                $moveis[] = $t;
            } else {
                $digits = preg_replace('/\D+/', '', (string) ($t['TELEFONE'] ?? ''));
                if (strlen($digits) === 8) {
                    $fixos[] = $t;
                } elseif (strlen($digits) >= 9) {
                    $moveis[] = $t;
                } else {
                    $outros[] = $t;
                }
            }
        }

        if (empty($fixos) && empty($moveis) && ! empty($outros)) {
            $moveis = $outros;
        }

        return array_merge($this->sectionMeta('telefones'), [
            'type'   => 'phones',
            'fixos'  => $fixos,
            'moveis' => $moveis,
            'count'  => count($telefones),
        ]);
    }

    private function emailsSection(array $emails): array
    {
        return array_merge($this->sectionMeta('emails'), [
            'type'  => 'emails',
            'items' => $emails,
            'count' => count($emails),
        ]);
    }

    private function tableSection(string $key, array $rows, mixed $total = null): array
    {
        $rows = $this->normalizeList($rows);
        $table = $this->buildTable($rows);

        return array_merge($this->sectionMeta($key), [
            'type'    => 'table',
            'columns' => $table['columns'],
            'rows'    => $table['rows'],
            'count'   => is_numeric($total) ? (int) $total : count($rows),
            'empty_ok'=> count($rows) === 0,
        ]);
    }

    /** @return list<array<string, mixed>> */
    private function discoverExtraSections(array $r): array
    {
        $sections = [];
        $known = array_merge(self::META_KEYS, self::KNOWN_ROOT_KEYS);

        foreach ($r as $key => $value) {
            if (in_array($key, $known, true) || str_starts_with((string) $key, '_')) {
                continue;
            }
            if ($value === null || $value === '' || $value === []) {
                continue;
            }

            $slug = Str::slug((string) $key, '_');
            if (is_array($value) && $this->isListOfAssoc($value)) {
                $sections[] = $this->tableSection($slug, $value);
                $sections[count($sections) - 1]['title'] = $this->label((string) $key);
                $sections[count($sections) - 1]['icon'] = 'fa-table';
            } elseif (is_array($value) && $this->isAssocArray($value)) {
                $sections[] = $this->gridSection($slug, $value);
                $sections[count($sections) - 1]['title'] = $this->label((string) $key);
                $sections[count($sections) - 1]['icon'] = 'fa-folder-open';
            }
        }

        return $sections;
    }

    private function buildTable(array $rows): array
    {
        $columns = [];
        foreach ($rows as $row) {
            if (! is_array($row)) {
                continue;
            }
            foreach (array_keys($row) as $col) {
                if (! in_array($col, $columns, true)) {
                    $columns[] = $col;
                }
            }
        }

        return ['columns' => $columns, 'rows' => $rows];
    }

    private function normalizeList(mixed $data): array
    {
        if (! is_array($data)) {
            return [];
        }
        if ($this->isAssocArray($data) && $this->looksLikeRecord($data)) {
            return [$data];
        }

        return array_values(array_filter($data, fn ($item) => is_array($item) && ! empty($item)));
    }

    private function firstPresent(array $r, array $keys): ?array
    {
        foreach ($keys as $key) {
            if (! empty($r[$key])) {
                return $this->normalizeList($r[$key]);
            }
        }

        return null;
    }

    private function looksLikeRecord(array $data): bool
    {
        $keys = array_map('strtoupper', array_keys($data));

        return (bool) array_intersect($keys, ['CPF', 'CNPJ', 'NOME', 'LOGRADOURO', 'EMAIL', 'TELEFONE', 'DDD']);
    }

    private function isListOfAssoc(array $data): bool
    {
        if (! array_is_list($data)) {
            return false;
        }

        foreach ($data as $item) {
            if (! is_array($item)) {
                return false;
            }
        }

        return count($data) > 0;
    }

    private function isAssocArray(array $data): bool
    {
        return array_keys($data) !== range(0, count($data) - 1);
    }

    private function isScalarMap(array $data): bool
    {
        foreach ($data as $v) {
            if (is_array($v) || is_object($v)) {
                return false;
            }
        }

        return true;
    }

    private function riskBadgeClass(?string $risco): ?string
    {
        if (! $risco) {
            return null;
        }
        $up = strtoupper($risco);

        return match (true) {
            str_contains($up, 'BAIX') => 'bg-success',
            str_contains($up, 'MED')  => 'bg-warning text-dark',
            str_contains($up, 'ALT')  => 'bg-danger',
            default                   => 'bg-secondary',
        };
    }
}
