<?php

namespace App\Services;

use App\Models\WhatsappChat;
use App\Models\WhatsappInstance;
use App\Models\WhatsappMessage;
use App\Services\WhatsApp\EvolutionGoService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

class ChatbotService
{
    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function isEnabled(int $companyId): bool
    {
        if (!$this->modules->isEnabled($companyId, 'whatsapp_chatbot')) {
            return false;
        }

        return (bool) ($this->config($companyId)['enabled'] ?? true);
    }

    public function config(int $companyId): array
    {
        return $this->settings->all($companyId, 'whatsapp_chatbot');
    }

    /**
     * Processa uma mensagem recebida. Retorna true se o bot respondeu.
     */
    public function handle(WhatsappInstance $instance, WhatsappChat $chat, string $number, string $body): bool
    {
        $companyId = (int) $instance->company_id;

        if (!$this->isEnabled($companyId)) {
            return false;
        }

        // Conversa já transferida para humano: o bot fica em silêncio.
        if (Cache::get($this->humanKey($instance->id, $number))) {
            return false;
        }

        $cfg = $this->config($companyId);
        $body = trim($body);
        $normalized = Str::lower($body);

        // Horário comercial (08h-18h, seg-sex) quando exigido.
        if (($cfg['business_hours_only'] ?? false) && !$this->withinBusinessHours()) {
            $this->reply($instance, $chat, $number, "No momento estamos fora do horário de atendimento (seg a sex, 8h às 18h). Deixe sua mensagem que retornaremos assim que possível.");
            return true;
        }

        $sessionKey = $this->sessionKey($instance->id, $number);
        $timeout = max(1, (int) ($cfg['menu_timeout_minutes'] ?? 10));
        $session = Cache::get($sessionKey);

        // Novo atendimento ou sessão expirada: envia boas-vindas + menu.
        if (!$session) {
            $welcome = $cfg['welcome_message'] ?? 'Olá! Sou o assistente virtual. Como posso ajudar?';
            $this->reply($instance, $chat, $number, $welcome . "\n\n" . $this->menu($cfg));
            Cache::put($sessionKey, ['stage' => 'menu'], now()->addMinutes($timeout));
            return true;
        }

        // Processa a opção escolhida.
        $response = $this->resolveOption($normalized, $cfg);

        if ($response['handoff']) {
            Cache::forget($sessionKey);
            Cache::put($this->humanKey($instance->id, $number), true, now()->addHours(2));
            $chat->update(['status' => 'open']);
            $this->reply($instance, $chat, $number, $response['text']);
            return true;
        }

        // Renova a sessão e responde.
        Cache::put($sessionKey, ['stage' => 'menu'], now()->addMinutes($timeout));
        $this->reply($instance, $chat, $number, $response['text']);

        return true;
    }

    /**
     * @return array{text: string, handoff: bool}
     */
    private function resolveOption(string $input, array $cfg): array
    {
        $fallbackHuman = (bool) ($cfg['fallback_to_human'] ?? true);

        $optionMatches = fn (array $keys) => in_array($input, $keys, true);

        if ($optionMatches(['1', 'financeiro', 'fatura', 'segunda via', '2a via'])) {
            return ['text' => "💳 *Financeiro*\nVocê pode acessar a 2ª via e pagar faturas na área do cliente. Se preferir falar com um atendente, responda *0*.", 'handoff' => false];
        }

        if ($optionMatches(['2', 'suporte', 'tecnico', 'técnico'])) {
            return ['text' => "🛠️ *Suporte técnico*\nDescreva seu problema em uma mensagem que um atendente vai te ajudar. Para falar agora com um humano, responda *0*.", 'handoff' => false];
        }

        if ($optionMatches(['3', 'comercial', 'vendas', 'planos'])) {
            return ['text' => "🛒 *Comercial*\nConheça nossos planos no site. Para falar com um consultor, responda *0*.", 'handoff' => false];
        }

        if ($optionMatches(['0', 'atendente', 'humano', 'pessoa'])) {
            if ($fallbackHuman) {
                return ['text' => "✅ Certo! Estou transferindo você para um de nossos atendentes. Aguarde um instante.", 'handoff' => true];
            }
            return ['text' => "No momento não há atendentes disponíveis. Deixe sua mensagem que retornaremos em breve.", 'handoff' => false];
        }

        // Opção inválida: reapresenta o menu.
        return ['text' => "Não entendi sua resposta. " . $this->menu($cfg), 'handoff' => false];
    }

    private function menu(array $cfg): string
    {
        $lines = [
            "Escolha uma opção digitando o número:",
            "*1* - Financeiro (2ª via, pagamentos)",
            "*2* - Suporte técnico",
            "*3* - Comercial / Planos",
        ];

        if ($cfg['fallback_to_human'] ?? true) {
            $lines[] = "*0* - Falar com um atendente";
        }

        return implode("\n", $lines);
    }

    private function withinBusinessHours(): bool
    {
        $now = Carbon::now();

        if ($now->isWeekend()) {
            return false;
        }

        return $now->hour >= 8 && $now->hour < 18;
    }

    private function reply(WhatsappInstance $instance, WhatsappChat $chat, string $number, string $text): void
    {
        try {
            $evolution = new EvolutionGoService($instance);
            $result = $evolution->sendText($instance->instance_key, $number, $text);

            WhatsappMessage::create([
                'uuid' => Str::uuid(),
                'company_id' => $instance->company_id,
                'instance_id' => $instance->id,
                'client_id' => $chat->client_id,
                'to_number' => $number,
                'type' => 'text',
                'content' => $text,
                'message_id' => $result['key']['id'] ?? ($result['data']['key']['id'] ?? null),
                'status' => 'sent',
                'sent_by' => 'BOT',
                'sent_at' => now(),
            ]);

            $chat->update(['last_message' => $text, 'last_message_at' => now()]);
        } catch (\Throwable $e) {
            logger()->error('Chatbot reply falhou: ' . $e->getMessage());
        }
    }

    private function sessionKey(int $instanceId, string $number): string
    {
        return "chatbot:session:{$instanceId}:{$number}";
    }

    private function humanKey(int $instanceId, string $number): string
    {
        return "chatbot:human:{$instanceId}:{$number}";
    }
}
