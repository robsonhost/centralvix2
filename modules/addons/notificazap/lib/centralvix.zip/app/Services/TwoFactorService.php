<?php

namespace App\Services;

use App\Models\User;
use App\Mail\VerificationCodeMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use PragmaRX\Google2FA\Google2FA;

class TwoFactorService
{
    public const METHOD_APP = 'app';
    public const METHOD_EMAIL = 'email';
    public const METHOD_WHATSAPP = 'whatsapp';

    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
        private EvolutionWhatsAppService $whatsapp,
    ) {}

    public function moduleEnabled(?int $companyId): bool
    {
        return $companyId ? $this->modules->isEnabled($companyId, 'two_factor') : false;
    }

    public function config(?int $companyId): array
    {
        if (!$companyId) {
            return [];
        }

        return $this->settings->all($companyId, 'two_factor');
    }

    public function allowedMethods(?int $companyId): array
    {
        if (!$this->moduleEnabled($companyId)) {
            return [];
        }

        $configured = $this->config($companyId)['method'] ?? 'any';

        return match ($configured) {
            'app'      => [self::METHOD_APP],
            'email'    => [self::METHOD_EMAIL],
            'whatsapp' => [self::METHOD_WHATSAPP],
            default    => array_values(array_filter([
                self::METHOD_APP,
                self::METHOD_EMAIL,
                $this->whatsappAvailable($companyId) ? self::METHOD_WHATSAPP : null,
            ])),
        };
    }

    public function whatsappAvailable(?int $companyId): bool
    {
        return $this->modules->isEnabled($companyId ?? 0, 'whatsapp')
            && $this->whatsapp->isEnabled();
    }

    public function isRequiredFor(User $user): bool
    {
        if (!$this->moduleEnabled($user->company_id)) {
            return false;
        }

        $cfg = $this->config($user->company_id);

        if ($user->isAdmin()) {
            return (bool) ($cfg['enforce_admins'] ?? true);
        }

        return (bool) ($cfg['enforce_all'] ?? false);
    }

    public function startGracePeriodIfNeeded(User $user): void
    {
        if ($user->isTwoFactorEnabled() || !$this->isRequiredFor($user)) {
            return;
        }

        if ($user->two_factor_grace_ends_at) {
            return;
        }

        $days = (int) ($this->config($user->company_id)['grace_days'] ?? 0);
        if ($days <= 0) {
            return;
        }

        $user->forceFill(['two_factor_grace_ends_at' => now()->addDays($days)])->saveQuietly();
    }

    public function isInGracePeriod(User $user): bool
    {
        if ($user->isTwoFactorEnabled() || !$this->isRequiredFor($user)) {
            return false;
        }

        $ends = $user->two_factor_grace_ends_at;
        return $ends && now()->lt($ends);
    }

    public function mustSetup(User $user): bool
    {
        if (!$this->moduleEnabled($user->company_id) || $user->isTwoFactorEnabled()) {
            return false;
        }

        if (!$this->isRequiredFor($user)) {
            return false;
        }

        $graceDays = (int) ($this->config($user->company_id)['grace_days'] ?? 0);
        if ($graceDays <= 0) {
            return true;
        }

        $this->startGracePeriodIfNeeded($user);
        $user->refresh();

        return !$this->isInGracePeriod($user);
    }

    public function graceMessage(User $user): ?string
    {
        if (!$this->isInGracePeriod($user)) {
            return null;
        }

        $ends = $user->two_factor_grace_ends_at?->locale('pt_BR')?->isoFormat('D [de] MMMM [de] YYYY');

        return "A verificação em duas etapas será obrigatória a partir de {$ends}. Configure agora para proteger sua conta.";
    }

    public function shouldChallenge(Request $request, User $user): bool
    {
        if (!$this->moduleEnabled($user->company_id) || !$user->isTwoFactorEnabled()) {
            return false;
        }

        if ($this->deviceRemembered($request, $user)) {
            return false;
        }

        return true;
    }

    public function rememberDays(?int $companyId): int
    {
        if (!$this->moduleEnabled($companyId)) {
            return 0;
        }

        return (int) ($this->config($companyId)['remember_days'] ?? 0);
    }

    public function deviceToken(User $user): string
    {
        return hash('sha256', $user->id . '|' . ($user->two_factor_secret ?? '') . '|' . config('app.key'));
    }

    public function cookieName(User $user): string
    {
        return '2fa_device_' . $user->id;
    }

    public function deviceRemembered(Request $request, User $user): bool
    {
        $days = $this->rememberDays($user->company_id);
        if ($days <= 0) {
            return false;
        }

        return $request->cookie($this->cookieName($user)) === $this->deviceToken($user);
    }

    public function rememberDevice(User $user): void
    {
        $days = $this->rememberDays($user->company_id);
        if ($days <= 0) {
            return;
        }

        Cookie::queue(Cookie::make(
            $this->cookieName($user),
            $this->deviceToken($user),
            $days * 24 * 60,
        ));
    }

    public function generateAppSecret(): string
    {
        return (new Google2FA())->generateSecretKey();
    }

    public function appQrUrl(User $user, string $secret): string
    {
        return (new Google2FA())->getQRCodeUrl(
            config('app.name'),
            $user->email,
            $secret,
        );
    }

    public function verifyAppCode(string $secret, string $code): bool
    {
        return (new Google2FA())->verifyKey($secret, $code);
    }

    public function activate(User $user, string $method, ?string $secret = null): void
    {
        $payload = [
            'two_factor_method'       => $method,
            'two_factor_confirmed_at' => now(),
            'two_factor_grace_ends_at'=> null,
        ];

        if ($method === self::METHOD_APP && $secret) {
            $payload['two_factor_secret'] = $secret;
        }

        $user->forceFill($payload)->save();
    }

    public function deactivate(User $user): void
    {
        $user->forceFill([
            'two_factor_secret'        => null,
            'two_factor_method'        => null,
            'two_factor_confirmed_at'  => null,
            'two_factor_recovery_codes'=> null,
        ])->save();
    }

    public function resolveChallengeMethod(User $user): string
    {
        return $user->two_factor_method ?: self::METHOD_APP;
    }

    public function sendChallengeCode(User $user): array
    {
        $method = $this->resolveChallengeMethod($user);
        $code = (string) random_int(100000, 999999);
        $ttl = 10;

        Cache::put($this->challengeCacheKey($user->id), [
            'code'   => $code,
            'method' => $method,
        ], now()->addMinutes($ttl));

        return match ($method) {
            self::METHOD_EMAIL    => $this->dispatchEmailCode($user, $code, $ttl),
            self::METHOD_WHATSAPP => $this->dispatchWhatsAppCode($user, $code, $ttl),
            default               => ['success' => true, 'message' => 'Use o aplicativo autenticador.'],
        };
    }

    public function sendSetupCode(User $user, string $method): array
    {
        if (!in_array($method, $this->allowedMethods($user->company_id), true)) {
            return ['success' => false, 'message' => 'Método não permitido pela empresa.'];
        }

        $code = (string) random_int(100000, 999999);
        $ttl = 10;

        Cache::put($this->setupCacheKey($user->id, $method), $code, now()->addMinutes($ttl));

        return match ($method) {
            self::METHOD_EMAIL    => $this->dispatchEmailCode($user, $code, $ttl),
            self::METHOD_WHATSAPP => $this->dispatchWhatsAppCode($user, $code, $ttl),
            default               => ['success' => false, 'message' => 'Método inválido para envio de código.'],
        };
    }

    public function verifyChallenge(User $user, string $code): bool
    {
        $method = $this->resolveChallengeMethod($user);

        if ($method === self::METHOD_APP) {
            return $this->verifyAppCode($user->two_factor_secret ?? '', $code);
        }

        $cached = Cache::get($this->challengeCacheKey($user->id));
        if (!$cached || ($cached['code'] ?? '') !== $code) {
            return false;
        }

        Cache::forget($this->challengeCacheKey($user->id));

        return true;
    }

    public function verifySetupCode(User $user, string $method, string $code): bool
    {
        $cached = Cache::get($this->setupCacheKey($user->id, $method));
        if (!$cached || $cached !== $code) {
            return false;
        }

        Cache::forget($this->setupCacheKey($user->id, $method));

        return true;
    }

    public function challengeSentTo(User $user): string
    {
        return match ($this->resolveChallengeMethod($user)) {
            self::METHOD_EMAIL => $this->maskEmail($user->email),
            self::METHOD_WHATSAPP => $this->maskPhone($this->resolvePhone($user)),
            default => 'aplicativo autenticador',
        };
    }

    protected function dispatchEmailCode(User $user, string $code, int $ttl): array
    {
        try {
            Mail::to($user->email)->send(new VerificationCodeMail($code, $ttl, $user->name));
            return ['success' => true, 'message' => 'Código enviado para ' . $this->maskEmail($user->email)];
        } catch (\Throwable $e) {
            Log::error('2FA e-mail: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Não foi possível enviar o código por e-mail.'];
        }
    }

    protected function dispatchWhatsAppCode(User $user, string $code, int $ttl): array
    {
        $phone = $this->resolvePhone($user);
        if ($phone === '') {
            return ['success' => false, 'message' => 'Nenhum WhatsApp/telefone cadastrado no perfil.'];
        }

        if (!$this->whatsapp->sendVerificationCode($phone, $code, $ttl)) {
            return ['success' => false, 'message' => 'Falha ao enviar código via WhatsApp.'];
        }

        return ['success' => true, 'message' => 'Código enviado para ' . $this->maskPhone($phone)];
    }

    protected function resolvePhone(User $user): string
    {
        $client = $user->resolveClient();
        $raw = $client?->whatsapp ?: $client?->mobile ?: $client?->phone ?: $user->whatsapp ?: $user->phone;

        return preg_replace('/\D/', '', (string) $raw);
    }

    protected function challengeCacheKey(int $userId): string
    {
        return "2fa_challenge:{$userId}";
    }

    protected function setupCacheKey(int $userId, string $method): string
    {
        return "2fa_setup:{$userId}:{$method}";
    }

    protected function maskEmail(string $email): string
    {
        if (!str_contains($email, '@')) {
            return $email;
        }

        [$local, $domain] = explode('@', $email, 2);
        $visible = substr($local, 0, min(2, strlen($local)));

        return $visible . str_repeat('*', max(1, strlen($local) - 2)) . '@' . $domain;
    }

    protected function maskPhone(string $phone): string
    {
        $digits = preg_replace('/\D/', '', $phone);
        if (strlen($digits) < 4) {
            return '****';
        }

        return str_repeat('*', max(0, strlen($digits) - 4)) . substr($digits, -4);
    }
}
