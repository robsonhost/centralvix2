<?php

namespace App\Services;

use App\Jobs\ApplyLateFees;
use App\Jobs\CheckSslMonitors;
use App\Jobs\CheckUptimeMonitors;
use App\Jobs\ExpireServiceTrials;
use App\Jobs\GenerateRecurringInvoices;
use App\Jobs\ProcessAbandonedCarts;
use App\Jobs\ProcessDomainRenewals;
use App\Jobs\ReactivateServices;
use App\Jobs\SendInvoiceReminders;
use App\Jobs\SendSatisfactionSurveys;
use App\Jobs\SuspendOverdueServices;
use App\Jobs\SyncServiceStatus;
use App\Jobs\TerminateOverdueServices;
use App\Jobs\UpdateExchangeRates;
use App\Jobs\VerifyCentralVixLicenses;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;

class CronJobManagerService
{
    public function definitions(): array
    {
        return [
            [
                'slug' => 'schedule-run',
                'title' => 'Executar Scheduler Completo',
                'description' => 'Roda php artisan schedule:run — dispara todos os jobs agendados para este minuto.',
                'schedule' => 'A cada minuto',
                'category' => 'sistema',
                'accent' => 'purple',
                'icon' => 'fa-play-circle',
                'master' => true,
            ],
            [
                'slug' => 'mark-overdue-invoices',
                'title' => 'Marcar Faturas Vencidas',
                'description' => 'Atualiza status de faturas não pagas para vencidas.',
                'schedule' => 'Diário 00:05',
                'category' => 'faturamento',
                'accent' => 'yellow',
                'icon' => 'fa-file-invoice',
            ],
            [
                'slug' => 'apply-late-fees',
                'title' => 'Multa e Juros',
                'description' => 'Aplica encargos em faturas vencidas (módulo Multa e Juros).',
                'schedule' => 'Diário 00:30',
                'category' => 'faturamento',
                'accent' => 'red',
                'icon' => 'fa-percent',
                'job' => ApplyLateFees::class,
            ],
            [
                'slug' => 'expire-service-trials',
                'title' => 'Expirar Trials',
                'description' => 'Encerra períodos de teste e notifica clientes.',
                'schedule' => 'Diário 01:00',
                'category' => 'servicos',
                'accent' => 'blue',
                'icon' => 'fa-hourglass-end',
                'job' => ExpireServiceTrials::class,
            ],
            [
                'slug' => 'generate-recurring-invoices',
                'title' => 'Faturas Recorrentes',
                'description' => 'Gera faturas de serviços com vencimento próximo.',
                'schedule' => 'Diário 06:00',
                'category' => 'faturamento',
                'accent' => 'blue',
                'icon' => 'fa-sync',
                'job' => GenerateRecurringInvoices::class,
            ],
            [
                'slug' => 'check-ssl-monitors',
                'title' => 'Monitor SSL',
                'description' => 'Verifica certificados SSL configurados.',
                'schedule' => 'Diário 06:30',
                'category' => 'monitoramento',
                'accent' => 'cyan',
                'icon' => 'fa-lock',
                'job' => CheckSslMonitors::class,
            ],
            [
                'slug' => 'suspend-overdue-services',
                'title' => 'Suspensão por Inadimplência',
                'description' => 'Suspende clientes e serviços com faturas vencidas.',
                'schedule' => 'Diário 07:00',
                'category' => 'servicos',
                'accent' => 'red',
                'icon' => 'fa-pause-circle',
                'job' => SuspendOverdueServices::class,
            ],
            [
                'slug' => 'terminate-overdue-services',
                'title' => 'Encerramento Automático',
                'description' => 'Encerra serviços suspensos há muito tempo sem pagamento.',
                'schedule' => 'Diário 07:30',
                'category' => 'servicos',
                'accent' => 'red',
                'icon' => 'fa-trash',
                'job' => TerminateOverdueServices::class,
            ],
            [
                'slug' => 'process-domain-renewals',
                'title' => 'Renovação de Domínios',
                'description' => 'Gera faturas de renovação para domínios com auto-renew.',
                'schedule' => 'Diário 08:00',
                'category' => 'dominios',
                'accent' => 'blue',
                'icon' => 'fa-globe',
                'job' => ProcessDomainRenewals::class,
            ],
            [
                'slug' => 'send-invoice-reminders',
                'title' => 'Régua de Cobrança',
                'description' => 'Envia lembretes 10/7/3/1 dias e cobranças pós-vencimento.',
                'schedule' => 'Diário 09:00',
                'category' => 'faturamento',
                'accent' => 'yellow',
                'icon' => 'fa-bell',
                'job' => SendInvoiceReminders::class,
            ],
            [
                'slug' => 'reactivate-services',
                'title' => 'Reativação Automática',
                'description' => 'Reativa serviços quando faturas são quitadas.',
                'schedule' => 'A cada 30 min',
                'category' => 'servicos',
                'accent' => 'green',
                'icon' => 'fa-redo',
                'job' => ReactivateServices::class,
            ],
            [
                'slug' => 'sync-service-status',
                'title' => 'Sincronizar WHM/cPanel',
                'description' => 'Sincroniza status dos serviços com os servidores.',
                'schedule' => 'A cada hora',
                'category' => 'infra',
                'accent' => 'purple',
                'icon' => 'fa-server',
                'job' => SyncServiceStatus::class,
            ],
            [
                'slug' => 'process-abandoned-carts',
                'title' => 'Carrinho Abandonado',
                'description' => 'Envia lembretes de carrinhos não finalizados.',
                'schedule' => 'A cada hora',
                'category' => 'comercial',
                'accent' => 'blue',
                'icon' => 'fa-shopping-cart',
                'job' => ProcessAbandonedCarts::class,
            ],
            [
                'slug' => 'update-exchange-rates',
                'title' => 'Câmbio / Multi-moeda',
                'description' => 'Atualiza taxas de câmbio configuradas.',
                'schedule' => 'A cada hora',
                'category' => 'financeiro',
                'accent' => 'cyan',
                'icon' => 'fa-coins',
                'job' => UpdateExchangeRates::class,
            ],
            [
                'slug' => 'check-uptime-monitors',
                'title' => 'Monitor Uptime',
                'description' => 'Verifica disponibilidade dos monitores.',
                'schedule' => 'A cada 5 min',
                'category' => 'monitoramento',
                'accent' => 'green',
                'icon' => 'fa-heartbeat',
                'job' => CheckUptimeMonitors::class,
            ],
            [
                'slug' => 'send-satisfaction-surveys',
                'title' => 'Pesquisas de Satisfação',
                'description' => 'Envia pesquisas pendentes aos clientes.',
                'schedule' => 'A cada 15 min',
                'category' => 'comercial',
                'accent' => 'blue',
                'icon' => 'fa-star',
                'job' => SendSatisfactionSurveys::class,
            ],
            [
                'slug' => 'verify-centralvix-licenses',
                'title' => 'Licenças CentralVix',
                'description' => 'Valida licenças do sistema.',
                'schedule' => 'A cada minuto',
                'category' => 'sistema',
                'accent' => 'purple',
                'icon' => 'fa-key',
                'job' => VerifyCentralVixLicenses::class,
            ],
        ];
    }

    public function categories(): array
    {
        return [
            'sistema' => ['label' => 'Sistema', 'icon' => 'fa-cogs'],
            'faturamento' => ['label' => 'Faturamento', 'icon' => 'fa-file-invoice-dollar'],
            'servicos' => ['label' => 'Serviços', 'icon' => 'fa-server'],
            'dominios' => ['label' => 'Domínios', 'icon' => 'fa-globe'],
            'comercial' => ['label' => 'Comercial', 'icon' => 'fa-shopping-bag'],
            'financeiro' => ['label' => 'Financeiro', 'icon' => 'fa-coins'],
            'infra' => ['label' => 'Infraestrutura', 'icon' => 'fa-network-wired'],
            'monitoramento' => ['label' => 'Monitoramento', 'icon' => 'fa-chart-line'],
        ];
    }

    public function grouped(): array
    {
        $grouped = [];
        foreach ($this->definitions() as $job) {
            $cat = $job['category'] ?? 'sistema';
            $grouped[$cat][] = $job;
        }

        return $grouped;
    }

    public function isCronHealthy(): bool
    {
        $last = $this->getLastRun('schedule-run');
        if (!$last || empty($last['at'])) {
            return false;
        }

        return \Carbon\Carbon::parse($last['at'])->diffInMinutes(now()) <= 5;
    }

    public function masterCronCommand(): string
    {
        return '* * * * * cd ' . base_path() . ' && php artisan schedule:run >> /dev/null 2>&1';
    }

    public function run(string $slug): array
    {
        $started = microtime(true);
        $output = [];

        try {
            if ($slug === 'schedule-run') {
                Artisan::call('schedule:run');
                $output[] = trim(Artisan::output()) ?: 'schedule:run executado.';
            } elseif ($slug === 'mark-overdue-invoices') {
                app(InvoiceService::class)->markOverdueInvoices();
                $output[] = 'Faturas vencidas processadas.';
            } else {
                $def = collect($this->definitions())->firstWhere('slug', $slug);
                if (!$def || empty($def['job'])) {
                    throw new \InvalidArgumentException("Cron job não encontrado: {$slug}");
                }
                $jobClass = $def['job'];
                $job = app($jobClass);
                app()->call([$job, 'handle']);
                $output[] = class_basename($jobClass) . ' executado com sucesso.';
            }

            $elapsed = round(microtime(true) - $started, 2);
            $log = implode("\n", $output) . "\n[{$elapsed}s] Concluído em " . now()->format('d/m/Y H:i:s');

            $this->storeRun($slug, true, $log);

            return ['success' => true, 'message' => 'Job executado com sucesso.', 'output' => $log, 'elapsed' => $elapsed];
        } catch (\Throwable $e) {
            $log = "ERRO: {$e->getMessage()}\n" . $e->getFile() . ':' . $e->getLine();
            Log::error("Cron manual run failed [{$slug}]", ['error' => $e->getMessage()]);
            $this->storeRun($slug, false, $log);

            return ['success' => false, 'message' => $e->getMessage(), 'output' => $log];
        }
    }

    public function runAll(): array
    {
        $results = [];
        foreach ($this->definitions() as $def) {
            if ($def['slug'] === 'schedule-run') {
                continue;
            }
            $results[$def['slug']] = $this->run($def['slug']);
        }

        return $results;
    }

    public function getLastRun(string $slug): ?array
    {
        return Cache::get("cron_run:{$slug}");
    }

    public function getLog(string $slug, int $lines = 80): string
    {
        $last = $this->getLastRun($slug);
        $parts = [];

        if ($last) {
            $parts[] = "=== Última execução manual ({$last['at']}) ===";
            $parts[] = $last['output'] ?? '';
            $parts[] = '';
        }

        $parts[] = "=== Laravel Log (trecho) ===";
        $parts[] = $this->tailLog($slug, $lines);

        return implode("\n", array_filter($parts));
    }

    public function stats(): array
    {
        $defs = $this->definitions();
        $lastRuns = collect($defs)->map(fn ($d) => $this->getLastRun($d['slug']))->filter();
        $lastAt = $lastRuns->max('at');

        return [
            'total' => count($defs),
            'runnable' => count($defs) - 1,
            'last_run' => $lastAt,
            'success_today' => $lastRuns->filter(fn ($r) => ($r['success'] ?? false) && str_starts_with($r['at'] ?? '', now()->toDateString()))->count(),
        ];
    }

    private function storeRun(string $slug, bool $success, string $output): void
    {
        Cache::put("cron_run:{$slug}", [
            'at' => now()->toIso8601String(),
            'success' => $success,
            'output' => $output,
        ], now()->addDays(7));
    }

    private function tailLog(string $slug, int $lines): string
    {
        $path = storage_path('logs/laravel.log');
        if (!File::exists($path)) {
            return 'Arquivo de log não encontrado.';
        }

        $content = File::get($path);
        $allLines = explode("\n", $content);
        $filtered = array_filter($allLines, fn ($line) => stripos($line, $slug) !== false
            || stripos($line, 'Régua de cobrança') !== false && $slug === 'send-invoice-reminders'
            || stripos($line, 'ProcessDomainRenewals') !== false && $slug === 'process-domain-renewals'
        );

        if (empty($filtered)) {
            $filtered = array_slice($allLines, -$lines);
        } else {
            $filtered = array_slice($filtered, -$lines);
        }

        return implode("\n", $filtered) ?: 'Nenhuma entrada relevante no log.';
    }
}
