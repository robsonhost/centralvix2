<?php

namespace App\Services;

use App\Models\SatisfactionSurvey;
use App\Models\Ticket;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class SatisfactionSurveyService
{
    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    /**
     * Cria a pesquisa quando um ticket é fechado (não envia ainda; o envio
     * respeita o atraso configurado e é feito pelo job SendSatisfactionSurveys).
     */
    public function onTicketClosed(Ticket $ticket): void
    {
        if (!$ticket->company_id || !$this->modules->isEnabled($ticket->company_id, 'satisfaction_survey')) {
            return;
        }

        $cfg = $this->settings->all($ticket->company_id, 'satisfaction_survey');
        $trigger = $cfg['trigger'] ?? 'ticket_close';

        if (!in_array($trigger, ['ticket_close', 'both'], true)) {
            return;
        }

        // Evita duplicidade por ticket.
        if (SatisfactionSurvey::where('ticket_id', $ticket->id)->exists()) {
            return;
        }

        SatisfactionSurvey::create([
            'company_id' => $ticket->company_id,
            'client_id'  => $ticket->client_id,
            'ticket_id'  => $ticket->id,
            'type'       => in_array(($cfg['type'] ?? 'csat'), ['csat', 'nps'], true) ? $cfg['type'] : 'csat',
            'token'      => $this->uniqueToken(),
            'status'     => 'pending',
        ]);
    }

    /**
     * Envia a pesquisa pelos canais configurados.
     */
    public function send(SatisfactionSurvey $survey): void
    {
        $cfg = $this->settings->all($survey->company_id, 'satisfaction_survey');
        $client = $survey->client;
        if (!$client) {
            $survey->update(['sent_at' => now(), 'channel' => 'none']);
            return;
        }

        $url = route('survey.show', $survey->token);
        $name = $client->firstname ?? $client->display_name ?? 'Cliente';
        $text = "Olá, {$name}! Como foi seu atendimento? Leva 10 segundos: {$url}";

        $channels = [];

        if (($cfg['channel_email'] ?? true) && $client->email) {
            try {
                Mail::raw($text, function ($m) use ($client) {
                    $m->to($client->email)->subject('Como foi seu atendimento?');
                });
                $channels[] = 'email';
            } catch (\Throwable $e) {
                Log::error("Survey e-mail #{$survey->id}: " . $e->getMessage());
            }
        }

        if (($cfg['channel_whatsapp'] ?? true)) {
            try {
                $phone = preg_replace('/\D/', '', $client->whatsapp ?? $client->mobile ?? $client->phone ?? '');
                if ($phone && strlen($phone) === 11) {
                    $phone = '55' . $phone;
                }
                if ($phone) {
                    app(\App\Services\EvolutionWhatsAppService::class)->sendText($phone, $text);
                    $channels[] = 'whatsapp';
                }
            } catch (\Throwable $e) {
                Log::error("Survey WhatsApp #{$survey->id}: " . $e->getMessage());
            }
        }

        $survey->update([
            'sent_at' => now(),
            'channel' => implode('_', $channels) ?: 'none',
        ]);
    }

    private function uniqueToken(): string
    {
        do {
            $token = Str::random(48);
        } while (SatisfactionSurvey::where('token', $token)->exists());

        return $token;
    }
}
