<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Service;
use Carbon\Carbon;

class UpgradeService
{
    public function __construct(private BillingService $billing)
    {
    }

    /**
     * Calcula crédito pro-rata do ciclo atual e valor do upgrade.
     */
    public function quote(Service $service, Product $newProduct, string $newCycle): array
    {
        $service->loadMissing('product');
        $oldPrice = (float) $service->amount;
        $newPrice = (float) $newProduct->getPriceForCycle($newCycle);

        $credit = $this->prorataCredit($service, $oldPrice);
        $due = max(0, round($newPrice - $credit, 2));

        return [
            'current_product' => $service->product?->name,
            'new_product' => $newProduct->name,
            'current_price' => $oldPrice,
            'new_price' => $newPrice,
            'prorata_credit' => $credit,
            'amount_due' => $due,
            'billing_cycle' => $newCycle,
        ];
    }

    /**
     * Aplica upgrade/downgrade gerando fatura de diferença.
     */
    public function apply(Service $service, Product $newProduct, string $newCycle): Service
    {
        $quote = $this->quote($service, $newProduct, $newCycle);

        $service->update([
            'product_id' => $newProduct->id,
            'name' => $newProduct->name,
            'amount' => $newProduct->getPriceForCycle($newCycle),
            'billing_cycle' => $newCycle,
            'module' => $newProduct->module ?? $service->module,
            'server_id' => $newProduct->server_id ?? $service->server_id,
            'next_due_date' => $this->billing->getNextDueDate($newCycle),
        ]);

        if ($quote['amount_due'] > 0) {
            $invoice = $this->billing->createUpgradeInvoice($service, $quote);
            $service->setRelation('latestUpgradeInvoice', $invoice);
        }

        return $service->fresh(['product']);
    }

    private function prorataCredit(Service $service, float $cyclePrice): float
    {
        if (!$service->next_due_date || $cyclePrice <= 0) {
            return 0.0;
        }

        $totalDays = max(1, $this->cycleDays($service->billing_cycle));
        $remaining = max(0, now()->diffInDays($service->next_due_date, false));

        return round($cyclePrice * ($remaining / $totalDays), 2);
    }

    private function cycleDays(string $cycle): int
    {
        return match ($cycle) {
            'monthly' => 30,
            'quarterly' => 90,
            'semiannually' => 180,
            'annually' => 365,
            'biennially' => 730,
            'triennially' => 1095,
            default => 30,
        };
    }
}
