<?php

namespace App\Services;

use App\Models\Client;
use App\Models\Contract;
use App\Models\ContractTemplate;
use App\Models\Service;
use App\Services\WhatsApp\WhatsappNotificationService;
use App\Services\AutoLoginService;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ContractService
{
    public function __construct(
        private WhatsappNotificationService $whatsapp,
        private AutoLoginService $autoLogin
    ) {}

    /**
     * Create a new contract from template or raw content.
     */
    public function create(
        Client          $client,
        string          $title,
        string          $content,
        array           $options = [],
        ?ContractTemplate $template = null,
        ?Service        $service  = null
    ): Contract {
        $contract = Contract::create([
            'uuid'               => Str::uuid(),
            'company_id'         => $client->company_id,
            'client_id'          => $client->id,
            'template_id'        => $template?->id,
            'service_id'         => $service?->id,
            'title'              => $title,
            'content'            => $content,
            'status'             => 'draft',
            'signature_methods'  => $options['signature_methods'] ?? ['whatsapp', 'email', 'link'],
            'expires_at'         => now()->addDays(config('contracts.expiry_days', 30)),
            'metadata'           => $options['metadata'] ?? null,
        ]);

        return $contract;
    }

    /**
     * Create from template with variable substitution.
     */
    public function createFromTemplate(
        Client   $client,
        ContractTemplate $template,
        array    $vars    = [],
        ?Service $service = null
    ): Contract {
        $mergedVars = array_merge($this->buildClientVars($client), $vars);

        if ($service) {
            $mergedVars = array_merge($mergedVars, $this->buildServiceVars($service));
        }

        $content = $template->render($mergedVars);
        return $this->create($client, $template->name, $content, [], $template, $service);
    }

    /**
     * Send contract to client (email + WhatsApp).
     */
    public function send(Contract $contract): bool
    {
        if ($contract->status === 'signed') return false;

        $contract->update([
            'status'  => 'sent',
            'sent_at' => now(),
        ]);

        $client    = $contract->client;
        $signUrl   = $this->autoLogin->generateContractLink($client, $contract);

        // WhatsApp notification
        $this->whatsapp->contractSent($client, [
            'contract_title'   => $contract->title,
            'contract_number'  => $contract->number,
            'sign_url'         => $signUrl,
            'expires_at'       => $contract->expires_at?->format('d/m/Y'),
            'invoice_id'       => 0,
        ]);

        return true;
    }

    /**
     * Mark contract as signed.
     */
    public function sign(Contract $contract, string $ip, ?string $geolocation = null, ?string $device = null): bool
    {
        if ($contract->isSigned()) return false;
        if ($contract->isExpired()) return false;

        $contract->update([
            'status'             => 'signed',
            'signed_at'          => now(),
            'signer_ip'          => $ip,
            'signer_geolocation' => $geolocation,
            'signer_device'      => $device,
        ]);

        // Mark viewed too if not already
        if (!$contract->viewed_at) {
            $contract->update(['viewed_at' => now(), 'status' => 'signed']);
        }

        // Generate signed PDF
        $this->generatePdf($contract);

        // Notify
        $this->whatsapp->contractSigned($contract->client, [
            'contract_title'  => $contract->title,
            'contract_number' => $contract->number,
            'signed_at'       => now()->format('d/m/Y H:i'),
            'invoice_id'      => 0,
        ]);

        return true;
    }

    /**
     * Generate and store the PDF of the contract.
     */
    public function generatePdf(Contract $contract): string
    {
        $pdf  = Pdf::loadView('pdf.contract', compact('contract'));
        $path = "contracts/{$contract->company_id}/{$contract->uuid}.pdf";

        Storage::disk(config('contracts.storage_disk', 'public'))->put($path, $pdf->output());

        $contract->update(['pdf_path' => $path]);

        return $path;
    }

    /**
     * Mark as viewed (tracking).
     */
    public function markViewed(Contract $contract): void
    {
        if (!$contract->viewed_at) {
            $contract->update(['viewed_at' => now(), 'status' => 'viewed']);
        }
    }

    // ====== Variable Builders ======

    public function buildClientVars(Client $client): array
    {
        return [
            'client_name'       => $client->display_name,
            'client_email'      => $client->email,
            'client_cpf'        => $client->cpf ?? '',
            'client_cnpj'       => $client->cnpj ?? '',
            'client_company'    => $client->company_name ?? '',
            'client_address'    => $client->address . ', ' . $client->address_number,
            'client_city'       => $client->city ?? '',
            'client_state'      => $client->state ?? '',
            'client_zip'        => $client->zip ?? '',
            'company_name'      => $client->company?->name ?? config('app.name'),
            'today'             => now()->format('d/m/Y'),
            'today_full'        => now()->translatedFormat('d \d\e F \d\e Y'),
        ];
    }

    public function buildServiceVars(Service $service): array
    {
        return [
            'service_name'          => $service->name,
            'service_domain'        => $service->domain ?? '',
            'service_plan'          => $service->product?->name ?? '',
            'service_billing_cycle' => $service->billing_cycle_label,
            'service_amount'        => 'R$ ' . number_format($service->amount, 2, ',', '.'),
            'service_start_date'    => $service->first_payment_date?->format('d/m/Y') ?? '',
            'service_next_due'      => $service->next_due_date?->format('d/m/Y') ?? '',
        ];
    }
}
