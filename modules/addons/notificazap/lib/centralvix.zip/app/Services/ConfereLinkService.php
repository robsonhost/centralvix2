<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ConfereLinkService
{
    private const BASE_URL = 'https://confere.link/api/';

    /** Mapeamento slug interno → ação da API confere.link */
    private const ACTION_MAP = [
        'cpf'            => 'CONS_CPF',
        'nome'           => 'CONS_NOME',
        'email-pessoa'   => 'CONS_EMAIL',
        'email-empresa'  => 'CONS_EMAIL',
    ];

    public function token(int $companyId): ?string
    {
        $token = trim((string) Setting::get($companyId, 'confere_link', 'api_token', ''));

        return $token !== '' ? $token : null;
    }

    public function isConfigured(int $companyId): bool
    {
        return $this->token($companyId) !== null;
    }

    public function saveToken(int $companyId, ?string $token): void
    {
        Setting::set($companyId, 'confere_link', 'api_token', trim((string) $token));
    }

    /**
     * Executa consulta na API confere.link.
     *
     * @return array{success: bool, data?: mixed, raw?: mixed, message?: string}
     */
    public function consult(int $companyId, string $slug, string $searchTerm): array
    {
        $token = $this->token($companyId);
        if (!$token) {
            return [
                'success' => false,
                'message' => 'Token da API Confere.link não configurado. Acesse Admin → Consultas → Configuração API.',
            ];
        }

        $action = self::ACTION_MAP[$slug] ?? null;
        if (!$action) {
            return [
                'success' => false,
                'message' => "Consulta '{$slug}' ainda não mapeada para a API Confere.link.",
            ];
        }

        $params = $this->buildParams($action, $token, $searchTerm);

        try {
            $response = Http::timeout(120)->get(self::BASE_URL, $params);

            if (!$response->successful()) {
                return [
                    'success' => false,
                    'message' => 'API Confere.link retornou HTTP ' . $response->status(),
                    'raw' => ['body' => $response->body()],
                ];
            }

            $data = $response->json();
            if (!is_array($data)) {
                return [
                    'success' => false,
                    'message' => 'Resposta inválida da API Confere.link.',
                    'raw' => ['body' => $response->body()],
                ];
            }

            if ($this->isErrorResponse($data)) {
                return [
                    'success' => false,
                    'message' => $this->extractErrorMessage($data),
                    'raw' => $data,
                ];
            }

            return [
                'success' => true,
                'data' => $this->normalizeResult($action, $data),
                'raw' => $data,
            ];
        } catch (\Throwable $e) {
            Log::warning('Confere.link API error', [
                'company_id' => $companyId,
                'action' => $action,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => 'Erro de conexão com Confere.link: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Teste rápido de conectividade (usa CPF de demonstração).
     */
    public function test(int $companyId): array
    {
        return $this->consult($companyId, 'cpf', '00000000000');
    }

    public function supportsSlug(string $slug): bool
    {
        return isset(self::ACTION_MAP[$slug]);
    }

    private function buildParams(string $action, string $token, string $searchTerm): array
    {
        $params = [
            'acao' => $action,
            'TK'   => $token,
            'TIPO' => 'JSON',
        ];

        if ($action === 'CONS_CPF') {
            $params['DADO'] = preg_replace('/\D/', '', $searchTerm);
        } elseif ($action === 'CONS_EMAIL') {
            // CONS_EMAIL usa parâmetro "dado" com o e-mail (sem espaços).
            $params['dado'] = trim($searchTerm);
        } else {
            // CONS_NOME usa parâmetro "dado" (minúsculo) com + entre palavras.
            $params['dado'] = preg_replace('/\s+/', '+', trim($searchTerm));
        }

        return $params;
    }

    private function isErrorResponse(array $data): bool
    {
        if (isset($data['ERRO']) || isset($data['erro']) || isset($data['error'])) {
            return true;
        }

        if (isset($data['valid']) && $data['valid'] === false) {
            return true;
        }

        if (isset($data['success']) && $data['success'] === false) {
            return true;
        }

        return false;
    }

    private function extractErrorMessage(array $data): string
    {
        foreach (['ERRO', 'erro', 'error', 'message', 'MENSAGEM', 'mensagem'] as $key) {
            if (!empty($data[$key]) && is_string($data[$key])) {
                return $data[$key];
            }
        }

        return 'Consulta não retornou resultados.';
    }

    private function normalizeResult(string $action, array $data): array
    {
        if ($action === 'CONS_CPF') {
            return [
                'tipo' => 'cpf',
                'cadastrais' => $data['CADASTRAIS'] ?? $data['cadastrais'] ?? null,
                'enderecos'  => $data['ENDERECOS'] ?? $data['enderecos'] ?? [],
                'telefones'  => $data['TELEFONES'] ?? $data['telefones'] ?? [],
                'emails'     => $data['EMAILS'] ?? $data['emails'] ?? [],
                'socios'     => $data['SOCIOS'] ?? $data['socios'] ?? [],
            ];
        }

        if ($action === 'CONS_NOME' || $action === 'CONS_EMAIL') {
            return [
                'tipo' => $action === 'CONS_EMAIL' ? 'email' : 'nome',
                'total' => $data['TOTAL'] ?? $data['total'] ?? count($data['RESULTADO'] ?? $data['resultado'] ?? []),
                'resultado' => $data['RESULTADO'] ?? $data['resultado'] ?? [],
            ];
        }

        return $data;
    }
}
