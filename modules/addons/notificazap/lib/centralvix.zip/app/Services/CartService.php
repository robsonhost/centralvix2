<?php

namespace App\Services;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Client;
use App\Models\Coupon;
use App\Models\Product;

class CartService
{
    public function resolve(Client $client): Cart
    {
        $cart = Cart::query()
            ->where('company_id', $client->company_id)
            ->where('client_id', $client->id)
            ->where('status', 'active')
            ->with('items.product')
            ->first();

        if ($cart) {
            return $cart;
        }

        return Cart::create([
            'company_id' => $client->company_id,
            'client_id' => $client->id,
            'session_id' => session()->getId(),
            'status' => 'active',
            'last_activity_at' => now(),
        ]);
    }

    public function addItem(Client $client, Product $product, string $billingCycle, ?string $domain = null, int $qty = 1): CartItem
    {
        $cart = $this->resolve($client);

        $item = $cart->items()->updateOrCreate(
            [
                'product_id' => $product->id,
                'billing_cycle' => $billingCycle,
                'domain' => $domain,
            ],
            [
                'quantity' => $qty,
                'unit_price' => $product->getPriceForCycle($billingCycle),
            ],
        );

        $cart->update(['last_activity_at' => now()]);

        return $item->load('product');
    }

    public function removeItem(CartItem $item): void
    {
        $item->cart?->update(['last_activity_at' => now()]);
        $item->delete();
    }

    public function clear(Cart $cart): void
    {
        $cart->items()->delete();
        $cart->update(['status' => 'converted', 'last_activity_at' => now()]);
    }

    public function checkout(Client $client, BillingService $billing, ?Coupon $coupon = null): array
    {
        $cart = $this->resolve($client)->load('items.product');
        $orders = [];

        foreach ($cart->items as $item) {
            $orders[] = $billing->createOrder(
                $client,
                $item->product,
                $item->billing_cycle,
                $item->domain,
                $coupon,
            );
        }

        $this->clear($cart);

        return $orders;
    }
}
