<?php

namespace App\Services;

use App\Models\Client;
use App\Models\ConsultaLog;
use App\Models\ConsultaType;
use App\Models\Setting;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Serviço central de consultas pagas (CPF/CNPJ/Score/Serasa).
 *
 * As integrações com APIs externas são despachadas pelo `slug` do tipo
 * de consulta. Cada provedor recebe seus credenciais via `api_config` no
 * próprio cadastro do tipo de consulta — assim o cliente pode passar
 * cada API (uma por vez) e habilitar conforme forem chegando.
 */
class ConsultaService
{
    public function __construct(private WalletService $wallet) {}

    /**
     * Executa uma consulta para o cliente, debitando do saldo e
     * persistindo o resultado no histórico (consulta_logs).
     *
     * @return array{success: bool, message: string, log?: ConsultaLog}
     */
    public function run(Client $client, ConsultaType $type, string $parameter, array $context = []): array
    {
        if (! $type->active) {
            return ['success' => false, 'message' => 'Esta consulta está desativada no momento.'];
        }

        $parameter = trim($parameter);
        if ($parameter === '') {
            return ['success' => false, 'message' => 'Informe o valor para realizar a consulta.'];
        }

        $price = round((float) $type->sale_price, 2);

        // Verifica saldo
        if ((float) $client->credit_balance < $price) {
            return [
                'success' => false,
                'message' => 'Saldo insuficiente. Faça uma recarga para realizar esta consulta.',
            ];
        }

        return DB::transaction(function () use ($client, $type, $parameter, $context, $price) {
            // Debita o saldo (já cria WalletTransaction)
            $debit = $this->wallet->debit(
                $client,
                $price,
                'consulta',
                "Consulta {$type->name}: {$parameter}",
                null,
                $client->user_id,
            );

            if (! $debit) {
                return ['success' => false, 'message' => 'Não foi possível debitar o saldo.'];
            }

            // Cria log pendente
            $log = ConsultaLog::create([
                'company_id'       => $client->company_id,
                'client_id'        => $client->id,
                'consulta_type_id' => $type->id,
                'parameter'        => $parameter,
                'parameter_label'  => $type->name,
                'cost_price'       => $type->cost_price,
                'sale_price'       => $price,
                'status'           => 'pending',
                'ip_address'       => $context['ip']        ?? null,
                'user_agent'       => $context['user_agent'] ?? null,
            ]);

            // Despacha para a API correspondente (ou modo demo)
            try {
                $payload = $this->dispatch($type, $parameter, $client);

                $log->update([
                    'request_payload' => $payload['request'] ?? null,
                    'result'          => $payload['result']  ?? null,
                    'status'          => $payload['status']  ?? 'success',
                    'error_message'   => $payload['error']   ?? null,
                ]);

                return [
                    'success' => $log->status === 'success',
                    'message' => $log->status === 'success'
                        ? 'Consulta realizada com sucesso.'
                        : ($payload['error'] ?? 'Consulta finalizada sem dados.'),
                    'log'     => $log->fresh(),
                ];
            } catch (\Throwable $e) {
                Log::error('ConsultaService.run falhou', [
                    'type'  => $type->slug,
                    'error' => $e->getMessage(),
                ]);

                $log->update([
                    'status'        => 'failed',
                    'error_message' => $e->getMessage(),
                ]);

                // Reembolsa o cliente em caso de falha do provedor
                $this->wallet->credit(
                    $client,
                    $price,
                    'consulta_refund',
                    "Estorno consulta {$type->name} ({$parameter})",
                    null,
                    $client->user_id,
                );

                return [
                    'success' => false,
                    'message' => 'Não foi possível concluir a consulta. O valor foi estornado para o seu saldo.',
                    'log'     => $log->fresh(),
                ];
            }
        });
    }

    /**
     * Direciona a chamada para o provedor correto.
     *
     * @return array{result?: array, request?: array, status?: string, error?: ?string}
     */
    protected function dispatch(ConsultaType $type, string $parameter, Client $client): array
    {
        $cfg = $type->api_config ?? [];

        // Se não há credencial configurada, devolve resposta de demonstração
        // (modo "preview") para o cliente conseguir testar a UI antes de
        // contratar/configurar a API.
        $hasEndpoint = ! empty($type->api_endpoint) && ! empty($cfg);
        if (! $hasEndpoint) {
            return [
                'request' => ['demo' => true, 'parameter' => $parameter],
                'result'  => $this->demoResult($type, $parameter),
                'status'  => 'success',
                'error'   => null,
            ];
        }

        // Pré-processa parâmetro (sanitiza + valida) antes de qualquer chamada.
        $clean = $this->preprocessParameter($parameter, $cfg);
        if (isset($clean['error'])) {
            return [
                'request' => ['parameter' => $parameter],
                'result'  => null,
                'status'  => 'failed',
                'error'   => $clean['error'],
            ];
        }
        $parameter = $clean['value'];

        // Roteamento por provider quando definido.
        if (strtolower((string) $type->api_provider) === 'confere.link') {
            return $this->callConfereLink($type, $parameter, $client);
        }

        return $this->callGenericProvider($type, $parameter);
    }

    /**
     * Lê o token global de um provedor a partir de `settings(consultas.{provider}_token)`.
     */
    protected function resolveProviderToken(string $providerKey, int $companyId): ?string
    {
        $token = Setting::get($companyId, 'consultas', $providerKey . '_token');

        if (is_string($token)) {
            $token = trim($token);
        }

        return ! empty($token) ? (string) $token : null;
    }

    /**
     * Sanitiza/valida o parâmetro segundo o `api_config` do tipo:
     *   - sanitize:  'digits'      → remove tudo que não é número
     *   - sanitize:  'lower'       → lowercase + trim
     *   - sanitize:  'upper_trim'  → MAIÚSCULAS, sem espaços duplicados
     *   - validate:  'cpf'         → 11 dígitos
     *   - validate:  'cnpj'        → 14 dígitos
     *   - validate:  'cpf_or_cnpj' → 11 OU 14 dígitos
     *   - validate:  'email'       → e-mail válido
     *   - validate:  'phone'       → 10 ou 11 dígitos (com DDD)
     *   - validate:  'cep'         → 8 dígitos
     *   - validate:  'fullname'    → nome completo (≥ 2 palavras de ≥ 2 letras)
     *   - validate:  'min:N'       → comprimento mínimo de N caracteres
     *
     * @return array{value?: string, error?: string}
     */
    protected function preprocessParameter(string $parameter, array $cfg): array
    {
        $value = trim($parameter);

        switch ($cfg['sanitize'] ?? null) {
            case 'digits':
                $value = preg_replace('/\D+/', '', $value);
                break;
            case 'lower':
                $value = mb_strtolower($value);
                break;
            case 'upper_trim':
                $value = mb_strtoupper(trim(preg_replace('/\s+/', ' ', $value)));
                break;
        }

        $rule = $cfg['validate'] ?? null;
        switch (true) {
            case $rule === 'cpf':
                if (strlen($value) !== 11) {
                    return ['error' => 'CPF inválido. Informe os 11 dígitos do CPF.'];
                }
                break;
            case $rule === 'cnpj':
                if (strlen($value) !== 14) {
                    return ['error' => 'CNPJ inválido. Informe os 14 dígitos do CNPJ.'];
                }
                break;
            case $rule === 'cpf_or_cnpj':
                $len = strlen($value);
                if ($len !== 11 && $len !== 14) {
                    return ['error' => 'Documento inválido. Informe um CPF (11 dígitos) ou CNPJ (14 dígitos).'];
                }
                break;
            case $rule === 'email':
                if (! filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    return ['error' => 'E-mail inválido.'];
                }
                break;
            case $rule === 'phone':
                $len = strlen($value);
                if ($len !== 10 && $len !== 11) {
                    return ['error' => 'Telefone inválido. Informe DDD + número (10 ou 11 dígitos).'];
                }
                break;
            case $rule === 'cep':
                if (strlen($value) !== 8) {
                    return ['error' => 'CEP inválido. Informe os 8 dígitos do CEP.'];
                }
                break;
            case $rule === 'fullname':
                $parts = preg_split('/\s+/', $value, -1, PREG_SPLIT_NO_EMPTY);
                if (count($parts) < 2) {
                    return ['error' => 'Informe o nome completo (nome + sobrenome).'];
                }
                foreach ($parts as $p) {
                    if (mb_strlen($p) < 2) {
                        return ['error' => 'Informe o nome completo, sem abreviações.'];
                    }
                }
                break;
            case is_string($rule) && str_starts_with($rule, 'min:'):
                $min = (int) substr($rule, 4);
                if (mb_strlen($value) < $min) {
                    return ['error' => "Informe pelo menos {$min} caracteres."];
                }
                break;
        }

        return ['value' => $value];
    }

    /**
     * Chamada padronizada para o provedor confere.link.
     *
     * O TOKEN é resolvido a partir das configurações da empresa
     * (`settings(group=consultas, key=confere_link_token)`). Se não estiver
     * configurado, retorna erro amigável instruindo o admin.
     *
     * O retorno do confere.link é um JSON cuja chave principal varia por ação
     * (`CADASTRAIS`, `EMPRESA`, `RESULTADO`, etc.). O config do tipo informa em
     * `success_when` quais chaves são esperadas para considerar sucesso.
     */
    protected function callConfereLink(ConsultaType $type, string $parameter, Client $client): array
    {
        $token = $this->resolveProviderToken('confere_link', (int) $client->company_id);

        if (! $token) {
            return [
                'request' => null,
                'result'  => null,
                'status'  => 'failed',
                'error'   => 'O token do provedor confere.link não está configurado. '
                          . 'Peça ao administrador para inserir em "Admin > Consultas > Tokens de Provedores".',
            ];
        }

        // Injeta o TK dinamicamente em `extra` para a chamada genérica
        $cfg                  = $type->api_config ?? [];
        $cfg['extra']         = array_merge($cfg['extra'] ?? [], ['TK' => $token]);
        $type->api_config     = $cfg; // alteração apenas na instância em memória

        $resp = $this->callGenericProvider($type, $parameter);

        if ($resp['status'] === 'failed') {
            // Esconde o token do request salvo no log
            $resp['request'] = $this->maskTokenInPayload($resp['request'] ?? null);
            return $resp;
        }

        $body = $resp['result'] ?? [];

        // Resposta esperada como PDF binário (ex.: SERA_OFC, SERA_PREMIUM).
        // Salvamos no storage privado e o cliente acessa via rota dedicada.
        if (($cfg['response_format'] ?? 'json') === 'pdf') {
            $raw = is_array($body) ? ($body['raw'] ?? null) : null;

            if (! is_string($raw) || ! str_starts_with($raw, '%PDF')) {
                $errorText = is_string($raw) ? trim($raw) : 'O provedor não retornou um PDF.';
                return [
                    'request' => $this->maskTokenInPayload($resp['request'] ?? null),
                    'result'  => ['mensagem' => mb_substr($errorText, 0, 500)],
                    'status'  => 'failed',
                    'error'   => mb_strlen($errorText) > 200 ? 'O provedor retornou um conteúdo inválido (esperado PDF).' : $errorText,
                ];
            }

            $relativePath = sprintf(
                'consultas/pdfs/%s/%s/%s.pdf',
                date('Y'),
                date('m'),
                Str::uuid()->toString(),
            );
            Storage::disk('local')->put($relativePath, $raw);

            return [
                'request' => $this->maskTokenInPayload($resp['request'] ?? null),
                'result'  => [
                    '_format'   => 'pdf',
                    '_path'     => $relativePath,
                    '_size'     => strlen($raw),
                    '_filename' => Str::slug($type->name) . '-' . preg_replace('/\D+/', '', $parameter) . '.pdf',
                ],
                'status'  => 'success',
                'error'   => null,
            ];
        }

        // Resposta esperada como HTML (ex.: SCR_BACEN). Não tratamos como erro
        // mesmo não sendo JSON; salvamos o HTML cru para renderização.
        if (($cfg['response_format'] ?? 'json') === 'html') {
            $raw = is_array($body) ? ($body['raw'] ?? null) : null;

            if (! is_string($raw) || trim($raw) === '') {
                return [
                    'request' => $this->maskTokenInPayload($resp['request'] ?? null),
                    'result'  => null,
                    'status'  => 'failed',
                    'error'   => 'O provedor não retornou conteúdo.',
                ];
            }

            $rawTrim = trim($raw);
            $looksHtml = preg_match('/<\s*(html|table|div|body|head|tr|tbody)\b/i', $rawTrim) === 1;

            // Se o retorno é curto e não parece HTML, provavelmente é mensagem de erro
            if (! $looksHtml && mb_strlen($rawTrim) < 500) {
                return [
                    'request' => $this->maskTokenInPayload($resp['request'] ?? null),
                    'result'  => ['mensagem' => $rawTrim],
                    'status'  => 'failed',
                    'error'   => $rawTrim,
                ];
            }

            return [
                'request' => $this->maskTokenInPayload($resp['request'] ?? null),
                'result'  => ['_format' => 'html', '_html' => $raw],
                'status'  => 'success',
                'error'   => null,
            ];
        }

        // Mensagem de erro do provedor em texto plano
        if (isset($body['raw']) && is_string($body['raw'])) {
            $raw = trim($body['raw']);
            if ($raw !== '' && ! str_starts_with($raw, '{') && ! str_starts_with($raw, '[')) {
                return [
                    'request' => $this->maskTokenInPayload($resp['request'] ?? null),
                    'result'  => ['mensagem' => $raw],
                    'status'  => 'failed',
                    'error'   => $raw,
                ];
            }
        }

        // Erro estruturado retornado pela API (campos comuns no confere.link)
        $errorMsg = $body['ERRO'] ?? $body['MSG'] ?? $body['MENSAGEM'] ?? null;
        if (! empty($errorMsg)) {
            return [
                'request' => $this->maskTokenInPayload($resp['request'] ?? null),
                'result'  => $body,
                'status'  => 'failed',
                'error'   => is_string($errorMsg) ? $errorMsg : 'A API retornou erro.',
            ];
        }

        // Verifica se algum dos campos esperados está presente
        $expected = $cfg['success_when'] ?? [];
        if (! empty($expected)) {
            $hasAny = false;
            foreach ((array) $expected as $key) {
                if (! empty($body[$key])) {
                    $hasAny = true;
                    break;
                }
            }
            if (! $hasAny) {
                return [
                    'request' => $this->maskTokenInPayload($resp['request'] ?? null),
                    'result'  => $body,
                    'status'  => 'no_data',
                    'error'   => 'Nenhum dado encontrado para a consulta informada.',
                ];
            }
        }

        return [
            'request' => $this->maskTokenInPayload($resp['request'] ?? null),
            'result'  => $body,
            'status'  => 'success',
            'error'   => null,
        ];
    }

    /**
     * Substitui o token por placeholder no payload salvo no log
     * (evita que o TK fique exposto no histórico).
     */
    protected function maskTokenInPayload(?array $payload): ?array
    {
        if (! is_array($payload)) {
            return $payload;
        }
        if (isset($payload['TK'])) {
            $payload['TK'] = '***';
        }
        return $payload;
    }

    /**
     * Chamada HTTP genérica configurável via `api_config`. Estrutura esperada:
     *  - method:            GET|POST (default GET)
     *  - headers:           ['Authorization' => 'Bearer xxx']
     *  - param:             nome do parâmetro de query/post (default: parameter)
     *  - extra:             array de campos extras
     *  - timeout:           segundos (default 20)
     *  - space_replacement: caractere para substituir espaços no valor (ex: '+')
     */
    protected function callGenericProvider(ConsultaType $type, string $parameter): array
    {
        $cfg     = $type->api_config ?? [];
        $method  = strtoupper($cfg['method']  ?? 'GET');
        $headers = $cfg['headers'] ?? [];
        $param   = $cfg['param']   ?? 'parameter';
        $extra   = $cfg['extra']   ?? [];
        $timeout = (int) ($cfg['timeout'] ?? 20);

        // Alguns provedores exigem '+' (ou outro caractere) no lugar do espaço.
        if (! empty($cfg['space_replacement'])) {
            $parameter = str_replace(' ', $cfg['space_replacement'], $parameter);
        }

        $payload = array_merge($extra, [$param => $parameter]);

        try {
            $request = Http::withHeaders($headers)->timeout($timeout);

            $response = $method === 'POST'
                ? $request->asJson()->post($type->api_endpoint, $payload)
                : $request->get($type->api_endpoint, $payload);

            if ($response->failed()) {
                return [
                    'request' => $payload,
                    'result'  => $response->json() ?: ['raw' => $response->body()],
                    'status'  => 'failed',
                    'error'   => 'Provedor retornou status ' . $response->status(),
                ];
            }

            $body = $response->json();
            $hasData = ! empty($body) && (! is_array($body) || count($body) > 0);

            return [
                'request' => $payload,
                'result'  => is_array($body) ? $body : ['raw' => $response->body()],
                'status'  => $hasData ? 'success' : 'no_data',
                'error'   => null,
            ];
        } catch (ConnectionException $e) {
            return [
                'request' => $payload,
                'result'  => null,
                'status'  => 'failed',
                'error'   => 'Falha de conexão com o provedor: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Resultado de demonstração caso a API ainda não esteja configurada.
     */
    protected function demoResult(ConsultaType $type, string $parameter): array
    {
        $digits = preg_replace('/\D+/', '', $parameter);
        $isCpf  = strlen($digits) === 11;
        $isCnpj = strlen($digits) === 14;

        if ($type->category === 'pessoas' || $isCpf || str_contains(strtolower($type->slug ?? ''), 'cpf')) {
            return array_merge(['_demo' => true], $this->demoCpfResult($parameter, $digits ?: '00000000000'));
        }

        if ($type->category === 'empresas' || $isCnpj || str_contains(strtolower($type->slug ?? ''), 'cnpj')) {
            return array_merge(['_demo' => true], $this->demoCnpjResult($parameter, $digits ?: '00000000000000'));
        }

        if ($type->category === 'score' || str_contains(strtolower($type->slug ?? ''), 'score')) {
            return array_merge(['_demo' => true], $this->demoScoreResult($parameter, $digits ?: '00000000000'));
        }

        return [
            '_demo'        => true,
            'message'      => 'Resultado de demonstração — configure a API no menu admin > Consultas.',
            'consulta'     => $type->name,
            'categoria'    => $type->category_label,
            'parametro'    => $parameter,
            'consulted_at' => now()->toIso8601String(),
        ];
    }

    protected function demoCpfResult(string $parameter, string $cpf): array
    {
        return [
            'CADASTRAIS' => [
                'CPF'              => $cpf,
                'NOME'             => 'ROBSON SILVA DE JESUS',
                'SEXO'             => 'MASCULINO',
                'NASCIMENTO'       => '15/03/1985',
                'IDADE'            => '41',
                'MAE'              => 'MARIA SILVA DE JESUS',
                'PAI'              => 'JOSE SILVA DE JESUS',
                'RG'               => '12.345.678-9',
                'ORGAO_EMISSOR'    => 'SSP',
                'UF_EMISSOR'       => 'ES',
                'TITULO_ELEITOR'   => '123456789012',
                'NIT'              => '12345678901',
                'CBO'              => '2525-10 — ANALISTA DE SISTEMAS',
                'PROFISSAO'        => 'ANALISTA DE SISTEMAS',
                'ESCOLARIDADE'     => 'SUPERIOR COMPLETO',
                'NACIONALIDADE'    => 'BRASILEIRA',
                'ESTADO_CIVIL'     => 'CASADO',
                'REGISTRO_OBITO'   => 'NÃO CONSTA',
                'CLASSE_ECONOMICA' => 'B',
                'FAIXA_SALARIAL'   => 'DE R$ 3.001 A R$ 5.000',
                'SITUACAO'         => 'REGULAR',
            ],
            'ENDERECOS' => [
                [
                    'LOGRADOURO'  => 'RUA EXEMPLO',
                    'NUMERO'      => '123',
                    'COMPLEMENTO' => 'AP 101',
                    'BAIRRO'      => 'CENTRO',
                    'CIDADE'      => 'VITÓRIA',
                    'UF'          => 'ES',
                    'CEP'         => '29000-000',
                ],
            ],
            'HISTORICO_ENDERECOS' => [
                [
                    'LOGRADOURO' => 'AV BRASIL',
                    'NUMERO'     => '456',
                    'BAIRRO'     => 'JARDIM DA PENHA',
                    'CIDADE'     => 'VITÓRIA',
                    'UF'         => 'ES',
                    'CEP'        => '29060-000',
                ],
                [
                    'LOGRADOURO' => 'RUA DAS FLORES',
                    'NUMERO'     => '78',
                    'BAIRRO'     => 'PRAIA DO CANTO',
                    'CIDADE'     => 'VITÓRIA',
                    'UF'         => 'ES',
                    'CEP'        => '29055-000',
                ],
            ],
            'TELEFONES' => [
                ['DDD' => '27', 'TELEFONE' => '3222-3344', 'TIPO' => 'FIXO', 'OPERADORA' => 'VIVO'],
                ['DDD' => '27', 'TELEFONE' => '99988-7766', 'TIPO' => 'MOVEL', 'OPERADORA' => 'CLARO', 'CLASSIFICACAO' => 4],
                ['DDD' => '27', 'TELEFONE' => '98877-6655', 'TIPO' => 'MOVEL', 'OPERADORA' => 'TIM', 'CLASSIFICACAO' => 3],
            ],
            'EMAILS' => [
                ['EMAIL' => 'robson.exemplo@email.com'],
                ['EMAIL' => 'contato.exemplo@gmail.com'],
            ],
            'POSSIVEIS_PARENTES' => [
                ['NOME' => 'MARIA SILVA DE JESUS', 'CPF' => '11122233344', 'IDADE' => '68', 'CIDADE' => 'VITÓRIA/ES', 'PARENTESCO' => 'MÃE'],
                ['NOME' => 'ANA SILVA DE JESUS', 'CPF' => '55566677788', 'IDADE' => '35', 'CIDADE' => 'VITÓRIA/ES', 'PARENTESCO' => 'IRMÃ'],
            ],
            'POSSIVEIS_VIZINHOS' => [
                ['NOME' => 'CARLOS ALMEIDA', 'LOGRADOURO' => 'RUA EXEMPLO', 'NUMERO' => '121', 'CIDADE' => 'VITÓRIA', 'UF' => 'ES'],
            ],
            'REFERENCIA_PROFISSIONAL' => [
                ['EMPRESA' => 'TECH SOLUTIONS LTDA', 'CIDADE' => 'VITÓRIA', 'UF' => 'ES', 'ADMISSAO' => '01/2018', 'RESCISAO' => '—', 'ANO_BASE' => '2024'],
                ['EMPRESA' => 'HOST BRASIL SA', 'CIDADE' => 'SERRA', 'UF' => 'ES', 'ADMISSAO' => '03/2012', 'RESCISAO' => '12/2017', 'ANO_BASE' => '2017'],
            ],
            'POSSIVEIS_CONTATOS' => [
                ['NOME' => 'FERNANDA COSTA LIMA', 'CPF' => '22233344455', 'IDADE' => '29', 'CIDADE' => 'SERRA/ES', 'RELACAO' => 'CONTATO'],
                ['NOME' => 'PAULO HENRIQUE SANTOS', 'CPF' => '33344455566', 'IDADE' => '44', 'CIDADE' => 'VILA VELHA/ES', 'RELACAO' => 'CONTATO'],
            ],
            'EMPRESAS_SOCIETARIAS' => [
                ['CNPJ' => '12345678000199', 'RAZAO_SOCIAL' => 'TECH SOLUTIONS LTDA', 'PARTICIPACAO' => '50%', 'CARGO' => 'SÓCIO', 'SITUACAO' => 'ATIVA'],
                ['CNPJ' => '98765432000188', 'RAZAO_SOCIAL' => 'HOST BRASIL SA', 'PARTICIPACAO' => '10%', 'CARGO' => 'SÓCIO', 'SITUACAO' => 'ATIVA'],
            ],
            'PENDENCIAS_FINANCEIRAS' => [],
            'PROTESTOS' => [],
            'CHEQUES' => [],
            'SCORE' => 745,
            'RISCO' => 'BAIXO',
        ];
    }

    protected function demoScoreResult(string $parameter, string $doc): array
    {
        return [
            'DOCUMENTO' => $doc,
            'NOME'      => 'ROBSON SILVA DE JESUS',
            'SCORE'     => 782,
            'RISCO'     => 'BAIXO',
            'CADASTRAIS' => [
                'CPF'        => $doc,
                'NOME'       => 'ROBSON SILVA DE JESUS',
                'NASCIMENTO' => '15/03/1985',
                'SITUACAO'   => 'REGULAR',
            ],
            'PENDENCIAS_FINANCEIRAS' => [
                ['CREDOR' => 'BANCO EXEMPLO SA', 'VALOR' => 'R$ 450,00', 'DATA' => '10/2024', 'STATUS' => 'QUITADA'],
            ],
            'PROTESTOS' => [],
            'CHEQUES'   => [],
            'ACOES_JUDICIAIS' => [],
            'INSCRICOES' => [],
            'TOTAL'     => '0',
        ];
    }

    protected function demoCnpjResult(string $parameter, string $cnpj): array
    {
        return [
            'EMPRESA' => [
                'CNPJ'                => $cnpj,
                'RAZAO_SOCIAL'        => 'CENTRAL VIX TECNOLOGIA LTDA',
                'FANTASIA'            => 'CENTRALVIX',
                'ABERTURA'            => '10/05/2018',
                'SITUACAO'            => 'ATIVA',
                'NATUREZA_JURIDICA'   => '206-2 - SOCIEDADE EMPRESÁRIA LIMITADA',
                'ATIVIDADE_PRINCIPAL' => '62.01-5-01 — DESENVOLVIMENTO DE PROGRAMAS',
                'CAPITAL_SOCIAL'      => 'R$ 50.000,00',
                'PORTE'               => 'ME',
            ],
            'ENDERECO' => [
                'LOGRADOURO' => 'RUA COMERCIAL',
                'NUMERO'     => '500',
                'BAIRRO'     => 'CENTRO',
                'CIDADE'     => 'VITÓRIA',
                'UF'         => 'ES',
                'CEP'        => '29010-000',
            ],
            'SOCIOS' => [
                ['NOME' => 'ROBSON SILVA DE JESUS', 'CPF' => '00000000000', 'QUALIFICACAO' => 'SÓCIO-ADMINISTRADOR', 'PARTICIPACAO' => '100%'],
            ],
            'QUADRO_SOCIETARIO' => [
                ['NOME' => 'ROBSON SILVA DE JESUS', 'CPF' => '00000000000', 'QUALIFICACAO' => 'SÓCIO-ADMINISTRADOR', 'PARTICIPACAO' => '100%', 'ENTRADA' => '10/05/2018'],
            ],
            'TELEFONES' => [
                ['DDD' => '27', 'TELEFONE' => '3333-4444', 'TIPO' => 'FIXO', 'OPERADORA' => 'VIVO'],
                ['DDD' => '27', 'TELEFONE' => '99911-2233', 'TIPO' => 'MOVEL', 'OPERADORA' => 'CLARO', 'CLASSIFICACAO' => 5],
            ],
            'EMAILS' => [
                ['EMAIL' => 'contato@centralvix.com.br'],
                ['EMAIL' => 'financeiro@centralvix.com.br'],
            ],
            'PENDENCIAS_FINANCEIRAS' => [],
            'PROTESTOS' => [],
        ];
    }
}
