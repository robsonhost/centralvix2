<?php

namespace App\Services\License;

use App\Models\CompanyLicense;
use App\Models\Setting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class CentralVixLicenseService
{
    public function getOrCreateForCompany(int $companyId): CompanyLicense
    {
        $license = CompanyLicense::where('company_id', $companyId)->first();

        if ($license) {
            if ($this->shouldRevalidate($license)) {
                $this->verifyExisting($license);
                $license->refresh();
            }

            return $license;
        }

        $envKey = trim((string) config('app.centralvix_license_key', env('CENTRALVIX_LICENSE_KEY', '')));
        if ($envKey !== '') {
            $result = $this->activateForCompany($companyId, $envKey);
            if ($result['success'] && $result['license'] instanceof CompanyLicense) {
                return $result['license'];
            }
        }

        return $this->createTrialLicense($companyId);
    }

    public function activateForCompany(int $companyId, string $licenseKey): array
    {
        $licenseKey = trim($licenseKey);
        if ($licenseKey === '') {
            return ['success' => false, 'message' => 'Informe a chave de licença.'];
        }

        $validation = $this->validateRemote($licenseKey);
        if (!($validation['valid'] ?? false)) {
            return [
                'success' => false,
                'message' => $validation['message'] ?? 'Licença inválida ou não encontrada no servidor.',
            ];
        }

        $remote = $validation['license'] ?? [];
        $payload = $this->mapRemoteToLocal($remote, $licenseKey, true);

        $license = CompanyLicense::updateOrCreate(
            ['company_id' => $companyId],
            $payload
        );

        $this->persistLicenseKey($companyId, $licenseKey);

        return [
            'success' => true,
            'message' => 'Licença validada e vinculada com sucesso!',
            'license' => $license->fresh(),
        ];
    }

    public function forceVerify(int $companyId): array
    {
        $license = CompanyLicense::where('company_id', $companyId)->first();
        if (!$license || !$license->license_key) {
            return ['success' => false, 'message' => 'Nenhuma licença configurada para verificar.'];
        }

        return $this->verifyExisting($license);
    }

    public function isCompliant(int $companyId): bool
    {
        if (!config('license.enforce', true)) {
            return true;
        }

        $license = CompanyLicense::where('company_id', $companyId)->first();
        if (!$license) {
            return false;
        }

        // Requisições web usam apenas o status já armazenado no banco — sem chamada
        // HTTP nem consulta extra. A revalidação periódica fica exclusivamente a cargo
        // do job VerifyCentralVixLicenses (cron), evitando timeout em cada page load.
        return !$license->isBlocked();
    }

    public function blockMessage(int $companyId): string
    {
        $license = CompanyLicense::where('company_id', $companyId)->first();
        if (!$license) {
            return 'Nenhuma licença configurada. Informe sua chave em Ajuda & Fiscal → Licença.';
        }

        if ($license->compliance_message) {
            return $license->compliance_message;
        }

        if ($license->isExpired()) {
            return 'Licença expirada em ' . $license->expires_at->format('d/m/Y H:i');
        }

        return match ($license->remote_status) {
            'suspended' => 'Licença suspensa pelo licenciador.',
            'blocked' => 'Licença bloqueada pelo licenciador.',
            'cancelled' => 'Licença cancelada.',
            'expired' => 'Licença expirada.',
            default => 'Licença não está em conformidade com este servidor.',
        };
    }

    private function verifyExisting(CompanyLicense $license): array
    {
        $result = $this->validateRemote((string) $license->license_key);
        $valid = $result['valid'] ?? null;

        // Status DESCONHECIDO (servidor de licença indisponível / sem resposta clara):
        // mantém o estado atual e NÃO bloqueia. Evita derrubar o site por falha transitória.
        if ($valid === null) {
            $license->update(['last_verified_at' => now()]);

            return [
                'success' => (bool) $license->is_compliant,
                'message' => $result['message'] ?? 'Não foi possível verificar a licença agora.',
                'license' => $license->fresh(),
            ];
        }

        // Validação POSITIVA: sincroniza dados e zera o contador de falhas.
        if ($valid === true) {
            Cache::forget($this->failureKey($license->id));
            $license->update($this->mapRemoteToLocal($result['license'] ?? [], (string) $license->license_key, true));

            return [
                'success' => true,
                'message' => 'Licença verificada com sucesso!',
                'license' => $license->fresh(),
            ];
        }

        // Validação NEGATIVA: aplica carência. Só bloqueia após N falhas consecutivas,
        // evitando bloqueio por uma checagem anômala isolada (ex.: IP momentaneamente diferente).
        $failures = (int) Cache::get($this->failureKey($license->id), 0) + 1;
        Cache::put($this->failureKey($license->id), $failures, now()->addHours(2));

        $tolerated = max(1, (int) config('license.failure_grace', 3));
        if ($failures < $tolerated) {
            $license->update(['last_verified_at' => now()]);

            return [
                'success' => (bool) $license->is_compliant,
                'message' => $result['message'] ?? 'Falha na verificação (nova tentativa em instantes).',
                'license' => $license->fresh(),
            ];
        }

        $license->update($this->mapFailedValidation((string) $license->license_key, $result['message'] ?? 'Validação falhou'));

        return [
            'success' => false,
            'message' => $result['message'] ?? 'Falha na verificação',
            'license' => $license->fresh(),
        ];
    }

    private function failureKey(int $licenseId): string
    {
        return 'centralvix.license.failures.' . $licenseId;
    }

    private function shouldRevalidate(CompanyLicense $license): bool
    {
        if (!$license->license_key) {
            return false;
        }

        if (!$license->last_verified_at) {
            return true;
        }

        $minutes = (int) config('license.check_interval_minutes', 1);
        if ($minutes > 0) {
            return $license->last_verified_at->lt(now()->subMinutes($minutes));
        }

        $hours = (int) config('license.check_interval_hours', 24);

        return $license->last_verified_at->lt(now()->subHours($hours));
    }

    /**
     * Revalida licenças de todas as empresas (cron / job).
     */
    public function verifyAllCompanies(): int
    {
        $count = 0;

        CompanyLicense::query()
            ->whereNotNull('license_key')
            ->where('license_key', 'not like', 'TRIAL-%')
            ->orderBy('id')
            ->each(function (CompanyLicense $license) use (&$count) {
                $this->verifyExisting($license);
                $count++;
            });

        return $count;
    }

    public function validateRemote(string $licenseKey): array
    {
        // Domínio/IP resolvidos de forma estável: idênticos em requisição HTTP e no
        // agendador (CLI/cron). Evita enviar "localhost" / 127.0.0.1 e gerar bloqueio falso.
        $domain = $this->resolveDomain();
        $ip = $this->resolveServerIp();

        // Quando a tabela system_licenses existe no banco local, este servidor É o servidor
        // de licenças. Validar via HTTP seria uma chamada circular ao próprio servidor,
        // causando timeouts a cada minuto no agendador. Vai direto ao banco.
        if (Schema::hasTable('system_licenses')) {
            return $this->validateFromDatabase($licenseKey, $domain, $ip);
        }

        $apiUrl = config('license.api_url') ?: rtrim((string) config('app.url'), '/') . '/license/api.php';

        try {
            $response = Http::timeout(10)
                ->asForm()
                ->post($apiUrl . '?action=validate', [
                    'license_key' => $licenseKey,
                    'domain' => $domain,
                    'ip' => $ip,
                ]);

            if ($response->successful()) {
                $data = $response->json();
                // Só consideramos uma resposta conclusiva quando ela traz a chave 'valid'.
                if (is_array($data) && array_key_exists('valid', $data)) {
                    return $data;
                }
            }
        } catch (\Throwable $e) {
            Log::warning('CentralVix license API unreachable', [
                'url' => $apiUrl,
                'error' => $e->getMessage(),
            ]);
        }

        // Servidor de licença indisponível/inconclusivo: status DESCONHECIDO (valid = null).
        // Não bloqueia o site — mantém o último estado conhecido.
        return [
            'valid' => null,
            'unknown' => true,
            'message' => 'Servidor de licenças indisponível no momento. Mantendo último status válido.',
        ];
    }

    private function validateFromDatabase(string $licenseKey, string $domain, string $ip): array
    {
        $row = DB::table('system_licenses')->where('license_key', $licenseKey)->first();

        if (!$row) {
            return ['valid' => false, 'message' => 'Licença não encontrada. Verifique a chave no painel licenciador.'];
        }

        $license = (array) $row;

        if (($license['status'] ?? '') !== 'active') {
            $status = $license['status'] ?? 'inativa';
            $message = match ($status) {
                'suspended' => 'Licença suspensa pelo licenciador',
                'blocked' => 'Licença bloqueada pelo licenciador',
                'cancelled' => 'Licença cancelada',
                'expired' => 'Licença expirada',
                default => 'Licença ' . $status,
            };
            return ['valid' => false, 'message' => $message, 'license' => $license];
        }

        if (!empty($license['expires_at']) && strtotime($license['expires_at']) < time()) {
            DB::table('system_licenses')->where('id', $license['id'])->update(['status' => 'expired']);
            return ['valid' => false, 'message' => 'Licença expirada em ' . $license['expires_at'], 'license' => $license];
        }

        if (!empty($license['domain']) && $domain && $license['domain'] !== $domain) {
            return [
                'valid' => false,
                'message' => "Domínio não autorizado. Licença vinculada a: {$license['domain']}",
                'license' => $license,
            ];
        }

        if (!empty($license['ip_address']) && $ip && $license['ip_address'] !== $ip) {
            return [
                'valid' => false,
                'message' => "IP não autorizado. Licença vinculada a: {$license['ip_address']}",
                'license' => $license,
            ];
        }

        DB::table('system_licenses')
            ->where('id', $license['id'])
            ->update(['last_check' => now()]);

        try {
            DB::table('system_licenses')->where('id', $license['id'])->increment('check_count');
        } catch (\Throwable) {
            // coluna opcional
        }

        $this->recordActivation((int) $license['id'], $domain, $ip);

        return ['valid' => true, 'message' => 'Licença válida', 'license' => $license];
    }

    private function recordActivation(int $licenseId, string $domain, string $ip): void
    {
        if (!Schema::hasTable('license_activations')) {
            return;
        }

        try {
            DB::table('license_activations')->updateOrInsert(
                [
                    'license_id' => $licenseId,
                    'domain' => $domain,
                    'ip_address' => $ip,
                ],
                [
                    'server_hostname' => gethostname() ?: null,
                    'php_version' => PHP_VERSION,
                    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? null,
                    'activated_at' => now(),
                    'last_seen' => now(),
                    'is_active' => true,
                    'created_at' => now(),
                ]
            );
        } catch (\Throwable $e) {
            Log::debug('License activation record skipped', ['error' => $e->getMessage()]);
        }
    }

    private function mapRemoteToLocal(array $remote, string $licenseKey, bool $valid): array
    {
        $planType = $remote['plan_type'] ?? 'trial';
        $expiresAt = !empty($remote['expires_at']) ? $remote['expires_at'] : null;

        return [
            'license_key' => $licenseKey,
            'remote_license_id' => $remote['id'] ?? null,
            'license_type' => $this->normalizePlanType($planType),
            'registered_to' => $remote['client_name'] ?? 'CentralVix',
            'registered_domain' => $remote['domain'] ?? $this->resolveDomain(),
            'max_clients' => (int) ($remote['max_clients'] ?? 0),
            'valid_domain' => $remote['domain'] ?? $this->resolveDomain(),
            'valid_ip' => $remote['ip_address'] ?? $this->resolveServerIp(),
            'valid_directory' => base_path(),
            'branding_removal' => in_array($planType, ['professional', 'enterprise', 'lifetime'], true),
            'remote_status' => $remote['status'] ?? 'active',
            'is_compliant' => $valid,
            'compliance_message' => $valid ? null : 'Licença não conforme',
            'issued_at' => !empty($remote['issued_at']) ? $remote['issued_at'] : (!empty($remote['created_at']) ? $remote['created_at'] : now()),
            'expires_at' => $expiresAt,
            'last_verified_at' => now(),
            'active' => true,
        ];
    }

    private function mapFailedValidation(string $licenseKey, string $message): array
    {
        return [
            'license_key' => $licenseKey,
            'is_compliant' => false,
            'compliance_message' => $message,
            'last_verified_at' => now(),
            'active' => true,
        ];
    }

    private function normalizePlanType(string $planType): string
    {
        return match ($planType) {
            'standard', 'basic' => 'basic',
            'professional' => 'professional',
            'enterprise', 'lifetime' => 'enterprise',
            default => 'trial',
        };
    }

    private function createTrialLicense(int $companyId): CompanyLicense
    {
        $days = config('license.trial_days', 30);

        return CompanyLicense::create([
            'company_id' => $companyId,
            'license_key' => 'TRIAL-' . strtoupper(substr(md5((string) $companyId . config('app.key')), 0, 16)),
            'license_type' => 'trial',
            'registered_to' => 'Demonstração',
            'registered_domain' => request()->getHost(),
            'max_clients' => 10,
            'valid_domain' => request()->getHost(),
            'valid_ip' => $this->resolveServerIp(),
            'valid_directory' => base_path(),
            'branding_removal' => false,
            'remote_status' => 'trial',
            'is_compliant' => true,
            'compliance_message' => 'Modo demonstração — vincule uma licença emitida em /license/ para produção.',
            'issued_at' => now(),
            'expires_at' => now()->addDays($days),
            'last_verified_at' => now(),
            'active' => true,
        ]);
    }

    private function persistLicenseKey(int $companyId, string $licenseKey): void
    {
        Setting::set($companyId, 'license', 'key', $licenseKey);

        $envPath = base_path('.env');
        if (!is_writable($envPath)) {
            return;
        }

        $contents = file_get_contents($envPath);
        if ($contents === false) {
            return;
        }

        if (preg_match('/^CENTRALVIX_LICENSE_KEY=.*$/m', $contents)) {
            $contents = preg_replace('/^CENTRALVIX_LICENSE_KEY=.*$/m', 'CENTRALVIX_LICENSE_KEY=' . $licenseKey, $contents);
        } else {
            $contents .= "\nCENTRALVIX_LICENSE_KEY=" . $licenseKey . "\n";
        }

        file_put_contents($envPath, $contents);
    }

    /**
     * Resolve o domínio do servidor de forma estável (HTTP e CLI/cron).
     *
     * Prioriza o host configurado em APP_URL (sempre disponível, inclusive no
     * agendador) para nunca enviar "localhost" ao licenciador.
     */
    private function resolveDomain(): string
    {
        $appHost = parse_url((string) config('app.url'), PHP_URL_HOST);
        if (is_string($appHost) && $appHost !== '' && !$this->isLocalHost($appHost)) {
            Cache::forever('centralvix.license.server_domain', $appHost);
            return $appHost;
        }

        // Em requisição HTTP real, usa o host da requisição (e guarda para reuso no cron).
        if (!app()->runningInConsole()) {
            $host = request()->getHost();
            if (is_string($host) && $host !== '' && !$this->isLocalHost($host)) {
                Cache::forever('centralvix.license.server_domain', $host);
                return $host;
            }
        }

        // Reusa o último domínio confiável capturado em contexto HTTP.
        $cached = Cache::get('centralvix.license.server_domain');
        if (is_string($cached) && $cached !== '') {
            return $cached;
        }

        return is_string($appHost) ? (string) $appHost : '';
    }

    /**
     * Resolve o IP do servidor de forma estável (HTTP e CLI/cron).
     *
     * Em HTTP, SERVER_ADDR é o IP real do servidor (igual ao validado no painel) e é
     * memorizado em cache. No agendador (sem SERVER_ADDR), reutiliza esse valor para
     * não enviar 127.0.0.1 e disparar "IP não autorizado". Se nada confiável existir,
     * retorna string vazia: o licenciador então ignora a checagem de IP em vez de bloquear.
     */
    private function resolveServerIp(): string
    {
        $serverAddr = $_SERVER['SERVER_ADDR'] ?? null;
        if ($this->isUsableIp($serverAddr)) {
            Cache::forever('centralvix.license.server_ip', $serverAddr);
            return (string) $serverAddr;
        }

        $cached = Cache::get('centralvix.license.server_ip');
        if ($this->isUsableIp($cached)) {
            return (string) $cached;
        }

        // Último recurso offline: IP público resolvido pelo DNS do domínio.
        $domain = $this->resolveDomain();
        if ($domain !== '') {
            $resolved = @gethostbyname($domain);
            if ($this->isUsableIp($resolved)) {
                return (string) $resolved;
            }
        }

        $reqIp = request()->ip();
        if ($this->isUsableIp($reqIp)) {
            return (string) $reqIp;
        }

        return '';
    }

    /**
     * IP utilizável para validação: válido e não-loopback. IPs privados são aceitos
     * porque, em hospedagens, o SERVER_ADDR registrado no painel pode ser interno.
     */
    private function isUsableIp(?string $ip): bool
    {
        if (!is_string($ip) || $ip === '' || !filter_var($ip, FILTER_VALIDATE_IP)) {
            return false;
        }

        return !in_array($ip, ['127.0.0.1', '::1', '0.0.0.0'], true);
    }

    private function isLocalHost(string $host): bool
    {
        return in_array(strtolower($host), ['localhost', '127.0.0.1', '::1'], true);
    }
}
