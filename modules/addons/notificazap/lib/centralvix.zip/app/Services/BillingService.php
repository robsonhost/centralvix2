<?php

namespace App\Services;

use App\Models\Client;
use App\Models\Coupon;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductBundle;
use App\Models\Service;
use App\Models\Setting;
use App\Events\InvoiceGenerated;
use Carbon\Carbon;
use Illuminate\Support\Str;

class BillingService
{
    public function createOrder(Client $client, Product $product, string $billingCycle, ?string $domain = null, ?Coupon $coupon = null): Order
    {
        $unitPrice = $product->getPriceForCycle($billingCycle);
        $discount = 0;

        if ($coupon) {
            $discount = $coupon->calculateDiscount($unitPrice);
            $coupon->increment('uses');
        }

        $total = max(0, $unitPrice - $discount);

        $order = Order::create([
            'uuid' => Str::uuid(),
            'company_id' => $client->company_id,
            'client_id' => $client->id,
            'status' => 'pending',
            'total' => $total + $product->setup_fee,
            'discount' => $discount,
            'tax' => 0,
            'ip_address' => request()->ip(),
        ]);

        // Create service
        $nextDueDate = $this->getNextDueDate($billingCycle);

        $service = Service::create([
            'uuid' => Str::uuid(),
            'company_id' => $client->company_id,
            'client_id' => $client->id,
            'product_id' => $product->id,
            'order_id' => $order->id,
            'name' => $product->name,
            'status' => 'pending',
            'domain' => \App\Support\HostingRules::normalizeDomain($domain),
            'module' => $product->module,
            'server_id' => $product->server_id ?? $product->module_config['server_id'] ?? null,
            'billing_cycle' => $billingCycle,
            'amount' => $unitPrice,
            'setup_fee' => $product->setup_fee,
            'first_payment_date' => now()->toDateString(),
            'next_due_date' => $nextDueDate,
        ]);

        if ($product->type === 'domain' && $domain) {
            \App\Models\Domain::create([
                'company_id' => $client->company_id,
                'client_id' => $client->id,
                'service_id' => $service->id,
                'domain' => strtolower(trim($domain)),
                'status' => 'pending',
                'auto_renew' => true,
            ]);
        }

        OrderItem::create([
            'order_id' => $order->id,
            'product_id' => $product->id,
            'service_id' => $service->id,
            'description' => $product->name . ' (' . $billingCycle . ')',
            'qty' => 1,
            'unit_price' => $unitPrice,
            'total' => $total,
            'billing_cycle' => $billingCycle,
        ]);

        // Generate invoice
        $this->createInvoiceForService($service, $order);

        return $order;
    }

    public function createInvoiceForService(Service $service, ?Order $order = null): Invoice
    {
        $client = $service->client;
        $companyId = (int) $client->company_id;
        $dueDays = (int) Setting::get($companyId, 'billing', 'due_days', 7);

        $tax = app(TaxService::class);
        $currency = app(CurrencyService::class);

        // Itens na moeda BASE.
        $items = [
            [
                'description' => $service->name . ' - ' . $this->getBillingCycleLabel($service->billing_cycle),
                'amount' => (float) $service->amount,
            ],
        ];
        if ($service->setup_fee > 0) {
            $items[] = [
                'description' => 'Taxa de configuração - ' . $service->name,
                'amount' => (float) $service->setup_fee,
            ];
        }

        $issRate = $tax->issRate($companyId);

        // Moeda da fatura + taxa de câmbio aplicada.
        $invoiceCurrency = $currency->resolveForClient($client);
        $invoiceRate = $currency->invoiceRate($companyId, $invoiceCurrency);
        $conv = fn (float $valueBase): float => $currency->convertFromBase($companyId, $valueBase, $invoiceCurrency);

        $subtotal = 0.0;
        $taxTotal = 0.0;
        $rows = [];

        foreach ($items as $item) {
            $amount = $conv($item['amount']);
            $itemTax = $issRate > 0 ? round($amount * $issRate / 100, 2) : 0.0;

            $subtotal += $amount;
            $taxTotal += $itemTax;

            $rows[] = [
                'service_id' => $service->id,
                'domain_id' => $service->domains()->value('id'),
                'item_type' => $service->product?->type === 'domain' ? 'domain_register' : null,
                'description' => $item['description'],
                'amount' => $amount,
                'tax_rate' => $issRate,
                'tax_amount' => $itemTax,
                'total' => round($amount + $itemTax, 2),
            ];
        }

        $total = round($subtotal + $taxTotal, 2);

        $invoice = Invoice::create([
            'uuid' => Str::uuid(),
            'company_id' => $companyId,
            'client_id' => $client->id,
            'order_id' => $order?->id,
            'date_created' => now()->toDateString(),
            'date_due' => now()->addDays($dueDays)->toDateString(),
            'status' => 'unpaid',
            'subtotal' => round($subtotal, 2),
            'discount' => 0,
            'tax' => round($taxTotal, 2),
            'total' => $total,
            'amount_paid' => 0,
            'currency' => $invoiceCurrency,
            'exchange_rate' => $invoiceRate,
        ]);

        foreach ($rows as $row) {
            InvoiceItem::create(array_merge(['invoice_id' => $invoice->id], $row));
        }

        InvoiceGenerated::dispatch($invoice);

        return $invoice;
    }

    public function generateRecurringInvoices(): int
    {
        $generated = 0;
        $daysAhead = (int) config('centralvix.billing.generate_days_ahead', 7);

        $services = Service::where('status', 'active')
            ->whereDate('next_due_date', '<=', now()->addDays($daysAhead))
            ->get();

        foreach ($services as $service) {
            $existing = Invoice::where('client_id', $service->client_id)
                ->whereHas('items', fn($q) => $q->where('service_id', $service->id))
                ->whereIn('status', ['unpaid', 'overdue'])
                ->exists();

            if (!$existing) {
                $this->createInvoiceForService($service);
                $generated++;
            }
        }

        return $generated;
    }

    public function suspendOverdueServices(): int
    {
        $suspended = 0;
        $gracedays = (int) config('centralvix.billing.auto_suspend_days', 3);

        $services = Service::where('status', 'active')
            ->where('override_auto_suspend', false)
            ->whereDate('next_due_date', '<=', now()->subDays($gracedays))
            ->get();

        foreach ($services as $service) {
            $hasUnpaid = Invoice::where('client_id', $service->client_id)
                ->whereHas('items', fn($q) => $q->where('service_id', $service->id))
                ->whereIn('status', ['unpaid', 'overdue'])
                ->exists();

            if ($hasUnpaid) {
                $service->update(['status' => 'suspended']);
                $suspended++;
            }
        }

        return $suspended;
    }

    public function createUpgradeInvoice(Service $service, array $quote): Invoice
    {
        $client = $service->client;
        $companyId = (int) $client->company_id;
        $dueDays = (int) Setting::get($companyId, 'billing', 'due_days', 7);
        $amount = (float) $quote['amount_due'];

        $invoice = Invoice::create([
            'uuid' => Str::uuid(),
            'company_id' => $companyId,
            'client_id' => $client->id,
            'status' => 'unpaid',
            'subtotal' => $amount,
            'discount' => (float) ($quote['prorata_credit'] ?? 0),
            'tax' => 0,
            'total' => $amount,
            'amount_paid' => 0,
            'date_created' => now()->toDateString(),
            'date_due' => now()->addDays($dueDays)->toDateString(),
            'notes' => json_encode(['type' => 'service_upgrade', 'service_id' => $service->id]),
        ]);

        InvoiceItem::create([
            'invoice_id' => $invoice->id,
            'service_id' => $service->id,
            'item_type' => 'service_upgrade',
            'description' => 'Upgrade: ' . ($quote['new_product'] ?? $service->name),
            'amount' => $amount,
            'total' => $amount,
            'metadata' => $quote,
        ]);

        InvoiceGenerated::dispatch($invoice);

        return $invoice;
    }

    public function createBundleOrder(Client $client, ProductBundle $bundle, ?Coupon $coupon = null): Order
    {
        $bundle->loadMissing('items.product');
        $discountPct = (float) $bundle->discount_percent;
        $orderTotal = 0;
        $orderDiscount = 0;

        $order = Order::create([
            'uuid' => Str::uuid(),
            'company_id' => $client->company_id,
            'client_id' => $client->id,
            'status' => 'pending',
            'total' => 0,
            'discount' => 0,
            'tax' => 0,
            'ip_address' => request()->ip(),
        ]);

        foreach ($bundle->items as $bundleItem) {
            $product = $bundleItem->product;
            if (!$product) {
                continue;
            }

            $cycle = $bundleItem->billing_cycle ?: 'annually';
            $unitPrice = $product->getPriceForCycle($cycle);
            $lineDiscount = round($unitPrice * ($discountPct / 100), 2);
            $lineTotal = max(0, $unitPrice - $lineDiscount);

            if ($coupon) {
                $lineTotal = max(0, $lineTotal - $coupon->calculateDiscount($lineTotal));
            }

            $service = Service::create([
                'uuid' => Str::uuid(),
                'company_id' => $client->company_id,
                'client_id' => $client->id,
                'product_id' => $product->id,
                'order_id' => $order->id,
                'name' => $product->name,
                'status' => 'pending',
                'module' => $product->module,
                'server_id' => $product->server_id ?? null,
                'billing_cycle' => $cycle,
                'amount' => $lineTotal,
                'first_payment_date' => now()->toDateString(),
                'next_due_date' => $this->getNextDueDate($cycle),
            ]);

            OrderItem::create([
                'order_id' => $order->id,
                'product_id' => $product->id,
                'service_id' => $service->id,
                'description' => $bundle->name . ' — ' . $product->name,
                'qty' => 1,
                'unit_price' => $unitPrice,
                'total' => $lineTotal,
                'billing_cycle' => $cycle,
            ]);

            $this->createInvoiceForService($service, $order);
            $orderTotal += $lineTotal;
            $orderDiscount += $lineDiscount;
        }

        if ($coupon) {
            $coupon->increment('uses');
        }

        $order->update(['total' => $orderTotal, 'discount' => $orderDiscount]);

        return $order->fresh();
    }

    public function getNextDueDate(string $billingCycle): string
    {
        return match ($billingCycle) {
            'monthly' => now()->addMonth()->toDateString(),
            'quarterly' => now()->addMonths(3)->toDateString(),
            'semiannually' => now()->addMonths(6)->toDateString(),
            'annually' => now()->addYear()->toDateString(),
            'biennially' => now()->addYears(2)->toDateString(),
            'triennially' => now()->addYears(3)->toDateString(),
            'lifetime' => now()->addYears(100)->toDateString(),
            default => now()->addMonth()->toDateString(),
        };
    }

    private function getBillingCycleLabel(string $cycle): string
    {
        return match ($cycle) {
            'monthly' => 'Mensal',
            'quarterly' => 'Trimestral',
            'semiannually' => 'Semestral',
            'annually' => 'Anual',
            'biennially' => 'Bienal',
            'triennially' => 'Trienal',
            'lifetime' => 'Vitalício',
            default => ucfirst($cycle),
        };
    }
}
