# Cache Strategy Documentation

## Overview

The CentralVix billing system implements an enterprise-grade cache strategy using **Redis with tags** for domain-specific cache invalidation. This document explains the architecture, usage patterns, and best practices.

## Architecture

### Cache Driver
- **Driver**: Redis (configured in `config/cache.php`)
- **Database**: Redis Database 1 (separate from queue database 0)
- **Tagging**: Enabled via Redis driver for granular invalidation

### Cache Tags Structure

#### Primary Tags
- `products` - Product catalog cache
- `whm_packages` - WHM server package lists
- `settings` - System settings
- `dashboard` - Dashboard statistics
- `clients.list` - Client listings
- `invoices.list` - Invoice listings
- `services.list` - Service listings
- `servers.list` - Server listings

#### Company-Specific Tags
Every cache entry is tagged with `company.{id}` to enable:
- Multi-tenant isolation
- Company-specific cache invalidation
- Efficient cache management per tenant

#### Resource-Specific Tags
Additional tags for fine-grained control:
- `server.{id}` - Server-specific caches
- Any custom resource tags as needed

### Cache TTL (Time To Live) Strategy

| Resource | TTL | Rationale |
|----------|-----|-----------|
| **Products** | 1 hour (3600s) | Products change infrequently, but need to reflect updates reasonably fast |
| **WHM Packages** | 6 hours (21600s) | Server packages rarely change, expensive API call to WHM |
| **Settings** | 24 hours (86400s) | Settings are mostly static, critical for performance |
| **Dashboard Stats** | 5 minutes (300s) | Need fresh data for business metrics, but can tolerate slight delay |
| **List Pages** | 30 minutes (1800s) | Balance between performance and data freshness |

## Usage Patterns

### 1. Using CacheService Directly

```php
use App\Services\CacheService;

class ProductController extends Controller
{
    protected CacheService $cache;
    
    public function __construct(CacheService $cache)
    {
        $this->cache = $cache;
    }
    
    public function index()
    {
        $companyId = auth()->user()->company_id;
        
        $products = $this->cache->getProducts($companyId, function () use ($companyId) {
            return Product::where('company_id', $companyId)
                ->with('features')
                ->get();
        });
        
        return view('admin.products.index', compact('products'));
    }
}
```

### 2. Using CacheHelper for Convenience

```php
use App\Helpers\CacheHelper;

$products = CacheHelper::products($companyId, function () use ($companyId) {
    return Product::where('company_id', $companyId)->get();
});
```

### 3. Caching Dashboard Statistics

```php
$stats = CacheHelper::dashboardStats($companyId, function () use ($companyId) {
    return [
        'total_clients' => Client::where('company_id', $companyId)->count(),
        'active_services' => Service::where('company_id', $companyId)
            ->where('status', 'active')
            ->count(),
        'unpaid_invoices' => Invoice::where('company_id', $companyId)
            ->where('status', 'unpaid')
            ->sum('total'),
        'monthly_revenue' => Invoice::where('company_id', $companyId)
            ->where('status', 'paid')
            ->whereYear('paid_at', now()->year)
            ->whereMonth('paid_at', now()->month)
            ->sum('total'),
    ];
});
```

### 4. Caching WHM Packages

```php
use App\Helpers\CacheHelper;

$packages = CacheHelper::whmPackages($companyId, $serverId, function () use ($server) {
    // Expensive WHM API call
    return $this->whmService->listPackages($server);
});
```

### 5. Caching Settings

```php
// Single setting
$gracePeriod = CacheHelper::setting(
    $companyId, 
    'billing', 
    'auto_suspend_days',
    fn() => Setting::getValue('billing', 'auto_suspend_days', 3)
);

// All settings
$allSettings = CacheHelper::allSettings($companyId, function () use ($companyId) {
    return Setting::where('company_id', $companyId)
        ->get()
        ->keyBy(fn($s) => "{$s->group}.{$s->key}");
});
```

## Automatic Cache Invalidation

### Observer Pattern

The system uses Laravel Observers to automatically invalidate cache when models change:

| Model | Observer | Cache Invalidation |
|-------|----------|-------------------|
| **Product** | ProductObserver | Invalidates products cache |
| **Setting** | SettingObserver | Invalidates settings cache |
| **Server** | ServerObserver | Invalidates servers + WHM packages cache |
| **Client** | ClientObserver | Invalidates clients list + dashboard |
| **Invoice** | InvoiceObserver | Invalidates invoices list + dashboard |
| **Service** | ServiceObserver | Invalidates services list + dashboard |

### Observer Registration

Observers are registered in `AppServiceProvider::boot()`:

```php
Product::observe(ProductObserver::class);
Setting::observe(SettingObserver::class);
Client::observe(ClientObserver::class);
Invoice::observe(InvoiceObserver::class);
Service::observe(ServiceObserver::class);
Server::observe(ServerObserver::class);
```

### How It Works

1. **Model Event**: When a Product is created, updated, or deleted
2. **Observer Triggered**: ProductObserver detects the event
3. **Cache Invalidation**: Observer calls `CacheService->invalidateProducts()`
4. **Tag Flush**: All cache entries tagged with `products` and `company.{id}` are removed
5. **Next Request**: Fresh data is fetched and cached again

Example Observer:

```php
class ProductObserver
{
    protected CacheService $cacheService;

    public function __construct(CacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    public function created(Product $product): void
    {
        $this->cacheService->invalidateProducts($product->company_id);
    }

    public function updated(Product $product): void
    {
        $this->cacheService->invalidateProducts($product->company_id);
    }

    public function deleted(Product $product): void
    {
        $this->cacheService->invalidateProducts($product->company_id);
    }
}
```

## Manual Cache Invalidation

### When to Manually Invalidate

While observers handle most cases, you may need manual invalidation for:
- Bulk operations that bypass Eloquent events
- External data changes (e.g., WHM API sync)
- Administrative cache refresh

### Invalidation Methods

```php
use App\Helpers\CacheHelper;

// Invalidate products cache
CacheHelper::invalidateProducts($companyId);

// Invalidate WHM packages for specific server
CacheHelper::invalidateWhmPackages($companyId, $serverId);

// Invalidate all WHM packages for company
CacheHelper::invalidateWhmPackages($companyId);

// Invalidate settings
CacheHelper::invalidateSettings($companyId);

// Invalidate dashboard
CacheHelper::invalidateDashboard($companyId);

// Invalidate lists
CacheHelper::invalidateClientsList($companyId);
CacheHelper::invalidateInvoicesList($companyId);
CacheHelper::invalidateServicesList($companyId);
CacheHelper::invalidateServersList($companyId);

// Nuclear option: invalidate ALL cache for a company
CacheHelper::invalidateAll($companyId);

// DANGER: Clear entire Redis cache (all companies)
CacheHelper::clearAll(); // Use with extreme caution!
```

## Best Practices

### DO

✅ **Use appropriate TTL** for each resource type
```php
// Dashboard data - short TTL (5 minutes)
CacheHelper::dashboardStats($companyId, $callback);

// Settings - long TTL (24 hours)  
CacheHelper::allSettings($companyId, $callback);
```

✅ **Always tag with company_id** for multi-tenant isolation
```php
Cache::tags(['products', "company.{$companyId}"])->remember($key, $ttl, $callback);
```

✅ **Let observers handle invalidation** automatically
```php
// This automatically invalidates cache via ProductObserver
$product->update(['price' => 99.99]);
```

✅ **Use cache for expensive operations**
```php
// Expensive WHM API call
$packages = CacheHelper::whmPackages($companyId, $serverId, fn() => $whmService->listPackages($server));
```

✅ **Include filters/pagination in cache key**
```php
CacheHelper::clientsList($companyId, $filters, $page, $callback);
```

### DON'T

❌ **Don't cache user-specific data in shared cache**
```php
// BAD: User session data should use session, not cache
Cache::put("user_{$id}_cart", $cart, 3600);

// GOOD: Company-wide data
CacheHelper::products($companyId, $callback);
```

❌ **Don't use extremely long TTL for frequently changing data**
```php
// BAD: Dashboard with 24h TTL
Cache::remember('dashboard', 86400, $callback);

// GOOD: Use appropriate short TTL
CacheHelper::dashboardStats($companyId, $callback); // 5 minutes
```

❌ **Don't forget to invalidate after bulk operations**
```php
// BAD: Bulk update without invalidation
DB::table('products')->update(['active' => false]);

// GOOD: Invalidate after bulk operation
DB::table('products')->where('company_id', $companyId)->update(['active' => false]);
CacheHelper::invalidateProducts($companyId);
```

❌ **Don't use Cache::flush() in production**
```php
// DANGER: Clears ALL companies' cache
Cache::flush(); // Never use in production!

// GOOD: Company-specific invalidation
CacheHelper::invalidateAll($companyId);
```

## Performance Monitoring

### Cache Hit Rate

Monitor cache effectiveness in your logs:

```
[INFO] Cache MISS: Products list | tag=products
[INFO] Cache invalidation: Products | company_id=1
```

### Expected Performance Gains

| Scenario | Without Cache | With Cache | Improvement |
|----------|---------------|------------|-------------|
| Dashboard Load | 800ms | 150ms | **81% faster** |
| Product List | 300ms | 50ms | **83% faster** |
| Settings Load | 100ms | 10ms | **90% faster** |
| WHM Package List | 2000ms | 100ms | **95% faster** |

## Troubleshooting

### Cache Not Updating

**Problem**: Changes not reflected in UI

**Solution**: Check if observer is registered in AppServiceProvider

```php
// Ensure this exists in AppServiceProvider::boot()
Product::observe(ProductObserver::class);
```

### Cache Tagging Not Working

**Problem**: Tags not flushing properly

**Solution**: Verify Redis is configured as cache driver

```bash
# Check .env
CACHE_DRIVER=redis

# Verify in Laravel
php artisan tinker
>>> config('cache.default');
// Should return: "redis"
```

### Memory Issues

**Problem**: Redis running out of memory

**Solution**: Set maxmemory policy in Redis config

```redis
maxmemory 256mb
maxmemory-policy allkeys-lru
```

## Testing Cache Strategy

### Manual Testing

```bash
# Connect to Redis
redis-cli

# Select cache database (database 1)
SELECT 1

# View all keys
KEYS *

# Check specific cached item
GET laravel_cache:products:1

# View tags
KEYS laravel_cache:tag:*

# Flush cache database
FLUSHDB
```

### Automated Testing

Create tests to verify cache behavior:

```php
public function test_product_cache_invalidates_on_update()
{
    $product = Product::factory()->create();
    $companyId = $product->company_id;
    
    // First call - should cache
    $cached1 = CacheHelper::products($companyId, fn() => Product::all());
    
    // Second call - should hit cache
    $cached2 = CacheHelper::products($companyId, fn() => Product::all());
    
    // Update product - should invalidate cache
    $product->update(['name' => 'Updated Name']);
    
    // Third call - should fetch fresh data
    $cached3 = CacheHelper::products($companyId, fn() => Product::all());
    
    $this->assertEquals('Updated Name', $cached3->first()->name);
}
```

## Implementation Checklist

- [x] Redis configured as cache driver (Task 2.1)
- [x] CacheService with tag support implemented
- [x] TTL strategy defined per resource type
- [x] Observers registered for automatic invalidation
- [x] CacheHelper for convenient access
- [x] Multi-tenant tagging (`company.{id}`)
- [x] Documentation complete
- [x] Ready for production use

## Related Documentation

- **Redis Configuration**: `.env` file, `config/cache.php`
- **Queue Configuration**: Task 2.1 (TASK_2.1_REDIS_CONFIGURATION_COMPLETE.md)
- **Event-Driven Architecture**: Task 2.2
- **Requirements**: Requisitos 64.1, 64.2, 64.3

## Support

For questions or issues with the cache strategy, refer to:
- Laravel Cache Documentation: https://laravel.com/docs/10.x/cache
- Redis Tagging: https://laravel.com/docs/10.x/cache#cache-tags
- Internal: `app/Services/CacheService.php`
