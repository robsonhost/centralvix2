<?php

namespace App\Services;

use App\Models\AutoLoginLog;
use App\Models\AutoLoginToken;
use App\Models\Client;
use App\Models\Contract;
use App\Models\Invoice;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class AutoLoginService
{
    public function isEnabled(int $companyId): bool
    {
        return app(ModuleService::class)->isEnabled($companyId, 'autologin');
    }

    public function config(int $companyId): array
    {
        return app(ModuleSettingsService::class)->all($companyId, 'autologin');
    }

    public function ttlMinutes(int $companyId): int
    {
        $seconds = (int) ($this->config($companyId)['token_ttl_seconds'] ?? 3600);

        return max(1, (int) ceil($seconds / 60));
    }

    public function generateLink(
        Client $client,
        ?string $redirectTo = null,
        ?int $ttlMinutes = null,
        ?string $sentVia = 'manual',
        ?int $createdBy = null,
    ): string {
        $ttl = $ttlMinutes ?? $this->ttlMinutes($client->company_id);
        $token = AutoLoginToken::generate($client, $redirectTo, null, null, $ttl, $sentVia, $createdBy);

        return $token->publicUrl($this->useShortLinks($client->company_id));
    }

    public function generateInvoiceLink(Client $client, Invoice $invoice, ?int $ttl = null): string
    {
        $ttl ??= $this->ttlMinutes($client->company_id);
        $redirectTo = route('client.invoices.show', $invoice);
        $token = AutoLoginToken::generate($client, $redirectTo, 'invoice', $invoice->id, $ttl, 'system');

        return $token->publicUrl($this->useShortLinks($client->company_id));
    }

    public function generateTicketLink(Client $client, Ticket $ticket, ?int $ttl = null): string
    {
        $ttl ??= $this->ttlMinutes($client->company_id);
        $redirectTo = route('client.tickets.show', $ticket);
        $token = AutoLoginToken::generate($client, $redirectTo, 'ticket', $ticket->id, $ttl, 'system');

        return $token->publicUrl($this->useShortLinks($client->company_id));
    }

    public function generateContractLink(Client $client, Contract $contract, ?int $ttl = 1440): string
    {
        $redirectTo = url('/contract/' . $contract->signature_token);
        $token = AutoLoginToken::generate($client, $redirectTo, 'contract', $contract->id, $ttl, 'system');

        return $token->publicUrl($this->useShortLinks($client->company_id));
    }

    public function generateDashboardLink(Client $client, ?int $ttl = null): string
    {
        return $this->generateLink($client, route('client.dashboard'), $ttl);
    }

    /** Verifica se links devem ser embutidos em e-mails transacionais. */
    public function shouldEmbedInEmails(int $companyId): bool
    {
        if (!$this->isEnabled($companyId)) {
            return false;
        }

        return (bool) ($this->config($companyId)['embed_in_emails'] ?? true);
    }

    /** Verifica se links de auto login devem ir nos templates WhatsApp. */
    public function shouldEmbedInWhatsApp(int $companyId): bool
    {
        if (!$this->isEnabled($companyId)) {
            return false;
        }

        return (bool) ($this->config($companyId)['whatsapp_integration'] ?? true);
    }

    /** Gera link de auto login para e-mails (fatura, ticket, etc.) ou null se indisponível. */
    public function linkForEmail(Client $client, string $redirectTo, string $contextType = 'generic', ?int $contextId = null): ?string
    {
        if (!$this->shouldEmbedInEmails($client->company_id) || !$this->clientCanAutoLogin($client)) {
            return null;
        }

        return $this->linkForChannel($client, $redirectTo, $contextType, $contextId, 'email_auto');
    }

    /** Gera link de auto login para WhatsApp ou null se indisponível. */
    public function linkForWhatsApp(Client $client, string $redirectTo, string $contextType = 'generic', ?int $contextId = null): ?string
    {
        if (!$this->shouldEmbedInWhatsApp($client->company_id) || !$this->clientCanAutoLogin($client)) {
            return null;
        }

        return $this->linkForChannel($client, $redirectTo, $contextType, $contextId, 'whatsapp_auto');
    }

    /**
     * Preenche invoice_url, payment_url, ticket_url, portal_url etc. nos templates WhatsApp.
     */
    public function enrichWhatsAppTemplateData(Client $client, array $data, string $contextType = '', int $contextId = 0): array
    {
        if (!$this->shouldEmbedInWhatsApp($client->company_id)) {
            return $data;
        }

        $portalFallback = route('client.dashboard');
        $data['portal_url'] = $this->linkForWhatsApp($client, $portalFallback)
            ?? ($data['portal_url'] ?? $portalFallback);

        $supportFallback = route('client.tickets.create');
        $data['support_url'] = $this->linkForWhatsApp($client, $supportFallback)
            ?? ($data['support_url'] ?? $supportFallback);

        $invoiceId = (int) ($data['invoice_id'] ?? ($contextType === 'invoice' ? $contextId : 0));
        if ($invoiceId > 0) {
            $invoice = Invoice::find($invoiceId);
            if ($invoice && $invoice->client_id === $client->id) {
                $fallback = route('client.invoices.show', $invoice);
                $url = $this->linkForWhatsApp($client, $fallback, 'invoice', $invoice->id) ?? $fallback;
                $data['invoice_url'] = $url;
                $data['payment_url'] = $url;
            }
        }

        $ticketId = (int) ($data['ticket_id'] ?? ($contextType === 'ticket' ? $contextId : 0));
        if ($ticketId > 0) {
            $ticket = Ticket::find($ticketId);
            if ($ticket && $ticket->client_id === $client->id) {
                $fallback = route('client.tickets.show', $ticket);
                $data['ticket_url'] = $this->linkForWhatsApp($client, $fallback, 'ticket', $ticket->id) ?? $fallback;
            }
        }

        return $data;
    }

    protected function linkForChannel(
        Client $client,
        string $redirectTo,
        string $contextType,
        ?int $contextId,
        string $sentVia,
    ): ?string {
        if ($contextType === 'invoice' && $contextId) {
            $invoice = Invoice::find($contextId);
            if ($invoice && $invoice->client_id === $client->id) {
                $token = AutoLoginToken::generate(
                    $client,
                    route('client.invoices.show', $invoice),
                    'invoice',
                    $invoice->id,
                    $this->ttlMinutes($client->company_id),
                    $sentVia,
                );

                return $token->publicUrl($this->useShortLinks($client->company_id));
            }
        }

        if ($contextType === 'ticket' && $contextId) {
            $ticket = Ticket::find($contextId);
            if ($ticket && $ticket->client_id === $client->id) {
                $token = AutoLoginToken::generate(
                    $client,
                    route('client.tickets.show', $ticket),
                    'ticket',
                    $ticket->id,
                    $this->ttlMinutes($client->company_id),
                    $sentVia,
                );

                return $token->publicUrl($this->useShortLinks($client->company_id));
            }
        }

        return $this->generateLink($client, $redirectTo, null, $sentVia);
    }

    /** Login mágico por e-mail (sem senha). */
    public function sendMagicLink(string $email, ?int $companyId = null): array
    {
        $query = Client::where('email', $email)->where('status', '!=', 'closed');
        if ($companyId) {
            $query->where('company_id', $companyId);
        }
        $client = $query->first();

        // Resposta genérica (não revela se e-mail existe)
        if (!$client || !$this->isEnabled($client->company_id)) {
            return ['success' => true, 'message' => 'Se o e-mail estiver cadastrado, você receberá um link de acesso.'];
        }

        if (!($this->config($client->company_id)['magic_login_enabled'] ?? true)) {
            return ['success' => false, 'message' => 'Login por link não está habilitado.'];
        }

        if (!$this->clientCanAutoLogin($client)) {
            return ['success' => true, 'message' => 'Se o e-mail estiver cadastrado, você receberá um link de acesso.'];
        }

        $link = $this->generateLink($client, route('client.dashboard'), null, 'magic_email');

        try {
            $companyName = app(BrandingService::class)->get($client->company_id)['company_name'] ?? config('app.name');
            Mail::send('emails.autologin-magic-link', [
                'client' => $client,
                'link' => $link,
                'companyName' => $companyName,
                'ttlMinutes' => $this->ttlMinutes($client->company_id),
            ], fn ($m) => $m->to($client->email)->subject('Seu link de acesso — ' . $companyName));
        } catch (\Throwable $e) {
            Log::error('Magic login e-mail falhou: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Não foi possível enviar o e-mail. Tente novamente.'];
        }

        return ['success' => true, 'message' => 'Enviamos um link de acesso para seu e-mail.'];
    }

    public function sendLinkToClient(
        Client $client,
        ?string $redirectTo,
        string $channel = 'email',
        ?User $admin = null,
    ): array {
        if (!$this->isEnabled($client->company_id)) {
            return ['success' => false, 'message' => 'Módulo Auto Login desativado.'];
        }

        if (!$this->clientCanAutoLogin($client)) {
            return ['success' => false, 'message' => 'Cliente sem serviço ativo — auto login bloqueado pela configuração.'];
        }

        $link = $this->generateLink(
            $client,
            $redirectTo ?: route('client.dashboard'),
            null,
            $channel,
            $admin?->id,
        );

        if ($channel === 'whatsapp') {
            if (!($this->config($client->company_id)['whatsapp_integration'] ?? true)) {
                return ['success' => true, 'message' => 'Integração WhatsApp desativada — link gerado para cópia.', 'link' => $link];
            }

            return $this->dispatchWhatsApp($client, $link);
        }

        try {
            $companyName = app(BrandingService::class)->get($client->company_id)['company_name'] ?? config('app.name');
            Mail::send('emails.autologin-link', [
                'client' => $client,
                'link' => $link,
                'companyName' => $companyName,
            ], fn ($m) => $m->to($client->email)->subject('Link de acesso — ' . $companyName));
            return ['success' => true, 'message' => 'Link enviado por e-mail.', 'link' => $link];
        } catch (\Throwable $e) {
            return ['success' => true, 'message' => 'Link gerado (e-mail falhou — copie manualmente).', 'link' => $link];
        }
    }

    public function resolve(string $token): ?AutoLoginToken
    {
        $record = AutoLoginToken::where('token', $token)->first();

        if (!$record || !$record->isValid()) {
            return null;
        }

        if ($record->single_use) {
            $record->update(['used' => true, 'used_at' => now()]);
        }

        return $record;
    }

    public function resolveShort(string $shortCode): ?AutoLoginToken
    {
        $record = AutoLoginToken::where('short_code', $shortCode)->first();
        if (!$record) {
            return null;
        }

        return $this->resolve($record->token);
    }

    public function recordClick(AutoLoginToken $token, Request $request): void
    {
        $token->increment('click_count');
        $token->update([
            'last_clicked_at' => now(),
            'ip_address'      => $request->ip(),
            'user_agent'      => substr((string) $request->userAgent(), 0, 500),
        ]);
    }

    public function logAccess(
        ?AutoLoginToken $token,
        Request $request,
        bool $success,
        ?string $failureReason = null,
    ): void {
        if (!$token || !($this->config($token->company_id)['log_access'] ?? true)) {
            return;
        }

        AutoLoginLog::create([
            'auto_login_token_id' => $token->id,
            'client_id'           => $token->client_id,
            'company_id'          => $token->company_id,
            'ip_address'          => $request->ip(),
            'user_agent'          => substr((string) $request->userAgent(), 0, 1000),
            'success'             => $success,
            'failure_reason'      => $failureReason,
        ]);
    }

    public function clientCanAutoLogin(Client $client): bool
    {
        if ($client->status === 'closed') {
            return false;
        }

        if (!($this->config($client->company_id)['require_active_service'] ?? false)) {
            return true;
        }

        return $client->services()->where('status', 'active')->exists();
    }

    protected function useShortLinks(int $companyId): bool
    {
        return (bool) ($this->config($companyId)['short_links'] ?? true);
    }

    protected function dispatchWhatsApp(Client $client, string $link): array
    {
        if (!app(ModuleService::class)->isEnabled($client->company_id, 'whatsapp')) {
            return ['success' => true, 'message' => 'WhatsApp desativado — link gerado para cópia.', 'link' => $link];
        }

        $phone = preg_replace('/\D/', '', $client->mobile ?? $client->phone ?? '');
        if ($phone === '') {
            return ['success' => false, 'message' => 'Cliente sem telefone/WhatsApp cadastrado.', 'link' => $link];
        }

        try {
            $message = "Olá {$client->firstname}! Acesse sua área do cliente:\n{$link}";
            $sent = app(\App\Services\WhatsApp\WhatsappNotificationService::class)->sendRaw(
                $client->company_id,
                $phone,
                $message,
                $client,
                'autologin',
                0,
            );

            if ($sent) {
                return ['success' => true, 'message' => 'Link enviado via WhatsApp.', 'link' => $link];
            }
        } catch (\Throwable $e) {
            Log::warning('AutoLogin WhatsApp: ' . $e->getMessage());
        }

        return ['success' => true, 'message' => 'Link gerado (WhatsApp indisponível — copie manualmente).', 'link' => $link];
    }
}
