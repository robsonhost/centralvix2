<?php

namespace App\Services;

use App\Models\Holiday;
use App\Models\HolidaySetting;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class HolidayService
{
    /**
     * Ajustar data de vencimento considerando feriados e fins de semana
     */
    public function adjustDueDate(Carbon $date, int $companyId): Carbon
    {
        $settings = $this->getSettings($companyId);

        if (!$settings->enabled) {
            return $date;
        }

        $adjusted = $date->copy();
        $maxIterations = 30; // Evitar loop infinito
        $iteration = 0;

        while ($iteration < $maxIterations) {
            $needsAdjustment = false;

            // Verificar se é fim de semana
            if ($settings->adjust_weekends && in_array($adjusted->dayOfWeek, $settings->skip_weekdays ?? [0, 6])) {
                $needsAdjustment = true;
            }

            // Verificar se é feriado
            if (!$needsAdjustment && $this->isHoliday($adjusted, $companyId, $settings)) {
                $needsAdjustment = true;
            }

            if ($needsAdjustment) {
                $adjusted->addDays($settings->default_adjustment_days);
                $iteration++;
            } else {
                break;
            }
        }

        return $adjusted;
    }

    /**
     * Verificar se uma data é feriado
     */
    public function isHoliday(Carbon $date, int $companyId, ?HolidaySetting $settings = null): bool
    {
        $settings = $settings ?? $this->getSettings($companyId);

        $query = Holiday::where('company_id', $companyId)
            ->active()
            ->forDate($date);

        // Verificar feriados nacionais
        if ($settings->adjust_national_holidays) {
            $query->orWhere(fn($q) => $q->where('type', 'national')->forDate($date));
        }

        // Verificar feriados estaduais
        if ($settings->adjust_state_holidays && $settings->state_code) {
            $query->orWhere(fn($q) => $q->where('type', 'state')
                ->where('state_code', $settings->state_code)
                ->forDate($date));
        }

        // Verificar feriados municipais
        if ($settings->adjust_municipal_holidays && $settings->city_name) {
            $query->orWhere(fn($q) => $q->where('type', 'municipal')
                ->where('city_name', $settings->city_name)
                ->forDate($date));
        }

        return $query->exists();
    }

    /**
     * Obter configurações de feriados
     */
    public function getSettings(int $companyId): HolidaySetting
    {
        return HolidaySetting::firstOrCreate(
            ['company_id' => $companyId],
            [
                'enabled' => true,
                'adjust_weekends' => true,
                'adjust_national_holidays' => true,
                'adjust_state_holidays' => false,
                'adjust_municipal_holidays' => false,
                'default_adjustment_days' => 1,
                'skip_weekdays' => [0, 6], // Domingo e Sábado
            ]
        );
    }

    /**
     * Gerar feriados nacionais brasileiros para um ano
     * Fonte: Febrabran
     */
    public function generateNationalHolidays(int $year, int $companyId): void
    {
        $holidays = [
            // Feriados fixos
            ['name' => 'Confraternização Universal', 'date' => "{$year}-01-01", 'type' => 'national'],
            ['name' => 'Tiradentes', 'date' => "{$year}-04-21", 'type' => 'national'],
            ['name' => 'Dia do Trabalhador', 'date' => "{$year}-05-01", 'type' => 'national'],
            ['name' => 'Independência do Brasil', 'date' => "{$year}-09-07", 'type' => 'national'],
            ['name' => 'Nossa Senhora Aparecida', 'date' => "{$year}-10-12", 'type' => 'national'],
            ['name' => 'Finados', 'date' => "{$year}-11-02", 'type' => 'national'],
            ['name' => 'Proclamação da República', 'date' => "{$year}-11-15", 'type' => 'national'],
            ['name' => 'Dia da Consciência Negra', 'date' => "{$year}-11-20", 'type' => 'national'],
            ['name' => 'Natal', 'date' => "{$year}-12-25", 'type' => 'national'],
        ];

        // Calcular Páscoa (algoritmo de Meeus)
        $easter = $this->calculateEaster($year);

        // Feriados móveis baseados na Páscoa
        $holidays[] = [
            'name' => 'Carnaval (Segunda-feira)',
            'date' => $easter->copy()->subDays(48)->toDateString(),
            'type' => 'national',
            'recurring_rule' => 'easter-48',
        ];
        $holidays[] = [
            'name' => 'Carnaval (Terça-feira)',
            'date' => $easter->copy()->subDays(47)->toDateString(),
            'type' => 'national',
            'recurring_rule' => 'easter-47',
        ];
        $holidays[] = [
            'name' => 'Sexta-feira Santa',
            'date' => $easter->copy()->subDays(2)->toDateString(),
            'type' => 'national',
            'recurring_rule' => 'easter-2',
        ];
        $holidays[] = [
            'name' => 'Páscoa',
            'date' => $easter->toDateString(),
            'type' => 'national',
            'recurring_rule' => 'easter',
        ];
        $holidays[] = [
            'name' => 'Corpus Christi',
            'date' => $easter->copy()->addDays(60)->toDateString(),
            'type' => 'national',
            'recurring_rule' => 'easter+60',
        ];

        // Inserir ou atualizar feriados
        foreach ($holidays as $holiday) {
            Holiday::updateOrCreate(
                [
                    'company_id' => $companyId,
                    'date' => $holiday['date'],
                    'type' => $holiday['type'],
                ],
                array_merge($holiday, [
                    'recurring' => true,
                    'adjusts_due_date' => true,
                    'adjustment_days' => 1,
                    'is_active' => true,
                ])
            );
        }
    }

    /**
     * Calcular data da Páscoa usando o algoritmo de Meeus
     */
    private function calculateEaster(int $year): Carbon
    {
        $a = $year % 19;
        $b = intval($year / 100);
        $c = $year % 100;
        $d = intval($b / 4);
        $e = $b % 4;
        $f = intval(($b + 8) / 25);
        $g = intval(($b - $f + 1) / 3);
        $h = (19 * $a + $b - $d - $g + 15) % 30;
        $i = intval($c / 4);
        $k = $c % 4;
        $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7;
        $m = intval(($a + 11 * $h + 22 * $l) / 451);
        $month = intval(($h + $l - 7 * $m + 114) / 31);
        $day = (($h + $l - 7 * $m + 114) % 31) + 1;

        return Carbon::create($year, $month, $day);
    }

    /**
     * Sincronizar feriados de múltiplos anos
     */
    public function syncHolidaysForYears(int $companyId, int $startYear, int $endYear): void
    {
        for ($year = $startYear; $year <= $endYear; $year++) {
            $this->generateNationalHolidays($year, $companyId);
        }
    }

    /**
     * Obter próximos feriados
     */
    public function getUpcomingHolidays(int $companyId, int $limit = 10): array
    {
        return Holiday::where('company_id', $companyId)
            ->active()
            ->where('date', '>=', now())
            ->orderBy('date')
            ->limit($limit)
            ->get()
            ->toArray();
    }

    /**
     * Verificar e ajustar todas as faturas futuras não pagas
     */
    public function adjustAllPendingInvoices(int $companyId): int
    {
        $invoices = DB::table('invoices')
            ->where('company_id', $companyId)
            ->whereIn('status', ['unpaid', 'pending'])
            ->where('due_date', '>=', now())
            ->get();

        $adjusted = 0;

        foreach ($invoices as $invoice) {
            $originalDate = Carbon::parse($invoice->due_date);
            $adjustedDate = $this->adjustDueDate($originalDate, $companyId);

            if (!$originalDate->isSameDay($adjustedDate)) {
                DB::table('invoices')
                    ->where('id', $invoice->id)
                    ->update(['due_date' => $adjustedDate]);
                $adjusted++;
            }
        }

        return $adjusted;
    }
}
