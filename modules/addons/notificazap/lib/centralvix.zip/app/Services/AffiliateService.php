<?php

namespace App\Services;

use App\Models\Affiliate;
use App\Models\AffiliateReferral;
use App\Models\Client;
use App\Models\Invoice;

class AffiliateService
{
    public function trackReferral(Client $client, string $affiliateCode): void
    {
        $affiliate = Affiliate::where('code', $affiliateCode)
            ->where('status', 'active')
            ->first();

        if ($affiliate && $affiliate->client_id !== $client->id) {
            $client->update(['affiliate_id' => $affiliate->id]);
            $affiliate->increment('clicks');
        }
    }

    public function processCommission(Invoice $invoice): void
    {
        $client = $invoice->client;

        if (!$client->affiliate_id) {
            return;
        }

        $affiliate = Affiliate::find($client->affiliate_id);

        if (!$affiliate || $affiliate->status !== 'active') {
            return;
        }

        // Check if already processed
        $existing = AffiliateReferral::where('affiliate_id', $affiliate->id)
            ->where('invoice_id', $invoice->id)
            ->exists();

        if ($existing) {
            return;
        }

        $commission = $affiliate->commission_type === 'percentage'
            ? round($invoice->total * ($affiliate->commission_value / 100), 2)
            : min($affiliate->commission_value, $invoice->total);

        AffiliateReferral::create([
            'affiliate_id' => $affiliate->id,
            'client_id' => $client->id,
            'invoice_id' => $invoice->id,
            'amount' => $invoice->total,
            'commission' => $commission,
            'status' => 'pending',
        ]);

        $affiliate->increment('conversions');
    }

    public function approveCommission(AffiliateReferral $referral): void
    {
        if ($referral->status !== 'pending') {
            return;
        }

        $referral->update(['status' => 'approved']);
        $referral->affiliate->increment('balance', $referral->commission);
        $referral->affiliate->increment('total_earned', $referral->commission);
    }

    public function payout(Affiliate $affiliate, float $amount): void
    {
        if ($affiliate->balance < $amount) {
            throw new \InvalidArgumentException('Saldo insuficiente.');
        }

        $affiliate->decrement('balance', $amount);

        // Mark referrals as paid
        AffiliateReferral::where('affiliate_id', $affiliate->id)
            ->where('status', 'approved')
            ->update(['status' => 'paid']);
    }
}
