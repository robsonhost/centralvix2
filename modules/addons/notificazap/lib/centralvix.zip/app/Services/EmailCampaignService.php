<?php

namespace App\Services;

use App\Mail\CampaignMail;
use App\Models\Client;
use App\Models\EmailCampaign;
use App\Models\EmailCampaignRecipient;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class EmailCampaignService
{
    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function isEnabled(int $companyId): bool
    {
        return $this->modules->isEnabled($companyId, 'email_marketing');
    }

    public function config(int $companyId): array
    {
        return $this->settings->all($companyId, 'email_marketing');
    }

    /**
     * Monta a lista de destinatários da campanha a partir da audiência,
     * removendo duplicados, e-mails vazios e quem optou por descadastro.
     */
    public function buildRecipients(EmailCampaign $campaign): int
    {
        $campaign->recipients()->delete();

        $query = Client::where('company_id', $campaign->company_id)
            ->whereNotNull('email')
            ->where('email', '!=', '');

        if (\Illuminate\Support\Facades\Schema::hasColumn('clients', 'marketing_opt_out')) {
            $query->where(function ($q) {
                $q->whereNull('marketing_opt_out')->orWhere('marketing_opt_out', false);
            });
        }

        switch ($campaign->audience) {
            case 'active':
                $query->where('status', 'active');
                break;
            case 'overdue':
                $query->whereHas('invoices', fn ($q) => $q->where('status', 'overdue'));
                break;
            case 'specific':
                $query->whereIn('id', $campaign->client_ids ?: [0]);
                break;
        }

        $seen = [];
        $count = 0;

        $query->select('id', 'email', 'firstname', 'lastname')
            ->chunkById(500, function ($clients) use ($campaign, &$seen, &$count) {
                $rows = [];
                foreach ($clients as $client) {
                    $email = strtolower(trim($client->email));
                    if ($email === '' || isset($seen[$email]) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        continue;
                    }
                    $seen[$email] = true;
                    $rows[] = [
                        'campaign_id' => $campaign->id,
                        'client_id' => $client->id,
                        'email' => $client->email,
                        'name' => trim(($client->firstname ?? '') . ' ' . ($client->lastname ?? '')) ?: null,
                        'status' => 'pending',
                        'token' => Str::random(48),
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                    $count++;
                }
                if ($rows) {
                    EmailCampaignRecipient::insert($rows);
                }
            });

        $campaign->update(['total_recipients' => $count]);

        return $count;
    }

    /**
     * Processa um lote de envios respeitando o limite diário. Reagenda para
     * o dia seguinte caso ainda restem destinatários pendentes.
     */
    public function processBatch(EmailCampaign $campaign): void
    {
        if (!$this->isEnabled($campaign->company_id)) {
            $campaign->update(['status' => 'cancelled']);
            return;
        }

        if ($campaign->status === 'cancelled') {
            return;
        }

        $cfg = $this->config($campaign->company_id);
        $dailyLimit = (int) ($cfg['daily_limit'] ?? 500);
        $fromName = $cfg['from_name'] ?: ($campaign->company->name ?? config('app.name'));
        $replyTo = $cfg['reply_to'] ?: null;
        $includeUnsub = (bool) ($cfg['include_unsubscribe'] ?? true);

        if (!$campaign->started_at) {
            $campaign->update(['status' => 'sending', 'started_at' => now()]);
        }

        $pending = $campaign->recipients()
            ->where('status', 'pending')
            ->limit(max(1, $dailyLimit))
            ->get();

        foreach ($pending as $recipient) {
            try {
                Mail::to($recipient->email)->send(
                    new CampaignMail($campaign, $recipient, $fromName, $replyTo, $includeUnsub)
                );
                $recipient->update(['status' => 'sent', 'sent_at' => now()]);
                $campaign->increment('sent_count');
            } catch (\Throwable $e) {
                $recipient->update(['status' => 'failed', 'error' => Str::limit($e->getMessage(), 500)]);
                $campaign->increment('failed_count');
                Log::error("Campanha #{$campaign->id} destinatário #{$recipient->id}: " . $e->getMessage());
            }
        }

        $remaining = $campaign->recipients()->where('status', 'pending')->count();

        if ($remaining > 0) {
            \App\Jobs\SendEmailCampaign::dispatch($campaign->id)->delay(now()->addDay());
        } else {
            $campaign->update(['status' => 'sent', 'completed_at' => now()]);
        }
    }

    public function registerOpen(EmailCampaignRecipient $recipient): void
    {
        if ($recipient->opened_at) {
            return;
        }

        $recipient->update(['opened_at' => now(), 'status' => 'opened']);
        $recipient->campaign()->increment('opened_count');
    }
}
