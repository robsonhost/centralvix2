<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Collection;

class ModuleService
{
    public function definitions(): array
    {
        return config('modules.modules', []);
    }

    public function categories(): array
    {
        return config('modules.categories', []);
    }

    public function all(int $companyId): Collection
    {
        return collect($this->definitions())->map(function (array $def, string $slug) use ($companyId) {
            return $this->enrich($slug, $def, $companyId);
        })->values();
    }

    public function grouped(int $companyId): Collection
    {
        return $this->all($companyId)->groupBy('category');
    }

    public function find(string $slug): ?array
    {
        $def = $this->definitions()[$slug] ?? null;

        return $def ? array_merge($def, ['slug' => $slug]) : null;
    }

    public function isEnabled(int $companyId, string $slug): bool
    {
        $def = $this->definitions()[$slug] ?? null;
        if (!$def) {
            return false;
        }

        if (!empty($def['depends_on']) && !$this->isEnabled($companyId, $def['depends_on'])) {
            return false;
        }

        $explicit = Setting::where('company_id', $companyId)
            ->where('group', 'modules')
            ->where('key', $slug)
            ->first();

        if ($explicit !== null) {
            return (bool) $explicit->typed_value;
        }

        if (!empty($def['legacy_key'])) {
            $legacy = Setting::where('company_id', $companyId)
                ->where('group', 'general')
                ->where('key', $def['legacy_key'])
                ->first();

            if ($legacy !== null) {
                return (bool) $legacy->typed_value;
            }
        }

        // Consultas: se o admin já configurou tipos ativos, libera no painel do cliente.
        if ($slug === 'consultas' && class_exists(\App\Models\ConsultaType::class)) {
            if (\App\Models\ConsultaType::active()->exists()) {
                return true;
            }
        }

        return (bool) ($def['default'] ?? false);
    }

    public function toggle(int $companyId, string $slug, ?bool $enabled = null): bool
    {
        if (!$this->find($slug)) {
            throw new \InvalidArgumentException("Módulo '{$slug}' não encontrado.");
        }

        $newState = $enabled ?? !$this->isEnabled($companyId, $slug);
        Setting::set($companyId, 'modules', $slug, $newState, 'boolean');

        if (!$newState) {
            $this->disableDependents($companyId, $slug);
        }

        return $newState;
    }

    public function stats(int $companyId): array
    {
        $all = $this->all($companyId);
        $enabled = $all->where('enabled', true)->count();

        return [
            'total' => $all->count(),
            'enabled' => $enabled,
            'disabled' => $all->count() - $enabled,
        ];
    }

    public function enrich(string $slug, array $def, int $companyId): array
    {
        $enabled = $this->isEnabled($companyId, $slug);
        $dependsOn = $def['depends_on'] ?? null;
        $dependencyEnabled = $dependsOn ? $this->isEnabled($companyId, $dependsOn) : true;

        return array_merge($def, [
            'slug' => $slug,
            'enabled' => $enabled,
            'can_toggle' => $dependencyEnabled || !$dependsOn,
            'depends_on_label' => $dependsOn ? ($this->definitions()[$dependsOn]['name'] ?? $dependsOn) : null,
            'config_url' => $this->resolveConfigUrl($def),
        ]);
    }

    private function disableDependents(int $companyId, string $parentSlug): void
    {
        foreach ($this->definitions() as $slug => $def) {
            if (($def['depends_on'] ?? null) === $parentSlug && $this->isEnabled($companyId, $slug)) {
                Setting::set($companyId, 'modules', $slug, false, 'boolean');
            }
        }
    }

    private function resolveConfigUrl(array $def): ?string
    {
        $routeName = $def['config_route'] ?? null;
        if (!$routeName || !\Route::has($routeName)) {
            return null;
        }

        $params = $def['config_params'] ?? [];

        return $params ? route($routeName, $params) : route($routeName);
    }
}
