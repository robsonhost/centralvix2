<?php

namespace App\Services;

use App\Events\ServiceProvisioned;
use App\Events\ServiceReactivated;
use App\Models\Server;
use App\Models\Service;
use App\Support\HostingRules;

class ProvisioningService
{
    public function provision(Service $service): bool
    {
        if (!$service->module) {
            $service->update(['status' => 'active']);
            return true;
        }

        $this->assertProvisionable($service);

        try {
            $module = $this->loadModule($service->module, $service->server);
            $result = $module->create($service);

            if ($result) {
                $service->update(['status' => 'active']);
                $password = method_exists($module, 'getLastGeneratedPassword')
                    ? $module->getLastGeneratedPassword()
                    : $service->getDecryptedPassword();

                ServiceProvisioned::dispatch($service->fresh(['client', 'product', 'server']), $password);
                logger()->info("Service #{$service->id} provisioned successfully.");
            }

            return $result;
        } catch (\Exception $e) {
            logger()->error("Provisioning failed for service #{$service->id}: " . $e->getMessage());
            throw $e;
        }
    }

    public function suspend(Service $service): bool
    {
        if (!$service->module) {
            $service->update(['status' => 'suspended']);
            return true;
        }

        try {
            $module = $this->loadModule($service->module, $service->server);
            $result = $module->suspend($service);

            if ($result) {
                $service->update(['status' => 'suspended']);
            }

            return $result;
        } catch (\Exception $e) {
            logger()->error("Suspend failed for service #{$service->id}: " . $e->getMessage());
            $service->update(['status' => 'suspended']);
            return true;
        }
    }

    public function unsuspend(Service $service): bool
    {
        if (!$service->module) {
            $service->update(['status' => 'active']);
            return true;
        }

        try {
            $module = $this->loadModule($service->module, $service->server);
            $result = $module->unsuspend($service);

            if ($result) {
                $service->update(['status' => 'active']);
                ServiceReactivated::dispatch($service->fresh(['client', 'product', 'server']));
            }

            return $result;
        } catch (\Exception $e) {
            logger()->error("Unsuspend failed for service #{$service->id}: " . $e->getMessage());
            throw $e;
        }
    }

    public function terminate(Service $service): bool
    {
        if (!$service->module) {
            $service->update(['status' => 'terminated']);
            return true;
        }

        try {
            $module = $this->loadModule($service->module, $service->server);
            $module->terminate($service);
            $service->update(['status' => 'terminated']);
            return true;
        } catch (\Exception $e) {
            logger()->error("Terminate failed for service #{$service->id}: " . $e->getMessage());
            $service->update(['status' => 'terminated']);
            return true;
        }
    }

    public function changePassword(Service $service, string $newPassword): bool
    {
        if (!$service->server) {
            $service->update(['password' => encrypt($newPassword)]);
            return true;
        }

        try {
            $module = $this->getModule($service);
            return $module->changePassword($service, $newPassword);
        } catch (\Exception $e) {
            logger()->error("Password change failed for service #{$service->id}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Gera URL de login SSO para o painel do serviço (cPanel, etc.).
     */
    public function createLoginSession(Service $service, string $serviceType = 'cpaneld'): ?string
    {
        if (!$service->server) {
            return null;
        }

        try {
            $module = $this->getModule($service);

            if (!method_exists($module, 'createLoginSession')) {
                return $service->module_data['cpanel_url'] ?? null;
            }

            return $module->createLoginSession($service, $serviceType);
        } catch (\Exception $e) {
            logger()->error("Login session failed for service #{$service->id}: " . $e->getMessage());
            return null;
        }
    }

    public function createWhmLoginSession(Service $service): ?string
    {
        return $this->createLoginSession($service, 'whostmgrd');
    }

    /**
     * Instancia o módulo de provisionamento do serviço.
     */
    public function getModule(Service $service): object
    {
        $moduleName = $this->resolveModuleName($service);

        return $this->loadModule($moduleName, $service->server);
    }

    /**
     * Nome do módulo efetivo (produto → serviço → cPanel padrão).
     */
    public function resolveModuleName(Service $service): string
    {
        if ($service->module) {
            return $service->module;
        }

        if ($service->product?->module) {
            return $service->product->module;
        }

        return 'CpanelModule';
    }

    /**
     * Resolve and instantiate a provisioning module.
     * Search order: Modules\Hosting\X → Modules\Vps\X → Modules\X\Module
     */
    private function loadModule(string $moduleName, ?Server $server = null): object
    {
        // Hosting namespace (cPanel, Plesk, DirectAdmin)
        $hostingClass = "Modules\\Hosting\\{$moduleName}";
        if (class_exists($hostingClass)) {
            if (!$server) {
                throw new \RuntimeException("Server required for module {$moduleName}.");
            }
            return new $hostingClass($server);
        }

        // VPS namespace (Virtualizor, Proxmox)
        $vpsClass = "Modules\\Vps\\{$moduleName}";
        if (class_exists($vpsClass)) {
            if (!$server) {
                throw new \RuntimeException("Server required for module {$moduleName}.");
            }
            return new $vpsClass($server);
        }

        // Streaming namespace (Shoutcast, Centova Cast)
        $streamingClass = "Modules\\Streaming\\{$moduleName}";
        if (class_exists($streamingClass)) {
            if (!$server) {
                throw new \RuntimeException("Server required for module {$moduleName}.");
            }
            return new $streamingClass($server);
        }

        // Generic / Custom fallback
        $genericClass = "Modules\\{$moduleName}\\Module";
        if (class_exists($genericClass)) {
            return new $genericClass();
        }

        throw new \RuntimeException("Module {$moduleName} not found in Hosting/Vps/Streaming/Custom namespaces.");
    }

    private function assertProvisionable(Service $service): void
    {
        if (!$service->server_id && !$service->server) {
            throw new \RuntimeException('Servidor não configurado para este serviço.');
        }

        if (HostingRules::productRequiresDomain($service->product) && blank($service->domain)) {
            throw new \InvalidArgumentException('Domínio é obrigatório para provisionar este serviço.');
        }
    }
}
