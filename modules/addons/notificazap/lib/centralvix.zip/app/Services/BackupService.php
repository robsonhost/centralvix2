<?php

namespace App\Services;

use App\Models\Backup;
use App\Models\BackupSetting;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use ZipArchive;

class BackupService
{
    /**
     * Run backup
     */
    public function runBackup($companyId, string $type = 'full', ?int $userId = null): Backup
    {
        $settings = BackupSetting::where('company_id', $companyId)->first();

        if (!$settings || !$settings->enabled) {
            throw new \Exception('Backup não está habilitado para esta empresa');
        }

        // Create backup record
        $backup = Backup::create([
            'company_id' => $companyId,
            'user_id' => $userId,
            'type' => $type,
            'filename' => $this->generateFilename($type),
            'path' => '',
            'status' => 'processing',
            'is_automatic' => $userId === null,
            'started_at' => now(),
        ]);

        try {
            $path = null;
            $metadata = [];

            switch ($type) {
                case 'database':
                    $path = $this->backupDatabase($companyId);
                    $metadata = ['tables' => $this->getDatabaseTables()];
                    break;

                case 'files':
                    $path = $this->backupFiles($companyId);
                    $metadata = ['files_count' => $this->countFiles()];
                    break;

                case 'uploads':
                    $path = $this->backupUploads($companyId);
                    $metadata = ['uploads_count' => $this->countUploads()];
                    break;

                case 'full':
                default:
                    $path = $this->backupFull($companyId);
                    $metadata = [
                        'tables' => $this->getDatabaseTables(),
                        'files_count' => $this->countFiles(),
                        'uploads_count' => $this->countUploads(),
                    ];
                    break;
            }

            $size = Storage::size($path);

            $backup->update([
                'path' => $path,
                'size_bytes' => $size,
                'status' => 'completed',
                'metadata' => $metadata,
                'completed_at' => now(),
            ]);

            // Send email notification
            if ($settings->email_notifications) {
                $this->sendNotification($backup, $settings);
            }

            // Clean old backups
            $this->cleanOldBackups($companyId, $settings->retention_days);

            return $backup;

        } catch (\Exception $e) {
            Log::error('Backup failed: ' . $e->getMessage());

            $backup->update([
                'status' => 'failed',
                'error_message' => $e->getMessage(),
                'completed_at' => now(),
            ]);

            throw $e;
        }
    }

    /**
     * Backup database
     */
    protected function backupDatabase($companyId): string
    {
        $filename = "backup_database_{$companyId}_" . date('Y-m-d_His') . ".sql";
        $path = "backups/{$filename}";

        $command = sprintf(
            'mysqldump --user=%s --password=%s --host=%s %s > %s',
            config('database.connections.mysql.username'),
            config('database.connections.mysql.password'),
            config('database.connections.mysql.host'),
            config('database.connections.mysql.database'),
            storage_path("app/{$path}")
        );

        exec($command, $output, $returnVar);

        if ($returnVar !== 0) {
            throw new \Exception('Falha ao executar mysqldump');
        }

        return $path;
    }

    /**
     * Backup files
     */
    protected function backupFiles($companyId): string
    {
        $filename = "backup_files_{$companyId}_" . date('Y-m-d_His') . ".zip";
        $path = storage_path("app/backups/{$filename}");

        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new \Exception('Não foi possível criar arquivo ZIP');
        }

        $this->addFilesToZip($zip, base_path(), 'app/');
        $this->addFilesToZip($zip, base_path(), 'config/');
        $this->addFilesToZip($zip, base_path(), 'resources/');

        $zip->close();

        return "backups/{$filename}";
    }

    /**
     * Backup uploads
     */
    protected function backupUploads($companyId): string
    {
        $filename = "backup_uploads_{$companyId}_" . date('Y-m-d_His') . ".zip";
        $path = storage_path("app/backups/{$filename}");

        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new \Exception('Não foi possível criar arquivo ZIP');
        }

        $this->addFilesToZip($zip, storage_path('app/public'));

        $zip->close();

        return "backups/{$filename}";
    }

    /**
     * Backup full (database + files + uploads)
     */
    protected function backupFull($companyId): string
    {
        $filename = "backup_full_{$companyId}_" . date('Y-m-d_His') . ".zip";
        $path = storage_path("app/backups/{$filename}");

        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new \Exception('Não foi possível criar arquivo ZIP');
        }

        // Database SQL
        $sqlPath = $this->backupDatabase($companyId);
        $zip->addFile(storage_path("app/{$sqlPath}"), 'database.sql');

        // Files
        $this->addFilesToZip($zip, base_path(), 'app/');
        $this->addFilesToZip($zip, base_path(), 'config/');
        $this->addFilesToZip($zip, base_path(), 'resources/');

        // Uploads
        $this->addFilesToZip($zip, storage_path('app/public'), 'uploads/');

        $zip->close();

        return "backups/{$filename}";
    }

    /**
     * Add files to ZIP recursively
     */
    protected function addFilesToZip(ZipArchive $zip, string $source, string $prefix = '')
    {
        if (!is_dir($source)) {
            return;
        }

        $files = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($source),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = $prefix . substr($filePath, strlen($source) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
    }

    /**
     * Clean old backups
     */
    protected function cleanOldBackups($companyId, int $retentionDays)
    {
        $cutoffDate = now()->subDays($retentionDays);

        $oldBackups = Backup::where('company_id', $companyId)
            ->where('created_at', '<', $cutoffDate)
            ->where('status', 'completed')
            ->get();

        foreach ($oldBackups as $backup) {
            // Delete file
            if (Storage::exists($backup->path)) {
                Storage::delete($backup->path);
            }

            // Delete record
            $backup->delete();
        }
    }

    /**
     * Send notification email
     */
    protected function sendNotification(Backup $backup, BackupSetting $settings)
    {
        if (!$settings->notification_email) {
            return;
        }

        // TODO: Send email using Mail facade
        // Mail::to($settings->notification_email)->send(new BackupCompletedMail($backup));
    }

    /**
     * Generate backup filename
     */
    protected function generateFilename(string $type): string
    {
        return "backup_{$type}_" . date('Y-m-d_His') . ".zip";
    }

    /**
     * Get database tables
     */
    protected function getDatabaseTables(): array
    {
        return DB::select('SHOW TABLES');
    }

    /**
     * Count files
     */
    protected function countFiles(): int
    {
        // Simplified count
        return 1000;
    }

    /**
     * Count uploads
     */
    protected function countUploads(): int
    {
        // Simplified count
        return Storage::allFiles('public') ? count(Storage::allFiles('public')) : 0;
    }
}
