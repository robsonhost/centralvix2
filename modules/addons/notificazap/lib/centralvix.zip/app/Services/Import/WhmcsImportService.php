<?php

namespace App\Services\Import;

use App\Models\Client;
use App\Models\ClientContact;
use App\Models\ClientGroup;
use App\Models\CustomField;
use App\Models\CustomFieldValue;
use App\Models\Domain;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductGroup;
use App\Models\Server;
use App\Models\Service;
use App\Models\Transaction;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class WhmcsImportService
{
    private string $connection;
    private string $prefix;
    private int $companyId;
    private int $chunk;
    private bool $dryRun = false;

    /** @var array<string, string> */
    private array $tables = [];

    /** @var array<string, int> */
    private array $stats = [];

    public function __construct(
        private $logger = null,
    ) {
        $this->connection = config('whmcs_import.connection', 'whmcs');
        $this->prefix = config('whmcs_import.table_prefix', 'tbl');
        $this->chunk = config('whmcs_import.chunk_size', 200);
    }

    public function run(int $companyId, array $only = [], bool $dryRun = false): array
    {
        $this->companyId = $companyId;
        $this->dryRun = $dryRun;
        $this->stats = [];

        $this->log('Verificando conexão WHMCS…');
        $this->assertWhmcsConnection();
        $this->resolveTables();

        $steps = $only !== [] ? $only : config('whmcs_import.entities', []);

        foreach ($steps as $step) {
            match ($step) {
                'servers'         => $this->importServers(),
                'product_groups'  => $this->importProductGroups(),
                'products'          => $this->importProducts(),
                'client_groups'     => $this->importClientGroups(),
                'clients'           => $this->importClients(),
                'client_contacts'   => $this->importClientContacts(),
                'custom_fields'     => $this->importCustomFields(),
                'services'          => $this->importServices(),
                'domains'           => $this->importDomains(),
                'orders'            => $this->importOrders(),
                'invoices'          => $this->importInvoices(),
                'transactions'      => $this->importTransactions(),
                default             => $this->log("Etapa desconhecida ignorada: {$step}"),
            };
        }

        return $this->stats;
    }

    public function getAvailableTables(): array
    {
        return array_values($this->tables);
    }

    private function assertWhmcsConnection(): void
    {
        try {
            DB::connection($this->connection)->getPdo();
        } catch (\Throwable $e) {
            throw new \RuntimeException(
                'Não foi possível conectar ao banco WHMCS. Importe o SQL e configure WHMCS_DB_* no .env. Erro: ' . $e->getMessage()
            );
        }
    }

    private function resolveTables(): void
    {
        $dbName = config("database.connections.{$this->connection}.database");
        $rows = DB::connection($this->connection)->select('SHOW TABLES');
        $key = 'Tables_in_' . $dbName;

        foreach ($rows as $row) {
            $name = $row->{$key} ?? array_values((array) $row)[0] ?? null;
            if (!$name) {
                continue;
            }
            $short = str_starts_with($name, $this->prefix)
                ? substr($name, strlen($this->prefix))
                : $name;
            $this->tables[$short] = $name;
        }

        $required = ['clients', 'hosting', 'products', 'productgroups', 'servers'];
        foreach ($required as $req) {
            if (!isset($this->tables[$req])) {
                $this->log("Aviso: tabela WHMCS '{$this->prefix}{$req}' não encontrada.");
            }
        }
    }

    private function whmcsTable(string $short): ?string
    {
        return $this->tables[$short] ?? null;
    }

    private function whmcsQuery(string $short)
    {
        $table = $this->whmcsTable($short);
        if (!$table) {
            return null;
        }

        return DB::connection($this->connection)->table($table);
    }

    // ─── SERVERS ───────────────────────────────────────────────

    private function importServers(): void
    {
        $q = $this->whmcsQuery('servers');
        if (!$q) {
            return;
        }

        $this->log('Importando servidores…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use (&$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('server', (int) $row->id)) {
                    continue;
                }

                $data = [
                    'company_id'        => $this->companyId,
                    'name'              => $row->name ?: ('Servidor ' . $row->id),
                    'hostname'          => $row->hostname ?: $row->name,
                    'ip_address'        => $row->ipaddress ?: '0.0.0.0',
                    'ip_secondary'      => $row->assignedips ?: null,
                    'type'              => $this->mapServerType($row->type ?? ''),
                    'module'            => $this->mapServerType($row->type ?? ''),
                    'username'          => $row->username ?? null,
                    'password'          => $row->password ?? null,
                    'port'              => (int) ($row->port ?: 2087),
                    'secure'            => (bool) ($row->secure ?? true),
                    'api_token'         => !empty($row->accesshash) ? encrypt($row->accesshash) : null,
                    'status'            => ($row->disabled ?? 0) ? 'inactive' : 'active',
                    'max_accounts'      => (int) ($row->maxaccounts ?? 0),
                    'assigned_accounts' => 0,
                    'notes'             => trim(($row->noc ?? '') . "\n" . ($row->statusaddress ?? '')),
                    'settings'          => json_encode([
                        'whmcs_id'   => $row->id,
                        'monthlycost'=> $row->monthlycost ?? null,
                        'raw'        => (array) $row,
                    ]),
                    'created_at'        => now(),
                    'updated_at'        => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('servers')->insertGetId($data);
                    $this->saveMap('server', (int) $row->id, $id, 'servers', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['servers'] = $count;
        $this->log("Servidores: {$count}");
    }

    // ─── PRODUCT GROUPS ────────────────────────────────────────

    private function importProductGroups(): void
    {
        $q = $this->whmcsQuery('productgroups');
        if (!$q) {
            return;
        }

        $this->log('Importando categorias de produtos…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use (&$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('product_group', (int) $row->id)) {
                    continue;
                }

                $name = $row->name ?: ('Grupo ' . $row->id);
                $data = [
                    'company_id'  => $this->companyId,
                    'name'        => $name,
                    'slug'        => Str::slug($name) . '-' . $row->id,
                    'description' => trim(($row->headline ?? '') . "\n" . ($row->tagline ?? '')),
                    'icon'        => 'fas fa-box',
                    'order'       => (int) ($row->order ?? 0),
                    'status'      => ($row->hidden ?? 0) || ($row->disabled ?? 0) ? 'inactive' : 'active',
                    'created_at'  => now(),
                    'updated_at'  => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('product_groups')->insertGetId($data);
                    $this->saveMap('product_group', (int) $row->id, $id, 'productgroups', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['product_groups'] = $count;
        $this->log("Categorias: {$count}");
    }

    // ─── PRODUCTS ──────────────────────────────────────────────

    private function importProducts(): void
    {
        $q = $this->whmcsQuery('products');
        if (!$q) {
            return;
        }

        $pricing = $this->loadProductPricing();
        $this->log('Importando produtos/planos…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use ($pricing, &$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('product', (int) $row->id)) {
                    continue;
                }

                $name = $row->name ?: ('Produto ' . $row->id);
                $prices = $pricing->get((int) $row->id, []);
                $groupId = $this->getLocalId('product_group', (int) ($row->gid ?? 0));

                $data = [
                    'uuid'               => (string) Str::uuid(),
                    'company_id'         => $this->companyId,
                    'group_id'           => $groupId,
                    'name'               => $name,
                    'slug'               => Str::slug($name) . '-' . $row->id,
                    'description'        => $row->description ?? null,
                    'short_description'  => Str::limit(strip_tags($row->description ?? ''), 200),
                    'type'               => $this->mapProductType($row->type ?? ''),
                    'module'             => $row->servertype ?? null,
                    'module_config'      => json_encode(['whmcs' => (array) $row]),
                    'price_monthly'      => $prices['monthly'] ?? 0,
                    'price_quarterly'    => $prices['quarterly'] ?? 0,
                    'price_semiannually' => $prices['semiannually'] ?? 0,
                    'price_annually'     => $prices['annually'] ?? 0,
                    'price_biennially'   => $prices['biennially'] ?? 0,
                    'price_triennially'  => $prices['triennially'] ?? 0,
                    'price_lifetime'     => $prices['onetime'] ?? 0,
                    'setup_fee'          => $prices['msetupfee'] ?? 0,
                    'stock'              => (int) ($row->qty ?? 0),
                    'stock_unlimited'    => !((bool) ($row->stockcontrol ?? 0)),
                    'status'             => ($row->hidden ?? 0) ? 'hidden' : 'active',
                    'order'              => (int) ($row->order ?? 0),
                    'featured'           => false,
                    'created_at'         => now(),
                    'updated_at'         => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('products')->insertGetId($data);
                    $this->saveMap('product', (int) $row->id, $id, 'products', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['products'] = $count;
        $this->log("Produtos: {$count}");
    }

    private function loadProductPricing(): Collection
    {
        $q = $this->whmcsQuery('pricing');
        if (!$q) {
            return collect();
        }

        return $q->where('type', 'product')
            ->get()
            ->groupBy('relid')
            ->map(function ($rows) {
                $row = $rows->first();
                return [
                    'monthly'      => (float) ($row->monthly ?? 0),
                    'quarterly'    => (float) ($row->quarterly ?? 0),
                    'semiannually' => (float) ($row->semiannually ?? 0),
                    'annually'     => (float) ($row->annually ?? 0),
                    'biennially'   => (float) ($row->biennially ?? 0),
                    'triennially'  => (float) ($row->triennially ?? 0),
                    'onetime'      => (float) ($row->monthly ?? 0),
                    'msetupfee'    => (float) ($row->msetupfee ?? 0),
                ];
            });
    }

    // ─── CLIENT GROUPS ─────────────────────────────────────────

    private function importClientGroups(): void
    {
        $q = $this->whmcsQuery('clientgroups');
        if (!$q) {
            return;
        }

        $this->log('Importando grupos de clientes…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use (&$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('client_group', (int) $row->id)) {
                    continue;
                }

                $data = [
                    'company_id' => $this->companyId,
                    'name'       => $row->groupname ?? ('Grupo ' . $row->id),
                    'color'      => '#007bff',
                ];

                if (Schema::hasColumn('client_groups', 'discount_percentage')) {
                    $data['discount_percentage'] = (float) ($row->discountpercent ?? 0);
                    $data['active'] = true;
                } else {
                    $data['discount'] = (float) ($row->discountpercent ?? 0);
                    $data['status'] = 'active';
                }

                if (Schema::hasColumn('client_groups', 'created_at')) {
                    $data['created_at'] = now();
                    $data['updated_at'] = now();
                }

                if (!$this->dryRun) {
                    $id = DB::table('client_groups')->insertGetId($data);
                    $this->saveMap('client_group', (int) $row->id, $id, 'clientgroups', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['client_groups'] = $count;
        $this->log("Grupos de clientes: {$count}");
    }

    // ─── CLIENTS ───────────────────────────────────────────────

    private function importClients(): void
    {
        $q = $this->whmcsQuery('clients');
        if (!$q) {
            return;
        }

        $customValues = $this->loadCustomFieldValuesForClients();
        $this->log('Importando clientes…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use ($customValues, &$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('client', (int) $row->id)) {
                    continue;
                }

                $email = strtolower(trim($row->email ?? ''));
                if ($email === '') {
                    continue;
                }

                $existing = Client::where('company_id', $this->companyId)->where('email', $email)->first();
                if ($existing) {
                    $this->saveMap('client', (int) $row->id, $existing->id, 'clients', (array) $row);
                    continue;
                }

                $notes = $row->notes ?? '';
                if ($customValues->has((int) $row->id)) {
                    $notes .= "\n\n--- Campos WHMCS ---\n" . $customValues->get((int) $row->id);
                }

                $data = [
                    'uuid'           => (string) Str::uuid(),
                    'company_id'     => $this->companyId,
                    'client_code'    => 'WHMCS' . $row->id,
                    'type'           => !empty($row->companyname) ? 'company' : 'individual',
                    'firstname'      => $row->firstname ?: 'Cliente',
                    'lastname'       => $row->lastname ?: (string) $row->id,
                    'email'          => $email,
                    'phone'          => $row->phonenumber ?? null,
                    'company_name'   => $row->companyname ?? null,
                    'address'        => $row->address1 ?? null,
                    'address_complement' => $row->address2 ?? null,
                    'city'           => $row->city ?? null,
                    'state'          => $row->state ?? null,
                    'country'        => $this->normalizeCountry($row->country ?? 'BR'),
                    'zip'            => $row->postcode ?? null,
                    'notes'          => trim($notes) ?: null,
                    'internal_notes' => json_encode(['whmcs_id' => $row->id, 'whmcs_raw' => (array) $row], JSON_UNESCAPED_UNICODE),
                    'status'         => $this->mapClientStatus($row->status ?? 'Active'),
                    'credit_balance' => (float) ($row->credit ?? 0),
                    'currency'       => strtoupper($row->currency ?? 'BRL'),
                    'language'       => $row->language ?? 'pt_BR',
                    'group_id'       => $this->getLocalId('client_group', (int) ($row->groupid ?? 0)),
                    'password'       => !empty($row->password) ? $row->password : bcrypt(Str::random(16)),
                    'created_at'     => $this->parseDate($row->datecreated ?? null) ?? now(),
                    'updated_at'     => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('clients')->insertGetId($data);
                    $this->saveMap('client', (int) $row->id, $id, 'clients', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['clients'] = $count;
        $this->log("Clientes: {$count}");
    }

    private function loadCustomFieldValuesForClients(): Collection
    {
        $fieldsQ = $this->whmcsQuery('customfields');
        $valuesQ = $this->whmcsQuery('customfieldsvalues');
        if (!$fieldsQ || !$valuesQ) {
            return collect();
        }

        $fields = $fieldsQ->where('type', 'client')->get()->keyBy('id');
        $lines = [];

        $valuesQ->orderBy('id')->chunk(500, function ($rows) use ($fields, &$lines) {
            foreach ($rows as $row) {
                $field = $fields->get($row->fieldid);
                if (!$field) {
                    continue;
                }
                $relId = (int) $row->relid;
                $lines[$relId] ??= [];
                $lines[$relId][] = ($field->fieldname ?? 'campo') . ': ' . ($row->value ?? '');
            }
        });

        return collect($lines)->map(fn ($arr) => implode("\n", $arr));
    }

    // ─── CLIENT CONTACTS ───────────────────────────────────────

    private function importClientContacts(): void
    {
        $q = $this->whmcsQuery('contacts');
        if (!$q) {
            return;
        }

        $this->log('Importando contatos de clientes…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use (&$count) {
            foreach ($rows as $row) {
                $clientId = $this->getLocalId('client', (int) ($row->userid ?? 0));
                if (!$clientId) {
                    continue;
                }

                if ($this->getLocalId('client_contact', (int) $row->id)) {
                    continue;
                }

                $data = [
                    'client_id'  => $clientId,
                    'firstname'  => $row->firstname ?? '',
                    'lastname'   => $row->lastname ?? '',
                    'email'      => $row->email ?? '',
                    'phone'      => $row->phonenumber ?? null,
                    'permissions'=> json_encode(['whmcs' => (array) $row]),
                    'created_at' => now(),
                    'updated_at' => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('client_contacts')->insertGetId($data);
                    $this->saveMap('client_contact', (int) $row->id, $id, 'contacts', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['client_contacts'] = $count;
        $this->log("Contatos: {$count}");
    }

    // ─── CUSTOM FIELDS ─────────────────────────────────────────

    private function importCustomFields(): void
    {
        if (!Schema::hasTable('custom_fields')) {
            return;
        }

        $fieldsQ = $this->whmcsQuery('customfields');
        $valuesQ = $this->whmcsQuery('customfieldsvalues');
        if (!$fieldsQ) {
            return;
        }

        $this->log('Importando campos personalizados…');
        $fieldMap = [];
        $count = 0;

        foreach ($fieldsQ->get() as $row) {
            if ($this->getLocalId('custom_field', (int) $row->id)) {
                $fieldMap[(int) $row->id] = $this->getLocalId('custom_field', (int) $row->id);
                continue;
            }

            $data = [
                'company_id'  => $this->companyId,
                'name'        => $row->fieldname ?? ('Campo ' . $row->id),
                'field_type'  => $this->mapCustomFieldType($row->fieldtype ?? 'text'),
                'applies_to'  => $row->type ?? 'client',
                'options'     => json_encode(['whmcs' => (array) $row]),
                'required'    => (bool) ($row->required ?? false),
                'active'      => !((bool) ($row->adminonly ?? false)),
                'order'       => (int) ($row->sortorder ?? 0),
                'created_at'  => now(),
                'updated_at'  => now(),
            ];

            if (!$this->dryRun) {
                $id = DB::table('custom_fields')->insertGetId($data);
                $this->saveMap('custom_field', (int) $row->id, $id, 'customfields', (array) $row);
                $fieldMap[(int) $row->id] = $id;
            }
            $count++;
        }

        if ($valuesQ && !$this->dryRun) {
            $valuesQ->orderBy('id')->chunk(500, function ($rows) use ($fieldMap) {
                foreach ($rows as $row) {
                    $fieldId = $fieldMap[(int) $row->fieldid] ?? $this->getLocalId('custom_field', (int) $row->fieldid);
                    if (!$fieldId) {
                        continue;
                    }
                    $clientId = $this->getLocalId('client', (int) $row->relid);
                    if (!$clientId) {
                        continue;
                    }

                    CustomFieldValue::firstOrCreate(
                        [
                            'custom_field_id' => $fieldId,
                            'related_id'      => $clientId,
                            'related_type'    => Client::class,
                        ],
                        ['value' => $row->value ?? '']
                    );
                }
            });
        }

        $this->stats['custom_fields'] = $count;
        $this->log("Campos personalizados: {$count}");
    }

    // ─── SERVICES (tblhosting) ─────────────────────────────────

    private function importServices(): void
    {
        $q = $this->whmcsQuery('hosting');
        if (!$q) {
            return;
        }

        $this->log('Importando serviços/hospedagens (servidor ativo, datas, login)…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use (&$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('service', (int) $row->id)) {
                    continue;
                }

                $clientId = $this->getLocalId('client', (int) ($row->userid ?? 0));
                if (!$clientId) {
                    continue;
                }

                $productId = $this->getLocalId('product', (int) ($row->packageid ?? 0));
                $serverId = $this->getLocalId('server', (int) ($row->server ?? 0));
                $productName = $productId
                    ? (Product::find($productId)?->name ?? 'Serviço')
                    : ('Serviço WHMCS #' . $row->id);

                $data = [
                    'uuid'               => (string) Str::uuid(),
                    'company_id'         => $this->companyId,
                    'client_id'          => $clientId,
                    'product_id'         => $productId,
                    'name'               => $productName,
                    'status'             => $this->mapServiceStatus($row->domainstatus ?? 'Pending'),
                    'domain'             => $row->domain ?? null,
                    'username'           => $row->username ?? null,
                    'password'           => $row->password ?? null,
                    'server_id'          => $serverId,
                    'module'             => 'cpanel',
                    'module_data'        => json_encode(['whmcs_hosting' => (array) $row], JSON_UNESCAPED_UNICODE),
                    'billing_cycle'      => $this->mapBillingCycle($row->billingcycle ?? 'Monthly'),
                    'amount'             => (float) ($row->amount ?? 0),
                    'setup_fee'          => (float) ($row->firstpaymentamount ?? 0),
                    'first_payment_date' => $this->parseDate($row->regdate ?? null),
                    'next_due_date'      => $this->parseDate($row->nextduedate ?? null),
                    'billing_date'       => $this->parseDate($row->nextinvoicedate ?? null),
                    'notes'              => trim(($row->notes ?? '') . "\n" . ($row->suspendreason ?? '')),
                    'created_at'         => $this->parseDate($row->regdate ?? null) ?? now(),
                    'updated_at'         => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('services')->insertGetId($data);
                    $this->saveMap('service', (int) $row->id, $id, 'hosting', (array) $row);

                    if ($serverId) {
                        DB::table('servers')->where('id', $serverId)->increment('assigned_accounts');
                    }
                }
                $count++;
            }
        });

        $this->stats['services'] = $count;
        $this->log("Serviços: {$count}");
    }

    // ─── DOMAINS ───────────────────────────────────────────────

    private function importDomains(): void
    {
        $q = $this->whmcsQuery('domains');
        if (!$q) {
            return;
        }

        $this->log('Importando domínios…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use (&$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('domain', (int) $row->id)) {
                    continue;
                }

                $clientId = $this->getLocalId('client', (int) ($row->userid ?? 0));
                if (!$clientId || empty($row->domain)) {
                    continue;
                }

                [$domain, $tld] = $this->splitDomain($row->domain);

                $data = [
                    'uuid'               => (string) Str::uuid(),
                    'company_id'         => $this->companyId,
                    'client_id'          => $clientId,
                    'domain'             => $domain,
                    'tld'                => $tld,
                    'registrar'          => $row->registrar ?? null,
                    'registrar_data'     => json_encode(['whmcs' => (array) $row]),
                    'status'             => $this->mapDomainStatus($row->status ?? 'Active'),
                    'registration_date'  => $this->parseDate($row->registrationdate ?? null),
                    'expiry_date'        => $this->parseDate($row->expirydate ?? null),
                    'next_due_date'      => $this->parseDate($row->nextduedate ?? null),
                    'auto_renew'         => (bool) ($row->donotrenew ?? 0) === false,
                    'created_at'         => now(),
                    'updated_at'         => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('domains')->insertGetId($data);
                    $this->saveMap('domain', (int) $row->id, $id, 'domains', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['domains'] = $count;
        $this->log("Domínios: {$count}");
    }

    // ─── ORDERS ────────────────────────────────────────────────

    private function importOrders(): void
    {
        $q = $this->whmcsQuery('orders');
        if (!$q) {
            return;
        }

        $this->log('Importando pedidos…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use (&$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('order', (int) $row->id)) {
                    continue;
                }

                $clientId = $this->getLocalId('client', (int) ($row->userid ?? 0));
                if (!$clientId) {
                    continue;
                }

                $data = [
                    'uuid'        => (string) Str::uuid(),
                    'company_id'  => $this->companyId,
                    'client_id'   => $clientId,
                    'status'      => $this->mapOrderStatus($row->status ?? 'Pending'),
                    'total'       => (float) ($row->amount ?? 0),
                    'discount'    => 0,
                    'tax'         => 0,
                    'notes'       => $row->notes ?? null,
                    'ip_address'  => $row->ipaddress ?? null,
                    'created_at'  => $this->parseDate($row->date ?? null) ?? now(),
                    'updated_at'  => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('orders')->insertGetId($data);
                    $this->saveMap('order', (int) $row->id, $id, 'orders', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['orders'] = $count;
        $this->log("Pedidos: {$count}");
    }

    // ─── INVOICES ──────────────────────────────────────────────

    private function importInvoices(): void
    {
        $q = $this->whmcsQuery('invoices');
        if (!$q) {
            return;
        }

        $itemsQ = $this->whmcsQuery('invoiceitems');
        $this->log('Importando faturas…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use ($itemsQ, &$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('invoice', (int) $row->id)) {
                    continue;
                }

                $clientId = $this->getLocalId('client', (int) ($row->userid ?? 0));
                if (!$clientId) {
                    continue;
                }

                $invoiceNumber = 'WHMCS-' . $row->id;
                if (Invoice::where('invoice_number', $invoiceNumber)->exists()) {
                    continue;
                }

                $data = [
                    'uuid'           => (string) Str::uuid(),
                    'company_id'     => $this->companyId,
                    'client_id'      => $clientId,
                    'invoice_number' => $invoiceNumber,
                    'status'         => $this->mapInvoiceStatus($row->status ?? 'Unpaid'),
                    'subtotal'       => (float) ($row->subtotal ?? 0),
                    'discount'       => (float) ($row->credit ?? 0),
                    'tax'            => (float) ($row->tax ?? 0) + (float) ($row->tax2 ?? 0),
                    'total'          => (float) ($row->total ?? 0),
                    'date_created'   => $this->parseDate($row->date ?? null) ?? now()->toDateString(),
                    'date_due'       => $this->parseDate($row->duedate ?? null) ?? now()->toDateString(),
                    'date_paid'      => !empty($row->datepaid) && $row->datepaid !== '0000-00-00 00:00:00'
                        ? $this->parseDate($row->datepaid)
                        : null,
                    'payment_method' => $row->paymentmethod ?? null,
                    'notes'          => $row->notes ?? null,
                    'admin_notes'    => json_encode(['whmcs' => (array) $row], JSON_UNESCAPED_UNICODE),
                    'created_at'     => $this->parseDate($row->date ?? null) ?? now(),
                    'updated_at'     => now(),
                ];

                if (!$this->dryRun) {
                    $invoiceId = DB::table('invoices')->insertGetId($data);
                    $this->saveMap('invoice', (int) $row->id, $invoiceId, 'invoices', (array) $row);

                    if ($itemsQ) {
                        $items = $itemsQ->where('invoiceid', $row->id)->get();
                        foreach ($items as $item) {
                            DB::table('invoice_items')->insert([
                                'invoice_id'  => $invoiceId,
                                'service_id'  => $this->getLocalId('service', (int) ($item->relid ?? 0)),
                                'description' => $item->description ?? 'Item',
                                'amount'      => (float) ($item->amount ?? 0),
                                'tax_rate'    => 0,
                                'tax_amount'  => (float) ($item->taxed ?? 0),
                                'total'       => (float) ($item->amount ?? 0),
                                'created_at'  => now(),
                                'updated_at'  => now(),
                            ]);
                        }
                    }
                }
                $count++;
            }
        });

        $this->stats['invoices'] = $count;
        $this->log("Faturas: {$count}");
    }

    // ─── TRANSACTIONS ──────────────────────────────────────────

    private function importTransactions(): void
    {
        $q = $this->whmcsQuery('accounts');
        if (!$q) {
            return;
        }

        $this->log('Importando transações…');
        $count = 0;

        $q->orderBy('id')->chunk($this->chunk, function ($rows) use (&$count) {
            foreach ($rows as $row) {
                if ($this->getLocalId('transaction', (int) $row->id)) {
                    continue;
                }

                $clientId = $this->getLocalId('client', (int) ($row->userid ?? 0));
                $invoiceId = $this->getLocalId('invoice', (int) ($row->invoiceid ?? 0));

                $data = [
                    'company_id'       => $this->companyId,
                    'client_id'        => $clientId,
                    'invoice_id'       => $invoiceId,
                    'gateway'          => $row->gateway ?? 'whmcs',
                    'type'             => ((float) ($row->amountin ?? 0)) > 0 ? 'payment' : 'refund',
                    'amount'           => abs((float) (($row->amountin ?? 0) ?: ($row->amountout ?? 0))),
                    'fee'              => (float) ($row->fees ?? 0),
                    'currency'         => 'BRL',
                    'status'           => 'completed',
                    'gateway_response' => json_encode(['whmcs' => (array) $row]),
                    'created_at'       => $this->parseDate($row->date ?? null) ?? now(),
                    'updated_at'       => now(),
                ];

                if (!$this->dryRun) {
                    $id = DB::table('transactions')->insertGetId($data);
                    $this->saveMap('transaction', (int) $row->id, $id, 'accounts', (array) $row);
                }
                $count++;
            }
        });

        $this->stats['transactions'] = $count;
        $this->log("Transações: {$count}");
    }

    // ─── MAP HELPERS ───────────────────────────────────────────

    private function getLocalId(string $entity, int $whmcsId): ?int
    {
        if ($whmcsId <= 0) {
            return null;
        }

        $row = DB::table('whmcs_import_maps')
            ->where('company_id', $this->companyId)
            ->where('entity_type', $entity)
            ->where('whmcs_id', $whmcsId)
            ->first();

        return $row ? (int) $row->local_id : null;
    }

    private function saveMap(string $entity, int $whmcsId, int $localId, string $table, array $meta = []): void
    {
        DB::table('whmcs_import_maps')->updateOrInsert(
            [
                'company_id'  => $this->companyId,
                'entity_type' => $entity,
                'whmcs_id'    => $whmcsId,
            ],
            [
                'local_id'    => $localId,
                'whmcs_table' => $table,
                'meta'        => json_encode($meta, JSON_UNESCAPED_UNICODE),
                'updated_at'  => now(),
                'created_at'  => now(),
            ]
        );
    }

    // ─── MAPPERS ───────────────────────────────────────────────

    private function mapClientStatus(string $status): string
    {
        return match (strtolower($status)) {
            'active'   => 'active',
            'inactive' => 'inactive',
            'closed'   => 'inactive',
            default    => 'active',
        };
    }

    private function mapServiceStatus(string $status): string
    {
        return match (strtolower($status)) {
            'active'     => 'active',
            'pending'    => 'pending',
            'suspended'  => 'suspended',
            'terminated' => 'terminated',
            'cancelled'  => 'cancelled',
            'fraud'      => 'fraud',
            'completed'  => 'active',
            default      => 'pending',
        };
    }

    private function mapBillingCycle(string $cycle): string
    {
        $c = strtolower(str_replace([' ', '-'], '', $cycle));

        return match ($c) {
            'monthly'       => 'monthly',
            'quarterly'     => 'quarterly',
            'semiannually'  => 'semiannually',
            'annually'      => 'annually',
            'biennially'    => 'biennially',
            'triennially'   => 'triennially',
            'one-time', 'onetime' => 'lifetime',
            default         => 'monthly',
        };
    }

    private function mapProductType(string $type): string
    {
        return match (strtolower($type)) {
            'hostingaccount'  => 'hosting',
            'reselleraccount' => 'reseller',
            'server'          => 'vps',
            'other'           => 'custom',
            default           => 'hosting',
        };
    }

    private function mapServerType(string $type): string
    {
        $t = strtolower($type);

        return match (true) {
            str_contains($t, 'cpanel')     => 'cpanel',
            str_contains($t, 'plesk')      => 'plesk',
            str_contains($t, 'directadmin')=> 'directadmin',
            str_contains($t, 'virtualizor')  => 'virtualizor',
            default                        => 'custom',
        };
    }

    private function mapInvoiceStatus(string $status): string
    {
        return match (strtolower($status)) {
            'paid'       => 'paid',
            'unpaid'     => 'unpaid',
            'cancelled'  => 'cancelled',
            'refunded'   => 'refunded',
            'collections'=> 'overdue',
            'draft'      => 'draft',
            default      => 'unpaid',
        };
    }

    private function mapOrderStatus(string $status): string
    {
        return match (strtolower($status)) {
            'active', 'completed' => 'active',
            'pending'             => 'pending',
            'cancelled'           => 'cancelled',
            'fraud'               => 'fraud',
            default               => 'pending',
        };
    }

    private function mapDomainStatus(string $status): string
    {
        return match (strtolower($status)) {
            'active'     => 'active',
            'expired'    => 'expired',
            'cancelled'  => 'cancelled',
            'pending'    => 'pending',
            'pendingtransfer' => 'pending',
            default      => 'active',
        };
    }

    private function mapCustomFieldType(string $type): string
    {
        return match (strtolower($type)) {
            'tickbox'   => 'checkbox',
            'dropdown'  => 'select',
            'textarea'  => 'textarea',
            'password'  => 'password',
            default     => 'text',
        };
    }

    private function splitDomain(string $fqdn): array
    {
        $parts = explode('.', $fqdn, 2);

        return count($parts) === 2 ? [$parts[0], '.' . $parts[1]] : [$fqdn, ''];
    }

    private function normalizeCountry(string $country): string
    {
        $c = strtoupper(trim($country));

        return match ($c) {
            'BR', 'BRA', 'BRAZIL', 'BRASIL' => 'BR',
            default => strlen($c) === 2 ? $c : 'BR',
        };
    }

    private function parseDate(?string $value): ?\Carbon\Carbon
    {
        if (!$value || str_starts_with($value, '0000')) {
            return null;
        }

        try {
            return \Carbon\Carbon::parse($value);
        } catch (\Throwable) {
            return null;
        }
    }

    private function log(string $message): void
    {
        if ($this->logger) {
            ($this->logger)($message);
        }
    }
}
