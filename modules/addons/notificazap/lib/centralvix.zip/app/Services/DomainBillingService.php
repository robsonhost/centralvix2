<?php

namespace App\Services;

use App\Events\InvoiceGenerated;
use App\Models\Domain;
use App\Models\DomainPricing;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Setting;
use Illuminate\Support\Str;

class DomainBillingService
{
    public function __construct(
        private TaxService $tax,
        private CurrencyService $currency,
    ) {
    }

    /**
     * Preço de renovação por TLD/empresa.
     */
    public function renewalPrice(Domain $domain, int $years = 1): float
    {
        $pricing = DomainPricing::where('company_id', $domain->company_id)
            ->where('active', true)
            ->where(function ($q) use ($domain) {
                $tld = $domain->tld;
                $q->where('tld', $tld)
                    ->orWhere('tld', ltrim($tld, '.'))
                    ->orWhere('tld', '.' . ltrim($tld, '.'));
            })
            ->first();

        $yearPrice = (float) ($pricing?->renew_price ?? 49.90);

        return round($yearPrice * max(1, $years), 2);
    }

    /**
     * Verifica se já existe fatura de renovação em aberto.
     */
    public function hasPendingRenewalInvoice(Domain $domain): bool
    {
        return InvoiceItem::where('domain_id', $domain->id)
            ->where('item_type', 'domain_renewal')
            ->whereHas('invoice', fn ($q) => $q->whereIn('status', ['unpaid', 'overdue', 'partial']))
            ->exists();
    }

    /**
     * Gera fatura de renovação de domínio.
     */
    public function createRenewalInvoice(Domain $domain, int $years = 1): Invoice
    {
        if ($this->hasPendingRenewalInvoice($domain)) {
            throw new \InvalidArgumentException('Já existe uma fatura de renovação em aberto para este domínio.');
        }

        $domain->loadMissing('client');
        $client = $domain->client;
        $companyId = (int) $domain->company_id;
        $dueDays = (int) Setting::get($companyId, 'billing', 'due_days', 7);

        $amountBase = $this->renewalPrice($domain, $years);
        $invoiceCurrency = $this->currency->resolveForClient($client);
        $invoiceRate = $this->currency->invoiceRate($companyId, $invoiceCurrency);
        $amount = $this->currency->convertFromBase($companyId, $amountBase, $invoiceCurrency);

        $issRate = $this->tax->issRate($companyId);
        $taxAmount = $issRate > 0 ? round($amount * $issRate / 100, 2) : 0.0;
        $total = round($amount + $taxAmount, 2);

        $invoice = Invoice::create([
            'uuid' => Str::uuid(),
            'company_id' => $companyId,
            'client_id' => $client->id,
            'status' => 'unpaid',
            'subtotal' => $amount,
            'discount' => 0,
            'tax' => $taxAmount,
            'total' => $total,
            'amount_paid' => 0,
            'currency' => $invoiceCurrency,
            'exchange_rate' => $invoiceRate,
            'date_created' => now()->toDateString(),
            'date_due' => now()->addDays($dueDays)->toDateString(),
            'notes' => json_encode([
                'type' => 'domain_renewal',
                'domain_id' => $domain->id,
                'years' => $years,
            ]),
        ]);

        InvoiceItem::create([
            'invoice_id' => $invoice->id,
            'domain_id' => $domain->id,
            'service_id' => $domain->service_id,
            'item_type' => 'domain_renewal',
            'description' => "Renovação de domínio — {$domain->domain} ({$years} ano(s))",
            'amount' => $amount,
            'tax_rate' => $issRate,
            'tax_amount' => $taxAmount,
            'total' => $total,
            'metadata' => ['years' => $years, 'domain' => $domain->domain],
        ]);

        InvoiceGenerated::dispatch($invoice);

        return $invoice->fresh(['items']);
    }

    /**
     * Após pagamento, executa renovação no registrar.
     */
    public function processPaidRenewal(Invoice $invoice, DomainService $domainService): void
    {
        foreach ($invoice->items()->with('domain')->get() as $item) {
            $domain = $item->domain;
            if (!$domain) {
                continue;
            }

            if ($item->item_type === 'domain_renewal') {
                $years = (int) ($item->metadata['years'] ?? 1);
                $domainService->renew($domain, $years);
                continue;
            }

            if ($item->item_type === 'domain_register' && $domain->status === 'pending') {
                $years = (int) ($item->metadata['years'] ?? 1);
                $domainService->activateRegistration($domain, $years);
            }
        }
    }

    public function isDomainInvoice(Invoice $invoice): bool
    {
        if ($invoice->items()->whereIn('item_type', ['domain_renewal', 'domain_register'])->exists()) {
            return true;
        }

        $notes = json_decode($invoice->notes ?? '', true);

        return is_array($notes) && in_array($notes['type'] ?? '', ['domain_renewal', 'domain_register'], true);
    }
}
