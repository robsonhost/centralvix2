<?php

namespace App\Services;

use App\Models\Client;
use App\Models\Coupon;
use App\Models\Product;

class CouponService
{
    public function validate(string $code, Client $client, ?Product $product = null): ?Coupon
    {
        $coupon = Coupon::where('code', strtoupper($code))
            ->where('company_id', $client->company_id)
            ->first();

        if (!$coupon || !$coupon->isValid()) {
            return null;
        }

        // Check if new clients only
        if ($coupon->new_clients_only) {
            $hasOrders = $client->orders()->where('status', '!=', 'cancelled')->exists();
            if ($hasOrders) {
                return null;
            }
        }

        // Check product applicability
        if ($product && $coupon->applies_to === 'products') {
            $productIds = $coupon->product_ids ?? [];
            if (!in_array($product->id, $productIds)) {
                return null;
            }
        }

        if ($product && $coupon->applies_to === 'categories') {
            $categoryIds = $coupon->category_ids ?? [];
            if (!in_array($product->group_id, $categoryIds)) {
                return null;
            }
        }

        return $coupon;
    }

    public function apply(Coupon $coupon, float $amount): float
    {
        return $coupon->calculateDiscount($amount);
    }
}
