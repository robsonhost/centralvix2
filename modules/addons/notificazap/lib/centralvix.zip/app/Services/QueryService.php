<?php

namespace App\Services;

use App\Models\Client;
use App\Models\ClientQuery;
use App\Models\QueryType;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class QueryService
{
    /**
     * Executa uma consulta
     */
    public function execute(Client $client, QueryType $queryType, string $searchTerm, ?string $ip = null): array
    {
        $price = (float) $queryType->sell_price;
        $balance = (float) $client->credit_balance;

        if ($balance < $price) {
            return [
                'success' => false,
                'message' => 'Saldo insuficiente. Seu saldo é R$ ' . number_format($balance, 2, ',', '.') . ' e a consulta custa R$ ' . number_format($price, 2, ',', '.'),
                'needs_recharge' => true,
            ];
        }

        return DB::transaction(function () use ($client, $queryType, $searchTerm, $price, $balance, $ip) {
            $client->decrement('credit_balance', $price);
            $newBalance = $balance - $price;

            $query = ClientQuery::create([
                'company_id' => $client->company_id,
                'client_id' => $client->id,
                'query_type_id' => $queryType->id,
                'search_term' => $searchTerm,
                'amount' => $price,
                'balance_before' => $balance,
                'balance_after' => $newBalance,
                'status' => 'pending',
                'ip_address' => $ip,
            ]);

            try {
                $result = $this->callApi($queryType, $searchTerm);

                if ($result['success']) {
                    $query->update([
                        'status' => 'completed',
                        'result' => $result['data'] ?? null,
                        'raw_response' => $result['raw'] ?? null,
                    ]);

                    return [
                        'success' => true,
                        'message' => 'Consulta realizada com sucesso!',
                        'query' => $query->fresh(),
                        'data' => $result['data'],
                        'new_balance' => $newBalance,
                    ];
                } else {
                    $client->increment('credit_balance', $price);
                    
                    $query->update([
                        'status' => 'failed',
                        'error_message' => $result['message'] ?? 'Erro na consulta',
                        'balance_after' => $balance,
                    ]);

                    return [
                        'success' => false,
                        'message' => $result['message'] ?? 'Erro ao realizar consulta. O valor foi estornado.',
                        'query' => $query->fresh(),
                    ];
                }
            } catch (\Throwable $e) {
                $client->increment('credit_balance', $price);
                
                $query->update([
                    'status' => 'failed',
                    'error_message' => $e->getMessage(),
                    'balance_after' => $balance,
                ]);

                Log::error('Erro na consulta', [
                    'query_id' => $query->id,
                    'type' => $queryType->slug,
                    'error' => $e->getMessage(),
                ]);

                return [
                    'success' => false,
                    'message' => 'Erro ao processar consulta. O valor foi estornado.',
                    'query' => $query->fresh(),
                ];
            }
        });
    }

    /**
     * Chama a API externa baseado no tipo de consulta
     */
    protected function callApi(QueryType $queryType, string $searchTerm): array
    {
        $provider = $queryType->api_provider;
        $config = $queryType->api_config ?? [];
        $companyId = (int) $queryType->company_id;

        // Se o token Confere.link estiver configurado no painel admin, usa a API real
        // para consultas mapeadas (CPF, NOME), mesmo que o tipo esteja em modo mock.
        $confere = app(ConfereLinkService::class);
        if ($confere->isConfigured($companyId) && $confere->supportsSlug($queryType->slug)) {
            return $confere->consult($companyId, $queryType->slug, $searchTerm);
        }

        return match ($provider) {
            'confere' => $confere->consult($companyId, $queryType->slug, $searchTerm),
            'serasa' => $this->callSerasaApi($queryType->slug, $searchTerm, $config),
            'mock' => $this->mockResponse($queryType->slug, $searchTerm),
            default => ['success' => false, 'message' => 'Provedor de API não configurado'],
        };
    }

    /**
     * @deprecated Mantido por compatibilidade — use ConfereLinkService.
     */
    protected function callConfereApi(string $type, string $term, array $config): array
    {
        return ['success' => false, 'message' => 'Configure o token em Admin → Consultas → Configuração API.'];
    }

    /**
     * API Serasa (exemplo - será customizado)
     */
    protected function callSerasaApi(string $type, string $term, array $config): array
    {
        return ['success' => false, 'message' => 'API Serasa não implementada'];
    }

    /**
     * Resposta mock para testes
     */
    protected function mockResponse(string $type, string $term): array
    {
        return [
            'success' => true,
            'data' => [
                'consulta' => $type,
                'termo' => $term,
                'resultado' => 'Dados de exemplo para teste',
                'timestamp' => now()->toISOString(),
            ],
            'raw' => ['mock' => true],
        ];
    }

    /**
     * Estorna uma consulta
     */
    public function refund(ClientQuery $query): array
    {
        if ($query->status !== 'completed') {
            return ['success' => false, 'message' => 'Apenas consultas concluídas podem ser estornadas'];
        }

        return DB::transaction(function () use ($query) {
            $client = $query->client;
            $amount = (float) $query->amount;

            $client->increment('credit_balance', $amount);

            $query->update([
                'status' => 'refunded',
                'balance_after' => $client->credit_balance,
            ]);

            return [
                'success' => true,
                'message' => 'Consulta estornada com sucesso',
            ];
        });
    }
}
