<?php

namespace App\Services\Logging;

use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * SentryService - Centralized error tracking and alerting
 * 
 * Requirement 65.3: Send critical logs to Sentry for real-time alerts
 * 
 * This service provides a convenient interface to send errors and
 * messages to Sentry for monitoring and alerting.
 */
class SentryService
{
    /**
     * Capture an exception and send to Sentry
     *
     * @param Throwable $exception
     * @param array $context Additional context data
     * @return void
     */
    public function captureException(Throwable $exception, array $context = []): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        // Add context to the exception
        if (!empty($context)) {
            $this->captureToSentry($exception);

            // Also log locally for redundancy
            Log::channel('single')->error($exception->getMessage(), array_merge([
                'exception' => get_class($exception),
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
                'trace' => $exception->getTraceAsString(),
            ], $context));
        } else {
            $this->captureToSentry($exception);
        }
    }

    /**
     * Capture a critical message and send to Sentry
     *
     * @param string $message
     * @param array $context
     * @return void
     */
    public function captureMessage(string $message, array $context = []): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        Log::channel('sentry')->critical($message, $context);
    }

    /**
     * Capture a critical error with context
     *
     * @param string $message
     * @param array $context
     * @return void
     */
    public function logCritical(string $message, array $context = []): void
    {
        if (!$this->isEnabled()) {
            Log::channel('single')->critical($message, $context);
            return;
        }

        // Log to both Sentry and local file
        Log::channel('sentry')->critical($message, $context);
        Log::channel('single')->critical($message, $context);
    }

    /**
     * Capture an error (non-critical)
     *
     * @param string $message
     * @param array $context
     * @return void
     */
    public function logError(string $message, array $context = []): void
    {
        if (!$this->isEnabled()) {
            Log::channel('single')->error($message, $context);
            return;
        }

        Log::channel('sentry')->error($message, $context);
        Log::channel('single')->error($message, $context);
    }

    /**
     * Add context to the current scope
     * Useful for adding user/company information that will be included in all subsequent events
     *
     * @param array $context
     * @return void
     */
    public function addContext(array $context): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        \Sentry\configureScope(function (\Sentry\State\Scope $scope) use ($context): void {
            foreach ($context as $key => $value) {
                $scope->setContext($key, is_array($value) ? $value : ['value' => $value]);
            }
        });
    }

    /**
     * Set user context for tracking in Sentry
     *
     * @param int|string $id
     * @param string|null $email
     * @param array $additional
     * @return void
     */
    public function setUser($id, ?string $email = null, array $additional = []): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        \Sentry\configureScope(function (\Sentry\State\Scope $scope) use ($id, $email, $additional): void {
            $scope->setUser(array_merge([
                'id' => $id,
                'email' => $email,
            ], $additional));
        });
    }

    /**
     * Set company/tenant context
     *
     * @param int $companyId
     * @param string|null $companyName
     * @return void
     */
    public function setCompanyContext(int $companyId, ?string $companyName = null): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        $this->addContext([
            'company' => [
                'id' => $companyId,
                'name' => $companyName,
            ]
        ]);
    }

    /**
     * Add a breadcrumb for better error context
     *
     * @param string $message
     * @param string $category
     * @param array $data
     * @param string $level (debug, info, warning, error, critical)
     * @return void
     */
    public function addBreadcrumb(string $message, string $category = 'default', array $data = [], string $level = 'info'): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        \Sentry\addBreadcrumb(
            category: $category,
            message: $message,
            metadata: $data,
            level: \Sentry\Breadcrumb::parseLevel($level)
        );
    }

    /**
     * Check if Sentry is enabled
     *
     * @return bool
     */
    public function isEnabled(): bool
    {
        return !empty(config('sentry.dsn')) && class_exists(\Sentry\SentrySdk::class);
    }

    protected function captureToSentry(Throwable $exception): void
    {
        if (!class_exists(\Sentry\Laravel\Integration::class)) {
            return;
        }

        \Sentry\Laravel\Integration::captureUnhandledException($exception);
    }

    /**
     * Flush any pending events to Sentry
     * Useful before script termination
     *
     * @return void
     */
    public function flush(): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        \Sentry\flush();
    }
}
