<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class ModuleSettingsService
{
    public function schema(string $slug): ?array
    {
        return config("modules-settings.{$slug}");
    }

    public function all(int $companyId, string $slug): array
    {
        $schema = $this->schema($slug);
        if (!$schema) {
            return [];
        }

        $stored = Setting::where('company_id', $companyId)
            ->where('group', $this->group($slug))
            ->get()
            ->keyBy('key');

        $values = [];
        foreach ($this->flatFields($schema) as $key => $field) {
            $values[$key] = $stored->has($key)
                ? $this->castValue($stored[$key]->typed_value, $field['type'])
                : ($field['default'] ?? null);
        }

        return $values;
    }

    public function save(int $companyId, string $slug, array $input): void
    {
        $schema = $this->schema($slug);
        if (!$schema) {
            throw new \InvalidArgumentException("Schema não definido para módulo '{$slug}'.");
        }

        $validated = $this->validate($slug, $input);

        foreach ($this->flatFields($schema) as $key => $field) {
            $value = $validated[$key] ?? null;
            if (($field['type'] ?? '') === 'boolean') {
                $value = filter_var($value ?? false, FILTER_VALIDATE_BOOLEAN);
            }
            Setting::set($companyId, $this->group($slug), $key, $value, $this->settingType($field['type']));
        }
    }

    public function validate(string $slug, array $input): array
    {
        $fields = $this->flatFields($this->schema($slug) ?? []);
        $rules = [];
        $attributes = [];
        $data = [];

        foreach ($fields as $key => $field) {
            $attributes[$key] = $field['label'] ?? $key;

            if (($field['type'] ?? '') === 'boolean') {
                $data[$key] = filter_var($input[$key] ?? false, FILTER_VALIDATE_BOOLEAN);
                continue;
            }

            $rules[$key] = match ($field['type']) {
                'integer' => 'nullable|integer' . $this->rangeRule($field),
                'decimal' => 'nullable|numeric|min:0',
                'select' => 'nullable|string|in:' . implode(',', array_keys($field['options'] ?? [])),
                default => 'nullable|string|max:500',
            };
        }

        $validator = Validator::make($input, $rules, [], $attributes);

        if ($validator->fails()) {
            throw new ValidationException($validator);
        }

        return array_merge($data, $validator->validated());
    }

    public function flatFields(array $schema): array
    {
        $flat = [];
        foreach ($schema['sections'] ?? [] as $section) {
            foreach ($section['fields'] ?? [] as $key => $field) {
                $flat[$key] = $field;
            }
        }

        return $flat;
    }

    public function group(string $slug): string
    {
        return 'module_' . $slug;
    }

    private function castValue(mixed $value, string $type): mixed
    {
        return match ($type) {
            'boolean' => filter_var($value, FILTER_VALIDATE_BOOLEAN),
            'integer' => (int) $value,
            'decimal' => is_numeric($value) ? number_format((float) $value, 2, '.', '') : $value,
            default => $value,
        };
    }

    private function settingType(string $fieldType): string
    {
        return match ($fieldType) {
            'boolean' => 'boolean',
            'integer' => 'integer',
            default => 'string',
        };
    }

    private function rangeRule(array $field): string
    {
        $parts = [];
        if (isset($field['min'])) {
            $parts[] = 'min:' . $field['min'];
        }
        if (isset($field['max'])) {
            $parts[] = 'max:' . $field['max'];
        }

        return $parts ? '|' . implode('|', $parts) : '';
    }
}
