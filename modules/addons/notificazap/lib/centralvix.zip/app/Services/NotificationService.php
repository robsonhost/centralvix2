<?php

namespace App\Services;

use App\Models\Client;
use App\Models\EmailLog;
use App\Models\EmailTemplate;
use App\Models\Invoice;
use App\Models\Service;
use App\Models\Ticket;
use Illuminate\Support\Facades\Mail;

class NotificationService
{
    protected function actionUrl(Client $client, string $fallbackUrl, string $contextType = 'generic', ?int $contextId = null, string $channel = 'email'): string
    {
        $auto = app(AutoLoginService::class);
        $link = $channel === 'whatsapp'
            ? $auto->linkForWhatsApp($client, $fallbackUrl, $contextType, $contextId)
            : $auto->linkForEmail($client, $fallbackUrl, $contextType, $contextId);

        return $link ?? $fallbackUrl;
    }

    /** URLs de fatura com auto login (e-mail). */
    public function invoiceUrls(Invoice $invoice): array
    {
        return $this->invoiceUrlsForChannel($invoice, 'email');
    }

    /** URLs de fatura com auto login (WhatsApp). */
    public function invoiceUrlsForWhatsApp(Invoice $invoice): array
    {
        return $this->invoiceUrlsForChannel($invoice, 'whatsapp');
    }

    protected function invoiceUrlsForChannel(Invoice $invoice, string $channel): array
    {
        $invoice->loadMissing('client');
        $fallback = route('client.invoices.show', $invoice);
        $url = $this->actionUrl($invoice->client, $fallback, 'invoice', $invoice->id, $channel);

        return ['invoice_url' => $url, 'pay_url' => $url, 'payment_url' => $url];
    }

    /** URL de ticket com auto login (e-mail). */
    public function ticketUrls(Ticket $ticket): array
    {
        return $this->ticketUrlsForChannel($ticket, 'email');
    }

    /** URL de ticket com auto login (WhatsApp). */
    public function ticketUrlsForWhatsApp(Ticket $ticket): array
    {
        return $this->ticketUrlsForChannel($ticket, 'whatsapp');
    }

    protected function ticketUrlsForChannel(Ticket $ticket, string $channel): array
    {
        $ticket->loadMissing('client');
        $fallback = route('client.tickets.show', $ticket);

        return ['ticket_url' => $this->actionUrl($ticket->client, $fallback, 'ticket', $ticket->id, $channel)];
    }

    /**
     * Dispara e-mail + WhatsApp de nova fatura (com link de auto login).
     */
    public function dispatchInvoiceCreated(Invoice $invoice): void
    {
        $invoice->loadMissing('client');
        if (!$invoice->client) {
            return;
        }

        if ($invoice->client->email) {
            $hasTemplate = EmailTemplate::where('company_id', $invoice->client->company_id)
                ->where('slug', 'invoice_created')
                ->where('status', 'active')
                ->exists();

            if ($hasTemplate) {
                $this->notifyInvoiceCreated($invoice);
            } else {
                try {
                    Mail::to($invoice->client->email)->send(new \App\Mail\InvoiceMail($invoice));
                } catch (\Throwable $e) {
                    logger()->error('Falha ao enviar InvoiceMail: ' . $e->getMessage());
                }
            }
        }

        $this->dispatchWhatsApp(
            $invoice->client,
            'invoice_created',
            array_merge([
                'invoice_id'     => $invoice->id,
                'invoice_number' => $invoice->invoice_number,
                'invoice_total'  => number_format((float) $invoice->total, 2, ',', '.'),
                'due_date'       => $invoice->date_due?->format('d/m/Y'),
            ], $this->invoiceUrlsForWhatsApp($invoice)),
            'invoice',
            $invoice->id,
            fn ($client, $data) => app(\App\Services\WhatsApp\WhatsappNotificationService::class)->invoiceCreated($client, $data),
        );
    }

    /**
     * Dispara e-mail + WhatsApp de pagamento confirmado (com link de auto login).
     *
     * @param bool $emailTemplate Envia template de e-mail (desative se já enviou InvoicePaidMail).
     */
    public function dispatchInvoicePaid(Invoice $invoice, bool $emailTemplate = true): void
    {
        $invoice->loadMissing('client');
        if (!$invoice->client) {
            return;
        }

        if ($emailTemplate && $invoice->client->email) {
            $this->notifyPaymentConfirmed($invoice);
        }

        $this->dispatchWhatsApp(
            $invoice->client,
            'payment_confirmed',
            array_merge([
                'invoice_id'     => $invoice->id,
                'invoice_number' => $invoice->invoice_number,
                'amount_paid'    => number_format((float) $invoice->total, 2, ',', '.'),
                'payment_date'   => now()->format('d/m/Y H:i'),
            ], $this->invoiceUrlsForWhatsApp($invoice)),
            'invoice',
            $invoice->id,
            fn ($client, $data) => app(\App\Services\WhatsApp\WhatsappNotificationService::class)->paymentConfirmed($client, $data),
        );
    }

    /** Dispara e-mail + WhatsApp quando um ticket é aberto. */
    public function dispatchTicketOpened(Ticket $ticket): void
    {
        $ticket->loadMissing(['client', 'department']);
        if (!$ticket->client) {
            return;
        }

        if ($ticket->client->email) {
            $this->notifyTicketOpened($ticket);
        }

        $this->dispatchWhatsApp(
            $ticket->client,
            'ticket_opened',
            array_merge([
                'ticket_id'  => $ticket->id,
                'subject'    => $ticket->subject,
                'department' => $ticket->department?->name ?? 'Suporte',
            ], $this->ticketUrlsForWhatsApp($ticket)),
            'ticket',
            $ticket->id,
            fn ($client, $data) => app(\App\Services\WhatsApp\WhatsappNotificationService::class)->ticketOpened($client, $data),
        );
    }

    /** Dispara e-mail + WhatsApp quando o suporte responde um ticket. */
    public function dispatchTicketReplied(Ticket $ticket, string $replyMessage): void
    {
        $ticket->loadMissing('client');
        if (!$ticket->client) {
            return;
        }

        if ($ticket->client->email) {
            $this->notifyTicketReplied($ticket, $replyMessage);
        }

        $this->dispatchWhatsApp(
            $ticket->client,
            'ticket_replied',
            array_merge([
                'ticket_id'    => $ticket->id,
                'subject'      => $ticket->subject,
                'reply_message'=> $replyMessage,
            ], $this->ticketUrlsForWhatsApp($ticket)),
            'ticket',
            $ticket->id,
            fn ($client, $data) => app(\App\Services\WhatsApp\WhatsappNotificationService::class)->ticketReplied($client, $data),
        );
    }

    protected function dispatchWhatsApp(
        Client $client,
        string $event,
        array $data,
        string $contextType,
        int $contextId,
        callable $sender,
    ): void {
        try {
            if (!app(ModuleService::class)->isEnabled($client->company_id, 'whatsapp_notifications')) {
                return;
            }
            $sender($client, $data);
        } catch (\Throwable $e) {
            logger()->warning("WhatsApp {$event} falhou: " . $e->getMessage());
        }
    }

    public function sendEmail(Client $client, string $templateSlug, array $data = []): void
    {
        $template = EmailTemplate::where('company_id', $client->company_id)
            ->where('slug', $templateSlug)
            ->where('status', 'active')
            ->first();

        if (!$template) {
            logger()->warning("Email template '{$templateSlug}' not found for company {$client->company_id}");
            return;
        }

        $rendered = $template->render(array_merge([
            'client_name' => $client->full_name,
            'company_name' => $client->company->name ?? 'CentralVix',
        ], $data));

        $log = EmailLog::create([
            'company_id' => $client->company_id,
            'client_id' => $client->id,
            'template_id' => $template->id,
            'to' => $client->email,
            'subject' => $rendered['subject'],
            'body' => $rendered['bodyHtml'],
            'status' => 'pending',
            'created_at' => now(),
        ]);

        try {
            Mail::html($rendered['bodyHtml'], function ($message) use ($rendered, $client) {
                $message->to($client->email, $client->full_name)
                    ->subject($rendered['subject']);
            });

            $log->update(['status' => 'sent', 'sent_at' => now()]);
        } catch (\Exception $e) {
            $log->update(['status' => 'failed', 'error' => $e->getMessage()]);
            logger()->error("Email send failed: " . $e->getMessage());
        }
    }

    public function notifyInvoiceCreated(Invoice $invoice): void
    {
        $invoice->loadMissing('client');
        $urls = $this->invoiceUrls($invoice);
        $this->sendEmail($invoice->client, 'invoice_created', [
            'invoice_number' => $invoice->invoice_number,
            'invoice_total' => number_format($invoice->total, 2, ',', '.'),
            'due_date' => $invoice->date_due?->format('d/m/Y') ?? '—',
            'invoice_url' => $urls['invoice_url'],
            'pay_url' => $urls['pay_url'],
        ]);
    }

    public function notifyPaymentConfirmed(Invoice $invoice): void
    {
        $invoice->loadMissing('client');
        $urls = $this->invoiceUrls($invoice);
        $this->sendEmail($invoice->client, 'payment_confirmed', [
            'invoice_number' => $invoice->invoice_number,
            'amount_paid' => number_format($invoice->total, 2, ',', '.'),
            'payment_date' => now()->format('d/m/Y H:i'),
            'invoice_url' => $urls['invoice_url'],
        ]);
    }

    public function notifyServiceActivated(Service $service, ?string $plaintextPassword = null): void
    {
        $service->loadMissing(['client', 'product', 'server']);
        $payload = $this->serviceCredentialPayload($service, $plaintextPassword);

        $this->sendEmail($service->client, 'service_activated', $payload);
    }

    public function dispatchServiceProvisioned(Service $service, ?string $plaintextPassword = null): void
    {
        $service->loadMissing(['client', 'product', 'server']);
        if (!$service->client) {
            return;
        }

        $payload = array_merge($this->serviceCredentialPayload($service, $plaintextPassword), [
            'service_id' => $service->id,
        ]);

        if ($service->client->email) {
            $hasTemplate = EmailTemplate::where('company_id', $service->client->company_id)
                ->where('slug', 'service_activated')
                ->where('status', 'active')
                ->exists();

            if ($hasTemplate) {
                $this->notifyServiceActivated($service, $plaintextPassword);
            } else {
                try {
                    \Mail::to($service->client->email)->send(
                        new \App\Mail\ServiceActivatedMail($service, $plaintextPassword ?? $service->getDecryptedPassword())
                    );
                } catch (\Throwable $e) {
                    logger()->error('ServiceActivatedMail failed: ' . $e->getMessage());
                }
            }
        }

        $serviceUrl = route('client.services.show', $service);
        $waEvent = $service->isStreaming() ? 'service_activated_streaming' : 'service_activated';

        $this->dispatchWhatsApp(
            $service->client,
            $waEvent,
            array_merge($payload, [
                'service_url' => $this->actionUrl($service->client, $serviceUrl, 'service', $service->id, 'whatsapp'),
            ]),
            'service',
            $service->id,
            fn ($client, $data) => app(\App\Services\WhatsApp\WhatsappNotificationService::class)->serviceActivated($client, $data),
        );
    }

    public function dispatchServiceReactivated(Service $service): void
    {
        $service->loadMissing(['client', 'product']);
        if (!$service->client) {
            return;
        }

        $payload = array_merge($this->serviceCredentialPayload($service), [
            'service_id' => $service->id,
        ]);

        if ($service->client->email) {
            $this->sendEmail($service->client, 'service_reactivated', $payload);
        }

        $this->dispatchWhatsApp(
            $service->client,
            'service_reactivated',
            array_merge($payload, [
                'service_url' => $this->actionUrl($service->client, route('client.services.show', $service), 'service', $service->id, 'whatsapp'),
            ]),
            'service',
            $service->id,
            fn ($client, $data) => app(\App\Services\WhatsApp\WhatsappNotificationService::class)->serviceReactivated($client, $data),
        );
    }

    protected function serviceCredentialPayload(Service $service, ?string $plaintextPassword = null): array
    {
        $password = $plaintextPassword ?? $service->getDecryptedPassword();
        $nameservers = $service->module_data['nameservers'] ?? $service->server?->settings['nameservers'] ?? [];
        if (is_string($nameservers)) {
            $nameservers = array_filter(array_map('trim', explode(',', $nameservers)));
        }

        $cpanelUrl = $service->module_data['cpanel_url']
            ?? ($service->domain ? "https://{$service->domain}:2083" : null)
            ?? ($service->server ? "https://{$service->server->hostname}:2083" : '#');

        $whmUrl = $service->module_data['whm_url']
            ?? ($service->server ? "https://{$service->server->hostname}:" . ($service->server->port ?? 2087) : '#');

        $streamUrl = $service->module_data['stream_url'] ?? null;
        $panelUrl = $service->module_data['panel_url'] ?? $service->module_data['admin_url'] ?? null;

        $clientServiceUrl = route('client.services.show', $service);

        return [
            'service_name' => $service->name,
            'domain' => $service->domain ?? 'N/A',
            'username' => $service->username ?? 'N/A',
            'password' => $password ?? 'Consulte o painel do cliente',
            'server' => $service->server?->hostname ?? 'N/A',
            'control_panel_url' => $cpanelUrl,
            'cpanel_url' => $cpanelUrl,
            'whm_url' => $whmUrl,
            'stream_url' => $streamUrl ?? 'N/A',
            'streaming_panel_url' => $panelUrl ?? 'N/A',
            'nameservers' => is_array($nameservers) ? implode(', ', $nameservers) : (string) $nameservers,
            'nameserver1' => is_array($nameservers) ? ($nameservers[0] ?? '') : '',
            'nameserver2' => is_array($nameservers) ? ($nameservers[1] ?? '') : '',
            'service_url' => $this->actionUrl($service->client, $clientServiceUrl, 'service', $service->id),
        ];
    }

    public function notifyServiceSuspended(Service $service): void
    {
        $fallback = route('client.invoices.index');
        $this->sendEmail($service->client, 'service_suspended', [
            'service_name' => $service->name,
            'reason' => 'Fatura(s) em atraso',
            'payment_url' => $this->actionUrl($service->client, $fallback),
        ]);
    }

    public function notifyTicketOpened(Ticket $ticket): void
    {
        $ticket->loadMissing(['client', 'department']);
        $urls = $this->ticketUrls($ticket);
        $this->sendEmail($ticket->client, 'ticket_opened', [
            'ticket_id' => $ticket->id,
            'subject' => $ticket->subject,
            'department' => $ticket->department?->name ?? 'Suporte',
            'ticket_url' => $urls['ticket_url'],
        ]);
    }

    public function notifyTicketReplied(Ticket $ticket, string $replyMessage): void
    {
        $ticket->loadMissing('client');
        $urls = $this->ticketUrls($ticket);
        $this->sendEmail($ticket->client, 'ticket_replied', [
            'ticket_id' => $ticket->id,
            'subject' => $ticket->subject,
            'reply_message' => $replyMessage,
            'ticket_url' => $urls['ticket_url'],
        ]);
    }
}
