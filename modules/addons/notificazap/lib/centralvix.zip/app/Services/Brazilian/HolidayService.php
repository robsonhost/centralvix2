<?php

namespace App\Services\Brazilian;

use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;

class HolidayService
{
    /**
     * Verificar se uma data é feriado nacional
     */
    public function isFeriadoNacional(Carbon $data): bool
    {
        $feriados = $this->getFeriadosNacionais($data->year);
        $dataFormatada = $data->format('Y-m-d');
        
        return in_array($dataFormatada, $feriados);
    }
    
    /**
     * Verificar se uma data é fim de semana
     */
    public function isFimDeSemana(Carbon $data): bool
    {
        return $data->isWeekend();
    }
    
    /**
     * Verificar se uma data é dia útil
     */
    public function isDiaUtil(Carbon $data): bool
    {
        return !$this->isFimDeSemana($data) && !$this->isFeriadoNacional($data);
    }
    
    /**
     * Obter próximo dia útil
     */
    public function getProximoDiaUtil(Carbon $data, int $diasAdicionais = 0): Carbon
    {
        $data = $data->copy();
        
        // Adicionar dias adicionais se especificado
        if ($diasAdicionais > 0) {
            $data->addDays($diasAdicionais);
        }
        
        // Avançar até encontrar dia útil
        while (!$this->isDiaUtil($data)) {
            $data->addDay();
        }
        
        return $data;
    }
    
    /**
     * Ajustar data de vencimento de fatura
     */
    public function ajustarVencimento(Carbon $vencimento, array $opcoes = []): Carbon
    {
        $opcoes = array_merge([
            'ajustar_feriados' => true,
            'ajustar_finais_semana' => true,
            'dias_adicionais' => 1, // D+1
            'feriados_municipais' => [],
        ], $opcoes);
        
        // Se não deve ajustar nada, retornar data original
        if (!$opcoes['ajustar_feriados'] && !$opcoes['ajustar_finais_semana']) {
            return $vencimento;
        }
        
        $novoVencimento = $vencimento->copy();
        
        // Verificar se é feriado nacional
        $isFeriado = $this->isFeriadoNacional($novoVencimento);
        
        // Verificar se é feriado municipal
        if (!empty($opcoes['feriados_municipais'])) {
            $dataFormatada = $novoVencimento->format('Y-m-d');
            if (in_array($dataFormatada, $opcoes['feriados_municipais'])) {
                $isFeriado = true;
            }
        }
        
        // Verificar se é fim de semana
        $isFimDeSemana = $this->isFimDeSemana($novoVencimento);
        
        // Se precisa ajustar
        $precisaAjustar = false;
        if ($opcoes['ajustar_feriados'] && $isFeriado) {
            $precisaAjustar = true;
        }
        if ($opcoes['ajustar_finais_semana'] && $isFimDeSemana) {
            $precisaAjustar = true;
        }
        
        // Ajustar para próximo dia útil
        if ($precisaAjustar) {
            $novoVencimento = $this->getProximoDiaUtil($novoVencimento, $opcoes['dias_adicionais']);
        }
        
        return $novoVencimento;
    }
    
    /**
     * Verificar se pode suspender cliente (não suspender em feriados/fins de semana)
     */
    public function podeSuspenderCliente(Carbon $data = null): bool
    {
        $data = $data ?? now();
        
        // Não suspender em feriados
        if ($this->isFeriadoNacional($data)) {
            return false;
        }
        
        // Não suspender em fins de semana
        if ($this->isFimDeSemana($data)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Obter todos os feriados nacionais do ano
     */
    public function getFeriadosNacionais(int $ano): array
    {
        $cacheKey = "feriados_nacionais:{$ano}";
        
        return Cache::remember($cacheKey, now()->addYear(), function () use ($ano) {
            $feriados = [];
            
            // Feriados fixos
            $feriados[] = Carbon::create($ano, 1, 1)->format('Y-m-d'); // Confraternização Universal
            $feriados[] = Carbon::create($ano, 4, 21)->format('Y-m-d'); // Tiradentes
            $feriados[] = Carbon::create($ano, 5, 1)->format('Y-m-d'); // Dia do Trabalho
            $feriados[] = Carbon::create($ano, 9, 7)->format('Y-m-d'); // Independência
            $feriados[] = Carbon::create($ano, 10, 12)->format('Y-m-d'); // N. S. Aparecida
            $feriados[] = Carbon::create($ano, 11, 2)->format('Y-m-d'); // Finados
            $feriados[] = Carbon::create($ano, 11, 15)->format('Y-m-d'); // Proclamação da República
            $feriados[] = Carbon::create($ano, 11, 20)->format('Y-m-d'); // Consciência Negra
            $feriados[] = Carbon::create($ano, 12, 25)->format('Y-m-d'); // Natal
            
            // Feriados móveis (baseados na Páscoa)
            $pascoa = $this->calcularPascoa($ano);
            
            // Carnaval (47 dias antes da Páscoa)
            $carnaval = $pascoa->copy()->subDays(47);
            $feriados[] = $carnaval->format('Y-m-d'); // Segunda de Carnaval
            $feriados[] = $carnaval->copy()->addDay()->format('Y-m-d'); // Terça de Carnaval
            
            // Sexta-feira Santa (2 dias antes da Páscoa)
            $feriados[] = $pascoa->copy()->subDays(2)->format('Y-m-d');
            
            // Corpus Christi (60 dias depois da Páscoa)
            $feriados[] = $pascoa->copy()->addDays(60)->format('Y-m-d');
            
            return array_unique($feriados);
        });
    }
    
    /**
     * Calcular data da Páscoa usando algoritmo de Meeus
     */
    private function calcularPascoa(int $ano): Carbon
    {
        $a = $ano % 19;
        $b = intdiv($ano, 100);
        $c = $ano % 100;
        $d = intdiv($b, 4);
        $e = $b % 4;
        $f = intdiv($b + 8, 25);
        $g = intdiv($b - $f + 1, 3);
        $h = (19 * $a + $b - $d - $g + 15) % 30;
        $i = intdiv($c, 4);
        $k = $c % 4;
        $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7;
        $m = intdiv($a + 11 * $h + 22 * $l, 451);
        $mes = intdiv($h + $l - 7 * $m + 114, 31);
        $dia = (($h + $l - 7 * $m + 114) % 31) + 1;
        
        return Carbon::create($ano, $mes, $dia);
    }
    
    /**
     * Obter nome do feriado
     */
    public function getNomeFeriado(Carbon $data): ?string
    {
        $dataFormatada = $data->format('m-d');
        $ano = $data->year;
        
        // Feriados fixos
        $feriadosFixos = [
            '01-01' => 'Confraternização Universal',
            '04-21' => 'Tiradentes',
            '05-01' => 'Dia do Trabalho',
            '09-07' => 'Independência do Brasil',
            '10-12' => 'Nossa Senhora Aparecida',
            '11-02' => 'Finados',
            '11-15' => 'Proclamação da República',
            '11-20' => 'Dia da Consciência Negra',
            '12-25' => 'Natal',
        ];
        
        if (isset($feriadosFixos[$dataFormatada])) {
            return $feriadosFixos[$dataFormatada];
        }
        
        // Feriados móveis
        $pascoa = $this->calcularPascoa($ano);
        
        $carnaval = $pascoa->copy()->subDays(47);
        if ($data->isSameDay($carnaval)) {
            return 'Segunda-feira de Carnaval';
        }
        if ($data->isSameDay($carnaval->copy()->addDay())) {
            return 'Terça-feira de Carnaval';
        }
        
        if ($data->isSameDay($pascoa->copy()->subDays(2))) {
            return 'Sexta-feira Santa';
        }
        
        if ($data->isSameDay($pascoa)) {
            return 'Páscoa';
        }
        
        if ($data->isSameDay($pascoa->copy()->addDays(60))) {
            return 'Corpus Christi';
        }
        
        return null;
    }
    
    /**
     * Listar todos os feriados do mês
     */
    public function getFeriadosDoMes(int $ano, int $mes): array
    {
        $feriados = [];
        $feriadosAno = $this->getFeriadosNacionais($ano);
        
        foreach ($feriadosAno as $feriado) {
            $data = Carbon::parse($feriado);
            if ($data->month === $mes) {
                $feriados[] = [
                    'data' => $data->format('Y-m-d'),
                    'dia' => $data->day,
                    'nome' => $this->getNomeFeriado($data),
                    'dia_semana' => $data->locale('pt_BR')->dayName,
                ];
            }
        }
        
        return $feriados;
    }
}
