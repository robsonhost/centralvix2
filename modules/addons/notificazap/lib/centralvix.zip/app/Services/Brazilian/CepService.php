<?php

namespace App\Services\Brazilian;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class CepService
{
    /**
     * APIs de CEP (com fallback)
     */
    private const VIACEP_URL = 'https://viacep.com.br/ws/{cep}/json/';
    private const BRASILAPI_URL = 'https://brasilapi.com.br/api/cep/v1/{cep}';
    
    /**
     * Buscar CEP com cache e fallback
     */
    public function buscar(string $cep): ?array
    {
        // Limpar CEP
        $cep = $this->limparCep($cep);
        
        // Validar formato
        if (!$this->validarCep($cep)) {
            return null;
        }
        
        // Verificar cache (24 horas)
        $cacheKey = "cep:{$cep}";
        
        if (Cache::has($cacheKey)) {
            return Cache::get($cacheKey);
        }
        
        // Tentar ViaCEP primeiro
        $resultado = $this->buscarViaCep($cep);
        
        // Se falhar, tentar BrasilAPI
        if (!$resultado) {
            $resultado = $this->buscarBrasilApi($cep);
        }
        
        // Cachear resultado se encontrado
        if ($resultado) {
            Cache::put($cacheKey, $resultado, now()->addHours(24));
        }
        
        return $resultado;
    }
    
    /**
     * Buscar via ViaCEP
     */
    private function buscarViaCep(string $cep): ?array
    {
        try {
            $url = str_replace('{cep}', $cep, self::VIACEP_URL);
            $response = Http::timeout(5)->get($url);
            
            if ($response->successful()) {
                $data = $response->json();
                
                // ViaCEP retorna "erro: true" quando CEP não existe
                if (isset($data['erro']) && $data['erro'] === true) {
                    return null;
                }
                
                return $this->normalizarViaCep($data);
            }
        } catch (\Exception $e) {
            Log::warning("Erro ao buscar CEP no ViaCEP: {$cep}", ['error' => $e->getMessage()]);
        }
        
        return null;
    }
    
    /**
     * Buscar via BrasilAPI (fallback)
     */
    private function buscarBrasilApi(string $cep): ?array
    {
        try {
            $url = str_replace('{cep}', $cep, self::BRASILAPI_URL);
            $response = Http::timeout(5)->get($url);
            
            if ($response->successful()) {
                $data = $response->json();
                return $this->normalizarBrasilApi($data);
            }
        } catch (\Exception $e) {
            Log::warning("Erro ao buscar CEP no BrasilAPI: {$cep}", ['error' => $e->getMessage()]);
        }
        
        return null;
    }
    
    /**
     * Normalizar resposta do ViaCEP
     */
    private function normalizarViaCep(array $data): array
    {
        return [
            'cep' => $data['cep'] ?? '',
            'logradouro' => $data['logradouro'] ?? '',
            'complemento' => $data['complemento'] ?? '',
            'bairro' => $data['bairro'] ?? '',
            'cidade' => $data['localidade'] ?? '',
            'estado' => $data['uf'] ?? '',
            'ibge' => $data['ibge'] ?? '',
            'gia' => $data['gia'] ?? '',
            'ddd' => $data['ddd'] ?? '',
            'siafi' => $data['siafi'] ?? '',
        ];
    }
    
    /**
     * Normalizar resposta do BrasilAPI
     */
    private function normalizarBrasilApi(array $data): array
    {
        return [
            'cep' => $data['cep'] ?? '',
            'logradouro' => $data['street'] ?? '',
            'complemento' => '',
            'bairro' => $data['neighborhood'] ?? '',
            'cidade' => $data['city'] ?? '',
            'estado' => $data['state'] ?? '',
            'ibge' => '',
            'gia' => '',
            'ddd' => '',
            'siafi' => '',
        ];
    }
    
    /**
     * Limpar CEP (remover pontos, hífen, espaços)
     */
    public function limparCep(string $cep): string
    {
        return preg_replace('/[^0-9]/', '', $cep);
    }
    
    /**
     * Validar formato do CEP
     */
    public function validarCep(string $cep): bool
    {
        $cep = $this->limparCep($cep);
        return strlen($cep) === 8 && ctype_digit($cep);
    }
    
    /**
     * Formatar CEP (12345678 -> 12345-678)
     */
    public function formatarCep(string $cep): string
    {
        $cep = $this->limparCep($cep);
        
        if (strlen($cep) !== 8) {
            return $cep;
        }
        
        return substr($cep, 0, 5) . '-' . substr($cep, 5);
    }
}
