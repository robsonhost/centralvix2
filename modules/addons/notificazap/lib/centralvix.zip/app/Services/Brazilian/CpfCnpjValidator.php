<?php

namespace App\Services\Brazilian;

class CpfCnpjValidator
{
    /**
     * Validar CPF ou CNPJ
     */
    public function validar(string $documento): bool
    {
        $documento = $this->limpar($documento);
        
        if (strlen($documento) === 11) {
            return $this->validarCpf($documento);
        }
        
        if (strlen($documento) === 14) {
            return $this->validarCnpj($documento);
        }
        
        return false;
    }
    
    /**
     * Validar CPF
     */
    public function validarCpf(string $cpf): bool
    {
        $cpf = $this->limpar($cpf);
        
        // Verificar tamanho
        if (strlen($cpf) !== 11) {
            return false;
        }
        
        // Verificar se todos os dígitos são iguais
        if (preg_match('/^(\d)\1+$/', $cpf)) {
            return false;
        }
        
        // Calcular primeiro dígito verificador
        $soma = 0;
        for ($i = 0; $i < 9; $i++) {
            $soma += ((int) $cpf[$i]) * (10 - $i);
        }
        $resto = $soma % 11;
        $digito1 = $resto < 2 ? 0 : 11 - $resto;
        
        if ($digito1 != $cpf[9]) {
            return false;
        }
        
        // Calcular segundo dígito verificador
        $soma = 0;
        for ($i = 0; $i < 10; $i++) {
            $soma += ((int) $cpf[$i]) * (11 - $i);
        }
        $resto = $soma % 11;
        $digito2 = $resto < 2 ? 0 : 11 - $resto;
        
        return $digito2 == $cpf[10];
    }
    
    /**
     * Validar CNPJ
     */
    public function validarCnpj(string $cnpj): bool
    {
        $cnpj = $this->limpar($cnpj);
        
        // Verificar tamanho
        if (strlen($cnpj) !== 14) {
            return false;
        }
        
        // Verificar se todos os dígitos são iguais
        if (preg_match('/^(\d)\1+$/', $cnpj)) {
            return false;
        }
        
        // Calcular primeiro dígito verificador
        $soma = 0;
        $pesos = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        
        for ($i = 0; $i < 12; $i++) {
            $soma += ((int) $cnpj[$i]) * $pesos[$i];
        }
        
        $resto = $soma % 11;
        $digito1 = $resto < 2 ? 0 : 11 - $resto;
        
        if ($digito1 != $cnpj[12]) {
            return false;
        }
        
        // Calcular segundo dígito verificador
        $soma = 0;
        $pesos = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        
        for ($i = 0; $i < 13; $i++) {
            $soma += ((int) $cnpj[$i]) * $pesos[$i];
        }
        
        $resto = $soma % 11;
        $digito2 = $resto < 2 ? 0 : 11 - $resto;
        
        return $digito2 == $cnpj[13];
    }
    
    /**
     * Limpar documento (remover pontos, traços, barras)
     */
    public function limpar(string $documento): string
    {
        return preg_replace('/[^0-9]/', '', $documento);
    }
    
    /**
     * Formatar CPF (12345678901 -> 123.456.789-01)
     */
    public function formatarCpf(string $cpf): string
    {
        $cpf = $this->limpar($cpf);
        
        if (strlen($cpf) !== 11) {
            return $cpf;
        }
        
        return sprintf(
            '%s.%s.%s-%s',
            substr($cpf, 0, 3),
            substr($cpf, 3, 3),
            substr($cpf, 6, 3),
            substr($cpf, 9, 2)
        );
    }
    
    /**
     * Formatar CNPJ (12345678000190 -> 12.345.678/0001-90)
     */
    public function formatarCnpj(string $cnpj): string
    {
        $cnpj = $this->limpar($cnpj);
        
        if (strlen($cnpj) !== 14) {
            return $cnpj;
        }
        
        return sprintf(
            '%s.%s.%s/%s-%s',
            substr($cnpj, 0, 2),
            substr($cnpj, 2, 3),
            substr($cnpj, 5, 3),
            substr($cnpj, 8, 4),
            substr($cnpj, 12, 2)
        );
    }
    
    /**
     * Formatar automaticamente CPF ou CNPJ
     */
    public function formatar(string $documento): string
    {
        $documento = $this->limpar($documento);
        
        if (strlen($documento) === 11) {
            return $this->formatarCpf($documento);
        }
        
        if (strlen($documento) === 14) {
            return $this->formatarCnpj($documento);
        }
        
        return $documento;
    }
    
    /**
     * Verificar se CPF/CNPJ já existe no banco
     */
    public function verificarDuplicidade(string $documento, ?int $clienteIdExcluir = null): ?array
    {
        $documento = $this->limpar($documento);
        
        $query = \App\Models\Client::where(function ($q) use ($documento) {
            $q->where('cpf', $documento)
              ->orWhere('cnpj', $documento);
        });
        
        // Excluir o próprio cliente ao editar
        if ($clienteIdExcluir) {
            $query->where('id', '!=', $clienteIdExcluir);
        }
        
        $cliente = $query->first();
        
        if ($cliente) {
            return [
                'duplicado' => true,
                'cliente_id' => $cliente->id,
                'cliente_nome' => $cliente->name,
                'cliente_email' => $this->ofuscarEmail($cliente->email),
            ];
        }
        
        return ['duplicado' => false];
    }
    
    /**
     * Ofuscar email (exemplo@dominio.com -> ex***@dominio.com)
     */
    private function ofuscarEmail(string $email): string
    {
        $partes = explode('@', $email);
        
        if (count($partes) !== 2) {
            return $email;
        }
        
        $nome = $partes[0];
        $dominio = $partes[1];
        
        if (strlen($nome) <= 2) {
            return $email;
        }
        
        $ofuscado = substr($nome, 0, 2) . str_repeat('*', strlen($nome) - 2);
        
        return $ofuscado . '@' . $dominio;
    }
    
    /**
     * Determinar tipo de documento
     */
    public function getTipo(string $documento): ?string
    {
        $documento = $this->limpar($documento);
        
        if (strlen($documento) === 11) {
            return 'cpf';
        }
        
        if (strlen($documento) === 14) {
            return 'cnpj';
        }
        
        return null;
    }
}
