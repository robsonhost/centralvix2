<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;

class ValidationService
{
    /**
     * Validate CPF (Brazilian individual taxpayer number).
     */
    public function validateCpf(string $cpf): bool
    {
        $cpf = preg_replace('/\D/', '', $cpf);

        if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf)) {
            return false;
        }

        for ($t = 9; $t < 11; $t++) {
            $sum = 0;
            for ($d = 0; $d < $t; $d++) {
                $sum += intval($cpf[$d]) * ($t + 1 - $d);
            }
            $rem = $sum % 11;
            if ($rem < 2) $rem = 0;
            else $rem = 11 - $rem;

            if (intval($cpf[$t]) !== $rem) return false;
        }

        return true;
    }

    /**
     * Validate CNPJ (Brazilian company taxpayer number).
     */
    public function validateCnpj(string $cnpj): bool
    {
        $cnpj = preg_replace('/\D/', '', $cnpj);

        if (strlen($cnpj) !== 14 || preg_match('/^(\d)\1{13}$/', $cnpj)) {
            return false;
        }

        $weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        $weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];

        $calc = function (string $cnpj, array $weights): int {
            $sum = 0;
            foreach ($weights as $i => $w) {
                $sum += intval($cnpj[$i]) * $w;
            }
            $rem = $sum % 11;
            return $rem < 2 ? 0 : 11 - $rem;
        };

        return intval($cnpj[12]) === $calc($cnpj, $weights1)
            && intval($cnpj[13]) === $calc($cnpj, $weights2);
    }

    /**
     * Look up CNPJ data from BrasilAPI.
     */
    public function lookupCnpj(string $cnpj): ?array
    {
        $cnpj  = preg_replace('/\D/', '', $cnpj);
        $cache = 'cnpj_' . $cnpj;

        return Cache::remember($cache, 86400, function () use ($cnpj) {
            try {
                $r = Http::timeout(10)->get("https://brasilapi.com.br/api/cnpj/v1/{$cnpj}");
                if ($r->successful()) return $r->json();
            } catch (\Exception) {}

            // Fallback: ReceitaWS
            try {
                $r = Http::timeout(10)->get("https://www.receitaws.com.br/v1/cnpj/{$cnpj}");
                if ($r->successful() && $r->json('status') !== 'ERROR') return $r->json();
            } catch (\Exception) {}

            return null;
        });
    }

    /**
     * Look up address by CEP (Brazilian postal code).
     */
    public function lookupCep(string $cep): ?array
    {
        $cep   = preg_replace('/\D/', '', $cep);
        $cache = 'cep_' . $cep;

        return Cache::remember($cache, 86400, function () use ($cep) {
            try {
                $r = Http::timeout(10)->get("https://brasilapi.com.br/api/cep/v2/{$cep}");
                if ($r->successful()) {
                    $d = $r->json();
                    return [
                        'cep'          => $cep,
                        'logradouro'   => $d['street'] ?? '',
                        'bairro'       => $d['neighborhood'] ?? '',
                        'localidade'   => $d['city'] ?? '',
                        'uf'           => $d['state'] ?? '',
                        'ibge'         => $d['city_ibge'] ?? '',
                    ];
                }
            } catch (\Exception) {}

            // Fallback: ViaCEP
            try {
                $r = Http::timeout(10)->get("https://viacep.com.br/ws/{$cep}/json/");
                if ($r->successful() && !$r->json('erro')) return $r->json();
            } catch (\Exception) {}

            return null;
        });
    }

    /**
     * Geolocate IP address.
     */
    public function geolocateIp(string $ip): array
    {
        if (in_array($ip, ['127.0.0.1', '::1', 'localhost'])) {
            return ['city' => 'Localhost', 'region' => '', 'country' => 'BR', 'timezone' => 'America/Sao_Paulo'];
        }

        $cache = 'geoip_' . $ip;

        return Cache::remember($cache, 3600, function () use ($ip) {
            try {
                $r = Http::timeout(5)->get("https://ipapi.co/{$ip}/json/");
                if ($r->successful()) {
                    $d = $r->json();
                    return [
                        'city'     => $d['city'] ?? '',
                        'region'   => $d['region'] ?? '',
                        'country'  => $d['country_code'] ?? '',
                        'timezone' => $d['timezone'] ?? '',
                        'org'      => $d['org'] ?? '',
                        'lat'      => $d['latitude'] ?? 0,
                        'lng'      => $d['longitude'] ?? 0,
                    ];
                }
            } catch (\Exception) {}

            return ['city' => '', 'region' => '', 'country' => '', 'timezone' => ''];
        });
    }

    /**
     * Discover state/city from DDD (Brazil).
     */
    public function lookupDdd(string $ddd): array
    {
        $map = [
            '11' => ['state' => 'SP', 'city' => 'São Paulo'],
            '12' => ['state' => 'SP', 'city' => 'São José dos Campos'],
            '13' => ['state' => 'SP', 'city' => 'Santos'],
            '14' => ['state' => 'SP', 'city' => 'Bauru'],
            '15' => ['state' => 'SP', 'city' => 'Sorocaba'],
            '16' => ['state' => 'SP', 'city' => 'Ribeirão Preto'],
            '17' => ['state' => 'SP', 'city' => 'São José do Rio Preto'],
            '18' => ['state' => 'SP', 'city' => 'Presidente Prudente'],
            '19' => ['state' => 'SP', 'city' => 'Campinas'],
            '21' => ['state' => 'RJ', 'city' => 'Rio de Janeiro'],
            '22' => ['state' => 'RJ', 'city' => 'Campos dos Goytacazes'],
            '24' => ['state' => 'RJ', 'city' => 'Volta Redonda'],
            '27' => ['state' => 'ES', 'city' => 'Vitória'],
            '28' => ['state' => 'ES', 'city' => 'Cachoeiro de Itapemirim'],
            '31' => ['state' => 'MG', 'city' => 'Belo Horizonte'],
            '32' => ['state' => 'MG', 'city' => 'Juiz de Fora'],
            '33' => ['state' => 'MG', 'city' => 'Governador Valadares'],
            '34' => ['state' => 'MG', 'city' => 'Uberlândia'],
            '35' => ['state' => 'MG', 'city' => 'Poços de Caldas'],
            '37' => ['state' => 'MG', 'city' => 'Divinópolis'],
            '38' => ['state' => 'MG', 'city' => 'Montes Claros'],
            '41' => ['state' => 'PR', 'city' => 'Curitiba'],
            '42' => ['state' => 'PR', 'city' => 'Ponta Grossa'],
            '43' => ['state' => 'PR', 'city' => 'Londrina'],
            '44' => ['state' => 'PR', 'city' => 'Maringá'],
            '45' => ['state' => 'PR', 'city' => 'Foz do Iguaçu'],
            '46' => ['state' => 'PR', 'city' => 'Francisco Beltrão'],
            '47' => ['state' => 'SC', 'city' => 'Joinville'],
            '48' => ['state' => 'SC', 'city' => 'Florianópolis'],
            '49' => ['state' => 'SC', 'city' => 'Chapecó'],
            '51' => ['state' => 'RS', 'city' => 'Porto Alegre'],
            '53' => ['state' => 'RS', 'city' => 'Pelotas'],
            '54' => ['state' => 'RS', 'city' => 'Caxias do Sul'],
            '55' => ['state' => 'RS', 'city' => 'Santa Maria'],
            '61' => ['state' => 'DF', 'city' => 'Brasília'],
            '62' => ['state' => 'GO', 'city' => 'Goiânia'],
            '63' => ['state' => 'TO', 'city' => 'Palmas'],
            '64' => ['state' => 'GO', 'city' => 'Rio Verde'],
            '65' => ['state' => 'MT', 'city' => 'Cuiabá'],
            '66' => ['state' => 'MT', 'city' => 'Rondonópolis'],
            '67' => ['state' => 'MS', 'city' => 'Campo Grande'],
            '68' => ['state' => 'AC', 'city' => 'Rio Branco'],
            '69' => ['state' => 'RO', 'city' => 'Porto Velho'],
            '71' => ['state' => 'BA', 'city' => 'Salvador'],
            '73' => ['state' => 'BA', 'city' => 'Ilhéus'],
            '74' => ['state' => 'BA', 'city' => 'Juazeiro'],
            '75' => ['state' => 'BA', 'city' => 'Feira de Santana'],
            '77' => ['state' => 'BA', 'city' => 'Barreiras'],
            '79' => ['state' => 'SE', 'city' => 'Aracaju'],
            '81' => ['state' => 'PE', 'city' => 'Recife'],
            '82' => ['state' => 'AL', 'city' => 'Maceió'],
            '83' => ['state' => 'PB', 'city' => 'João Pessoa'],
            '84' => ['state' => 'RN', 'city' => 'Natal'],
            '85' => ['state' => 'CE', 'city' => 'Fortaleza'],
            '86' => ['state' => 'PI', 'city' => 'Teresina'],
            '87' => ['state' => 'PE', 'city' => 'Petrolina'],
            '88' => ['state' => 'CE', 'city' => 'Juazeiro do Norte'],
            '89' => ['state' => 'PI', 'city' => 'Picos'],
            '91' => ['state' => 'PA', 'city' => 'Belém'],
            '92' => ['state' => 'AM', 'city' => 'Manaus'],
            '93' => ['state' => 'PA', 'city' => 'Santarém'],
            '94' => ['state' => 'PA', 'city' => 'Marabá'],
            '95' => ['state' => 'RR', 'city' => 'Boa Vista'],
            '96' => ['state' => 'AP', 'city' => 'Macapá'],
            '97' => ['state' => 'AM', 'city' => 'Coari'],
            '98' => ['state' => 'MA', 'city' => 'São Luís'],
            '99' => ['state' => 'MA', 'city' => 'Imperatriz'],
        ];

        $ddd = preg_replace('/\D/', '', $ddd);
        return $map[$ddd] ?? ['state' => '', 'city' => 'DDD não encontrado'];
    }

    /**
     * Format CPF: 000.000.000-00
     */
    public function formatCpf(string $cpf): string
    {
        $cpf = preg_replace('/\D/', '', $cpf);
        return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $cpf);
    }

    /**
     * Format CNPJ: 00.000.000/0000-00
     */
    public function formatCnpj(string $cnpj): string
    {
        $cnpj = preg_replace('/\D/', '', $cnpj);
        return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $cnpj);
    }
}
