<?php

namespace App\Services;

use App\Services\WhatsApp\EvolutionGoService;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

/**
 * Serviço de verificação de WhatsApp (registro / 2FA).
 *
 * Delega a comunicação para o EvolutionGoService, que conhece os endpoints
 * corretos do Evolution Go (GestãoVix) — diferentes da Evolution API clássica.
 */
class WhatsAppService
{
    protected bool $enabled;
    protected string $instance;

    public function __construct(
        protected EvolutionGoService $evolution
    ) {
        $this->enabled  = (bool) config('whatsapp.evolution_go.enabled', config('services.evolution.enabled', false));
        $this->instance = (string) config('whatsapp.evolution_go.instance', config('services.evolution.instance', 'centralvix'));
    }

    /**
     * Verificar status da conexão da instância
     */
    public function checkConnectionStatus(): array
    {
        if (!$this->enabled) {
            return [
                'connected' => false,
                'message' => 'WhatsApp não está habilitado'
            ];
        }

        try {
            $result = $this->evolution->getConnectionState($this->instance);

            $connected = (bool) ($result['data']['connected'] ?? false)
                || (($result['data']['state'] ?? '') === 'open');

            return [
                'connected' => $connected,
                'state'     => $connected ? 'open' : ($result['data']['state'] ?? 'disconnected'),
                'instance'  => $this->instance,
                'message'   => $connected ? 'Conectado e pronto' : ($result['message'] ?? 'Desconectado'),
            ];
        } catch (\Exception $e) {
            Log::error('Erro ao verificar status WhatsApp', ['error' => $e->getMessage()]);

            return [
                'connected' => false,
                'message' => 'Erro: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Verificar se o número do WhatsApp existe.
     *
     * O Evolution Go nem sempre expõe a checagem de números; quando não for
     * possível verificar, não bloqueamos o fluxo (prosseguimos para o envio).
     */
    public function checkNumberExists(string $phoneNumber): array
    {
        if (!$this->enabled) {
            return ['success' => false, 'message' => 'WhatsApp não está habilitado'];
        }

        try {
            $result = $this->evolution->checkNumber($this->instance, $phoneNumber);

            if (!($result['success'] ?? false)) {
                // Endpoint indisponível nesta API — não bloquear o cadastro
                Log::info('WhatsAppService::checkNumberExists indisponível, prosseguindo', [
                    'status'  => $result['status'] ?? null,
                    'message' => $result['message'] ?? null,
                ]);

                return ['success' => true, 'exists' => true, 'message' => 'Prosseguindo sem checagem de número'];
            }

            $data  = $result['data'] ?? [];
            $entry = $data[0] ?? $data;
            $exists = is_array($entry) && (($entry['exists'] ?? false) === true);

            return [
                'success' => true,
                'exists'  => $exists,
                'jid'     => is_array($entry) ? ($entry['jid'] ?? null) : null,
                'message' => $exists ? 'Número válido no WhatsApp' : 'Número não encontrado no WhatsApp',
            ];
        } catch (\Exception $e) {
            Log::error('WhatsAppService::checkNumberExists error: ' . $e->getMessage());
            // Em caso de erro, não bloquear — tentamos enviar mesmo assim
            return ['success' => true, 'exists' => true, 'message' => 'Prosseguindo sem checagem de número'];
        }
    }

    /**
     * Enviar código de verificação via WhatsApp
     */
    public function sendVerificationCode(string $phoneNumber): array
    {
        if (!$this->enabled) {
            return ['success' => false, 'message' => 'WhatsApp não está habilitado'];
        }

        try {
            $formattedNumber = $this->formatPhoneNumber($phoneNumber);
            $code = str_pad((string) rand(0, 999999), 6, '0', STR_PAD_LEFT);

            // Armazenar código no cache por 10 minutos
            $cacheKey = "whatsapp_verification_{$formattedNumber}";
            Cache::put($cacheKey, $code, now()->addMinutes(10));

            $message  = "🔐 *CentralVix - Código de Verificação*\n\n";
            $message .= "Seu código de verificação é: *{$code}*\n\n";
            $message .= "Este código expira em 10 minutos.\n";
            $message .= "Não compartilhe este código com ninguém.";

            $result = $this->evolution->sendText($this->instance, $formattedNumber, $message);

            if ($result['success'] ?? false) {
                return [
                    'success' => true,
                    'message' => 'Código enviado com sucesso!',
                    'code_for_testing' => config('app.debug') ? $code : null,
                ];
            }

            Log::warning('WhatsAppService::sendVerificationCode falhou', [
                'status'  => $result['status'] ?? null,
                'message' => $result['message'] ?? null,
            ]);

            return ['success' => false, 'message' => $result['message'] ?? 'Erro ao enviar código'];
        } catch (\Exception $e) {
            Log::error('WhatsAppService::sendVerificationCode error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Erro: ' . $e->getMessage()];
        }
    }

    /**
     * Verificar código de verificação
     */
    public function verifyCode(string $phoneNumber, string $code): bool
    {
        $formattedNumber = $this->formatPhoneNumber($phoneNumber);
        $cacheKey = "whatsapp_verification_{$formattedNumber}";
        $storedCode = Cache::get($cacheKey);

        if ($storedCode && $storedCode === $code) {
            Cache::put("whatsapp_verified_{$formattedNumber}", true, now()->addDays(30));
            Cache::forget($cacheKey);
            return true;
        }

        return false;
    }

    /**
     * Verificar se número já foi verificado
     */
    public function isNumberVerified(string $phoneNumber): bool
    {
        $formattedNumber = $this->formatPhoneNumber($phoneNumber);
        return Cache::has("whatsapp_verified_{$formattedNumber}");
    }

    /**
     * Enviar mensagem de texto avulsa
     */
    public function sendMessage(string $phoneNumber, string $message): array
    {
        if (!$this->enabled) {
            return ['success' => false, 'message' => 'WhatsApp não está habilitado'];
        }

        try {
            $formattedNumber = $this->formatPhoneNumber($phoneNumber);
            $result = $this->evolution->sendText($this->instance, $formattedNumber, $message);

            if ($result['success'] ?? false) {
                return ['success' => true, 'message' => 'Mensagem enviada com sucesso'];
            }

            return ['success' => false, 'message' => $result['message'] ?? 'Erro ao enviar mensagem'];
        } catch (\Exception $e) {
            Log::error('WhatsAppService::sendMessage error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Erro: ' . $e->getMessage()];
        }
    }

    /**
     * Formatar número de telefone para padrão internacional
     */
    protected function formatPhoneNumber(string $phone): string
    {
        $phone = preg_replace('/\D/', '', $phone);

        if (substr($phone, 0, 2) === '55') {
            return $phone;
        }

        if (strlen($phone) === 11 || strlen($phone) === 10) {
            return '55' . $phone;
        }

        return $phone;
    }
}
