<?php

namespace App\Services\PaymentGateways;

abstract class PaymentGateway
{
    /**
     * Criar cobrança
     */
    abstract public function createCharge(array $data): array;

    /**
     * Consultar cobrança
     */
    abstract public function getCharge(string $chargeId): array;

    /**
     * Processar webhook
     */
    abstract public function processWebhook(array $payload): void;

    /**
     * Gerar PIX
     */
    abstract public function generatePix(array $data): array;

    /**
     * Gerar Boleto
     */
    abstract public function generateBoleto(array $data): array;
}
