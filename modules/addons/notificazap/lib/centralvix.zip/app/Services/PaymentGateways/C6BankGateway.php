<?php

namespace App\Services\PaymentGateways;

use App\Models\Invoice;
use App\Models\PaymentTransaction;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Gateway PIX C6 Bank (BaaS — padrão BACEN Pix v2).
 * Requer credenciais do portal developers.c6bank.com.br + certificado mTLS.
 */
class C6BankGateway extends PaymentGateway
{
    private string $clientId;
    private string $clientSecret;
    private string $pixKey;
    private ?string $certPath;
    private ?string $keyPath;
    private string $baseUrl;
    private bool $sandbox;

    public function __construct(?array $settings = null)
    {
        $cfg = config('payment.c6bank', []);
        $settings = $settings ?? [];

        $this->clientId     = (string) ($settings['client_id'] ?? $cfg['client_id'] ?? '');
        $this->clientSecret = (string) ($settings['client_secret'] ?? $cfg['client_secret'] ?? '');
        $this->pixKey       = (string) ($settings['pix_key'] ?? $cfg['pix_key'] ?? '');
        $this->certPath     = $settings['certificate_path'] ?? $cfg['certificate_path'] ?? null;
        $this->keyPath      = $settings['private_key_path'] ?? $cfg['private_key_path'] ?? null;
        $this->sandbox      = (bool) ($settings['sandbox'] ?? $cfg['sandbox'] ?? true);
        $this->baseUrl      = $this->sandbox
            ? 'https://baas-sandbox.c6bank.com.br'
            : 'https://baas.c6bank.com.br';
    }

    public function createCharge(array $data): array
    {
        return $this->generatePix($data);
    }

    /**
     * Cria cobrança PIX imediata (PUT /pix/v2/cob/{txid}).
     */
    public function generatePix(array $data): array
    {
        $invoice = Invoice::findOrFail($data['invoice_id']);
        $client  = $invoice->client;

        if (!$this->clientId || !$this->clientSecret || !$this->pixKey) {
            return ['success' => false, 'message' => 'C6 Bank: credenciais incompletas (Client ID, Secret e Chave PIX).'];
        }

        $txid = $this->generateTxid();
        $doc  = preg_replace('/\D/', '', $client->cpf ?? $client->cnpj ?? '');
        $name = trim(($client->firstname ?? $client->name ?? '') . ' ' . ($client->lastname ?? ''));

        $expiration = (int) ($data['expiration'] ?? config('payment.c6bank.pix_expiration_seconds', 3600));

        $devedor = ['nome' => mb_substr($name ?: 'Cliente', 0, 200)];
        if (strlen($doc) === 11) {
            $devedor['cpf'] = $doc;
        } elseif (strlen($doc) === 14) {
            $devedor['cnpj'] = $doc;
        }

        $payload = [
            'calendario' => ['expiracao' => max(300, min(86400, $expiration))],
            'devedor'    => $devedor,
            'valor'      => [
                'original'             => number_format((float) $invoice->total, 2, '.', ''),
                'modalidadeAlteracao'  => 0,
            ],
            'chave'                => $this->pixKey,
            'solicitacaoPagador'   => 'Fatura #' . ($invoice->invoice_number ?? $invoice->id),
        ];

        try {
            $token = $this->getAccessToken();
            if (!$token) {
                return ['success' => false, 'message' => 'C6 Bank: falha ao obter token OAuth2.'];
            }

            $response = $this->http()
                ->withToken($token)
                ->put("{$this->baseUrl}/pix/v2/cob/{$txid}", $payload);

            if (!$response->successful()) {
                Log::error('C6 Bank PIX: erro ao criar cob', [
                    'status' => $response->status(),
                    'body'   => $response->body(),
                ]);
                return ['success' => false, 'message' => 'C6 Bank: ' . ($response->json('detail') ?? $response->json('message') ?? 'Erro ao gerar PIX')];
            }

            $cob = $response->json();
            $qrData = $this->fetchQrCode($token, $cob);

            $this->saveTransaction($invoice, $txid, $cob, 'pix');

            return [
                'success'        => true,
                'charge_id'      => $txid,
                'status'         => strtolower($cob['status'] ?? 'pending'),
                'pix_copy_paste' => $qrData['emv'] ?? ($cob['pixCopiaECola'] ?? null),
                'pix_qrcode'     => $qrData['qrcode'] ?? null,
                'expires_at'     => isset($cob['calendario']['expiracao'])
                    ? now()->addSeconds((int) $cob['calendario']['expiracao'])->toIso8601String()
                    : null,
                'data'           => $cob,
            ];
        } catch (\Throwable $e) {
            Log::error('C6 Bank PIX: exceção', ['message' => $e->getMessage(), 'invoice_id' => $invoice->id]);
            return ['success' => false, 'message' => 'Erro ao processar PIX C6 Bank.'];
        }
    }

    public function generateBoleto(array $data): array
    {
        return ['success' => false, 'message' => 'Este módulo C6 Bank suporta apenas PIX.'];
    }

    public function getCharge(string $chargeId): array
    {
        try {
            $token = $this->getAccessToken();
            if (!$token) {
                return ['success' => false, 'message' => 'Token indisponível'];
            }

            $response = $this->http()
                ->withToken($token)
                ->get("{$this->baseUrl}/pix/v2/cob/{$chargeId}");

            if ($response->successful()) {
                return ['success' => true, 'data' => $response->json()];
            }

            return ['success' => false, 'message' => 'Cobrança não encontrada'];
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * Webhook PIX (padrão BACEN — pix recebido / cob atualizada).
     */
    public function processWebhook(array $payload): void
    {
        Log::info('C6 Bank: webhook recebido', $payload);

        $txid   = $payload['txid'] ?? ($payload['pix'][0]['txid'] ?? null);
        $status = strtoupper($payload['status'] ?? ($payload['pix'][0]['status'] ?? ''));

        if (!$txid) {
            // Formato alternativo: evento de pagamento recebido
            $txid = $payload['endToEndId'] ?? null;
        }

        if (!$txid) {
            Log::warning('C6 Bank: webhook sem txid');
            return;
        }

        $transaction = PaymentTransaction::where('gateway', 'c6bank')
            ->where('transaction_id', $txid)
            ->first();

        if (!$transaction) {
            Log::warning('C6 Bank: transação não encontrada', ['txid' => $txid]);
            return;
        }

        $paid = in_array($status, ['CONCLUIDA', 'PAID', 'COMPLETED'], true)
            || !empty($payload['pix']);

        if ($paid && !$transaction->isPaid()) {
            $transaction->markAsPaid();
            $invoice = $transaction->invoice;
            if ($invoice && $invoice->status !== 'paid') {
                $invoice->update(['status' => 'paid', 'date_paid' => now()]);
            }
            Log::info('C6 Bank: pagamento confirmado', ['txid' => $txid]);
        }
    }

    /** OAuth2 client_credentials com mTLS. */
    private function getAccessToken(): ?string
    {
        $cacheKey = 'c6bank_token_' . md5($this->clientId . $this->baseUrl);

        return Cache::remember($cacheKey, 3000, function () {
            $response = $this->http(asForm: true)
                ->post("{$this->baseUrl}/auth/oauth2/v1/token", [
                    'grant_type'    => 'client_credentials',
                    'client_id'     => $this->clientId,
                    'client_secret' => $this->clientSecret,
                ]);

            if (!$response->successful()) {
                Log::error('C6 Bank OAuth2 falhou', ['status' => $response->status(), 'body' => $response->body()]);
                return null;
            }

            return $response->json('access_token');
        });
    }

    /** Busca QR Code a partir do location retornado na cob. */
    private function fetchQrCode(string $token, array $cob): array
    {
        $locId = $cob['loc']['id'] ?? null;
        if (!$locId) {
            return [
                'emv'    => $cob['pixCopiaECola'] ?? null,
                'qrcode' => null,
            ];
        }

        try {
            $response = $this->http()
                ->withToken($token)
                ->get("{$this->baseUrl}/pix/v2/loc/{$locId}/qrcode");

            if ($response->successful()) {
                $json = $response->json();
                return [
                    'emv'    => $json['qrcode'] ?? ($json['emv'] ?? null),
                    'qrcode' => $json['imagemQrcode'] ?? null,
                ];
            }
        } catch (\Throwable $e) {
            Log::warning('C6 Bank: falha ao buscar QR', ['message' => $e->getMessage()]);
        }

        return ['emv' => $cob['pixCopiaECola'] ?? null, 'qrcode' => null];
    }

    private function http(bool $asForm = false)
    {
        $options = ['timeout' => 60, 'connect_timeout' => 15];

        if ($this->certPath && $this->keyPath && is_file($this->certPath) && is_file($this->keyPath)) {
            $options['cert']    = $this->certPath;
            $options['ssl_key'] = $this->keyPath;
        }

        $pending = Http::withOptions($options);

        return $asForm
            ? $pending->asForm()->acceptJson()
            : $pending->acceptJson()->contentType('application/json');
    }

    private function generateTxid(): string
    {
        return strtolower(Str::random(32));
    }

    private function saveTransaction(Invoice $invoice, string $txid, array $data, string $method): void
    {
        PaymentTransaction::create([
            'company_id'     => $invoice->company_id,
            'invoice_id'     => $invoice->id,
            'gateway'        => 'c6bank',
            'transaction_id' => $txid,
            'amount'         => (float) $invoice->total,
            'status'         => 'pending',
            'payment_method' => $method,
            'data'           => $data,
        ]);
    }
}
