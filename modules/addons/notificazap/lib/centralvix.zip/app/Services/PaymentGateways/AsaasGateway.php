<?php

namespace App\Services\PaymentGateways;

use App\Models\Invoice;
use App\Models\PaymentTransaction;
use App\Events\InvoicePaid;
use App\Services\InvoiceFulfillmentService;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class AsaasGateway extends PaymentGateway
{
    private string $apiKey;
    private string $baseUrl;
    private bool $sandbox;

    public function __construct()
    {
        $this->apiKey = config('payment.asaas.api_key');
        $this->sandbox = config('payment.asaas.sandbox', true);
        $this->baseUrl = $this->sandbox 
            ? 'https://sandbox.asaas.com/api/v3'
            : 'https://www.asaas.com/api/v3';
    }

    /**
     * Criar cobrança (PIX, Boleto ou Cartão)
     */
    public function createCharge(array $data): array
    {
        $invoice = Invoice::findOrFail($data['invoice_id']);
        $client = $invoice->client;

        // Criar ou obter cliente no ASAAS
        $customerId = $this->getOrCreateCustomer($client);

        // Preparar dados da cobrança
        $payload = [
            'customer' => $customerId,
            'billingType' => $this->getBillingType($data['payment_method']),
            'value' => $invoice->total,
            'dueDate' => $invoice->due_date->format('Y-m-d'),
            'description' => "Fatura #{$invoice->number}",
            'externalReference' => $invoice->id,
            
            // Descontos
            'discount' => [
                'value' => $invoice->discount ?? 0,
                'dueDateLimitDays' => 0,
            ],

            // Multa e Juros
            'fine' => [
                'value' => config('payment.asaas.multa_percentual', 2),
            ],
            'interest' => [
                'value' => config('payment.asaas.juros_percentual', 1),
            ],

            // Callback
            'callback' => [
                'successUrl' => route('payment.success', ['invoice' => $invoice->id]),
                'autoRedirect' => true,
            ],

            // Dados adicionais
            'postalService' => false, // Não enviar boleto pelos Correios
        ];

        // Se for PIX, adicionar configurações
        if ($data['payment_method'] === 'pix') {
            $payload['enablePixPayment'] = true;
        }

        // Se for cartão, adicionar dados do cartão
        if ($data['payment_method'] === 'credit_card' && isset($data['card'])) {
            $payload['creditCard'] = $this->formatCardData($data['card']);
            $payload['creditCardHolderInfo'] = $this->formatHolderInfo($client);
        }

        try {
            $response = Http::withToken($this->apiKey)
                ->post("{$this->baseUrl}/payments", $payload);

            if ($response->successful()) {
                $result = $response->json();
                
                // Salvar transação
                $this->saveTransaction($invoice, $result);

                return [
                    'success' => true,
                    'charge_id' => $result['id'],
                    'status' => $result['status'],
                    'payment_url' => $result['invoiceUrl'] ?? null,
                    'pix_qrcode' => $result['pixQrCodeBase64'] ?? null,
                    'pix_copy_paste' => $result['pixCopyAndPaste'] ?? null,
                    'boleto_url' => $result['bankSlipUrl'] ?? null,
                    'boleto_barcode' => $result['identificationField'] ?? null,
                    'data' => $result,
                ];
            }

            Log::error('ASAAS: Erro ao criar cobrança', [
                'response' => $response->json(),
                'status' => $response->status(),
            ]);

            return [
                'success' => false,
                'message' => $response->json()['errors'][0]['description'] ?? 'Erro ao criar cobrança',
            ];

        } catch (\Exception $e) {
            Log::error('ASAAS: Exceção ao criar cobrança', [
                'message' => $e->getMessage(),
                'invoice_id' => $invoice->id,
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao processar pagamento',
            ];
        }
    }

    /**
     * Consultar cobrança
     */
    public function getCharge(string $chargeId): array
    {
        try {
            $response = Http::withToken($this->apiKey)
                ->get("{$this->baseUrl}/payments/{$chargeId}");

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json(),
                ];
            }

            return [
                'success' => false,
                'message' => 'Cobrança não encontrada',
            ];

        } catch (\Exception $e) {
            Log::error('ASAAS: Erro ao consultar cobrança', [
                'charge_id' => $chargeId,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao consultar cobrança',
            ];
        }
    }

    /**
     * Processar webhook
     */
    public function processWebhook(array $payload): void
    {
        Log::info('ASAAS: Webhook recebido', $payload);

        $event = $payload['event'] ?? null;
        $payment = $payload['payment'] ?? null;

        if (!$event || !$payment) {
            Log::warning('ASAAS: Webhook inválido');
            return;
        }

        // Buscar fatura pela referência externa
        $invoice = Invoice::find($payment['externalReference']);

        if (!$invoice) {
            Log::warning('ASAAS: Fatura não encontrada', ['reference' => $payment['externalReference']]);
            return;
        }

        switch ($event) {
            case 'PAYMENT_RECEIVED':
            case 'PAYMENT_CONFIRMED':
                $this->handlePaymentReceived($invoice, $payment);
                break;

            case 'PAYMENT_OVERDUE':
                $this->handlePaymentOverdue($invoice, $payment);
                break;

            case 'PAYMENT_DELETED':
            case 'PAYMENT_REFUNDED':
                $this->handlePaymentRefunded($invoice, $payment);
                break;

            default:
                Log::info('ASAAS: Evento não tratado', ['event' => $event]);
        }
    }

    /**
     * Gerar PIX
     */
    public function generatePix(array $data): array
    {
        $data['payment_method'] = 'pix';
        return $this->createCharge($data);
    }

    /**
     * Gerar Boleto
     */
    public function generateBoleto(array $data): array
    {
        $data['payment_method'] = 'boleto';
        return $this->createCharge($data);
    }

    /**
     * Criar ou obter cliente no ASAAS
     */
    private function getOrCreateCustomer($client): string
    {
        // Verificar se já tem customer_id salvo
        if ($client->asaas_customer_id) {
            return $client->asaas_customer_id;
        }

        // Criar novo cliente
        $payload = [
            'name' => $client->name,
            'email' => $client->email,
            'phone' => preg_replace('/[^0-9]/', '', $client->phone ?? ''),
            'mobilePhone' => preg_replace('/[^0-9]/', '', $client->whatsapp ?? $client->phone ?? ''),
            'cpfCnpj' => preg_replace('/[^0-9]/', '', $client->cpf ?? $client->cnpj ?? ''),
            'postalCode' => preg_replace('/[^0-9]/', '', $client->zipcode ?? ''),
            'address' => $client->address,
            'addressNumber' => $client->number,
            'complement' => $client->complement,
            'province' => $client->district,
            'externalReference' => $client->id,
        ];

        try {
            $response = Http::withToken($this->apiKey)
                ->post("{$this->baseUrl}/customers", $payload);

            if ($response->successful()) {
                $result = $response->json();
                
                // Salvar customer_id
                $client->update(['asaas_customer_id' => $result['id']]);

                return $result['id'];
            }

            throw new \Exception('Erro ao criar cliente no ASAAS');

        } catch (\Exception $e) {
            Log::error('ASAAS: Erro ao criar cliente', [
                'client_id' => $client->id,
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }

    /**
     * Determinar tipo de cobrança
     */
    private function getBillingType(string $method): string
    {
        return match($method) {
            'pix' => 'PIX',
            'boleto' => 'BOLETO',
            'credit_card' => 'CREDIT_CARD',
            'debit_card' => 'DEBIT_CARD',
            default => 'UNDEFINED',
        };
    }

    /**
     * Formatar dados do cartão
     */
    private function formatCardData(array $card): array
    {
        return [
            'holderName' => $card['holder_name'],
            'number' => preg_replace('/\s+/', '', $card['number']),
            'expiryMonth' => $card['expiry_month'],
            'expiryYear' => $card['expiry_year'],
            'ccv' => $card['cvv'],
        ];
    }

    /**
     * Formatar dados do portador
     */
    private function formatHolderInfo($client): array
    {
        return [
            'name' => $client->name,
            'email' => $client->email,
            'cpfCnpj' => preg_replace('/[^0-9]/', '', $client->cpf ?? $client->cnpj ?? ''),
            'postalCode' => preg_replace('/[^0-9]/', '', $client->zipcode ?? ''),
            'addressNumber' => $client->number,
            'phone' => preg_replace('/[^0-9]/', '', $client->phone ?? ''),
        ];
    }

    /**
     * Salvar transação
     */
    private function saveTransaction(Invoice $invoice, array $data): void
    {
        PaymentTransaction::create([
            'company_id' => $invoice->company_id,
            'invoice_id' => $invoice->id,
            'gateway' => 'asaas',
            'transaction_id' => $data['id'],
            'amount' => $data['value'],
            'status' => $this->mapStatus($data['status']),
            'payment_method' => strtolower($data['billingType']),
            'data' => $data,
        ]);
    }

    /**
     * Mapear status do ASAAS para status interno
     */
    private function mapStatus(string $asaasStatus): string
    {
        return match($asaasStatus) {
            'PENDING' => 'pending',
            'RECEIVED', 'CONFIRMED' => 'paid',
            'OVERDUE' => 'overdue',
            'REFUNDED' => 'refunded',
            'DELETED' => 'cancelled',
            default => 'pending',
        };
    }

    /**
     * Handler: Pagamento recebido
     */
    private function handlePaymentReceived(Invoice $invoice, array $payment): void
    {
        if ($invoice->status === 'paid') {
            return;
        }

        $invoice->markAsPaid('asaas', $payment['id'] ?? null);

        Log::info('ASAAS: Fatura marcada como paga', [
            'invoice_id' => $invoice->id,
            'payment_id' => $payment['id'] ?? null,
        ]);

        app(InvoiceFulfillmentService::class)->fulfill($invoice->fresh(['items.service.product']));

        InvoicePaid::dispatch($invoice->fresh());
    }

    /**
     * Handler: Pagamento vencido
     */
    private function handlePaymentOverdue(Invoice $invoice, array $payment): void
    {
        if ($invoice->status !== 'overdue') {
            $invoice->update(['status' => 'overdue']);

            Log::info('ASAAS: Fatura marcada como vencida', [
                'invoice_id' => $invoice->id,
            ]);
        }
    }

    /**
     * Handler: Pagamento estornado
     */
    private function handlePaymentRefunded(Invoice $invoice, array $payment): void
    {
        $invoice->update([
            'status' => 'refunded',
            'notes' => ($invoice->notes ?? '') . "\nPagamento estornado em " . now()->format('d/m/Y H:i'),
        ]);

        Log::info('ASAAS: Fatura estornada', [
            'invoice_id' => $invoice->id,
            'payment_id' => $payment['id'],
        ]);
    }
}
