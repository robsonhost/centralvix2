<?php

namespace App\Services\PaymentGateways;

use App\Models\Invoice;
use App\Models\Transaction;
use App\Services\PaymentService;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PagHiperGateway extends PaymentGateway
{
    private string $apiKey;
    private string $token;
    private string $baseUrl;
    private ?string $partnerId;

    public function __construct(?array $settings = null)
    {
        $cfg = config('payment.paghiper', []);
        $settings = $settings ?? [];

        $this->apiKey  = trim((string) ($settings['api_key'] ?? $settings['apiKey'] ?? $cfg['api_key'] ?? ''));
        $this->token   = trim((string) ($settings['token'] ?? $settings['api_token'] ?? $cfg['token'] ?? ''));
        $this->partnerId = $this->resolvePartnerId($settings, $cfg);
        $this->baseUrl = 'https://api.paghiper.com/transaction';
    }

    /**
     * partners_id é OPCIONAL — só enviar com código oficial PagHiper.
     * PagHiper aceita apenas códigos de parceria com ≥ 8 chars alfanuméricos sem espaços.
     * Qualquer valor inválido/placeholder deve ser descartado silenciosamente.
     */
    private function resolvePartnerId(array $settings, array $cfg): ?string
    {
        $raw = trim((string) (
            $settings['partner_id']
            ?? $settings['partners_id']
            ?? $cfg['partner_id']
            ?? ''
        ));

        if ($raw === '') {
            return null;
        }

        // Descarta valores obviamente inválidos / placeholder
        $lower   = strtolower($raw);
        $invalid = ['null', 'none', 'undefined', '0', 'false', 'n/a', '-', 'partner', 'parceria', 'id'];
        if (in_array($lower, $invalid, true)) {
            return null;
        }

        // Exige mínimo 8 chars, apenas letras/números (sem espaços/especiais)
        if (strlen($raw) < 8 || !preg_match('/^[A-Za-z0-9_-]+$/', $raw)) {
            return null;
        }

        return $raw;
    }

    private function appendPartnersId(array $payload): array
    {
        if ($this->partnerId) {
            $payload['partners_id'] = $this->partnerId;
        }

        return $payload;
    }

    /**
     * Criar cobrança (PIX ou Boleto)
     */
    public function createCharge(array $data): array
    {
        $method = $data['payment_method'] ?? 'boleto';

        if ($method === 'pix') {
            return $this->generatePix($data);
        }

        return $this->generateBoleto($data);
    }

    private function daysUntilDue(Invoice $invoice): int
    {
        $due = $invoice->date_due ?? $invoice->due_date ?? null;

        if (!$due) {
            return 3;
        }

        $days = (int) now()->startOfDay()->diffInDays($due->startOfDay(), false);

        return max(1, $days);
    }

    /**
     * Gerar PIX
     */
    public function generatePix(array $data): array
    {
        $invoice = Invoice::findOrFail($data['invoice_id']);
        $client  = $invoice->client;

        $basePayload = [
            'apiKey'         => $this->apiKey,
            'token'          => $this->token,
            'order_id'       => (string) ($invoice->invoice_number ?? $invoice->id),
            'payer_email'    => $client->email,
            'payer_name'     => trim(($client->firstname ?? $client->name ?? '') . ' ' . ($client->lastname ?? '')),
            'payer_cpf_cnpj' => preg_replace('/\D/', '', $client->cpf ?? $client->cnpj ?? ''),
            'payer_phone'    => preg_replace('/\D/', '', $client->phone ?? $client->mobile ?? ''),
            'days_due_date'  => $this->daysUntilDue($invoice),
            'items' => [[
                'item_id'     => (string) $invoice->id,
                'description' => 'Fatura #' . ($invoice->invoice_number ?? $invoice->id),
                'quantity'    => 1,
                'price_cents' => (int) round((float) $invoice->total * 100),
            ]],
            'notification_url' => route('api.webhook.paghiper'),
        ];

        // Tentativa 1: com partners_id (se configurado)
        // Tentativa 2: sem partners_id (auto-retry se erro de parceria)
        $attempts = $this->partnerId
            ? [$this->appendPartnersId($basePayload), $basePayload]
            : [$basePayload];

        try {
            foreach ($attempts as $idx => $payload) {
                $response = Http::timeout(60)->post('https://pix.paghiper.com/invoice/create/', $payload);

                if (!$response->successful()) {
                    continue;
                }

                $rawBody = $response->json() ?? [];
                $parsed  = $this->parsePixResponse($rawBody);

                if ($parsed['success']) {
                    $pixData = $parsed['data'];

                    // Log WARNING com os campos reais da resposta PagHiper para diagnóstico
                    Log::warning('PagHiper PIX resposta recebida', [
                        'invoice_id'      => $invoice->id,
                        'keys_top'        => array_keys($rawBody),
                        'keys_nested'     => array_keys($pixData),
                        'has_emv'         => isset($pixData['emv']),
                        'has_qrcode_url'  => isset($pixData['qrcode_image_url']),
                        'has_qrcode_b64'  => isset($pixData['qrcode_base64']),
                        'transaction_id'  => $pixData['transaction_id'] ?? null,
                        'pix_url'         => $pixData['pix_url'] ?? null,
                        // Primeiros 60 chars do emv (se existir) para confirmar
                        'emv_preview'     => is_string($pixData['emv'] ?? null)
                            ? substr($pixData['emv'], 0, 60)
                            : (isset($pixData['emv']) ? '(não é string: ' . gettype($pixData['emv']) . ')' : 'ausente'),
                    ]);

                    // Busca recursiva: suporta qualquer estrutura de resposta PagHiper
                    $emvCode = $this->findPixField($pixData, ['emv', 'pix_copia_cola', 'emv_qrcode', 'pix_emv']);
                    $qrImage = $this->findPixField($pixData, ['qrcode_base64', 'qrcode_image_url', 'qrcode_url', 'qr_code_url']);

                    // Se ainda não encontrou, tenta na resposta completa
                    if (!$emvCode) {
                        $emvCode = $this->findPixField($rawBody, ['emv', 'pix_copia_cola', 'emv_qrcode', 'pix_emv']);
                    }
                    if (!$qrImage) {
                        $qrImage = $this->findPixField($rawBody, ['qrcode_base64', 'qrcode_image_url', 'qrcode_url']);
                    }

                    // Log de diagnóstico (WARNING aparece em produção)
                    if (!$emvCode && !$qrImage) {
                        Log::warning('PagHiper PIX: emv e qrcode ausentes — resposta bruta', [
                            'raw_body'   => $rawBody,
                            'invoice_id' => $invoice->id,
                        ]);
                    }

                    return [
                        'success'        => true,
                        'charge_id'      => $pixData['transaction_id'] ?? null,
                        'status'         => 'pending',
                        'pix_qrcode'     => $qrImage,
                        'pix_copy_paste' => $emvCode,
                        'pix_url'        => $pixData['pix_url'] ?? null,
                        'expires_at'     => $pixData['due_date'] ?? null,
                        'data'           => $pixData,
                    ];
                }

                // Se erro de parceria e ainda tem tentativa sem partners_id, continua
                if ($idx === 0 && $this->isPartnerIdError($parsed['message'])) {
                    Log::warning('PagHiper PIX: erro de partners_id, retentando sem ele');
                    continue;
                }

                Log::error('PagHiper: Erro ao gerar PIX', ['result' => $parsed['raw'] ?? []]);
                return ['success' => false, 'message' => $parsed['message']];
            }

            return ['success' => false, 'message' => 'Erro ao comunicar com PagHiper'];

        } catch (\Exception $e) {
            Log::error('PagHiper: Exceção ao gerar PIX', [
                'message'    => $e->getMessage(),
                'invoice_id' => $invoice->id,
            ]);
            return ['success' => false, 'message' => 'Erro ao processar pagamento'];
        }
    }

    /**
     * Gerar Boleto
     *
     * Estratégia de tentativas:
     *  1) Com partners_id + type_bank_slip=boletoavulso
     *  2) Sem partners_id  + type_bank_slip=boletoavulso  (retry se erro de parceria)
     *  3) Sem partners_id  + type_bank_slip=bolepix       (retry se boletoavulso inválido)
     *  4) Sem partners_id  + sem type_bank_slip           (fallback absoluto)
     */
    public function generateBoleto(array $data): array
    {
        $invoice = Invoice::findOrFail($data['invoice_id']);
        $client  = $invoice->client;

        $base = [
            'apiKey'           => $this->apiKey,
            'token'            => $this->token,
            'order_id'         => (string) ($invoice->invoice_number ?? $invoice->id),
            'payer_email'      => $client->email,
            'payer_name'       => trim(($client->firstname ?? $client->name ?? '') . ' ' . ($client->lastname ?? '')),
            'payer_cpf_cnpj'   => preg_replace('/\D/', '', $client->cpf ?? $client->cnpj ?? ''),
            'payer_phone'      => preg_replace('/\D/', '', $client->phone ?? $client->mobile ?? ''),
            'payer_street'     => $client->address ?? '',
            'payer_number'     => $client->address_number ?? $client->number ?? 'S/N',
            'payer_complement' => $client->complement ?? '',
            'payer_district'   => $client->district ?? '',
            'payer_city'       => $client->city ?? '',
            'payer_state'      => $client->state ?? '',
            'payer_zip_code'   => preg_replace('/\D/', '', $client->zipcode ?? ''),
            'days_due_date'    => $this->daysUntilDue($invoice),
            'items' => [[
                'item_id'     => (string) $invoice->id,
                'description' => 'Fatura #' . ($invoice->invoice_number ?? $invoice->id),
                'quantity'    => 1,
                'price_cents' => (int) round((float) $invoice->total * 100),
            ]],
            'discount_cents'                => (int) round((float) ($invoice->discount ?? 0) * 100),
            'early_payment_discounts_cents' => (int) config('payment.paghiper.desconto_antecipacao', 0),
            'late_payment_fine'             => config('payment.paghiper.multa_percentual', 2),
            'per_day_interest'              => true,
            'notification_url'              => route('api.webhook.paghiper'),
        ];

        // Sequência de tentativas: tipo_boleto × partners_id
        $attempts = [];

        // Tenta com partners_id se configurado
        if ($this->partnerId) {
            $attempts[] = array_merge($base, ['type_bank_slip' => 'boletoavulso'], ['partners_id' => $this->partnerId]);
            $attempts[] = array_merge($base, ['type_bank_slip' => 'boletoavulso']); // sem partners_id
        } else {
            $attempts[] = array_merge($base, ['type_bank_slip' => 'boletoavulso']);
        }

        // Fallbacks de tipo
        $attempts[] = array_merge($base, ['type_bank_slip' => 'bolepix']);
        $attempts[] = $base; // sem type_bank_slip (deixa PagHiper decidir)

        try {
            $lastMessage = 'Erro ao comunicar com PagHiper';

            foreach ($attempts as $idx => $payload) {
                $response = Http::timeout(60)->post("{$this->baseUrl}/create", $payload);

                if (!$response->successful()) {
                    continue;
                }

                $parsed = $this->parseBoletoResponse($response->json() ?? []);

                if ($parsed['success']) {
                    $bd = $parsed['data'];
                    return [
                        'success'               => true,
                        'charge_id'             => $bd['transaction_id'] ?? null,
                        'status'                => 'pending',
                        'boleto_url'            => $bd['bank_slip']['url_slip_pdf'] ?? $bd['bank_slip']['url_slip'] ?? null,
                        'boleto_digitable_line' => $bd['bank_slip']['digitable_line'] ?? null,
                        'boleto_barcode'        => $bd['bank_slip']['bar_code_number_to_image'] ?? null,
                        'pix_qrcode'            => $bd['pix_code']['qrcode_base64'] ?? null,
                        'pix_copy_paste'        => $bd['pix_code']['emv'] ?? null,
                        'due_date'              => $bd['due_date'] ?? null,
                        'data'                  => $bd,
                    ];
                }

                $lastMessage = $parsed['message'];
                $isPartnerErr = $this->isPartnerIdError($lastMessage);
                $isTypeErr    = $this->isBoletoTypeError($lastMessage);

                Log::warning('PagHiper boleto tentativa ' . ($idx + 1) . ' falhou', [
                    'message' => $lastMessage,
                    'type'    => $payload['type_bank_slip'] ?? 'não enviado',
                    'partner' => isset($payload['partners_id']) ? 'sim' : 'não',
                ]);

                // Se não é erro de parceria nem de tipo, não adianta tentar mais
                if (!$isPartnerErr && !$isTypeErr) {
                    break;
                }
            }

            $allTypeErrors = $this->isBoletoTypeError($lastMessage);

            Log::error('PagHiper: Todas as tentativas de boleto falharam', [
                'invoice_id'     => $invoice->id,
                'last_error'     => $lastMessage,
                'all_type_errors'=> $allTypeErrors,
            ]);

            // Mensagem específica quando a conta PagHiper não suporta boleto
            if ($allTypeErrors) {
                return [
                    'success' => false,
                    'message' => 'Boleto não está disponível na sua conta PagHiper. '
                        . 'Acesse o painel PagHiper e verifique se o boleto está habilitado, '
                        . 'ou desative o boleto nas configurações do gateway (Admin → Gateways → PagHiper → "Desativar Boleto").',
                ];
            }

            return ['success' => false, 'message' => $lastMessage];

        } catch (\Exception $e) {
            Log::error('PagHiper: Exceção ao gerar boleto', [
                'message'    => $e->getMessage(),
                'invoice_id' => $invoice->id,
            ]);
            return ['success' => false, 'message' => 'Erro ao processar pagamento'];
        }
    }

    /**
     * Consultar cobrança
     */
    public function getCharge(string $chargeId): array
    {
        try {
            $payload = [
                'token' => $this->token,
                'apiKey' => $this->apiKey,
                'transaction_id' => $chargeId,
            ];

            $response = Http::post("{$this->baseUrl}/status", $payload);

            if ($response->successful()) {
                $body = $response->json() ?? [];
                $statusRequest = $body['status_request'] ?? $body;
                $result = strtolower((string) ($body['result'] ?? $statusRequest['result'] ?? ''));

                if ($result === 'success') {
                    return [
                        'success' => true,
                        'data' => $statusRequest,
                    ];
                }
            }

            return [
                'success' => false,
                'message' => 'Cobrança não encontrada',
            ];

        } catch (\Exception $e) {
            Log::error('PagHiper: Erro ao consultar cobrança', [
                'charge_id' => $chargeId,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao consultar cobrança',
            ];
        }
    }

    /**
     * Processar webhook PagHiper.
     *
     * Fluxo oficial: POST inicial com notification_id → consulta API de notificação → confirma pagamento.
     */
    public function processWebhook(array $payload, ?PaymentService $paymentService = null): void
    {
        Log::info('PagHiper: Webhook recebido', $payload);

        $paymentService ??= app(PaymentService::class);

        $transactionId  = $payload['transaction_id'] ?? null;
        $notificationId = $payload['notification_id'] ?? null;
        $statusData     = [];
        $status         = '';

        if ($notificationId && $transactionId) {
            $statusData = $this->fetchNotificationStatus($payload);
            if (empty($statusData)) {
                Log::warning('PagHiper: Falha ao consultar notificação', $payload);

                return;
            }
            $status = strtolower((string) ($statusData['status'] ?? ''));
        } else {
            $receivedToken = $payload['token'] ?? null;
            if ($receivedToken && $this->token && $receivedToken !== $this->token) {
                Log::warning('PagHiper: Token inválido no webhook');

                return;
            }

            $statusData = $payload['status_request'] ?? $payload;
            $status     = strtolower((string) ($payload['status'] ?? $statusData['status'] ?? ''));
        }

        if (!$transactionId) {
            $transactionId = $statusData['transaction_id'] ?? null;
        }

        if (!$transactionId) {
            Log::warning('PagHiper: Webhook sem transaction_id');

            return;
        }

        $transaction = Transaction::where('gateway_transaction_id', $transactionId)
            ->where('gateway', 'paghiper')
            ->latest()
            ->first();

        if (!$transaction) {
            Log::warning('PagHiper: Transação não encontrada', ['transaction_id' => $transactionId]);

            return;
        }

        switch ($status) {
            case 'paid':
            case 'completed':
            case 'confirmed':
                $paymentService->confirmPayment($transaction, array_merge($statusData, $payload));
                Log::info('PagHiper: Pagamento confirmado', [
                    'transaction_id' => $transactionId,
                    'invoice_id'     => $transaction->invoice_id,
                ]);
                break;

            case 'cancelled':
            case 'canceled':
                $transaction->update(['status' => 'cancelled']);
                break;

            case 'refunded':
                $transaction->update(['status' => 'refunded']);
                break;

            default:
                Log::info('PagHiper: Status não tratado ou ainda pendente', ['status' => $status]);
        }
    }

    /**
     * Consulta o status real da notificação na API PagHiper.
     */
    private function fetchNotificationStatus(array $payload): array
    {
        $sourceApi = rtrim((string) ($payload['source_api'] ?? 'https://pix.paghiper.com'), '/');
        $notificationUrl = str_contains($sourceApi, 'pix.paghiper.com')
            ? 'https://pix.paghiper.com/invoice/notification/'
            : 'https://api.paghiper.com/transaction/notification/';

        $requestPayload = [
            'token'           => $this->token,
            'apiKey'          => $payload['apiKey'] ?? $payload['api_key'] ?? $this->apiKey,
            'transaction_id'  => $payload['transaction_id'],
            'notification_id' => $payload['notification_id'],
        ];

        try {
            $response = Http::timeout(30)
                ->withHeaders(['Accept' => 'application/json'])
                ->post($notificationUrl, $requestPayload);

            if (!$response->successful()) {
                Log::warning('PagHiper: HTTP erro na notificação', [
                    'status' => $response->status(),
                    'body'   => $response->body(),
                ]);

                return [];
            }

            $body          = $response->json() ?? [];
            $statusRequest = $body['status_request'] ?? [];
            $result        = strtolower((string) ($body['result'] ?? $statusRequest['result'] ?? ''));

            if ($result !== 'success') {
                Log::warning('PagHiper: Notificação rejeitada', ['response' => $body]);

                return [];
            }

            return $statusRequest;
        } catch (\Exception $e) {
            Log::error('PagHiper: Erro ao consultar notificação', ['error' => $e->getMessage()]);

            return [];
        }
    }

    /**
     * Normaliza resposta PIX PagHiper (suporta múltiplas estruturas de resposta).
     *
     * Estruturas conhecidas:
     *   A) { "pix_create_request": { "result": "success", "emv": "...", ... } }
     *   B) { "result": "success", "pix_create_request": { "emv": "...", ... } }
     *   C) { "result": "success", "emv": "...", ... }   (flat)
     */
    private function parsePixResponse(array $body): array
    {
        $nested = is_array($body['pix_create_request'] ?? null) ? $body['pix_create_request'] : [];

        // Determina o status: tenta top-level, depois nested, depois dentro de outros subkeys
        $status = strtolower((string) ($body['result'] ?? $nested['result'] ?? ''));

        // Se não encontrou status ainda, percorre subchaves
        if ($status === '') {
            foreach ($body as $val) {
                if (is_array($val) && isset($val['result'])) {
                    $status = strtolower((string) $val['result']);
                    if ($status !== '') {
                        // Usa este subarray como dados
                        $nested = $val;
                        break;
                    }
                }
            }
        }

        if ($status === 'success') {
            // Prioriza nested (pix_create_request), senão usa o body inteiro
            $data = !empty($nested) ? $nested : $body;

            return [
                'success' => true,
                'data'    => $data,
                'raw'     => $body,
                'message' => '',
            ];
        }

        $message = (string) (
            $nested['response_message']
            ?? $body['response_message']
            ?? 'Erro ao gerar PIX via PagHiper'
        );

        $message = $this->humanizePagHiperError($message);

        return ['success' => false, 'data' => [], 'raw' => $body, 'message' => $message];
    }

    /**
     * Normaliza resposta Boleto PagHiper.
     */
    private function parseBoletoResponse(array $body): array
    {
        $nested = is_array($body['create_request'] ?? null) ? $body['create_request'] : [];
        $status = strtolower((string) ($body['result'] ?? $nested['result'] ?? ''));

        if ($status === 'success') {
            return [
                'success' => true,
                'data'    => $nested ?: $body,
                'raw'     => $body,
                'message' => '',
            ];
        }

        $message = (string) (
            $nested['response_message']
            ?? $body['response_message']
            ?? 'Erro ao gerar boleto via PagHiper'
        );

        $message = $this->humanizePagHiperError($message);

        return ['success' => false, 'data' => [], 'raw' => $body, 'message' => $message];
    }

    /**
     * Busca recursiva por um campo em qualquer nível de um array.
     * Retorna string não-vazia ou null.
     */
    private function findPixField(array $data, array $keys, int $depth = 0): ?string
    {
        // Busca no nível atual
        foreach ($keys as $key) {
            if (isset($data[$key]) && is_string($data[$key]) && $data[$key] !== '') {
                return $data[$key];
            }
        }

        // Busca um nível abaixo (sem recursão infinita)
        if ($depth < 2) {
            foreach ($data as $value) {
                if (is_array($value)) {
                    $found = $this->findPixField($value, $keys, $depth + 1);
                    if ($found !== null) {
                        return $found;
                    }
                }
            }
        }

        return null;
    }

    /** Verifica se a mensagem de erro é de partners_id inválido */
    private function isPartnerIdError(string $message): bool
    {
        $lower = strtolower($message);
        return str_contains($lower, 'parceria')
            || str_contains($lower, 'partners')
            || str_contains($lower, 'idpaterns')
            || str_contains($lower, 'partner_id')
            || str_contains($lower, 'código de parceria');
    }

    /** Verifica se a mensagem de erro é de tipo de boleto inválido */
    private function isBoletoTypeError(string $message): bool
    {
        $lower = strtolower($message);
        return str_contains($lower, 'type_bank_slip')
            || str_contains($lower, 'type bank')
            || str_contains($lower, 'bolepix')
            || str_contains($lower, 'tipo de cobrança')
            || str_contains($lower, 'boletoavulso');
    }

    private function humanizePagHiperError(string $message): string
    {
        $lower = strtolower($message);

        if (str_contains($lower, 'apikey') || str_contains($lower, 'api key') || str_contains($lower, 'api_key')) {
            return 'PagHiper: API Key inválida. Acesse o painel PagHiper → Minha Conta → Credenciais e copie o valor que começa com apk_.';
        }

        if (str_contains($lower, 'token')) {
            return 'PagHiper: Token inválido. Acesse o painel PagHiper → Minha Conta → Credenciais e copie o Token corretamente.';
        }

        if (str_contains($lower, 'parceria') || str_contains($lower, 'idpaterns') || str_contains($lower, 'partners')) {
            return 'PagHiper: código de parceria inválido. Deixe o campo Partner ID vazio no cadastro do gateway.';
        }

        if (str_contains($lower, 'type_bank_slip') || str_contains($lower, 'type bank')) {
            return 'PagHiper: tipo de cobrança inválido para sua conta. Verifique se seu plano PagHiper suporta BolePIX ou entre em contato com o suporte.';
        }

        if (str_contains($lower, 'cpf') || str_contains($lower, 'cnpj') || str_contains($lower, 'payer_cpf')) {
            return 'PagHiper: CPF/CNPJ do pagador inválido. Verifique os dados cadastrais do cliente.';
        }

        if (str_contains($lower, 'email')) {
            return 'PagHiper: e-mail do pagador inválido. Verifique os dados cadastrais do cliente.';
        }

        return $message;
    }
}
