<?php

namespace App\Services;

use App\Exports\GenericArrayExport;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Response;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

class AdminExportService
{
    public function download(string $format, string $basename, array $headings, iterable $rows, ?string $pdfView = null, array $pdfData = []): StreamedResponse|BinaryFileResponse|Response
    {
        $format = strtolower($format);
        $filename = Str::slug($basename) . '-' . now()->format('Y-m-d_His');

        return match ($format) {
            'csv' => $this->csv("{$filename}.csv", $headings, $rows),
            'excel', 'xlsx' => Excel::download(new GenericArrayExport($headings, $this->normalizeRows($rows)), "{$filename}.xlsx"),
            'pdf' => $this->pdf("{$filename}.pdf", $pdfView ?? 'admin.exports.table', array_merge($pdfData, [
                'title' => $basename,
                'headings' => $headings,
                'rows' => $this->normalizeRows($rows),
                'generatedAt' => now()->format('d/m/Y H:i'),
            ])),
            default => abort(422, 'Formato de exportação inválido.'),
        };
    }

    public function csv(string $filename, array $headings, iterable $rows): StreamedResponse
    {
        return response()->streamDownload(function () use ($headings, $rows) {
            $out = fopen('php://output', 'w');
            fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
            fputcsv($out, $headings, ';');
            foreach ($rows as $row) {
                fputcsv($out, array_values((array) $row), ';');
            }
            fclose($out);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function pdf(string $filename, string $view, array $data): Response
    {
        $pdf = Pdf::loadView($view, $data)->setPaper('a4', 'landscape');

        return $pdf->download($filename);
    }

    private function normalizeRows(iterable $rows): array
    {
        $normalized = [];
        foreach ($rows as $row) {
            $normalized[] = array_values((array) $row);
        }

        return $normalized;
    }
}
