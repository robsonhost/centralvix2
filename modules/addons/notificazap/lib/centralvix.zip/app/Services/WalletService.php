<?php

namespace App\Services;

use App\Models\Client;
use App\Models\Invoice;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\DB;

class WalletService
{
    /**
     * Adiciona saldo à carteira do cliente e registra a transação.
     */
    public function credit(
        Client $client,
        float $amount,
        string $source = 'manual',
        ?string $description = null,
        ?Invoice $reference = null,
        ?int $createdBy = null,
    ): WalletTransaction {
        $amount = round($amount, 2);

        return DB::transaction(function () use ($client, $amount, $source, $description, $reference, $createdBy) {
            $client = Client::whereKey($client->id)->lockForUpdate()->firstOrFail();
            $client->increment('credit_balance', $amount);

            return $this->log($client, 'credit', $amount, $source, $description, $reference, $createdBy);
        });
    }

    /**
     * Debita saldo da carteira. Retorna null se não houver saldo suficiente.
     */
    public function debit(
        Client $client,
        float $amount,
        string $source = 'manual',
        ?string $description = null,
        ?Invoice $reference = null,
        ?int $createdBy = null,
    ): ?WalletTransaction {
        $amount = round($amount, 2);

        return DB::transaction(function () use ($client, $amount, $source, $description, $reference, $createdBy) {
            $client = Client::whereKey($client->id)->lockForUpdate()->firstOrFail();

            if ((float) $client->credit_balance < $amount) {
                return null;
            }

            $client->decrement('credit_balance', $amount);

            return $this->log($client, 'debit', $amount, $source, $description, $reference, $createdBy);
        });
    }

    /**
     * Abate uma fatura usando o saldo da carteira (pagamento integral).
     *
     * @return array{success: bool, message: string}
     */
    public function payInvoice(Invoice $invoice, ?int $createdBy = null): array
    {
        if (in_array($invoice->status, ['paid', 'cancelled', 'refunded'], true)) {
            return ['success' => false, 'message' => 'Esta fatura não está em aberto.'];
        }

        $client = $invoice->client;
        if (!$client) {
            return ['success' => false, 'message' => 'Fatura sem cliente vinculado.'];
        }

        $total = round((float) $invoice->total, 2);
        if ($total <= 0) {
            return ['success' => false, 'message' => 'Valor da fatura inválido.'];
        }

        if ((float) $client->credit_balance < $total) {
            return ['success' => false, 'message' => 'Saldo insuficiente para abater esta fatura.'];
        }

        return DB::transaction(function () use ($invoice, $client, $total, $createdBy) {
            $locked = Client::whereKey($client->id)->lockForUpdate()->firstOrFail();

            if ((float) $locked->credit_balance < $total) {
                return ['success' => false, 'message' => 'Saldo insuficiente para abater esta fatura.'];
            }

            // Recarrega a fatura para evitar pagamento duplo (concorrência).
            $freshInvoice = Invoice::whereKey($invoice->id)->lockForUpdate()->firstOrFail();
            if (in_array($freshInvoice->status, ['paid', 'cancelled', 'refunded'], true)) {
                return ['success' => false, 'message' => 'Esta fatura já foi processada.'];
            }

            $locked->decrement('credit_balance', $total);

            $this->log(
                $locked,
                'debit',
                $total,
                'invoice_payment',
                "Pagamento da fatura {$freshInvoice->invoice_number}",
                $freshInvoice,
                $createdBy,
            );

            $freshInvoice->markAsPaid('wallet', 'WALLET-' . $freshInvoice->id . '-' . now()->timestamp);

            \App\Events\InvoicePaid::dispatch($freshInvoice->fresh());

            return ['success' => true, 'message' => 'Fatura paga com saldo da carteira!'];
        });
    }

    /**
     * Abate parcialmente uma fatura com saldo da carteira.
     */
    public function payInvoicePartial(Invoice $invoice, ?float $amount = null, ?int $createdBy = null): array
    {
        if (in_array($invoice->status, ['paid', 'cancelled', 'refunded'], true)) {
            return ['success' => false, 'message' => 'Esta fatura não está em aberto.'];
        }

        $client = $invoice->client;
        if (!$client) {
            return ['success' => false, 'message' => 'Fatura sem cliente vinculado.'];
        }

        $balanceDue = $invoice->balance_due;
        if ($balanceDue <= 0) {
            return ['success' => false, 'message' => 'Não há saldo em aberto nesta fatura.'];
        }

        $payAmount = $amount === null
            ? min((float) $client->credit_balance, $balanceDue)
            : min(round($amount, 2), $balanceDue, (float) $client->credit_balance);

        if ($payAmount <= 0) {
            return ['success' => false, 'message' => 'Saldo insuficiente para pagamento parcial.'];
        }

        return DB::transaction(function () use ($invoice, $client, $payAmount, $createdBy) {
            $locked = Client::whereKey($client->id)->lockForUpdate()->firstOrFail();

            if ((float) $locked->credit_balance < $payAmount) {
                return ['success' => false, 'message' => 'Saldo insuficiente.'];
            }

            $freshInvoice = Invoice::whereKey($invoice->id)->lockForUpdate()->firstOrFail();
            $locked->decrement('credit_balance', $payAmount);

            $this->log(
                $locked,
                'debit',
                $payAmount,
                'invoice_payment_partial',
                "Pagamento parcial da fatura {$freshInvoice->invoice_number}",
                $freshInvoice,
                $createdBy,
            );

            $freshInvoice->applyPartialPayment($payAmount, 'wallet');

            $message = $freshInvoice->isPaid()
                ? 'Fatura quitada com saldo da carteira!'
                : 'Pagamento parcial aplicado. Saldo restante: R$ ' . number_format($freshInvoice->balance_due, 2, ',', '.');

            if ($freshInvoice->isPaid()) {
                \App\Events\InvoicePaid::dispatch($freshInvoice);
            }

            return ['success' => true, 'message' => $message, 'invoice' => $freshInvoice->fresh()];
        });
    }

    private function log(
        Client $client,
        string $type,
        float $amount,
        string $source,
        ?string $description,
        ?Invoice $reference,
        ?int $createdBy,
    ): WalletTransaction {
        return WalletTransaction::create([
            'company_id'     => $client->company_id,
            'client_id'      => $client->id,
            'type'           => $type,
            'amount'         => $amount,
            'balance_after'  => round((float) $client->fresh()->credit_balance, 2),
            'source'         => $source,
            'description'    => $description,
            'reference_type' => $reference ? Invoice::class : null,
            'reference_id'   => $reference?->id,
            'created_by'     => $createdBy,
        ]);
    }
}
