<?php

namespace App\Services;

use App\Models\Invoice;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Mail;

class InvoiceService
{
    public function generatePdf(Invoice $invoice): Response
    {
        $invoice->load(['client', 'items', 'company']);

        $pdf = Pdf::loadView('pdf.invoice', compact('invoice'));
        $pdf->setPaper('A4');

        return response($pdf->output(), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="fatura-' . $invoice->invoice_number . '.pdf"',
        ]);
    }

    public function sendByEmail(Invoice $invoice): void
    {
        $invoice->load(['client', 'items', 'company']);

        try {
            Mail::to($invoice->client->email)->send(new \App\Mail\InvoiceMail($invoice));
        } catch (\Exception $e) {
            logger()->error('Failed to send invoice email: ' . $e->getMessage());
        }

        // Também dispara template/WhatsApp com auto login (se configurados)
        try {
            app(NotificationService::class)->dispatchInvoiceCreated($invoice);
        } catch (\Exception $e) {
            logger()->error('Failed to dispatch invoice notifications: ' . $e->getMessage());
        }
    }

    public function generateInvoiceNumber(int $companyId): string
    {
        $prefix = \App\Models\Setting::get($companyId, 'billing', 'invoice_prefix', 'INV');
        $year = date('Y');
        $count = Invoice::where('company_id', $companyId)->whereYear('created_at', $year)->count() + 1;
        return $prefix . $year . str_pad($count, 5, '0', STR_PAD_LEFT);
    }

    public function markOverdueInvoices(): int
    {
        $count = Invoice::where('status', 'unpaid')
            ->whereDate('date_due', '<', now())
            ->count();

        Invoice::where('status', 'unpaid')
            ->whereDate('date_due', '<', now())
            ->update(['status' => 'overdue']);

        return $count;
    }
}
