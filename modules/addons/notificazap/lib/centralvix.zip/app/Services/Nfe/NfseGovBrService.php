<?php

namespace App\Services\Nfe;

use App\Models\InvoiceNfe;
use App\Models\NfeSetting;
use App\Models\Invoice;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class NfseGovBrService
{
    protected $baseUrl = 'https://www.nfse.gov.br/EmissorNacional/api/v1';
    protected $certificatePath;
    protected $certificatePassword;
    protected $environment;

    public function __construct()
    {
        $this->loadConfig();
    }

    protected function loadConfig()
    {
        $companyId = auth()->user()->company_id ?? 1;
        $settings = NfeSetting::where('company_id', $companyId)->first();
        
        if ($settings && $settings->provider === 'nfse_govbr') {
            $this->certificatePath = $settings->certificate_path;
            $this->certificatePassword = $settings->certificate_password;
            $this->environment = $settings->environment;
        }
    }

    /**
     * Emitir NFS-e
     */
    public function emitirNfse(Invoice $invoice): array
    {
        try {
            $data = $this->prepareNfseData($invoice);
            
            $response = Http::withOptions([
                'cert' => [$this->certificatePath, $this->certificatePassword],
                'verify' => $this->environment === 'producao',
            ])->post($this->baseUrl . '/nfse/emitir', $data);

            if ($response->successful()) {
                $result = $response->json();
                
                // Salvar NFS-e no banco
                $nfse = $this->saveNfse($invoice, $result);
                
                return [
                    'success' => true,
                    'nfse' => $nfse,
                    'data' => $result,
                ];
            }

            return [
                'success' => false,
                'message' => $response->json()['message'] ?? 'Erro ao emitir NFS-e',
                'errors' => $response->json()['errors'] ?? [],
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao emitir NFS-e Gov.br: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao comunicar com NFS-e Gov.br: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Preparar dados da NFS-e no formato DPS
     */
    protected function prepareNfseData(Invoice $invoice): array
    {
        $client = $invoice->client;
        $company = $invoice->company;
        $settings = NfeSetting::where('company_id', $company->id)->first();

        return [
            'dps' => [
                'versao' => '1.0',
                'InfDPS' => [
                    // Identificação da DPS
                    'tpAmb' => $this->environment === 'producao' ? 1 : 2,
                    'dhEmi' => now()->format('Y-m-d\TH:i:s'),
                    'verAplic' => 'CentralVIX_v2.0',
                    
                    // Prestador
                    'prest' => [
                        'CNPJ' => preg_replace('/\D/', '', $company->document),
                        'IM' => $company->municipal_registration,
                        'xNome' => $company->name,
                        'xFant' => $company->trade_name,
                        'ender' => [
                            'xLgr' => $company->address,
                            'nro' => $company->number,
                            'xCpl' => $company->complement,
                            'xBairro' => $company->district,
                            'cMun' => $company->city_code,
                            'xMun' => $company->city,
                            'UF' => $company->state,
                            'CEP' => preg_replace('/\D/', '', $company->zip_code),
                        ],
                        'fone' => preg_replace('/\D/', '', $company->phone),
                        'email' => $company->email,
                    ],
                    
                    // Tomador
                    'toma' => [
                        'CPF' => strlen(preg_replace('/\D/', '', $client->document)) === 11 
                            ? preg_replace('/\D/', '', $client->document) 
                            : null,
                        'CNPJ' => strlen(preg_replace('/\D/', '', $client->document)) === 14 
                            ? preg_replace('/\D/', '', $client->document) 
                            : null,
                        'xNome' => $client->name,
                        'ender' => [
                            'xLgr' => $client->address,
                            'nro' => $client->number,
                            'xCpl' => $client->complement,
                            'xBairro' => $client->district,
                            'cMun' => $client->city_code,
                            'xMun' => $client->city,
                            'UF' => $client->state,
                            'CEP' => preg_replace('/\D/', '', $client->zip_code),
                        ],
                        'fone' => preg_replace('/\D/', '', $client->phone),
                        'email' => $client->email,
                    ],
                    
                    // Serviço
                    'serv' => [
                        'cServ' => [
                            'cTribMun' => '01.01', // Código do serviço no município
                            'xServ' => $this->getServiceDescription($invoice),
                        ],
                        'cLocIncid' => 1, // Local da incidência
                        'vServ' => number_format($invoice->total, 2, '.', ''),
                        'vDesc' => number_format($invoice->discount, 2, '.', ''),
                        'vBC' => number_format($invoice->total - $invoice->discount, 2, '.', ''),
                        'vLiq' => number_format($invoice->total - $invoice->discount, 2, '.', ''),
                        
                        // Retenções
                        'retFed' => [
                            'vPIS' => '0.00',
                            'vCOFINS' => '0.00',
                            'vIRRF' => '0.00',
                            'vCSLL' => '0.00',
                        ],
                    ],
                    
                    // Valores
                    'valores' => [
                        'vNFS' => number_format($invoice->total, 2, '.', ''),
                        'vDesc' => number_format($invoice->discount, 2, '.', ''),
                        'vLiq' => number_format($invoice->total - $invoice->discount, 2, '.', ''),
                    ],
                    
                    // Informações adicionais
                    'infAdic' => [
                        'xInf' => 'Fatura #' . $invoice->id . ' - Vencimento: ' . $invoice->due_date->format('d/m/Y'),
                    ],
                ],
            ],
        ];
    }

    /**
     * Consultar NFS-e
     */
    public function consultarNfse(string $numeroNfse): array
    {
        try {
            $response = Http::withOptions([
                'cert' => [$this->certificatePath, $this->certificatePassword],
                'verify' => $this->environment === 'producao',
            ])->get($this->baseUrl . '/nfse/consultar/' . $numeroNfse);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json(),
                ];
            }

            return [
                'success' => false,
                'message' => 'NFS-e não encontrada',
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao consultar NFS-e: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao consultar NFS-e: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Cancelar NFS-e
     */
    public function cancelarNfse(InvoiceNfe $nfse, string $motivo): array
    {
        try {
            $data = [
                'numero' => $nfse->nfe_number,
                'motivo' => $motivo,
            ];

            $response = Http::withOptions([
                'cert' => [$this->certificatePath, $this->certificatePassword],
                'verify' => $this->environment === 'producao',
            ])->post($this->baseUrl . '/nfse/cancelar', $data);

            if ($response->successful()) {
                $nfse->update([
                    'status' => 'cancelled',
                    'cancelled_at' => now(),
                    'cancellation_reason' => $motivo,
                ]);

                return [
                    'success' => true,
                    'message' => 'NFS-e cancelada com sucesso',
                ];
            }

            return [
                'success' => false,
                'message' => $response->json()['message'] ?? 'Erro ao cancelar NFS-e',
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao cancelar NFS-e: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao cancelar NFS-e: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Download do PDF da NFS-e
     */
    public function downloadPdf(string $numeroNfse): ?string
    {
        try {
            $response = Http::withOptions([
                'cert' => [$this->certificatePath, $this->certificatePassword],
                'verify' => $this->environment === 'producao',
            ])->get($this->baseUrl . '/nfse/pdf/' . $numeroNfse);

            if ($response->successful()) {
                $filename = "nfse_{$numeroNfse}.pdf";
                $path = "nfse/pdf/{$filename}";
                
                Storage::put($path, $response->body());
                
                return Storage::url($path);
            }

            return null;

        } catch (\Exception $e) {
            Log::error('Erro ao baixar PDF da NFS-e: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Download do XML da NFS-e
     */
    public function downloadXml(string $numeroNfse): ?string
    {
        try {
            $response = Http::withOptions([
                'cert' => [$this->certificatePath, $this->certificatePassword],
                'verify' => $this->environment === 'producao',
            ])->get($this->baseUrl . '/nfse/xml/' . $numeroNfse);

            if ($response->successful()) {
                $filename = "nfse_{$numeroNfse}.xml";
                $path = "nfse/xml/{$filename}";
                
                Storage::put($path, $response->body());
                
                return Storage::url($path);
            }

            return null;

        } catch (\Exception $e) {
            Log::error('Erro ao baixar XML da NFS-e: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Salvar NFS-e no banco de dados
     */
    protected function saveNfse(Invoice $invoice, array $data): InvoiceNfe
    {
        $settings = NfeSetting::where('company_id', $invoice->company_id)->first();

        return InvoiceNfe::create([
            'company_id' => $invoice->company_id,
            'invoice_id' => $invoice->id,
            'client_id' => $invoice->client_id,
            'nfe_number' => $data['numero'] ?? null,
            'nfe_series' => $settings->serie_nfe,
            'nfe_key' => $data['chave'] ?? null,
            'protocol' => $data['protocolo'] ?? null,
            'status' => 'issued',
            'amount' => $invoice->total,
            'pdf_url' => $data['pdf_url'] ?? null,
            'xml_url' => $data['xml_url'] ?? null,
            'nfe_data' => $data,
            'issued_at' => now(),
        ]);
    }

    /**
     * Obter descrição dos serviços da fatura
     */
    protected function getServiceDescription(Invoice $invoice): string
    {
        $items = $invoice->items->pluck('description')->toArray();
        return implode(', ', $items) ?: 'Serviços de hospedagem e tecnologia';
    }

    /**
     * Validar certificado digital
     */
    public function validateCertificate(string $certificatePath, string $password): array
    {
        try {
            $cert = openssl_pkcs12_read(file_get_contents($certificatePath), $certs, $password);
            
            if ($cert) {
                $certInfo = openssl_x509_parse($certs['cert']);
                
                return [
                    'valid' => true,
                    'cn' => $certInfo['subject']['CN'] ?? 'N/A',
                    'valid_from' => date('d/m/Y', $certInfo['validFrom_time_t']),
                    'valid_to' => date('d/m/Y', $certInfo['validTo_time_t']),
                    'issuer' => $certInfo['issuer']['CN'] ?? 'N/A',
                ];
            }

            return [
                'valid' => false,
                'message' => 'Senha incorreta ou certificado inválido',
            ];

        } catch (\Exception $e) {
            return [
                'valid' => false,
                'message' => 'Erro ao validar certificado: ' . $e->getMessage(),
            ];
        }
    }
}
