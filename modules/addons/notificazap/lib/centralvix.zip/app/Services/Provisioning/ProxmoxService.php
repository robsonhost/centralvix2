<?php

namespace App\Services\Provisioning;

use App\Models\Server;
use App\Models\Service;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ProxmoxService
{
    private string $apiUrl;
    private string $apiUser;
    private string $apiToken;
    private ?string $ticket = null;
    private ?string $csrfToken = null;

    public function __construct(Server $server)
    {
        $this->apiUrl = rtrim($server->hostname ?? '', '/') . '/api2/json';
        $this->apiUser = $server->username ?? '';
        $this->apiToken = $server->getSetting('proxmox_token') ?? '';
        
        // Se não tiver token, vai usar autenticação por senha
        if (empty($this->apiToken)) {
            $this->authenticate($server->password ?? '');
        }
    }

    /**
     * Autenticar no Proxmox (se não usar API Token)
     */
    private function authenticate(string $password): void
    {
        try {
            $response = Http::timeout(30)
                ->asForm()
                ->post($this->apiUrl . '/access/ticket', [
                    'username' => $this->apiUser,
                    'password' => $password,
                ]);

            if ($response->successful()) {
                $data = $response->json('data');
                $this->ticket = $data['ticket'] ?? null;
                $this->csrfToken = $data['CSRFPreventionToken'] ?? null;
            }
        } catch (Exception $e) {
            Log::error('Proxmox Authentication Error', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Criar VM no Proxmox
     */
    public function createVM(Service $service, array $params = []): array
    {
        try {
            $node = $params['node'] ?? 'pve';
            $vmid = $params['vmid'] ?? $this->getNextVMID($node);

            $payload = [
                'vmid' => $vmid,
                'name' => $params['hostname'] ?? 'vm-' . $vmid,
                'cores' => $params['cores'] ?? 1,
                'memory' => $params['memory'] ?? 1024,
                'storage' => $params['storage'] ?? 'local-lvm',
                'ostype' => $params['ostype'] ?? 'l26',
                'net0' => 'virtio,bridge=vmbr0',
                'ide2' => $params['iso'] ?? 'local:iso/ubuntu-22.04.iso,media=cdrom',
            ];

            $response = $this->makeRequest('POST', "/nodes/{$node}/qemu", $payload);

            if ($response['success']) {
                return [
                    'success' => true,
                    'vmid' => $vmid,
                    'node' => $node,
                    'data' => $response['data'],
                ];
            }

            throw new Exception($response['message'] ?? 'Erro ao criar VM');

        } catch (Exception $e) {
            Log::error('Proxmox Create VM Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Criar Container LXC no Proxmox
     */
    public function createContainer(Service $service, array $params = []): array
    {
        try {
            $node = $params['node'] ?? 'pve';
            $vmid = $params['vmid'] ?? $this->getNextVMID($node);

            $payload = [
                'vmid' => $vmid,
                'hostname' => $params['hostname'] ?? 'ct-' . $vmid,
                'cores' => $params['cores'] ?? 1,
                'memory' => $params['memory'] ?? 512,
                'rootfs' => 'local-lvm:8',
                'ostemplate' => $params['template'] ?? 'local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst',
                'net0' => 'name=eth0,bridge=vmbr0,ip=dhcp',
                'password' => $params['password'] ?? bin2hex(random_bytes(8)),
            ];

            $response = $this->makeRequest('POST', "/nodes/{$node}/lxc", $payload);

            if ($response['success']) {
                return [
                    'success' => true,
                    'vmid' => $vmid,
                    'node' => $node,
                    'password' => $payload['password'],
                    'data' => $response['data'],
                ];
            }

            throw new Exception($response['message'] ?? 'Erro ao criar container');

        } catch (Exception $e) {
            Log::error('Proxmox Create Container Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Iniciar VM/Container
     */
    public function startVM(Service $service): array
    {
        try {
            $node = $service->getSetting('proxmox_node') ?? 'pve';
            $vmid = $service->getSetting('proxmox_vmid');
            $type = $service->getSetting('proxmox_type') ?? 'qemu';
            
            if (!$vmid) {
                throw new Exception('VMID não encontrado');
            }

            $response = $this->makeRequest('POST', "/nodes/{$node}/{$type}/{$vmid}/status/start");

            return [
                'success' => $response['success'],
                'message' => 'VM iniciada com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('Proxmox Start VM Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Parar VM/Container
     */
    public function stopVM(Service $service): array
    {
        try {
            $node = $service->getSetting('proxmox_node') ?? 'pve';
            $vmid = $service->getSetting('proxmox_vmid');
            $type = $service->getSetting('proxmox_type') ?? 'qemu';
            
            if (!$vmid) {
                throw new Exception('VMID não encontrado');
            }

            $response = $this->makeRequest('POST', "/nodes/{$node}/{$type}/{$vmid}/status/stop");

            return [
                'success' => $response['success'],
                'message' => 'VM parada com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('Proxmox Stop VM Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Reiniciar VM/Container
     */
    public function rebootVM(Service $service): array
    {
        try {
            $node = $service->getSetting('proxmox_node') ?? 'pve';
            $vmid = $service->getSetting('proxmox_vmid');
            $type = $service->getSetting('proxmox_type') ?? 'qemu';
            
            if (!$vmid) {
                throw new Exception('VMID não encontrado');
            }

            $response = $this->makeRequest('POST', "/nodes/{$node}/{$type}/{$vmid}/status/reboot");

            return [
                'success' => $response['success'],
                'message' => 'VM reiniciada com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('Proxmox Reboot VM Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Deletar VM/Container
     */
    public function deleteVM(Service $service): array
    {
        try {
            $node = $service->getSetting('proxmox_node') ?? 'pve';
            $vmid = $service->getSetting('proxmox_vmid');
            $type = $service->getSetting('proxmox_type') ?? 'qemu';
            
            if (!$vmid) {
                throw new Exception('VMID não encontrado');
            }

            // Parar primeiro
            $this->stopVM($service);
            sleep(5);

            $response = $this->makeRequest('DELETE', "/nodes/{$node}/{$type}/{$vmid}");

            return [
                'success' => $response['success'],
                'message' => 'VM deletada com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('Proxmox Delete VM Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Obter informações da VM/Container
     */
    public function getVMInfo(Service $service): ?array
    {
        try {
            $node = $service->getSetting('proxmox_node') ?? 'pve';
            $vmid = $service->getSetting('proxmox_vmid');
            $type = $service->getSetting('proxmox_type') ?? 'qemu';
            
            if (!$vmid) {
                return null;
            }

            $response = $this->makeRequest('GET', "/nodes/{$node}/{$type}/{$vmid}/status/current");

            if ($response['success']) {
                return $response['data'];
            }

            return null;

        } catch (Exception $e) {
            Log::error('Proxmox Get VM Info Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * Obter próximo VMID disponível
     */
    private function getNextVMID(string $node): int
    {
        $response = $this->makeRequest('GET', '/cluster/nextid');
        return (int) ($response['data']['data'] ?? 100);
    }

    /**
     * Fazer requisição à API do Proxmox
     */
    private function makeRequest(string $method, string $endpoint, array $data = []): array
    {
        $url = $this->apiUrl . $endpoint;

        try {
            $headers = [];
            
            // Usar API Token ou Ticket
            if (!empty($this->apiToken)) {
                $headers['Authorization'] = 'PVEAPIToken=' . $this->apiUser . '!' . $this->apiToken;
            } elseif (!empty($this->ticket)) {
                $headers['Cookie'] = 'PVEAuthCookie=' . $this->ticket;
                if ($method !== 'GET' && !empty($this->csrfToken)) {
                    $headers['CSRFPreventionToken'] = $this->csrfToken;
                }
            }

            $request = Http::timeout(30)->withHeaders($headers);

            if ($method === 'GET') {
                $response = $request->get($url, $data);
            } elseif ($method === 'POST') {
                $response = $request->asForm()->post($url, $data);
            } elseif ($method === 'DELETE') {
                $response = $request->delete($url, $data);
            } else {
                throw new Exception("Método HTTP não suportado: {$method}");
            }

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json('data'),
                ];
            }

            return [
                'success' => false,
                'message' => $response->body(),
                'status' => $response->status(),
            ];

        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }
}
