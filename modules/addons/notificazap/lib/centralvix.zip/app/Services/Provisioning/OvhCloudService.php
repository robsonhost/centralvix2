<?php

namespace App\Services\Provisioning;

use App\Models\Server;
use App\Models\Service;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class OvhCloudService
{
    private string $applicationKey;
    private string $applicationSecret;
    private string $consumerKey;
    private string $endpoint;

    public function __construct(Server $server)
    {
        $this->applicationKey = $server->getSetting('ovh_application_key') ?? '';
        $this->applicationSecret = $server->getSetting('ovh_application_secret') ?? '';
        $this->consumerKey = $server->getSetting('ovh_consumer_key') ?? '';
        $this->endpoint = $server->getSetting('ovh_endpoint') ?? 'ovh-eu'; // ovh-eu, ovh-ca, ovh-us
    }

    /**
     * Criar VPS na OVHcloud
     */
    public function createVPS(Service $service, array $params = []): array
    {
        try {
            $endpoint = $this->getApiUrl();
            
            $payload = [
                'serviceName' => $params['service_name'] ?? 'vps-' . uniqid(),
                'datacenter' => $params['datacenter'] ?? 'gra',
                'model' => $params['model'] ?? 'vps-value-1-2-20',
                'duration' => $params['duration'] ?? 'P1M',
            ];

            $response = $this->makeRequest('POST', '/order/vps/new', $payload);

            if ($response['success']) {
                return [
                    'success' => true,
                    'vps_id' => $response['data']['orderId'] ?? null,
                    'service_name' => $payload['serviceName'],
                    'data' => $response['data'],
                ];
            }

            throw new Exception($response['message'] ?? 'Erro ao criar VPS');

        } catch (Exception $e) {
            Log::error('OVHCloud Create VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Suspender VPS
     */
    public function suspendVPS(Service $service): array
    {
        try {
            $serviceName = $service->getSetting('ovh_service_name');
            
            if (!$serviceName) {
                throw new Exception('Nome do serviço OVH não encontrado');
            }

            $response = $this->makeRequest('POST', "/vps/{$serviceName}/stop");

            return [
                'success' => $response['success'],
                'message' => 'VPS suspenso com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('OVHCloud Suspend VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Reativar VPS
     */
    public function unsuspendVPS(Service $service): array
    {
        try {
            $serviceName = $service->getSetting('ovh_service_name');
            
            if (!$serviceName) {
                throw new Exception('Nome do serviço OVH não encontrado');
            }

            $response = $this->makeRequest('POST', "/vps/{$serviceName}/start");

            return [
                'success' => $response['success'],
                'message' => 'VPS reativado com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('OVHCloud Unsuspend VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Deletar VPS
     */
    public function deleteVPS(Service $service): array
    {
        try {
            $serviceName = $service->getSetting('ovh_service_name');
            
            if (!$serviceName) {
                throw new Exception('Nome do serviço OVH não encontrado');
            }

            $response = $this->makeRequest('DELETE', "/vps/{$serviceName}");

            return [
                'success' => $response['success'],
                'message' => 'VPS deletado com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('OVHCloud Delete VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Obter informações do VPS
     */
    public function getVPSInfo(Service $service): ?array
    {
        try {
            $serviceName = $service->getSetting('ovh_service_name');
            
            if (!$serviceName) {
                return null;
            }

            $response = $this->makeRequest('GET', "/vps/{$serviceName}");

            if ($response['success']) {
                return $response['data'];
            }

            return null;

        } catch (Exception $e) {
            Log::error('OVHCloud Get VPS Info Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * Fazer requisição à API da OVH
     */
    private function makeRequest(string $method, string $path, array $body = []): array
    {
        $url = $this->getApiUrl() . $path;
        $timestamp = time();
        
        // Calcular assinatura OVH
        $signature = $this->calculateSignature($method, $url, $body, $timestamp);

        try {
            $response = Http::timeout(30)
                ->withHeaders([
                    'X-Ovh-Application' => $this->applicationKey,
                    'X-Ovh-Consumer' => $this->consumerKey,
                    'X-Ovh-Signature' => $signature,
                    'X-Ovh-Timestamp' => $timestamp,
                    'Content-Type' => 'application/json',
                ])
                ->send($method, $url, ['json' => $body]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json(),
                ];
            }

            return [
                'success' => false,
                'message' => $response->body(),
                'status' => $response->status(),
            ];

        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Calcular assinatura para API OVH
     */
    private function calculateSignature(string $method, string $url, array $body, int $timestamp): string
    {
        $bodyString = empty($body) ? '' : json_encode($body);
        $toSign = $this->applicationSecret . '+' . $this->consumerKey . '+' . $method . '+' . $url . '+' . $bodyString . '+' . $timestamp;
        return '$1$' . sha1($toSign);
    }

    /**
     * Obter URL da API baseado no endpoint
     */
    private function getApiUrl(): string
    {
        return match($this->endpoint) {
            'ovh-eu' => 'https://eu.api.ovh.com/1.0',
            'ovh-ca' => 'https://ca.api.ovh.com/1.0',
            'ovh-us' => 'https://api.us.ovhcloud.com/1.0',
            default => 'https://eu.api.ovh.com/1.0',
        };
    }
}
