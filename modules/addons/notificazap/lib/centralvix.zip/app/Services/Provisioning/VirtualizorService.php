<?php

namespace App\Services\Provisioning;

use App\Models\Server;
use App\Models\Service;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class VirtualizorService
{
    private string $apiUrl;
    private string $apiKey;
    private string $apiPassword;

    public function __construct(Server $server)
    {
        $this->apiUrl = rtrim($server->hostname ?? '', '/');
        $this->apiKey = $server->getSetting('virtualizor_key') ?? '';
        $this->apiPassword = $server->getSetting('virtualizor_password') ?? '';
    }

    /**
     * Criar VPS no Virtualizor
     */
    public function createVPS(Service $service, array $params = []): array
    {
        try {
            $payload = [
                'svs' => 'create',
                'virt' => $params['virt'] ?? 'kvm',
                'hostname' => $params['hostname'] ?? 'vps-' . uniqid(),
                'osid' => $params['osid'] ?? 1,
                'iso' => $params['iso'] ?? '',
                'cores' => $params['cores'] ?? 1,
                'ram' => $params['ram'] ?? 1024,
                'space' => $params['space'] ?? 20,
                'bandwidth' => $params['bandwidth'] ?? 0,
                'network_speed' => $params['network_speed'] ?? 0,
                'user_email' => $service->client->email ?? '',
                'user_pass' => $params['password'] ?? bin2hex(random_bytes(8)),
            ];

            $response = $this->makeRequest('addvs', $payload);

            if ($response['success'] && isset($response['data']['done'])) {
                return [
                    'success' => true,
                    'vps_id' => $response['data']['vpsid'] ?? null,
                    'password' => $payload['user_pass'],
                    'ip_address' => $response['data']['ips'][0] ?? null,
                    'data' => $response['data'],
                ];
            }

            throw new Exception($response['data']['error'] ?? 'Erro ao criar VPS');

        } catch (Exception $e) {
            Log::error('Virtualizor Create VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Suspender VPS
     */
    public function suspendVPS(Service $service): array
    {
        try {
            $vpsId = $service->getSetting('virtualizor_vps_id');
            
            if (!$vpsId) {
                throw new Exception('ID do VPS não encontrado');
            }

            $response = $this->makeRequest('stop', ['vpsid' => $vpsId]);

            return [
                'success' => $response['success'],
                'message' => 'VPS suspenso com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('Virtualizor Suspend VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Reativar VPS
     */
    public function unsuspendVPS(Service $service): array
    {
        try {
            $vpsId = $service->getSetting('virtualizor_vps_id');
            
            if (!$vpsId) {
                throw new Exception('ID do VPS não encontrado');
            }

            $response = $this->makeRequest('start', ['vpsid' => $vpsId]);

            return [
                'success' => $response['success'],
                'message' => 'VPS reativado com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('Virtualizor Unsuspend VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Deletar VPS
     */
    public function deleteVPS(Service $service): array
    {
        try {
            $vpsId = $service->getSetting('virtualizor_vps_id');
            
            if (!$vpsId) {
                throw new Exception('ID do VPS não encontrado');
            }

            $response = $this->makeRequest('deletevs', ['vpsid' => $vpsId, 'delete_disk' => 1]);

            return [
                'success' => $response['success'],
                'message' => 'VPS deletado com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('Virtualizor Delete VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Obter informações do VPS
     */
    public function getVPSInfo(Service $service): ?array
    {
        try {
            $vpsId = $service->getSetting('virtualizor_vps_id');
            
            if (!$vpsId) {
                return null;
            }

            $response = $this->makeRequest('listvs', ['vpsid' => $vpsId]);

            if ($response['success'] && isset($response['data']['vs'][$vpsId])) {
                return $response['data']['vs'][$vpsId];
            }

            return null;

        } catch (Exception $e) {
            Log::error('Virtualizor Get VPS Info Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * Reiniciar VPS
     */
    public function rebootVPS(Service $service): array
    {
        try {
            $vpsId = $service->getSetting('virtualizor_vps_id');
            
            if (!$vpsId) {
                throw new Exception('ID do VPS não encontrado');
            }

            $response = $this->makeRequest('restart', ['vpsid' => $vpsId]);

            return [
                'success' => $response['success'],
                'message' => 'VPS reiniciado com sucesso',
            ];

        } catch (Exception $e) {
            Log::error('Virtualizor Reboot VPS Error', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Fazer requisição à API do Virtualizor
     */
    private function makeRequest(string $action, array $params = []): array
    {
        $url = $this->apiUrl . '/index.php';
        
        $queryParams = array_merge([
            'act' => $action,
            'api' => 'json',
            'apikey' => $this->apiKey,
            'apipass' => $this->apiPassword,
        ], $params);

        try {
            $response = Http::timeout(30)->get($url, $queryParams);

            if ($response->successful()) {
                $data = $response->json();
                
                return [
                    'success' => !isset($data['error']),
                    'data' => $data,
                ];
            }

            return [
                'success' => false,
                'message' => $response->body(),
                'status' => $response->status(),
            ];

        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }
}
