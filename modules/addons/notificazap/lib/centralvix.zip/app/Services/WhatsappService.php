<?php

namespace App\Services;

use App\Models\Client;
use App\Models\WhatsappInstance;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WhatsappService
{
    /**
     * Enviar mensagem de boas-vindas para cliente
     */
    public static function sendWelcomeMessage(Client $client, $password = null): bool
    {
        try {
            $message = self::buildWelcomeMessage($client, $password);
            return self::sendMessage($client->mobile, $message);
        } catch (\Exception $e) {
            Log::error('Erro ao enviar WhatsApp de boas-vindas', [
                'client_id' => $client->id,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Construir mensagem de boas-vindas
     */
    private static function buildWelcomeMessage(Client $client, $password = null): string
    {
        $appName = config('app.name');
        $loginUrl = route('client.login');
        
        $message = "🎉 *Bem-vindo à {$appName}!*\n\n";
        $message .= "Olá *{$client->firstname}*,\n\n";
        $message .= "Sua conta foi criada com sucesso! ✅\n\n";
        
        if ($password) {
            $message .= "🔐 *Seus Dados de Acesso:*\n";
            $message .= "📧 E-mail: `{$client->email}`\n";
            $message .= "🔑 Senha: `{$password}`\n\n";
            $message .= "⚠️ *Importante:* Recomendamos alterar sua senha no primeiro acesso.\n\n";
        }
        
        $message .= "🌐 *Acesse seu painel:*\n";
        $message .= "{$loginUrl}\n\n";
        
        $message .= "📊 No seu painel você pode:\n";
        $message .= "• Gerenciar seus serviços\n";
        $message .= "• Visualizar e pagar faturas\n";
        $message .= "• Abrir tickets de suporte\n";
        $message .= "• Atualizar seus dados\n\n";
        
        $message .= "⚠️ *Se você não criou esta conta*, entre em contato conosco imediatamente.\n\n";
        $message .= "Atenciosamente,\n";
        $message .= "Equipe {$appName} 💜";
        
        return $message;
    }

    /**
     * Enviar mensagem via Evolution API ou outro provedor
     */
    public static function sendMessage(string $phone, string $message, $instance = null): bool
    {
        try {
            // Se não especificado, pegar instância padrão ativa
            if (!$instance) {
                $instance = WhatsappInstance::where('status', 'connected')
                    ->where('is_default', true)
                    ->first();
            }

            if (!$instance) {
                Log::warning('Nenhuma instância WhatsApp ativa encontrada');
                return false;
            }

            // Limpar número (remover caracteres especiais)
            $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
            
            // Garantir formato internacional (BR)
            if (strlen($cleanPhone) === 11 && !str_starts_with($cleanPhone, '55')) {
                $cleanPhone = '55' . $cleanPhone;
            }

            // Endpoint da Evolution API
            $url = rtrim($instance->api_url, '/') . '/message/sendText/' . $instance->instance_name;

            // Enviar requisição
            $response = Http::withHeaders([
                'apikey' => $instance->api_key,
                'Content-Type' => 'application/json',
            ])->post($url, [
                'number' => $cleanPhone,
                'text' => $message,
            ]);

            if ($response->successful()) {
                Log::info('WhatsApp enviado com sucesso', [
                    'phone' => $cleanPhone,
                    'instance' => $instance->instance_name
                ]);
                return true;
            } else {
                Log::error('Erro ao enviar WhatsApp', [
                    'phone' => $cleanPhone,
                    'status' => $response->status(),
                    'response' => $response->body()
                ]);
                return false;
            }
        } catch (\Exception $e) {
            Log::error('Exceção ao enviar WhatsApp', [
                'phone' => $phone,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Enviar mensagem de fatura criada
     */
    public static function sendInvoiceCreated($client, $invoice): bool
    {
        $message = "💳 *Nova Fatura Gerada*\n\n";
        $message .= "Olá *{$client->firstname}*,\n\n";
        $message .= "Uma nova fatura foi gerada:\n\n";
        $message .= "📄 *Fatura:* #{$invoice->id}\n";
        $message .= "💰 *Valor:* R$ " . number_format($invoice->total, 2, ',', '.') . "\n";
        $message .= "📅 *Vencimento:* " . $invoice->due_date->format('d/m/Y') . "\n\n";
        $message .= "🔗 Ver fatura: " . route('client.invoices.show', $invoice->id) . "\n\n";
        $message .= "Equipe " . config('app.name');
        
        return self::sendMessage($client->mobile, $message);
    }

    /**
     * Enviar mensagem de fatura vencida
     */
    public static function sendInvoiceOverdue($client, $invoice): bool
    {
        $message = "⚠️ *Fatura Vencida*\n\n";
        $message .= "Olá *{$client->firstname}*,\n\n";
        $message .= "Sua fatura está vencida:\n\n";
        $message .= "📄 *Fatura:* #{$invoice->id}\n";
        $message .= "💰 *Valor:* R$ " . number_format($invoice->total, 2, ',', '.') . "\n";
        $message .= "📅 *Venceu em:* " . $invoice->due_date->format('d/m/Y') . "\n\n";
        $message .= "Para evitar a suspensão dos seus serviços, efetue o pagamento o quanto antes.\n\n";
        $message .= "🔗 Pagar agora: " . route('client.invoices.show', $invoice->id) . "\n\n";
        $message .= "Equipe " . config('app.name');
        
        return self::sendMessage($client->mobile, $message);
    }

    /**
     * Enviar mensagem de pagamento confirmado
     */
    public static function sendPaymentConfirmed($client, $invoice): bool
    {
        $message = "✅ *Pagamento Confirmado!*\n\n";
        $message .= "Olá *{$client->firstname}*,\n\n";
        $message .= "Seu pagamento foi confirmado com sucesso! 🎉\n\n";
        $message .= "📄 *Fatura:* #{$invoice->id}\n";
        $message .= "💰 *Valor:* R$ " . number_format($invoice->total, 2, ',', '.') . "\n";
        $message .= "📅 *Pago em:* " . now()->format('d/m/Y H:i') . "\n\n";
        $message .= "Obrigado por sua preferência!\n\n";
        $message .= "Equipe " . config('app.name');
        
        return self::sendMessage($client->mobile, $message);
    }

    /**
     * Enviar mensagem de serviço suspenso
     */
    public static function sendServiceSuspended($client, $service): bool
    {
        $message = "⛔ *Serviço Suspenso*\n\n";
        $message .= "Olá *{$client->firstname}*,\n\n";
        $message .= "Seu serviço foi suspenso:\n\n";
        $message .= "🖥️ *Serviço:* {$service->product->name}\n";
        $message .= "💰 *Motivo:* Fatura em atraso\n\n";
        $message .= "Para reativar, regularize os pagamentos pendentes.\n\n";
        $message .= "🔗 Ver faturas: " . route('client.invoices.index') . "\n\n";
        $message .= "Equipe " . config('app.name');
        
        return self::sendMessage($client->mobile, $message);
    }

    /**
     * Enviar mensagem de ticket respondido
     */
    public static function sendTicketReply($client, $ticket): bool
    {
        $message = "💬 *Resposta no Ticket*\n\n";
        $message .= "Olá *{$client->firstname}*,\n\n";
        $message .= "Seu ticket recebeu uma nova resposta:\n\n";
        $message .= "🎫 *Ticket:* #{$ticket->id}\n";
        $message .= "📝 *Assunto:* {$ticket->subject}\n\n";
        $message .= "🔗 Ver resposta: " . route('client.tickets.show', $ticket->id) . "\n\n";
        $message .= "Equipe " . config('app.name');
        
        return self::sendMessage($client->mobile, $message);
    }
}
