<?php

namespace App\Services;

use App\Models\Client;
use App\Models\Invoice;
use App\Models\RechargeOrder;
use App\Models\RechargePackage;
use Illuminate\Support\Facades\DB;

class RechargeService
{
    public function __construct(private WalletService $wallet) {}

    /**
     * Cria um pedido de recarga + Invoice para o cliente pagar via gateway.
     *
     * @return array{success: bool, message: string, order?: RechargeOrder, invoice?: Invoice}
     */
    public function createOrder(Client $client, RechargePackage $package): array
    {
        if (! $package->active) {
            return ['success' => false, 'message' => 'Este pacote de recarga não está disponível.'];
        }

        return DB::transaction(function () use ($client, $package) {
            $totalCredit = round((float) $package->amount + (float) $package->bonus, 2);

            $invoice = Invoice::create([
                'company_id'    => $client->company_id,
                'client_id'     => $client->id,
                'status'        => 'unpaid',
                'subtotal'      => $package->amount,
                'discount'      => 0,
                'tax'           => 0,
                'total'         => $package->amount,
                'currency'      => 'BRL',
                'date_created'  => now()->toDateString(),
                'date_due'      => now()->addDays(3)->toDateString(),
                'notes'         => 'Recarga de saldo — ' . $package->display_name
                    . ($package->bonus > 0 ? ' (bônus de R$ ' . number_format((float) $package->bonus, 2, ',', '.') . ')' : ''),
            ]);

            // Item da fatura, se houver tabela invoice_items
            if (class_exists(\App\Models\InvoiceItem::class)) {
                try {
                    $invoice->items()->create([
                        'description' => 'Recarga de saldo - ' . $package->display_name,
                        'quantity'    => 1,
                        'unit_price'  => $package->amount,
                        'amount'      => $package->amount,
                    ]);
                } catch (\Throwable $e) {
                    // se schema de items for diferente, ignora silenciosamente
                }
            }

            $order = RechargeOrder::create([
                'company_id'           => $client->company_id,
                'client_id'            => $client->id,
                'recharge_package_id'  => $package->id,
                'invoice_id'           => $invoice->id,
                'amount'               => $package->amount,
                'bonus'                => $package->bonus,
                'total_credit'         => $totalCredit,
                'status'               => 'pending',
            ]);

            return [
                'success' => true,
                'message' => 'Pedido de recarga criado com sucesso.',
                'order'   => $order,
                'invoice' => $invoice,
            ];
        });
    }

    /**
     * Marca um pedido como pago e credita o saldo na carteira do cliente.
     * Idempotente: chamadas repetidas não creditam duas vezes.
     */
    public function markPaid(RechargeOrder $order, ?string $gateway = null, ?string $transactionId = null): RechargeOrder
    {
        return DB::transaction(function () use ($order, $gateway, $transactionId) {
            $order = RechargeOrder::whereKey($order->id)->lockForUpdate()->firstOrFail();

            if ($order->status === 'paid') {
                return $order;
            }

            $order->update([
                'status'         => 'paid',
                'gateway'        => $gateway ?? $order->gateway,
                'transaction_id' => $transactionId ?? $order->transaction_id,
                'paid_at'        => now(),
            ]);

            $client = $order->client;
            if ($client) {
                $this->wallet->credit(
                    $client,
                    (float) $order->total_credit,
                    'topup',
                    'Recarga #' . $order->id . ' (R$ ' . number_format((float) $order->amount, 2, ',', '.')
                        . ($order->bonus > 0 ? ' + bônus R$ ' . number_format((float) $order->bonus, 2, ',', '.') : '')
                        . ')',
                    $order->invoice,
                    $client->user_id,
                );
            }

            return $order;
        });
    }
}
