<?php

namespace App\Services;

use App\Models\Client;
use App\Models\Company;

class ClientNotificationTemplates
{
    /**
     * Variáveis disponíveis em todos os templates.
     */
    public static function variables(): array
    {
        return [
            '{nome}'         => 'Primeiro nome do cliente',
            '{sobrenome}'    => 'Sobrenome do cliente',
            '{nome_completo}'=> 'Nome completo',
            '{empresa}'      => 'Nome da empresa do cliente',
            '{email}'        => 'E-mail do cliente',
            '{telefone}'     => 'Telefone/WhatsApp',
            '{servico}'      => 'Nome do serviço/produto',
            '{produto}'      => 'Nome do produto',
            '{valor}'        => 'Valor (R$)',
            '{vencimento}'   => 'Data de vencimento',
            '{fatura}'       => 'Número da fatura',
            '{dominio}'      => 'Nome do domínio',
            '{ticket}'       => 'Número do ticket',
            '{contrato}'     => 'Número/referência do contrato',
            '{link_painel}'  => 'Link do painel do cliente',
            '{link_fatura}'  => 'Link da fatura',
            '{empresa_nome}' => 'Nome da sua empresa',
        ];
    }

    /**
     * 20 templates de notificação para serviços CentralVix.
     */
    public static function all(): array
    {
        return [
            [
                'id'       => 'welcome',
                'icon'     => '🎉',
                'category' => 'Conta',
                'title'    => 'Boas-vindas',
                'message'  => "🎉 *Bem-vindo à {empresa_nome}!*\n\nOlá *{nome}*, sua conta foi criada com sucesso! ✅\n\n🌐 Acesse seu painel:\n{link_painel}\n\nAtenciosamente,\nEquipe {empresa_nome} 💜",
            ],
            [
                'id'       => 'service_renewal_reminder',
                'icon'     => '🔔',
                'category' => 'Serviços',
                'title'    => 'Lembrete de renovação',
                'message'  => "🔔 *Renovação de Serviço*\n\nOlá *{nome}*,\n\nSeu serviço *{servico}* vence em *{vencimento}*.\n\n💰 Valor: *{valor}*\n\nRenove agora para evitar interrupções:\n{link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'service_renewed',
                'icon'     => '✅',
                'category' => 'Serviços',
                'title'    => 'Serviço renovado',
                'message'  => "✅ *Serviço Renovado com Sucesso!*\n\nOlá *{nome}*,\n\nSeu serviço *{servico}* foi renovado até *{vencimento}*.\n\nObrigado pela confiança! 🙏\n\n{link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'service_cancelled',
                'icon'     => '❌',
                'category' => 'Serviços',
                'title'    => 'Cancelamento de serviço',
                'message'  => "❌ *Serviço Cancelado*\n\nOlá *{nome}*,\n\nConfirmamos o cancelamento do serviço *{servico}*.\n\nSe mudou de ideia, entre em contato conosco.\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'service_suspended',
                'icon'     => '⛔',
                'category' => 'Serviços',
                'title'    => 'Serviço suspenso',
                'message'  => "⛔ *Serviço Suspenso*\n\nOlá *{nome}*,\n\nSeu serviço *{servico}* foi suspenso por fatura em atraso.\n\n💰 Regularize: {link_fatura}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'service_reactivated',
                'icon'     => '🟢',
                'category' => 'Serviços',
                'title'    => 'Serviço reativado',
                'message'  => "🟢 *Serviço Reativado!*\n\nOlá *{nome}*,\n\nSeu serviço *{servico}* foi reativado com sucesso! 🎉\n\nAcesse: {link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'profile_updated',
                'icon'     => '📝',
                'category' => 'Conta',
                'title'    => 'Atualização de cadastro',
                'message'  => "📝 *Cadastro Atualizado*\n\nOlá *{nome}*,\n\nSeus dados cadastrais foram atualizados com sucesso.\n\nSe não foi você, entre em contato imediatamente.\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'contract_released',
                'icon'     => '📄',
                'category' => 'Contratos',
                'title'    => 'Contrato liberado',
                'message'  => "📄 *Contrato Disponível*\n\nOlá *{nome}*,\n\nSeu contrato *{contrato}* referente ao serviço *{servico}* está disponível para assinatura.\n\n✍️ Acesse: {link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'invoice_created',
                'icon'     => '💳',
                'category' => 'Financeiro',
                'title'    => 'Nova fatura',
                'message'  => "💳 *Nova Fatura Gerada*\n\nOlá *{nome}*,\n\n📄 Fatura: *#{fatura}*\n💰 Valor: *{valor}*\n📅 Vencimento: *{vencimento}*\n\n🔗 Pagar: {link_fatura}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'invoice_overdue',
                'icon'     => '⚠️',
                'category' => 'Financeiro',
                'title'    => 'Fatura vencida',
                'message'  => "⚠️ *Fatura Vencida*\n\nOlá *{nome}*,\n\nSua fatura *#{fatura}* no valor de *{valor}* venceu em *{vencimento}*.\n\nRegularize para evitar suspensão:\n{link_fatura}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'payment_confirmed',
                'icon'     => '✅',
                'category' => 'Financeiro',
                'title'    => 'Pagamento confirmado',
                'message'  => "✅ *Pagamento Confirmado!*\n\nOlá *{nome}*,\n\nRecebemos o pagamento da fatura *#{fatura}* no valor de *{valor}*. 🎉\n\nObrigado!\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'payment_reminder',
                'icon'     => '⏰',
                'category' => 'Financeiro',
                'title'    => 'Lembrete de pagamento',
                'message'  => "⏰ *Lembrete de Pagamento*\n\nOlá *{nome}*,\n\nSua fatura *#{fatura}* vence em *{vencimento}*.\n\n💰 Valor: *{valor}*\n\n🔗 Pagar: {link_fatura}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'ticket_reply',
                'icon'     => '💬',
                'category' => 'Suporte',
                'title'    => 'Ticket respondido',
                'message'  => "💬 *Resposta no Ticket*\n\nOlá *{nome}*,\n\nSeu ticket *#{ticket}* recebeu uma nova resposta.\n\n🔗 Ver: {link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'ticket_opened',
                'icon'     => '🎫',
                'category' => 'Suporte',
                'title'    => 'Ticket aberto',
                'message'  => "🎫 *Ticket Registrado*\n\nOlá *{nome}*,\n\nSeu ticket *#{ticket}* foi aberto com sucesso.\n\nResponderemos em breve!\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'domain_expiring',
                'icon'     => '🌐',
                'category' => 'Domínios',
                'title'    => 'Domínio expirando',
                'message'  => "🌐 *Domínio Expirando*\n\nOlá *{nome}*,\n\nSeu domínio *{dominio}* expira em *{vencimento}*.\n\nRenove agora para não perder seu domínio!\n\n{link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'domain_renewed',
                'icon'     => '✅',
                'category' => 'Domínios',
                'title'    => 'Domínio renovado',
                'message'  => "✅ *Domínio Renovado*\n\nOlá *{nome}*,\n\nO domínio *{dominio}* foi renovado até *{vencimento}*.\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'vps_provisioned',
                'icon'     => '🖥️',
                'category' => 'VPS',
                'title'    => 'VPS provisionado',
                'message'  => "🖥️ *VPS Provisionado!*\n\nOlá *{nome}*,\n\nSeu VPS *{servico}* está pronto e ativo! 🚀\n\nAcesse os detalhes no painel:\n{link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'password_reset',
                'icon'     => '🔐',
                'category' => 'Conta',
                'title'    => 'Senha resetada',
                'message'  => "🔐 *Senha Redefinida*\n\nOlá *{nome}*,\n\nSua senha de acesso foi redefinida com sucesso.\n\nSe não foi você, contate-nos imediatamente.\n\n{link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'credit_added',
                'icon'     => '💰',
                'category' => 'Financeiro',
                'title'    => 'Crédito adicionado',
                'message'  => "💰 *Crédito Adicionado*\n\nOlá *{nome}*,\n\nFoi adicionado *{valor}* de crédito à sua conta.\n\nConsulte seu saldo: {link_painel}\n\nEquipe {empresa_nome}",
            ],
            [
                'id'       => 'maintenance',
                'icon'     => '🔧',
                'category' => 'Sistema',
                'title'    => 'Manutenção programada',
                'message'  => "🔧 *Manutenção Programada*\n\nOlá *{nome}*,\n\nInformamos manutenção programada em *{vencimento}* que pode afetar o serviço *{servico}*.\n\nPedimos compreensão.\n\nEquipe {empresa_nome}",
            ],
        ];
    }

    public static function find(string $id): ?array
    {
        foreach (self::all() as $template) {
            if ($template['id'] === $id) {
                return $template;
            }
        }
        return null;
    }

    /**
     * Substitui variáveis no template com dados do cliente.
     */
    public static function render(string $message, Client $client, array $extra = []): string
    {
        $companyName = Company::find($client->company_id)?->name ?? config('app.name');
        $phone = $client->mobile ?: $client->phone;

        $vars = array_merge([
            '{nome}'          => $client->firstname ?? '',
            '{sobrenome}'     => $client->lastname ?? '',
            '{nome_completo}' => trim(($client->firstname ?? '') . ' ' . ($client->lastname ?? '')),
            '{empresa}'       => $client->company_name ?? '',
            '{email}'         => $client->email ?? '',
            '{telefone}'      => $phone ?? '',
            '{servico}'       => $extra['servico'] ?? 'seu serviço',
            '{produto}'       => $extra['produto'] ?? ($extra['servico'] ?? 'seu produto'),
            '{valor}'         => $extra['valor'] ?? 'R$ 0,00',
            '{vencimento}'    => $extra['vencimento'] ?? now()->addDays(7)->format('d/m/Y'),
            '{fatura}'        => $extra['fatura'] ?? '—',
            '{dominio}'       => $extra['dominio'] ?? 'seu domínio',
            '{ticket}'        => $extra['ticket'] ?? '—',
            '{contrato}'      => $extra['contrato'] ?? '—',
            '{link_painel}'   => route('client.dashboard'),
            '{link_fatura}'   => route('client.invoices.index'),
            '{empresa_nome}'  => $companyName,
        ], $extra);

        return str_replace(array_keys($vars), array_values($vars), $message);
    }
}
