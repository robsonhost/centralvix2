<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

/**
 * CacheService - Centralized cache management with tags and automatic invalidation
 * 
 * Implements cache strategy as per Requirement 64:
 * - Products: 1 hour TTL
 * - WHM Packages: 6 hours TTL
 * - Settings: 24 hours TTL
 * - Dashboard Stats: 5 minutes TTL
 */
class CacheService
{
    /**
     * Cache TTLs in seconds
     */
    const TTL_PRODUCTS = 3600;      // 1 hour
    const TTL_WHM_PACKAGES = 21600; // 6 hours
    const TTL_SETTINGS = 86400;     // 24 hours
    const TTL_DASHBOARD = 300;      // 5 minutes
    const TTL_LISTINGS = 1800;      // 30 minutes (for lists)

    /**
     * Cache Tags
     */
    const TAG_PRODUCTS = 'products';
    const TAG_WHM_PACKAGES = 'whm_packages';
    const TAG_SETTINGS = 'settings';
    const TAG_DASHBOARD = 'dashboard';
    const TAG_CLIENTS = 'clients.list';
    const TAG_INVOICES = 'invoices.list';
    const TAG_SERVICES = 'services.list';
    const TAG_SERVERS = 'servers.list';

    /**
     * Get or cache products list
     */
    public function getProducts(int $companyId, callable $callback): mixed
    {
        $key = $this->makeKey('products', $companyId);
        
        return Cache::tags([self::TAG_PRODUCTS, "company.{$companyId}"])
            ->remember($key, self::TTL_PRODUCTS, function () use ($callback) {
                Log::info('Cache MISS: Products list', ['tag' => self::TAG_PRODUCTS]);
                return $callback();
            });
    }

    /**
     * Get or cache WHM packages
     */
    public function getWhmPackages(int $companyId, int $serverId, callable $callback): mixed
    {
        $key = $this->makeKey('whm_packages', $companyId, $serverId);
        
        return Cache::tags([self::TAG_WHM_PACKAGES, "company.{$companyId}", "server.{$serverId}"])
            ->remember($key, self::TTL_WHM_PACKAGES, function () use ($callback) {
                Log::info('Cache MISS: WHM packages', ['tag' => self::TAG_WHM_PACKAGES]);
                return $callback();
            });
    }

    public function forgetWhmPackages(int $companyId, int $serverId): void
    {
        $key = $this->makeKey('whm_packages', $companyId, $serverId);
        Cache::tags([self::TAG_WHM_PACKAGES, "company.{$companyId}", "server.{$serverId}"])->forget($key);
    }

    /**
     * Get or cache settings
     */
    public function getSetting(int $companyId, string $group, string $key, callable $callback): mixed
    {
        $cacheKey = $this->makeKey('setting', $companyId, $group, $key);
        
        return Cache::tags([self::TAG_SETTINGS, "company.{$companyId}"])
            ->remember($cacheKey, self::TTL_SETTINGS, function () use ($callback, $group, $key) {
                Log::info('Cache MISS: Setting', ['group' => $group, 'key' => $key]);
                return $callback();
            });
    }

    /**
     * Get or cache all settings for a company
     */
    public function getAllSettings(int $companyId, callable $callback): mixed
    {
        $key = $this->makeKey('settings_all', $companyId);
        
        return Cache::tags([self::TAG_SETTINGS, "company.{$companyId}"])
            ->remember($key, self::TTL_SETTINGS, function () use ($callback) {
                Log::info('Cache MISS: All settings', ['tag' => self::TAG_SETTINGS]);
                return $callback();
            });
    }

    /**
     * Get or cache dashboard statistics
     */
    public function getDashboardStats(int $companyId, callable $callback): mixed
    {
        $key = $this->makeKey('dashboard_stats', $companyId);
        
        return Cache::tags([self::TAG_DASHBOARD, "company.{$companyId}"])
            ->remember($key, self::TTL_DASHBOARD, function () use ($callback) {
                Log::info('Cache MISS: Dashboard stats', ['tag' => self::TAG_DASHBOARD]);
                return $callback();
            });
    }

    /**
     * Get or cache clients list with pagination
     */
    public function getClientsList(int $companyId, array $filters, int $page, callable $callback): mixed
    {
        $key = $this->makeKey('clients_list', $companyId, md5(json_encode($filters)), $page);
        
        return Cache::tags([self::TAG_CLIENTS, "company.{$companyId}"])
            ->remember($key, self::TTL_LISTINGS, function () use ($callback) {
                Log::info('Cache MISS: Clients list', ['tag' => self::TAG_CLIENTS]);
                return $callback();
            });
    }

    /**
     * Get or cache invoices list with pagination
     */
    public function getInvoicesList(int $companyId, array $filters, int $page, callable $callback): mixed
    {
        $key = $this->makeKey('invoices_list', $companyId, md5(json_encode($filters)), $page);
        
        return Cache::tags([self::TAG_INVOICES, "company.{$companyId}"])
            ->remember($key, self::TTL_LISTINGS, function () use ($callback) {
                Log::info('Cache MISS: Invoices list', ['tag' => self::TAG_INVOICES]);
                return $callback();
            });
    }

    /**
     * Get or cache services list with pagination
     */
    public function getServicesList(int $companyId, array $filters, int $page, callable $callback): mixed
    {
        $key = $this->makeKey('services_list', $companyId, md5(json_encode($filters)), $page);
        
        return Cache::tags([self::TAG_SERVICES, "company.{$companyId}"])
            ->remember($key, self::TTL_LISTINGS, function () use ($callback) {
                Log::info('Cache MISS: Services list', ['tag' => self::TAG_SERVICES]);
                return $callback();
            });
    }

    /**
     * Get or cache servers list
     */
    public function getServersList(int $companyId, callable $callback): mixed
    {
        $key = $this->makeKey('servers_list', $companyId);
        
        return Cache::tags([self::TAG_SERVERS, "company.{$companyId}"])
            ->remember($key, self::TTL_LISTINGS, function () use ($callback) {
                Log::info('Cache MISS: Servers list', ['tag' => self::TAG_SERVERS]);
                return $callback();
            });
    }

    /**
     * Invalidate products cache
     */
    public function invalidateProducts(int $companyId): void
    {
        Log::info('Cache invalidation: Products', ['company_id' => $companyId]);
        Cache::tags([self::TAG_PRODUCTS, "company.{$companyId}"])->flush();
    }

    /**
     * Invalidate WHM packages cache
     */
    public function invalidateWhmPackages(int $companyId, ?int $serverId = null): void
    {
        $tags = [self::TAG_WHM_PACKAGES, "company.{$companyId}"];
        if ($serverId) {
            $tags[] = "server.{$serverId}";
        }
        
        Log::info('Cache invalidation: WHM packages', ['company_id' => $companyId, 'server_id' => $serverId]);
        Cache::tags($tags)->flush();
    }

    /**
     * Invalidate settings cache
     */
    public function invalidateSettings(int $companyId): void
    {
        Log::info('Cache invalidation: Settings', ['company_id' => $companyId]);
        Cache::tags([self::TAG_SETTINGS, "company.{$companyId}"])->flush();
    }

    /**
     * Invalidate dashboard stats cache
     */
    public function invalidateDashboard(int $companyId): void
    {
        Log::info('Cache invalidation: Dashboard', ['company_id' => $companyId]);
        Cache::tags([self::TAG_DASHBOARD, "company.{$companyId}"])->flush();
    }

    /**
     * Invalidate clients list cache
     */
    public function invalidateClientsList(int $companyId): void
    {
        Log::info('Cache invalidation: Clients list', ['company_id' => $companyId]);
        Cache::tags([self::TAG_CLIENTS, "company.{$companyId}"])->flush();
        
        // Dashboard also shows client count
        $this->invalidateDashboard($companyId);
    }

    /**
     * Invalidate invoices list cache
     */
    public function invalidateInvoicesList(int $companyId): void
    {
        Log::info('Cache invalidation: Invoices list', ['company_id' => $companyId]);
        Cache::tags([self::TAG_INVOICES, "company.{$companyId}"])->flush();
        
        // Dashboard also shows invoice stats
        $this->invalidateDashboard($companyId);
    }

    /**
     * Invalidate services list cache
     */
    public function invalidateServicesList(int $companyId): void
    {
        Log::info('Cache invalidation: Services list', ['company_id' => $companyId]);
        Cache::tags([self::TAG_SERVICES, "company.{$companyId}"])->flush();
        
        // Dashboard also shows service stats
        $this->invalidateDashboard($companyId);
    }

    /**
     * Invalidate servers list cache
     */
    public function invalidateServersList(int $companyId): void
    {
        Log::info('Cache invalidation: Servers list', ['company_id' => $companyId]);
        Cache::tags([self::TAG_SERVERS, "company.{$companyId}"])->flush();
    }

    /**
     * Invalidate all cache for a company
     */
    public function invalidateAll(int $companyId): void
    {
        Log::info('Cache invalidation: ALL', ['company_id' => $companyId]);
        Cache::tags(["company.{$companyId}"])->flush();
    }

    /**
     * Generate cache key
     */
    private function makeKey(string $prefix, ...$parts): string
    {
        return $prefix . ':' . implode(':', $parts);
    }

    /**
     * Clear all cache (use with caution)
     */
    public function clearAll(): void
    {
        Log::warning('Cache cleared: ENTIRE CACHE');
        Cache::flush();
    }
}
