<?php

namespace App\Services;

use App\Jobs\DispatchWebhook;
use App\Models\WebhookDelivery;
use App\Models\WebhookEndpoint;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WebhookDispatcher
{
    /**
     * Mapeia categorias de evento para a flag do módulo que as habilita.
     */
    private const EVENT_TOGGLES = [
        'invoice' => 'send_invoice_events',
        'payment' => 'send_payment_events',
        'ticket'  => 'send_ticket_events',
        'client'  => 'send_client_events',
    ];

    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    /**
     * Ponto de entrada para disparar um evento (respeita módulo + toggles).
     * Nunca lança exceção para não impactar o fluxo de negócio.
     */
    public function event(int $companyId, string $event, array $data): void
    {
        try {
            if (!$this->modules->isEnabled($companyId, 'webhooks')) {
                return;
            }

            $cfg = $this->settings->all($companyId, 'webhooks');
            if (!($cfg['enabled'] ?? true)) {
                return;
            }

            $category = explode('.', $event)[0];
            $toggle = self::EVENT_TOGGLES[$category] ?? null;
            if ($toggle && !($cfg[$toggle] ?? true)) {
                return;
            }

            $this->queue($companyId, $event, $data);
        } catch (\Throwable $e) {
            Log::error("Webhook dispatch '{$event}' falhou: " . $e->getMessage());
        }
    }

    /**
     * Cria as entregas e enfileira o envio para cada endpoint inscrito.
     */
    public function queue(int $companyId, string $event, array $data): void
    {
        $endpoints = WebhookEndpoint::forCompany($companyId)->active()->get()
            ->filter(fn (WebhookEndpoint $e) => $e->listensTo($event));

        foreach ($endpoints as $endpoint) {
            $delivery = WebhookDelivery::create([
                'company_id'          => $companyId,
                'webhook_endpoint_id' => $endpoint->id,
                'event'               => $event,
                'payload'             => $this->buildPayload($event, $data),
                'status'              => 'pending',
            ]);

            DispatchWebhook::dispatch($delivery->id);
        }
    }

    /**
     * Executa o POST com assinatura e retentativas (chamado pelo job).
     */
    public function deliver(WebhookDelivery $delivery): void
    {
        $endpoint = $delivery->endpoint;
        if (!$endpoint || !$endpoint->is_active) {
            $delivery->update(['status' => 'failed', 'error' => 'Endpoint inativo ou removido.']);
            return;
        }

        $cfg = $this->settings->all($endpoint->company_id, 'webhooks');
        $maxAttempts = max(1, (int) ($cfg['retry_attempts'] ?? 3));
        $timeout = max(3, (int) ($cfg['timeout_seconds'] ?? 10));
        $secret = $endpoint->secret ?: ($cfg['secret_token'] ?? '');

        $payload = $delivery->payload ?? [];
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $signature = $secret ? hash_hmac('sha256', $json, $secret) : '';

        $attempts = 0;
        $success = false;
        $httpCode = null;
        $responseBody = null;
        $error = null;

        while ($attempts < $maxAttempts && !$success) {
            $attempts++;
            try {
                $response = Http::timeout($timeout)
                    ->withHeaders([
                        'Content-Type'             => 'application/json',
                        'User-Agent'               => 'CentralVix-Webhooks/1.0',
                        'X-CentralVix-Event'       => $delivery->event,
                        'X-CentralVix-Delivery'    => (string) $delivery->id,
                        'X-CentralVix-Signature'   => $signature,
                    ])
                    ->withBody($json, 'application/json')
                    ->post($endpoint->url);

                $httpCode = $response->status();
                $responseBody = mb_substr((string) $response->body(), 0, 1000);
                $success = $response->successful();

                if (!$success) {
                    $error = "HTTP {$httpCode}";
                }
            } catch (\Throwable $e) {
                $error = $e->getMessage();
            }

            if (!$success && $attempts < $maxAttempts) {
                usleep(300000); // 0,3s entre tentativas
            }
        }

        $delivery->update([
            'status'        => $success ? 'success' : 'failed',
            'http_code'     => $httpCode,
            'attempts'      => $attempts,
            'response_body' => $responseBody,
            'error'         => $success ? null : $error,
            'dispatched_at' => now(),
        ]);

        $endpoint->forceFill([
            'last_triggered_at'     => now(),
            'last_status'           => $success ? 'success' : 'failed',
            'consecutive_failures'  => $success ? 0 : ((int) $endpoint->consecutive_failures + 1),
        ]);

        // Desativa automaticamente após muitas falhas seguidas.
        if (!$success && (int) $endpoint->consecutive_failures >= 20) {
            $endpoint->is_active = false;
            Log::warning("Webhook endpoint #{$endpoint->id} desativado após 20 falhas consecutivas.");
        }

        $endpoint->save();
    }

    /**
     * Envia um disparo de teste imediato (síncrono).
     *
     * @return array{success: bool, message: string}
     */
    public function test(WebhookEndpoint $endpoint): array
    {
        $delivery = WebhookDelivery::create([
            'company_id'          => $endpoint->company_id,
            'webhook_endpoint_id' => $endpoint->id,
            'event'               => 'webhook.test',
            'payload'             => $this->buildPayload('webhook.test', ['message' => 'Disparo de teste do CentralVix.']),
            'status'              => 'pending',
        ]);

        $this->deliver($delivery);
        $delivery->refresh();

        return [
            'success' => $delivery->status === 'success',
            'message' => $delivery->status === 'success'
                ? "Teste enviado com sucesso (HTTP {$delivery->http_code})."
                : 'Falha no teste: ' . ($delivery->error ?: 'sem resposta'),
        ];
    }

    private function buildPayload(string $event, array $data): array
    {
        return [
            'event'     => $event,
            'timestamp' => now()->toIso8601String(),
            'data'      => $data,
        ];
    }
}
