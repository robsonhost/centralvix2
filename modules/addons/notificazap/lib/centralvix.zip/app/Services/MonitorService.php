<?php

namespace App\Services;

use App\Models\Monitor;
use App\Models\MonitorCheck;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class MonitorService
{
    /**
     * Verifica um monitor de disponibilidade (HTTP).
     */
    public function runUptime(Monitor $monitor, array $cfg = []): void
    {
        $timeout = (int) ($cfg['timeout_seconds'] ?? 10);
        $threshold = max(1, (int) ($cfg['failure_threshold'] ?? 2));

        $url = $this->normalizeUrl($monitor->target);
        $prevStatus = $monitor->status;

        $start = microtime(true);
        $isUp = false;
        $error = null;
        $code = null;

        try {
            $response = Http::timeout($timeout)
                ->withOptions(['allow_redirects' => true])
                ->withHeaders(['User-Agent' => 'CentralVix-Monitor/1.0'])
                ->get($url);

            $code = $response->status();
            $isUp = $code >= 200 && $code < 400;

            if (!$isUp) {
                $error = "HTTP {$code}";
            }
        } catch (\Throwable $e) {
            $error = $e->getMessage();
        }

        $ms = (int) round((microtime(true) - $start) * 1000);

        if ($isUp) {
            $newStatus = 'up';
            $monitor->consecutive_failures = 0;
        } else {
            $monitor->consecutive_failures = (int) $monitor->consecutive_failures + 1;
            $newStatus = $monitor->consecutive_failures >= $threshold ? 'down' : ($prevStatus === 'down' ? 'down' : 'warning');
        }

        $monitor->status = $newStatus;
        $monitor->last_response_time = $ms;
        $monitor->last_error = $error;
        $monitor->last_checked_at = now();
        if ($newStatus !== $prevStatus) {
            $monitor->last_status_change_at = now();
        }
        $monitor->save();

        $this->record($monitor, $isUp ? 'up' : 'down', $ms, $error ?? "HTTP {$code}");

        // Alertas em transições.
        $channels = $this->channels($cfg);
        if ($newStatus === 'down' && $prevStatus !== 'down') {
            $this->alert(
                $monitor,
                "🔴 {$monitor->name} está FORA DO AR",
                "O monitor \"{$monitor->name}\" ({$monitor->target}) está fora do ar.\nErro: " . ($error ?: 'sem resposta') . "\nHorário: " . now()->format('d/m/Y H:i'),
                $channels,
            );
        } elseif ($newStatus === 'up' && $prevStatus === 'down') {
            $this->alert(
                $monitor,
                "🟢 {$monitor->name} voltou ao ar",
                "O monitor \"{$monitor->name}\" ({$monitor->target}) voltou a responder normalmente.\nTempo de resposta: {$ms} ms\nHorário: " . now()->format('d/m/Y H:i'),
                $channels,
            );
        }
    }

    /**
     * Verifica a expiração do certificado SSL de um host.
     */
    public function runSsl(Monitor $monitor, array $cfg = []): void
    {
        $daysBefore = (int) ($cfg['days_before_expiry'] ?? 15);
        $prevStatus = $monitor->status;

        try {
            $info = $this->fetchSslExpiry($monitor->target);
        } catch (\Throwable $e) {
            $monitor->status = 'warning';
            $monitor->last_error = $e->getMessage();
            $monitor->last_checked_at = now();
            $monitor->save();
            $this->record($monitor, 'warning', null, $e->getMessage());
            return;
        }

        $expires = $info['expires_at'];
        $daysLeft = $expires ? (int) now()->startOfDay()->diffInDays($expires, false) : null;

        if ($daysLeft === null) {
            $newStatus = 'warning';
        } elseif ($daysLeft < 0) {
            $newStatus = 'down';     // expirado
        } elseif ($daysLeft <= $daysBefore) {
            $newStatus = 'warning';  // perto de expirar
        } else {
            $newStatus = 'up';
        }

        $monitor->status = $newStatus;
        $monitor->ssl_expires_at = $expires;
        $monitor->ssl_issuer = $info['issuer'];
        $monitor->last_error = null;
        $monitor->last_checked_at = now();
        if ($newStatus !== $prevStatus) {
            $monitor->last_status_change_at = now();
        }
        $monitor->save();

        $msg = $daysLeft === null
            ? 'Não foi possível determinar a validade.'
            : ($daysLeft < 0 ? 'Certificado EXPIRADO há ' . abs($daysLeft) . ' dia(s).' : "Expira em {$daysLeft} dia(s).");
        $this->record($monitor, $newStatus, null, $msg);

        // Alerta uma vez por dia enquanto em estado de risco.
        $channels = $this->channels($cfg);
        $alertedToday = $monitor->last_alert_at && $monitor->last_alert_at->isToday();

        if (in_array($newStatus, ['warning', 'down'], true) && !$alertedToday) {
            $subject = $newStatus === 'down'
                ? "🔴 SSL EXPIRADO: {$monitor->name}"
                : "🟡 SSL expira em breve: {$monitor->name}";

            $this->alert(
                $monitor,
                $subject,
                "Certificado SSL de \"{$monitor->target}\".\n{$msg}\n" .
                ($expires ? 'Validade: ' . $expires->format('d/m/Y') . "\n" : '') .
                ($monitor->ssl_issuer ? 'Emissor: ' . $monitor->ssl_issuer : ''),
                $channels,
            );

            $monitor->last_alert_at = now();
            $monitor->save();
        }
    }

    private function record(Monitor $monitor, string $status, ?int $ms, ?string $message): void
    {
        MonitorCheck::create([
            'monitor_id'    => $monitor->id,
            'status'        => $status,
            'response_time' => $ms,
            'message'       => $message ? mb_substr($message, 0, 250) : null,
            'checked_at'    => now(),
        ]);
    }

    private function channels(array $cfg): array
    {
        return [
            'email'    => (bool) ($cfg['alert_email'] ?? true),
            'whatsapp' => (bool) ($cfg['alert_whatsapp'] ?? false),
        ];
    }

    private function alert(Monitor $monitor, string $subject, string $body, array $channels): void
    {
        Log::warning("📡 [Monitor] {$subject} — {$monitor->target}");

        if (!empty($channels['email']) && $monitor->notify_email) {
            try {
                Mail::raw($body, function ($m) use ($monitor, $subject) {
                    $m->to($monitor->notify_email)->subject($subject);
                });
            } catch (\Throwable $e) {
                Log::error("Monitor e-mail falhou (#{$monitor->id}): " . $e->getMessage());
            }
        }

        if (!empty($channels['whatsapp']) && $monitor->notify_phone) {
            try {
                $phone = preg_replace('/\D/', '', $monitor->notify_phone);
                if ($phone && strlen($phone) === 11) {
                    $phone = '55' . $phone;
                }
                app(\App\Services\EvolutionWhatsAppService::class)->sendText($phone, "{$subject}\n\n{$body}");
            } catch (\Throwable $e) {
                Log::error("Monitor WhatsApp falhou (#{$monitor->id}): " . $e->getMessage());
            }
        }
    }

    private function normalizeUrl(string $target): string
    {
        $target = trim($target);
        if (!preg_match('#^https?://#i', $target)) {
            $target = 'https://' . $target;
        }

        return $target;
    }

    /**
     * @return array{expires_at: ?Carbon, issuer: ?string}
     */
    private function fetchSslExpiry(string $target): array
    {
        $host = preg_replace('#^https?://#i', '', trim($target));
        $host = explode('/', $host)[0];
        $host = explode(':', $host)[0];

        if ($host === '') {
            throw new \RuntimeException('Host inválido.');
        }

        $context = stream_context_create([
            'ssl' => [
                'capture_peer_cert' => true,
                'verify_peer' => false,
                'verify_peer_name' => false,
                'SNI_enabled' => true,
                'peer_name' => $host,
            ],
        ]);

        $client = @stream_socket_client(
            "ssl://{$host}:443",
            $errno,
            $errstr,
            10,
            STREAM_CLIENT_CONNECT,
            $context,
        );

        if (!$client) {
            throw new \RuntimeException($errstr ?: 'Falha ao conectar via SSL.');
        }

        $params = stream_context_get_params($client);
        $cert = $params['options']['ssl']['peer_certificate'] ?? null;
        fclose($client);

        if (!$cert || !function_exists('openssl_x509_parse')) {
            throw new \RuntimeException('Certificado não pôde ser lido.');
        }

        $parsed = openssl_x509_parse($cert);
        $expiryTs = $parsed['validTo_time_t'] ?? null;
        $issuer = $parsed['issuer']['O'] ?? ($parsed['issuer']['CN'] ?? null);

        return [
            'expires_at' => $expiryTs ? Carbon::createFromTimestamp($expiryTs) : null,
            'issuer' => $issuer,
        ];
    }
}
