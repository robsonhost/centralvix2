<?php

namespace App\Services\Examples;

use App\Helpers\LogContext;
use App\Traits\HasStructuredLogging;
use Illuminate\Support\Facades\Log;

/**
 * Billing Service Logging Example
 * 
 * Requirements: 65.1, 65.2
 * 
 * This example demonstrates proper structured logging for billing operations.
 * Use this as a reference when implementing billing services.
 */
class BillingLoggingExample
{
    use HasStructuredLogging;

    /**
     * Example: Generate invoice with logging
     */
    public function generateInvoiceExample($client, $service): object
    {
        $startTime = microtime(true);

        // Log invoice generation start
        $this->logBilling('info', 'Generating invoice', [
            'client_id' => $client->id,
            'client_email' => $client->email,
            'service_id' => $service->id,
            'service_name' => $service->name,
            'action' => 'generate_invoice'
        ]);

        try {
            // Create invoice (simulated)
            $invoice = $this->createInvoice($client, $service);

            // Log successful generation with details
            $this->logWithDuration(
                'billing',
                'info',
                'Invoice generated successfully',
                $startTime,
                LogContext::invoice($invoice->id, [
                    'client_id' => $client->id,
                    'service_id' => $service->id,
                    'amount' => $invoice->total,
                    'due_date' => $invoice->date_due,
                    'currency' => $invoice->currency
                ])
            );

            return $invoice;

        } catch (\Exception $e) {
            $this->logException(
                'billing',
                'Failed to generate invoice',
                $e,
                [
                    'client_id' => $client->id,
                    'service_id' => $service->id
                ]
            );

            throw $e;
        }
    }

    /**
     * Example: Process payment with comprehensive logging
     */
    public function processPaymentExample($invoice, $paymentData): bool
    {
        $startTime = microtime(true);

        // Log payment processing start
        Log::channel('billing')->info('Processing payment', LogContext::billing([
            'invoice_id' => $invoice->id,
            'client_id' => $invoice->client_id,
            'amount' => $paymentData['amount'],
            'gateway' => $paymentData['gateway'],
            'method' => $paymentData['method'],
            'action' => 'process_payment'
        ]));

        try {
            // Process payment through gateway
            $result = $this->chargeGateway($paymentData);

            if ($result['success']) {
                // Log successful payment
                $this->logWithDuration(
                    'billing',
                    'info',
                    'Payment processed successfully',
                    $startTime,
                    [
                        'invoice_id' => $invoice->id,
                        'client_id' => $invoice->client_id,
                        'amount' => $paymentData['amount'],
                        'gateway' => $paymentData['gateway'],
                        'transaction_id' => $result['transaction_id'],
                        'gateway_response' => $result
                    ]
                );

                // Log invoice status change
                Log::channel('billing')->info('Invoice marked as paid', LogContext::invoice($invoice->id, [
                    'client_id' => $invoice->client_id,
                    'payment_method' => $paymentData['method'],
                    'transaction_id' => $result['transaction_id']
                ]));

                return true;

            } else {
                // Log payment failure
                Log::channel('billing')->warning('Payment failed', LogContext::billing([
                    'invoice_id' => $invoice->id,
                    'client_id' => $invoice->client_id,
                    'amount' => $paymentData['amount'],
                    'gateway' => $paymentData['gateway'],
                    'error' => $result['error'],
                    'error_code' => $result['error_code'] ?? null
                ]));

                return false;
            }

        } catch (\Exception $e) {
            $this->logException(
                'billing',
                'Exception during payment processing',
                $e,
                [
                    'invoice_id' => $invoice->id,
                    'client_id' => $invoice->client_id,
                    'gateway' => $paymentData['gateway'],
                    'amount' => $paymentData['amount']
                ]
            );

            throw $e;
        }
    }

    /**
     * Example: Apply credit with logging
     */
    public function applyCreditExample($client, $amount, $reason): void
    {
        Log::channel('billing')->info('Applying credit to client', LogContext::billing([
            'client_id' => $client->id,
            'amount' => $amount,
            'reason' => $reason,
            'previous_balance' => $client->credit_balance,
            'action' => 'apply_credit'
        ]));

        try {
            // Apply credit
            $client->credit_balance += $amount;
            $client->save();

            Log::channel('billing')->info('Credit applied successfully', LogContext::client($client->id, [
                'amount' => $amount,
                'new_balance' => $client->credit_balance,
                'reason' => $reason
            ]));

        } catch (\Exception $e) {
            $this->logException(
                'billing',
                'Failed to apply credit',
                $e,
                [
                    'client_id' => $client->id,
                    'amount' => $amount
                ]
            );

            throw $e;
        }
    }

    /**
     * Example: Suspension due to non-payment
     */
    public function suspendForNonPaymentExample($service, $invoice): void
    {
        Log::channel('billing')->warning('Suspending service for non-payment', LogContext::billing([
            'service_id' => $service->id,
            'client_id' => $service->client_id,
            'invoice_id' => $invoice->id,
            'overdue_amount' => $invoice->total,
            'days_overdue' => now()->diffInDays($invoice->date_due),
            'action' => 'suspend_for_nonpayment'
        ]));

        try {
            // Perform suspension
            $service->status = 'suspended';
            $service->suspended_at = now();
            $service->suspension_reason = 'non_payment';
            $service->save();

            // Log to both billing and security channels
            $context = [
                'service_id' => $service->id,
                'client_id' => $service->client_id,
                'invoice_id' => $invoice->id,
                'overdue_amount' => $invoice->total
            ];

            Log::channel('billing')->info('Service suspended', LogContext::billing($context));
            Log::channel('security')->warning('Service suspended for non-payment', LogContext::security($context));

        } catch (\Exception $e) {
            $this->logException(
                'billing',
                'Failed to suspend service',
                $e,
                [
                    'service_id' => $service->id,
                    'invoice_id' => $invoice->id
                ]
            );

            throw $e;
        }
    }

    /**
     * Example: Refund with logging
     */
    public function processRefundExample($payment, $amount, $reason): bool
    {
        $startTime = microtime(true);

        Log::channel('billing')->info('Processing refund', LogContext::billing([
            'payment_id' => $payment->id,
            'invoice_id' => $payment->invoice_id,
            'client_id' => $payment->client_id,
            'amount' => $amount,
            'reason' => $reason,
            'gateway' => $payment->gateway,
            'action' => 'refund'
        ]));

        try {
            $result = $this->refundGateway($payment, $amount);

            if ($result['success']) {
                $this->logWithDuration(
                    'billing',
                    'info',
                    'Refund processed successfully',
                    $startTime,
                    [
                        'payment_id' => $payment->id,
                        'client_id' => $payment->client_id,
                        'amount' => $amount,
                        'refund_transaction_id' => $result['refund_id']
                    ]
                );

                return true;
            }

            Log::channel('billing')->error('Refund failed', LogContext::billing([
                'payment_id' => $payment->id,
                'amount' => $amount,
                'error' => $result['error']
            ]));

            return false;

        } catch (\Exception $e) {
            $this->logException(
                'billing',
                'Exception during refund processing',
                $e,
                ['payment_id' => $payment->id, 'amount' => $amount]
            );

            throw $e;
        }
    }

    /**
     * Stub methods (replace with actual implementations)
     */
    private function createInvoice($client, $service): object
    {
        return (object) [
            'id' => 1,
            'total' => 100.00,
            'date_due' => now()->addDays(7),
            'currency' => 'BRL'
        ];
    }

    private function chargeGateway($data): array
    {
        return ['success' => true, 'transaction_id' => 'TXN123'];
    }

    private function refundGateway($payment, $amount): array
    {
        return ['success' => true, 'refund_id' => 'REF123'];
    }
}
