<?php

namespace App\Services\Examples;

use App\Helpers\LogContext;
use App\Traits\HasStructuredLogging;
use Illuminate\Support\Facades\Log;

/**
 * Security Event Logging Example
 * 
 * Requirements: 65.1, 65.2
 * 
 * This example demonstrates proper structured logging for security events.
 * Use this as a reference when implementing authentication and authorization.
 */
class SecurityLoggingExample
{
    use HasStructuredLogging;

    /**
     * Example: Successful login
     */
    public function logSuccessfulLoginExample($user, $request): void
    {
        Log::channel('security')->info('User logged in successfully', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'action' => 'login_success',
            'login_method' => '2fa_enabled' ? '2fa' : 'password'
        ]));
    }

    /**
     * Example: Failed login attempt
     */
    public function logFailedLoginExample($email, $request, $reason): void
    {
        Log::channel('security')->warning('Failed login attempt', LogContext::security([
            'email' => $email,
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'reason' => $reason, // 'invalid_password', 'user_not_found', 'account_locked'
            'action' => 'login_failed'
        ]));
    }

    /**
     * Example: Password change
     */
    public function logPasswordChangeExample($user, $changedBy = null): void
    {
        $context = [
            'user_id' => $user->id,
            'email' => $user->email,
            'action' => 'password_changed'
        ];

        // Log who initiated the change
        if ($changedBy && $changedBy->id !== $user->id) {
            $context['changed_by_admin_id'] = $changedBy->id;
            $context['changed_by_email'] = $changedBy->email;
        } else {
            $context['self_service'] = true;
        }

        Log::channel('security')->info('Password changed', LogContext::security($context));
    }

    /**
     * Example: Permission change
     */
    public function logPermissionChangeExample($user, $admin, $oldRole, $newRole): void
    {
        Log::channel('security')->warning('User permissions changed', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'admin_id' => $admin->id,
            'admin_email' => $admin->email,
            'old_role' => $oldRole,
            'new_role' => $newRole,
            'action' => 'permission_changed'
        ]));
    }

    /**
     * Example: Account lockout
     */
    public function logAccountLockoutExample($user, $reason): void
    {
        Log::channel('security')->error('Account locked', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'reason' => $reason, // 'too_many_failed_attempts', 'suspicious_activity', 'admin_action'
            'locked_at' => now()->toIso8601String(),
            'action' => 'account_locked'
        ]));
    }

    /**
     * Example: Suspicious activity detected
     */
    public function logSuspiciousActivityExample($user, $activity, $details): void
    {
        Log::channel('security')->critical('Suspicious activity detected', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'activity_type' => $activity, // 'unusual_location', 'rapid_requests', 'multiple_ips'
            'details' => $details,
            'action' => 'suspicious_activity'
        ]));
    }

    /**
     * Example: API key generation
     */
    public function logApiKeyGeneratedExample($user, $keyName, $scopes): void
    {
        Log::channel('security')->info('API key generated', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'key_name' => $keyName,
            'scopes' => $scopes,
            'action' => 'api_key_generated'
        ]));
    }

    /**
     * Example: API key revoked
     */
    public function logApiKeyRevokedExample($user, $keyName, $revokedBy = null): void
    {
        $context = [
            'user_id' => $user->id,
            'email' => $user->email,
            'key_name' => $keyName,
            'action' => 'api_key_revoked'
        ];

        if ($revokedBy && $revokedBy->id !== $user->id) {
            $context['revoked_by_admin_id'] = $revokedBy->id;
            $context['revoked_by_email'] = $revokedBy->email;
        }

        Log::channel('security')->warning('API key revoked', LogContext::security($context));
    }

    /**
     * Example: Two-factor authentication enabled
     */
    public function log2FAEnabledExample($user): void
    {
        Log::channel('security')->info('Two-factor authentication enabled', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'action' => '2fa_enabled'
        ]));
    }

    /**
     * Example: Two-factor authentication disabled
     */
    public function log2FADisabledExample($user, $disabledBy = null): void
    {
        $context = [
            'user_id' => $user->id,
            'email' => $user->email,
            'action' => '2fa_disabled'
        ];

        if ($disabledBy && $disabledBy->id !== $user->id) {
            $context['disabled_by_admin_id'] = $disabledBy->id;
            $context['disabled_by_email'] = $disabledBy->email;
            Log::channel('security')->warning('2FA disabled by admin', LogContext::security($context));
        } else {
            Log::channel('security')->info('2FA disabled', LogContext::security($context));
        }
    }

    /**
     * Example: Session hijacking attempt detected
     */
    public function logSessionHijackingExample($user, $originalIp, $newIp): void
    {
        Log::channel('security')->critical('Possible session hijacking detected', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'original_ip' => $originalIp,
            'new_ip' => $newIp,
            'action' => 'session_hijack_attempt'
        ]));
    }

    /**
     * Example: Data export request
     */
    public function logDataExportExample($user, $exportType, $recordCount): void
    {
        Log::channel('security')->info('Data export performed', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'export_type' => $exportType, // 'clients', 'invoices', 'services'
            'record_count' => $recordCount,
            'action' => 'data_export'
        ]));
    }

    /**
     * Example: Sensitive setting changed
     */
    public function logSensitiveSettingChangeExample($admin, $settingKey, $oldValue, $newValue): void
    {
        Log::channel('security')->warning('Sensitive setting changed', LogContext::security([
            'admin_id' => $admin->id,
            'admin_email' => $admin->email,
            'setting_key' => $settingKey,
            'old_value' => $this->maskSensitiveValue($oldValue),
            'new_value' => $this->maskSensitiveValue($newValue),
            'action' => 'setting_changed'
        ]));
    }

    /**
     * Example: Failed authorization attempt
     */
    public function logUnauthorizedAccessExample($user, $resource, $action): void
    {
        Log::channel('security')->warning('Unauthorized access attempt', LogContext::security([
            'user_id' => $user->id,
            'email' => $user->email,
            'resource' => $resource, // 'client:123', 'invoice:456'
            'attempted_action' => $action, // 'view', 'edit', 'delete'
            'action' => 'unauthorized_access'
        ]));
    }

    /**
     * Example: IP banned
     */
    public function logIpBannedExample($ip, $reason, $bannedBy): void
    {
        Log::channel('security')->error('IP address banned', LogContext::security([
            'banned_ip' => $ip,
            'reason' => $reason,
            'banned_by_admin_id' => $bannedBy->id,
            'banned_by_email' => $bannedBy->email,
            'action' => 'ip_banned'
        ]));
    }

    /**
     * Mask sensitive values for logging
     */
    private function maskSensitiveValue($value): string
    {
        if (strlen($value) <= 4) {
            return '****';
        }
        return substr($value, 0, 2) . str_repeat('*', strlen($value) - 4) . substr($value, -2);
    }
}
