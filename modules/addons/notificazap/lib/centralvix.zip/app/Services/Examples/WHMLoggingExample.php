<?php

namespace App\Services\Examples;

use App\Helpers\LogContext;
use App\Traits\HasStructuredLogging;
use Illuminate\Support\Facades\Log;

/**
 * WHM Service Logging Example
 * 
 * Requirements: 65.1, 65.2
 * 
 * This example demonstrates proper structured logging for WHM operations.
 * Use this as a reference when implementing WHM integration services.
 */
class WHMLoggingExample
{
    use HasStructuredLogging;

    /**
     * Example: Suspend account with structured logging
     */
    public function suspendAccountExample($server, $username, $reason): bool
    {
        $startTime = microtime(true);
        
        // Log the start of the operation
        $this->logWhm('info', 'Starting account suspension', [
            'server_id' => $server->id,
            'server_hostname' => $server->hostname,
            'username' => $username,
            'reason' => $reason,
            'action' => 'suspend'
        ]);

        try {
            // Simulate WHM API call
            $response = $this->callWhmApi($server, 'suspendacct', [
                'user' => $username,
                'reason' => $reason
            ]);

            if ($response['result'] === 1) {
                // Log successful suspension with duration
                $this->logWithDuration(
                    'whm',
                    'info',
                    'Account suspended successfully',
                    $startTime,
                    [
                        'server_id' => $server->id,
                        'username' => $username,
                        'whm_response' => $response
                    ]
                );

                return true;
            } else {
                // Log API failure
                $this->logWhm('error', 'WHM API returned error', [
                    'server_id' => $server->id,
                    'username' => $username,
                    'error' => $response['reason'] ?? 'Unknown error',
                    'whm_response' => $response
                ]);

                return false;
            }

        } catch (\Exception $e) {
            // Log exception with full context
            $this->logException(
                'whm',
                'Exception during account suspension',
                $e,
                [
                    'server_id' => $server->id,
                    'server_hostname' => $server->hostname,
                    'username' => $username,
                    'reason' => $reason
                ]
            );

            throw $e;
        }
    }

    /**
     * Example: Create account with detailed logging
     */
    public function createAccountExample($server, array $accountData): array
    {
        $startTime = microtime(true);

        // Log account creation start
        Log::channel('whm')->info('Creating WHM account', LogContext::whm([
            'server_id' => $server->id,
            'username' => $accountData['username'],
            'domain' => $accountData['domain'],
            'package' => $accountData['package'],
            'action' => 'create'
        ]));

        try {
            $response = $this->callWhmApi($server, 'createacct', $accountData);

            $duration = (microtime(true) - $startTime) * 1000;

            if ($response['result'][0]['status'] === 1) {
                // Log success with all relevant details
                Log::channel('whm')->info(
                    'Account created successfully',
                    LogContext::whm([
                        'server_id' => $server->id,
                        'username' => $accountData['username'],
                        'domain' => $accountData['domain'],
                        'package' => $accountData['package'],
                        'duration_ms' => round($duration, 2),
                        'whm_account_id' => $response['result'][0]['options']['account_id'] ?? null
                    ])
                );

                return $response;
            } else {
                // Log creation failure
                Log::channel('whm')->error(
                    'Account creation failed',
                    LogContext::whm([
                        'server_id' => $server->id,
                        'username' => $accountData['username'],
                        'error' => $response['result'][0]['statusmsg'] ?? 'Unknown error',
                        'duration_ms' => round($duration, 2)
                    ])
                );

                throw new \Exception($response['result'][0]['statusmsg'] ?? 'Account creation failed');
            }

        } catch (\Exception $e) {
            Log::channel('whm')->error(
                'Exception during account creation',
                LogContext::exception($e, LogContext::whm([
                    'server_id' => $server->id,
                    'username' => $accountData['username'],
                    'domain' => $accountData['domain']
                ]))
            );

            throw $e;
        }
    }

    /**
     * Example: DNS zone operation logging
     */
    public function addDnsRecordExample($server, $domain, $record): bool
    {
        Log::channel('whm')->info('Adding DNS record', LogContext::whm([
            'server_id' => $server->id,
            'domain' => $domain,
            'record_type' => $record['type'],
            'record_name' => $record['name'],
            'record_value' => $record['value'],
            'action' => 'dns_add'
        ]));

        try {
            $response = $this->callWhmApi($server, 'mass_edit_dns_zone', [
                'zone' => $domain,
                'serial' => time(),
                'add' => json_encode($record)
            ]);

            if ($response['result'][0]['status'] === 1) {
                Log::channel('whm')->info('DNS record added', LogContext::whm([
                    'server_id' => $server->id,
                    'domain' => $domain,
                    'record_type' => $record['type']
                ]));

                return true;
            }

            Log::channel('whm')->error('Failed to add DNS record', LogContext::whm([
                'server_id' => $server->id,
                'domain' => $domain,
                'error' => $response['result'][0]['statusmsg'] ?? 'Unknown error'
            ]));

            return false;

        } catch (\Exception $e) {
            $this->logException('whm', 'DNS record addition failed', $e, [
                'server_id' => $server->id,
                'domain' => $domain,
                'record' => $record
            ]);

            throw $e;
        }
    }

    /**
     * Simulate WHM API call (replace with actual implementation)
     */
    private function callWhmApi($server, $function, array $params): array
    {
        // This is just a stub - replace with actual WHM API implementation
        return ['result' => 1];
    }
}
