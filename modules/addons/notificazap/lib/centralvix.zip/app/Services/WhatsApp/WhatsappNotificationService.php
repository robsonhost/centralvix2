<?php

namespace App\Services\WhatsApp;

use App\Models\Client;
use App\Models\NotificationLog;
use App\Models\WhatsappInstance;
use App\Models\WhatsappMessage;
use App\Models\WhatsappTemplate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * CentralVix Notifications — WhatsApp channel.
 *
 * Core service responsible for resolving the right instance,
 * rendering templates, dispatching messages and logging every delivery.
 */
class WhatsappNotificationService
{
    public function __construct(
        private EvolutionGoService $evolution
    ) {}

    /**
     * Send a templated notification to a client.
     */
    public function notifyClient(
        Client $client,
        string $event,
        array  $data = [],
        string $contextType = '',
        int    $contextId   = 0
    ): bool {
        if (!config('whatsapp.enabled', true)) return false;

        $phone = $this->resolvePhone($client);
        if (!$phone) {
            Log::debug("WhatsApp: no phone for client #{$client->id}");
            return false;
        }

        $template = WhatsappTemplate::where('company_id', $client->company_id)
            ->where('slug', $event)
            ->where('is_active', true)
            ->first();

        if (!$template) {
            Log::debug("WhatsApp: template '{$event}' not found for company {$client->company_id}");
            return false;
        }

        $rendered = $template->render(
            app(\App\Services\AutoLoginService::class)->enrichWhatsAppTemplateData(
                $client,
                array_merge($this->clientVars($client), $data),
                $contextType,
                $contextId,
            )
        );

        $instance = $this->resolveInstance($client->company_id);
        if (!$instance || !$instance->isConnected()) {
            $this->logNotification($client, $event, 'whatsapp', $phone, $template->slug, $rendered, 'failed', 'No active instance', $contextType, $contextId);
            return false;
        }

        return $this->sendAndLog(
            $instance, $client, $phone, $template, $rendered, $event, $contextType, $contextId
        );
    }

    /**
     * Send a raw text message (not template-based).
     */
    public function sendRaw(
        int    $companyId,
        string $phone,
        string $text,
        ?Client $client     = null,
        string  $contextType = '',
        int     $contextId   = 0
    ): bool {
        $instance = $this->resolveInstance($companyId);
        if (!$instance || !$instance->isConnected()) return false;

        $evolution = new EvolutionGoService($instance);
        $result    = $evolution->sendText($instance->instance_key, $phone, $text);

        $this->storeMessage($instance, $phone, 'text', $text, $result, $client, $contextType, $contextId);

        return isset($result['key']['id']);
    }

    /**
     * Dispatch a specific notification event by name.
     * Alias used by NotificationService for multi-channel dispatch.
     */
    public function dispatch(
        Client $client,
        string $event,
        array  $data = [],
        string $contextType = '',
        int    $contextId   = 0
    ): void {
        $this->notifyClient($client, $event, $data, $contextType, $contextId);
    }

    // ============================
    // NAMED NOTIFICATION METHODS
    // ============================

    // --- Financeiro ---
    public function invoiceCreated(Client $c, array $d): bool  { return $this->notifyClient($c, 'invoice_created', $d, 'invoice', $d['invoice_id'] ?? 0); }
    public function invoicePaid(Client $c, array $d): bool     { return $this->notifyClient($c, 'invoice_paid', $d, 'invoice', $d['invoice_id'] ?? 0); }
    public function invoiceOverdue(Client $c, array $d): bool  { return $this->notifyClient($c, 'invoice_overdue', $d, 'invoice', $d['invoice_id'] ?? 0); }
    public function invoiceCancelled(Client $c, array $d): bool{ return $this->notifyClient($c, 'invoice_cancelled', $d, 'invoice', $d['invoice_id'] ?? 0); }
    public function pixGenerated(Client $c, array $d): bool    { return $this->notifyClient($c, 'pix_generated', $d, 'invoice', $d['invoice_id'] ?? 0); }
    public function pixPaid(Client $c, array $d): bool         { return $this->notifyClient($c, 'pix_paid', $d, 'invoice', $d['invoice_id'] ?? 0); }
    public function paymentConfirmed(Client $c, array $d): bool{ return $this->notifyClient($c, 'payment_confirmed', $d, 'invoice', $d['invoice_id'] ?? 0); }
    public function paymentFailed(Client $c, array $d): bool   { return $this->notifyClient($c, 'payment_failed', $d); }
    public function refundDone(Client $c, array $d): bool      { return $this->notifyClient($c, 'refund_done', $d); }

    // --- Clientes ---
    public function welcome(Client $c): bool          { return $this->notifyClient($c, 'client_welcome', $this->clientVars($c)); }
    public function passwordChanged(Client $c): bool  { return $this->notifyClient($c, 'password_changed', $this->clientVars($c)); }

    // --- Serviços ---
    public function serviceCreated(Client $c, array $d): bool  { return $this->notifyClient($c, 'service_created', $d, 'service', $d['service_id'] ?? 0); }
    public function serviceActivated(Client $c, array $d): bool{ return $this->notifyClient($c, 'service_activated', $d, 'service', $d['service_id'] ?? 0); }
    public function serviceSuspended(Client $c, array $d): bool{ return $this->notifyClient($c, 'service_suspended', $d, 'service', $d['service_id'] ?? 0); }
    public function serviceReactivated(Client $c, array $d): bool { return $this->notifyClient($c, 'service_reactivated', $d, 'service', $d['service_id'] ?? 0); }
    public function serviceCancelled(Client $c, array $d): bool{ return $this->notifyClient($c, 'service_cancelled', $d, 'service', $d['service_id'] ?? 0); }

    // --- Tickets ---
    public function ticketOpened(Client $c, array $d): bool    { return $this->notifyClient($c, 'ticket_opened', $d, 'ticket', $d['ticket_id'] ?? 0); }
    public function ticketReplied(Client $c, array $d): bool   { return $this->notifyClient($c, 'ticket_replied', $d, 'ticket', $d['ticket_id'] ?? 0); }
    public function ticketClosed(Client $c, array $d): bool    { return $this->notifyClient($c, 'ticket_closed', $d, 'ticket', $d['ticket_id'] ?? 0); }
    public function ticketUrgent(Client $c, array $d): bool    { return $this->notifyClient($c, 'ticket_urgent', $d, 'ticket', $d['ticket_id'] ?? 0); }

    // --- Domínios ---
    public function domainExpiring(Client $c, array $d): bool  { return $this->notifyClient($c, 'domain_expiring', $d, 'domain', $d['domain_id'] ?? 0); }
    public function domainExpired(Client $c, array $d): bool   { return $this->notifyClient($c, 'domain_expired', $d, 'domain', $d['domain_id'] ?? 0); }
    public function domainRenewed(Client $c, array $d): bool   { return $this->notifyClient($c, 'domain_renewed', $d, 'domain', $d['domain_id'] ?? 0); }

    // --- SSL ---
    public function sslExpiring(Client $c, array $d): bool     { return $this->notifyClient($c, 'ssl_expiring', $d); }

    // --- Contratos ---
    public function contractSent(Client $c, array $d): bool    { return $this->notifyClient($c, 'contract_sent', $d, 'contract', $d['contract_id'] ?? 0); }
    public function contractSigned(Client $c, array $d): bool  { return $this->notifyClient($c, 'contract_signed', $d, 'contract', $d['contract_id'] ?? 0); }

    // ============================
    // PRIVATE HELPERS
    // ============================

    private function sendAndLog(
        WhatsappInstance $instance,
        Client $client,
        string $phone,
        WhatsappTemplate $template,
        string $rendered,
        string $event,
        string $contextType,
        int    $contextId
    ): bool {
        $evolution = new EvolutionGoService($instance);

        try {
            $result = match ($template->type) {
                'buttons'  => $evolution->sendButtons($instance->instance_key, $phone, $rendered, config('app.name'), $template->buttons ?? []),
                'list'     => $evolution->sendList($instance->instance_key, $phone, config('app.name'), $rendered, 'Ver opções', $template->list ?? []),
                'image'    => $evolution->sendMedia($instance->instance_key, $phone, 'image', $template->variables['media_url'] ?? '', $rendered),
                'document' => $evolution->sendMedia($instance->instance_key, $phone, 'document', $template->variables['media_url'] ?? '', $rendered),
                default    => $evolution->sendText($instance->instance_key, $phone, $rendered),
            };

            $success = isset($result['key']['id']) || isset($result['message']);
            $msgId   = $result['key']['id'] ?? null;

            $this->storeMessage($instance, $phone, $template->type, $rendered, $result, $client, $contextType, $contextId, $template->slug, $msgId);
            $this->logNotification($client, $event, 'whatsapp', $phone, $template->slug, $rendered, $success ? 'sent' : 'failed', $result['error'] ?? null, $contextType, $contextId, $msgId);

            return $success;
        } catch (\Exception $e) {
            Log::error("WhatsApp send failed [{$event}]: " . $e->getMessage());
            $this->logNotification($client, $event, 'whatsapp', $phone, $template->slug, $rendered, 'failed', $e->getMessage(), $contextType, $contextId);
            return false;
        }
    }

    private function storeMessage(
        WhatsappInstance $instance,
        string $phone,
        string $type,
        string $content,
        array  $result,
        ?Client $client,
        string $contextType,
        int    $contextId,
        ?string $templateSlug = null,
        ?string $msgId        = null
    ): WhatsappMessage {
        return WhatsappMessage::create([
            'uuid'          => Str::uuid(),
            'company_id'    => $instance->company_id,
            'instance_id'   => $instance->id,
            'client_id'     => $client?->id,
            'to_number'     => $phone,
            'template_slug' => $templateSlug,
            'type'          => $type,
            'content'       => $content,
            'message_id'    => $msgId,
            'status'        => $msgId ? 'sent' : 'failed',
            'error_message' => $result['error'] ?? null,
            'context_type'  => $contextType ?: null,
            'context_id'    => $contextId ?: null,
            'sent_by'       => 'system',
            'sent_at'       => now(),
            'raw_response'  => $result,
        ]);
    }

    private function logNotification(
        Client $client,
        string $event,
        string $channel,
        string $recipient,
        string $templateSlug,
        string $rendered,
        string $status,
        ?string $error,
        string $contextType,
        int    $contextId,
        ?string $externalId = null
    ): void {
        NotificationLog::create([
            'uuid'             => Str::uuid(),
            'company_id'       => $client->company_id,
            'client_id'        => $client->id,
            'event'            => $event,
            'channel'          => $channel,
            'recipient'        => $recipient,
            'template_slug'    => $templateSlug,
            'rendered_content' => $rendered,
            'status'           => $status,
            'error'            => $error,
            'external_id'      => $externalId,
            'context_type'     => $contextType ?: null,
            'context_id'       => $contextId ?: null,
            'sent_at'          => $status === 'sent' ? now() : null,
        ]);
    }

    private function resolveInstance(int $companyId): ?WhatsappInstance
    {
        return WhatsappInstance::where('company_id', $companyId)
            ->where('is_active', true)
            ->where('status', 'connected')
            ->orderByDesc('is_default')
            ->first();
    }

    private function resolvePhone(Client $client): ?string
    {
        $phone = $client->whatsapp ?? $client->mobile ?? $client->phone ?? null;
        if (!$phone) return null;

        $phone = preg_replace('/\D/', '', $phone);

        if (strlen($phone) >= 10 && !str_starts_with($phone, '55')) {
            $phone = '55' . $phone;
        }

        return strlen($phone) >= 12 ? $phone : null;
    }

    private function clientVars(Client $client): array
    {
        return [
            'client_name'     => $client->display_name,
            'client_email'    => $client->email,
            'client_code'     => $client->client_code,
            'company_name'    => $client->company?->name ?? config('app.name'),
            'support_url'     => url('/client/tickets/create'),
            'portal_url'      => url('/client'),
        ];
    }
}
