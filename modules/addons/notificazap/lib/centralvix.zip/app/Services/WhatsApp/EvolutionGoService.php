<?php

namespace App\Services\WhatsApp;

use App\Models\WhatsappInstance;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class EvolutionGoService
{
    private string $baseUrl;
    private string $apiKey;

    public function __construct(
        private ?WhatsappInstance $instance = null
    ) {
        if ($instance) {
            $this->baseUrl = rtrim($instance->getEffectiveApiUrl(), '/');
            $this->apiKey  = $instance->getEffectiveApiKey() ?: (string) config('whatsapp.evolution_go.api_key', '');
        } else {
            $this->baseUrl = rtrim((string) config('whatsapp.evolution_go.url', ''), '/');
            $this->apiKey  = (string) config('whatsapp.evolution_go.api_key', '');
        }

        $this->baseUrl = $this->normalizeBaseUrl($this->baseUrl);
    }

    private function normalizeBaseUrl(string $url): string
    {
        $url = rtrim(trim($url), '/');

        $fixes = [
            'https://evolution.centralvix.com.br.br' => 'https://evolution.centralvix.com.br',
            'http://evolution.centralvix.com.br.br' => 'http://evolution.centralvix.com.br',
            'https://evolution.centralvix.com' => 'https://evolution.centralvix.com.br',
            'http://evolution.centralvix.com' => 'http://evolution.centralvix.com.br',
        ];

        foreach ($fixes as $from => $to) {
            if (str_starts_with($url, $from)) {
                $url = $to . substr($url, strlen($from));
                break;
            }
        }

        $envUrl = rtrim(trim((string) config('whatsapp.evolution_go.url', '')), '/');
        if ($envUrl !== '' && preg_match('#^https?://(evolution\.centralvix\.com(\.br)?)#i', $url)) {
            return $envUrl;
        }

        return (string) preg_replace('#(\.com\.br)\.br(?=/|$)#', '$1', $url);
    }

    public function hasValidConfig(): bool
    {
        return $this->baseUrl !== '' && filter_var($this->baseUrl, FILTER_VALIDATE_URL);
    }

    public function usesGoApi(): bool
    {
        if ($this->instance && $this->instance->provider === 'evolution_go') {
            return true;
        }

        return (bool) config('whatsapp.evolution_go.enabled', true)
            && str_contains(strtolower($this->baseUrl), 'gestaovix');
    }

    /**
     * Resolve o token UUID da instância no Evolution Go (painel GestãoVix).
     */
    public function resolveInstanceToken(string $instanceName): ?string
    {
        $fromModel = $this->instance?->getEvolutionToken();
        if ($fromModel) {
            return $fromModel;
        }

        $fromEnv = trim((string) config('whatsapp.evolution_go.instance_token', ''));
        if ($fromEnv !== '') {
            return $fromEnv;
        }

        if (!$this->usesGoApi()) {
            return null;
        }

        $all = $this->goRequest('GET', '/instance/all', [], null, true);
        if (!($all['success'] ?? false)) {
            return null;
        }

        $instances = $all['data']['data'] ?? $all['data'] ?? [];
        if (!is_array($instances)) {
            return null;
        }

        foreach ($instances as $row) {
            if (!is_array($row)) {
                continue;
            }
            $name = (string) ($row['name'] ?? $row['instanceName'] ?? '');
            if (strcasecmp($name, $instanceName) === 0) {
                return (string) ($row['token'] ?? $row['id'] ?? '') ?: null;
            }
        }

        return null;
    }

    // ===== INSTANCE MANAGEMENT =====

    public function createInstance(string $instanceName, array $options = []): array
    {
        if ($this->usesGoApi()) {
            return $this->goRequest('POST', '/instance/create', array_merge([
                'instanceName' => $instanceName,
                'integration'  => 'WHATSAPP-BAILEYS',
            ], $options), null, true);
        }

        $displayName = $options['name'] ?? $instanceName;

        return $this->legacyPost('/instance/create', array_merge([
            'instanceName' => $instanceName,
            'name'         => $displayName,
            'qrcode'       => true,
            'integration'  => 'WHATSAPP-BAILEYS',
        ], $options));
    }

    public function getInstanceInfo(string $instanceName): array
    {
        if ($this->usesGoApi()) {
            return $this->goRequest('GET', '/instance/all', [], null, true);
        }

        return $this->legacyGet("/instance/fetchInstances?instanceName={$instanceName}");
    }

    public function getQrCode(string $instanceName): array
    {
        if ($this->usesGoApi()) {
            $token = $this->resolveInstanceToken($instanceName);
            if (!$token) {
                return $this->failureResponse('Token da instância não encontrado no Evolution Go.');
            }

            return $this->goRequest('GET', '/instance/qr', [], $token);
        }

        return $this->legacyGet("/instance/connect/{$instanceName}");
    }

    public function restartInstance(string $instanceName): array
    {
        if ($this->usesGoApi()) {
            $token = $this->resolveInstanceToken($instanceName);
            if (!$token) {
                return $this->failureResponse('Token da instância não encontrado no Evolution Go.');
            }

            $disconnect = $this->goRequest('POST', '/instance/disconnect', [], $token);
            if (!$disconnect['success']) {
                return $disconnect;
            }

            return $this->connectInstance($instanceName);
        }

        return $this->legacyDelete("/instance/restart/{$instanceName}");
    }

    public function logoutInstance(string $instanceName): array
    {
        return $this->disconnectInstance($instanceName);
    }

    public function deleteInstance(string $instanceName): array
    {
        if ($this->usesGoApi()) {
            $token = $this->resolveInstanceToken($instanceName);

            return $this->goRequest('POST', '/instance/delete', [], $token ?: null, !$token);
        }

        return $this->legacyDelete("/instance/delete/{$instanceName}");
    }

    public function getConnectionState(string $instanceName): array
    {
        if ($this->usesGoApi()) {
            return $this->getInstanceStatus($instanceName);
        }

        return $this->legacyGet("/instance/connectionState/{$instanceName}");
    }

    public function connectInstance(string $instanceName): array
    {
        if ($this->usesGoApi()) {
            $token = $this->resolveInstanceToken($instanceName);
            if (!$token) {
                return $this->failureResponse(
                    'Instância "' . $instanceName . '" não encontrada no Evolution Go. Informe o Token UUID ou confirme o nome no painel.'
                );
            }

            $status = $this->getInstanceStatus($instanceName);
            if ($status['success'] && ($status['data']['connected'] ?? false)) {
                return array_merge($status, ['already_connected' => true]);
            }

            $webhookUrl = $this->instance
                ? route('api.whatsapp.webhook', ['instance' => $this->instance->instance_key])
                : '';

            $result = $this->goRequest('POST', '/instance/connect', array_filter([
                'immediate'  => true,
                'subscribe'  => ['ALL'],
                'webhookUrl' => $webhookUrl !== '' ? $webhookUrl : null,
            ]), $token);

            if (($result['success'] ?? false) && !$result['qrcode']) {
                $qr = $this->goRequest('GET', '/instance/qr', [], $token);
                if ($qr['success'] && $qr['qrcode']) {
                    $result['qrcode'] = $qr['qrcode'];
                }
            }

            return $result;
        }

        return $this->legacyGet("/instance/connect/{$instanceName}");
    }

    public function disconnectInstance(string $instanceName): array
    {
        if ($this->usesGoApi()) {
            $token = $this->resolveInstanceToken($instanceName);
            if (!$token) {
                return $this->failureResponse('Token da instância não encontrado no Evolution Go.');
            }

            return $this->goRequest('POST', '/instance/disconnect', [], $token);
        }

        return $this->legacyDelete("/instance/logout/{$instanceName}");
    }

    public function getInstanceStatus(string $instanceName): array
    {
        if ($this->usesGoApi()) {
            $token = $this->resolveInstanceToken($instanceName);
            if (!$token) {
                return $this->failureResponse('Token da instância não encontrado no Evolution Go.');
            }

            $state = $this->goRequest('GET', '/instance/status', [], $token);
            if (!($state['success'] ?? false)) {
                return $state;
            }

            $inner = $state['data']['data'] ?? $state['data'] ?? [];
            $connected = (bool) ($inner['Connected'] ?? $inner['connected'] ?? false)
                || (bool) ($inner['LoggedIn'] ?? $inner['loggedIn'] ?? false);

            return [
                'success' => true,
                'status'  => $state['status'] ?? 200,
                'data'    => [
                    'instance'  => $instanceName,
                    'state'     => $connected ? 'open' : 'close',
                    'connected' => $connected,
                    'raw'       => $inner,
                    'jid'       => $inner['jid'] ?? $inner['Jid'] ?? null,
                ],
                'message' => $state['message'] ?? 'success',
            ];
        }

        $state = $this->legacyGet("/instance/connectionState/{$instanceName}");

        return [
            'success' => $state['success'] ?? false,
            'status'  => $state['status'] ?? 500,
            'data'    => [
                'instance'  => $instanceName,
                'state'     => $state['data']['state'] ?? 'unknown',
                'connected' => ($state['data']['state'] ?? '') === 'open',
            ],
            'message' => $state['message'] ?? 'Failed to get instance status',
        ];
    }

    // ===== SEND MESSAGES =====

    /**
     * Send plain text message.
     */
    public function sendText(string $instanceName, string $number, string $text, ?string $delay = null): array
    {
        if ($this->usesGoApi()) {
            $token = $this->resolveInstanceToken($instanceName);
            if (!$token) {
                return $this->failureResponse('Token da instância não encontrado no Evolution Go.');
            }

            return $this->goRequest('POST', '/send/text', [
                'number' => $this->formatNumber($number),
                'text'   => $text,
                'delay'  => $delay ? (int) $delay : 1200,
            ], $token);
        }

        return $this->legacyPost("/message/sendText/{$instanceName}", [
            'number'  => $this->formatNumber($number),
            'text'    => $text,
            'delay'   => $delay,
            'options' => ['delay' => 1200, 'presence' => 'composing'],
        ]);
    }

    /**
     * Send media (image, video, document, audio).
     */
    public function sendMedia(string $instanceName, string $number, string $type, string $url, string $caption = '', string $filename = ''): array
    {
        return $this->post("/message/sendMedia/{$instanceName}", [
            'number'   => $this->formatNumber($number),
            'mediatype' => $type,
            'mimetype'  => $this->getMimeType($type),
            'media'     => $url,
            'caption'   => $caption,
            'fileName'  => $filename,
        ]);
    }

    /**
     * Send message with buttons.
     */
    public function sendButtons(string $instanceName, string $number, string $text, string $title, array $buttons, string $footer = ''): array
    {
        $formattedButtons = array_map(fn($b, $i) => [
            'type'       => 'reply',
            'displayText'=> $b['text'],
            'id'         => $b['id'] ?? 'btn_' . $i,
        ], $buttons, array_keys($buttons));

        return $this->post("/message/sendButtons/{$instanceName}", [
            'number'  => $this->formatNumber($number),
            'title'   => $title,
            'description' => $text,
            'footer'  => $footer,
            'buttons' => $formattedButtons,
        ]);
    }

    /**
     * Send list message.
     */
    public function sendList(string $instanceName, string $number, string $title, string $description, string $buttonText, array $sections): array
    {
        return $this->post("/message/sendList/{$instanceName}", [
            'number'      => $this->formatNumber($number),
            'title'       => $title,
            'description' => $description,
            'buttonText'  => $buttonText,
            'footerText'  => config('app.name'),
            'sections'    => $sections,
        ]);
    }

    /**
     * Send location.
     */
    public function sendLocation(string $instanceName, string $number, float $lat, float $lng, string $name = '', string $address = ''): array
    {
        return $this->post("/message/sendLocation/{$instanceName}", [
            'number'   => $this->formatNumber($number),
            'latitude' => $lat,
            'longitude' => $lng,
            'name'     => $name,
            'address'  => $address,
        ]);
    }

    /**
     * Send reaction to a message.
     */
    public function sendReaction(string $instanceName, string $number, string $messageId, string $emoji): array
    {
        return $this->post("/message/sendReaction/{$instanceName}", [
            'number'    => $this->formatNumber($number),
            'reactionMessage' => [
                'key'  => ['id' => $messageId],
                'reaction' => $emoji,
            ],
        ]);
    }

    // ===== WEBHOOK =====

    public function setWebhook(string $instanceName, string $webhookUrl, array $events = []): array
    {
        if (empty($events)) {
            $events = config('whatsapp.webhook_events');
        }

        return $this->post("/webhook/set/{$instanceName}", [
            'url'     => $webhookUrl,
            'webhook_by_events' => false,
            'webhook_base64'    => false,
            'events'  => $events,
        ]);
    }

    public function getWebhook(string $instanceName): array
    {
        return $this->get("/webhook/find/{$instanceName}");
    }

    // ===== CONTACTS & CHATS =====

    public function getContacts(string $instanceName): array
    {
        return $this->post("/chat/findContacts/{$instanceName}", ['where' => []]);
    }

    public function checkNumber(string $instanceName, string $number): array
    {
        return $this->post("/chat/whatsappNumbers/{$instanceName}", [
            'numbers' => [$this->formatNumber($number)],
        ]);
    }

    public function getMessages(string $instanceName, string $number, int $count = 50): array
    {
        return $this->post("/chat/findMessages/{$instanceName}", [
            'where'    => ['key' => ['remoteJid' => $this->formatNumber($number) . '@s.whatsapp.net']],
            'page'     => 1,
            'offset'   => $count,
        ]);
    }

    public function markAsRead(string $instanceName, string $messageId, string $number): array
    {
        return $this->post("/chat/markMessageAsRead/{$instanceName}", [
            'read_messages' => [
                ['remoteJid' => $this->formatNumber($number) . '@s.whatsapp.net', 'id' => $messageId, 'fromMe' => false],
            ],
        ]);
    }

    // ===== GROUPS =====

    public function createGroup(string $instanceName, string $subject, array $participants): array
    {
        return $this->post("/group/create/{$instanceName}", [
            'subject'      => $subject,
            'participants' => array_map(fn($p) => $this->formatNumber($p) . '@s.whatsapp.net', $participants),
        ]);
    }

    public function getGroups(string $instanceName): array
    {
        return $this->get("/group/fetchAllGroups/{$instanceName}?getParticipants=false");
    }

    // ===== PROFILE =====

    public function updateProfileName(string $instanceName, string $name): array
    {
        return $this->post("/chat/updateProfileName/{$instanceName}", ['name' => $name]);
    }

    public function updateProfilePicture(string $instanceName, string $imageUrl): array
    {
        return $this->post("/chat/updateProfilePicture/{$instanceName}", ['picture' => $imageUrl]);
    }

    // ===== HELPERS =====

    private function formatNumber(string $number): string
    {
        // Remove tudo que não é número
        $number = preg_replace('/\D/', '', $number);

        // Se não começa com 55 (Brasil) e tem 10-11 dígitos, adiciona 55
        if (strlen($number) <= 11 && !str_starts_with($number, '55')) {
            $number = '55' . $number;
        }

        return $number;
    }

    private function getMimeType(string $type): string
    {
        return match ($type) {
            'image'    => 'image/jpeg',
            'video'    => 'video/mp4',
            'document' => 'application/pdf',
            'audio'    => 'audio/mp4',
            default    => 'application/octet-stream',
        };
    }

    private function goHeaders(?string $instanceToken = null, bool $globalOnly = false): array
    {
        $headers = ['Content-Type' => 'application/json', 'apikey' => $this->apiKey];

        if (!$globalOnly && $instanceToken) {
            $headers['instanceId'] = $instanceToken;
        }

        return $headers;
    }

    private function goRequest(string $method, string $endpoint, array $body = [], ?string $instanceToken = null, bool $globalOnly = false): array
    {
        if ($configError = $this->configErrorResponse()) {
            return $configError;
        }

        $result = $this->executeGoRequest($method, $endpoint, $body, $this->goHeaders($instanceToken, $globalOnly));

        if (!$result['success'] && $instanceToken && !$globalOnly && in_array((int) ($result['status'] ?? 0), [401, 403, 404], true)) {
            $fallbackHeaders = [
                'Content-Type' => 'application/json',
                'apikey'       => $instanceToken,
            ];
            $result = $this->executeGoRequest($method, $endpoint, $body, $fallbackHeaders);
        }

        return $result;
    }

    private function executeGoRequest(string $method, string $endpoint, array $body, array $headers): array
    {
        try {
            $url = $this->baseUrl . $endpoint;
            $pending = Http::withHeaders($headers)->timeout(20);

            $response = match (strtoupper($method)) {
                'GET'    => $pending->get($url),
                'POST'   => $pending->post($url, $body),
                'DELETE' => $pending->delete($url),
                default  => throw new \InvalidArgumentException("Unsupported method: {$method}"),
            };

            return $this->normalizeResponse($response->json() ?? [], $response->status(), $response->successful());
        } catch (\Exception $e) {
            Log::error("EvolutionGo {$method} {$endpoint} failed: " . $e->getMessage());

            return $this->failureResponse($e->getMessage());
        }
    }

    private function legacyGet(string $endpoint): array
    {
        if ($configError = $this->configErrorResponse()) {
            return $configError;
        }

        try {
            $response = Http::withHeaders([
                'apikey'       => $this->apiKey,
                'Content-Type' => 'application/json',
            ])->timeout(15)->get($this->baseUrl . $endpoint);

            return $this->normalizeResponse($response->json() ?? [], $response->status(), $response->successful());
        } catch (\Exception $e) {
            Log::error("EvolutionGo GET {$endpoint} failed: " . $e->getMessage());

            return $this->failureResponse($e->getMessage());
        }
    }

    private function legacyPost(string $endpoint, array $data = []): array
    {
        if ($configError = $this->configErrorResponse()) {
            return $configError;
        }

        try {
            $response = Http::withHeaders([
                'apikey'       => $this->apiKey,
                'Content-Type' => 'application/json',
            ])->timeout(15)->post($this->baseUrl . $endpoint, $data);

            return $this->normalizeResponse($response->json() ?? [], $response->status(), $response->successful());
        } catch (\Exception $e) {
            Log::error("EvolutionGo POST {$endpoint} failed: " . $e->getMessage());

            return $this->failureResponse($e->getMessage());
        }
    }

    private function legacyDelete(string $endpoint): array
    {
        if ($configError = $this->configErrorResponse()) {
            return $configError;
        }

        try {
            $response = Http::withHeaders([
                'apikey'       => $this->apiKey,
                'Content-Type' => 'application/json',
            ])->timeout(15)->delete($this->baseUrl . $endpoint);

            return $this->normalizeResponse($response->json() ?? [], $response->status(), $response->successful());
        } catch (\Exception $e) {
            Log::error("EvolutionGo DELETE {$endpoint} failed: " . $e->getMessage());

            return $this->failureResponse($e->getMessage());
        }
    }

    /** @deprecated Use legacyGet/legacyPost or goRequest */
    private function get(string $endpoint): array
    {
        return $this->legacyGet($endpoint);
    }

    /** @deprecated Use legacyPost or goRequest */
    private function post(string $endpoint, array $data = []): array
    {
        return $this->legacyPost($endpoint, $data);
    }

    /** @deprecated Use legacyDelete or goRequest */
    private function delete(string $endpoint): array
    {
        return $this->legacyDelete($endpoint);
    }

    private function normalizeResponse(array $data, int $status, bool $httpOk): array
    {
        $bodySuccess = $data['success'] ?? null;
        $successful = $httpOk && ($bodySuccess === null || $bodySuccess === true);

        return [
            'success' => $successful,
            'status'  => $status,
            'data'    => $data,
            'qrcode'  => $this->extractQrFromPayload($data),
            'message' => $this->extractApiMessage($data, $status, $successful),
        ];
    }

    private function extractQrFromPayload(array $data): mixed
    {
        $nested = $data['data'] ?? null;
        if (is_array($nested)) {
            $qr = $nested['Qrcode'] ?? $nested['qrcode'] ?? $nested['base64'] ?? null;
            if (is_string($qr) && $qr !== '') {
                return $this->stripQrDataUri($qr);
            }
        }

        $qr = $data['qrcode'] ?? $data['Qrcode'] ?? $data['base64'] ?? null;

        if (is_array($qr)) {
            return $qr['base64'] ?? $qr['code'] ?? null;
        }

        return is_string($qr) ? $this->stripQrDataUri($qr) : $qr;
    }

    private function stripQrDataUri(string $qr): string
    {
        if (str_starts_with($qr, 'data:image')) {
            return (string) preg_replace('#^data:image/[^;]+;base64,#', '', $qr);
        }

        return $qr;
    }

    private function extractApiMessage(array $data, int $status, bool $successful): string
    {
        if ($successful) {
            $msg = $data['message'] ?? null;
            return is_string($msg) && $msg !== '' ? $msg : 'Success';
        }

        $candidates = [
            $data['message'] ?? null,
            is_array($data['error'] ?? null) ? ($data['error']['message'] ?? null) : ($data['error'] ?? null),
        ];

        $response = $data['response'] ?? null;
        if (is_array($response)) {
            $nested = $response['message'] ?? $response['error'] ?? null;
            $candidates[] = is_array($nested) ? implode(', ', $nested) : $nested;
        }

        foreach ($candidates as $msg) {
            if (is_string($msg) && $msg !== '' && strtolower($msg) !== 'request failed') {
                return $msg;
            }
        }

        return match (true) {
            $status === 401 => 'API key inválida. Verifique EVOLUTION_GO_API_KEY ou a chave configurada na instância.',
            $status === 403 => 'Acesso negado pela Evolution API.',
            $status === 404 => 'Instância não encontrada na Evolution API.',
            in_array($status, [500, 502, 503], true) => "Evolution API indisponível (HTTP {$status}).",
            $status > 0 => "Erro na Evolution API (HTTP {$status}).",
            default => 'Falha ao comunicar com a Evolution API.',
        };
    }

    private function configErrorResponse(): ?array
    {
        if ($this->hasValidConfig()) {
            return null;
        }

        return $this->failureResponse(
            'URL da Evolution API não configurada. Defina EVOLUTION_GO_URL no .env ou informe a URL na instância WhatsApp.'
        );
    }

    private function failureResponse(string $message): array
    {
        $friendly = $this->friendlyConnectionError($message);

        return [
            'success' => false,
            'error' => $message,
            'message' => $friendly,
        ];
    }

    private function friendlyConnectionError(string $message): string
    {
        if (str_contains($message, 'Could not resolve host')) {
            preg_match('/host: ([^\s(]+)/', $message, $matches);
            $host = $matches[1] ?? 'servidor Evolution';

            return "Não foi possível resolver o host {$host}. Verifique EVOLUTION_GO_URL no .env (ex.: https://evolution.centralvix.com.br) ou a URL configurada na instância.";
        }

        if (str_contains($message, 'Connection refused') || str_contains($message, 'Failed to connect')) {
            return 'Não foi possível conectar à Evolution API. Confirme se o serviço está online e se a URL/porta estão corretas.';
        }

        if (str_contains($message, 'SSL') || str_contains($message, 'certificate')) {
            return 'Erro de certificado SSL ao conectar na Evolution API. Verifique HTTPS e o certificado do servidor.';
        }

        return $message;
    }
}
