<?php

namespace App\Services;

use App\Models\Company;
use App\Models\Setting;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class BrandingService
{
    public function companyId(?int $fallback = null): int
    {
        if (auth()->check() && auth()->user()->company_id) {
            return (int) auth()->user()->company_id;
        }

        return $fallback ?? (int) (Company::query()->orderBy('id')->value('id') ?? 1);
    }

    public function get(?int $companyId = null): array
    {
        $companyId ??= $this->companyId();

        return Cache::remember("branding_{$companyId}", 300, function () use ($companyId) {
            $defaults = config('branding.defaults', []);
            $stored = Setting::where('company_id', $companyId)
                ->whereIn('group', ['branding', 'pwa'])
                ->get()
                ->mapWithKeys(fn ($s) => ["{$s->group}.{$s->key}" => $s->typed_value]);

            $data = array_merge($defaults, [
                'company_id' => $companyId,
                'company_name' => $stored->get('branding.company_name', $defaults['company_name'] ?? config('app.name')),
                'primary_color' => $stored->get('branding.primary_color', $defaults['primary_color']),
                'secondary_color' => $stored->get('branding.secondary_color', $defaults['secondary_color']),
                'accent_color' => $stored->get('branding.accent_color', $defaults['accent_color']),
                'sidebar_start' => $stored->get('branding.sidebar_start', $defaults['sidebar_start']),
                'sidebar_end' => $stored->get('branding.sidebar_end', $defaults['sidebar_end']),
                'login_gradient_start' => $stored->get('branding.login_gradient_start', $defaults['login_gradient_start']),
                'login_gradient_end' => $stored->get('branding.login_gradient_end', $defaults['login_gradient_end']),
                'pwa_enabled' => filter_var($stored->get('pwa.enabled', $defaults['pwa_enabled'] ?? true), FILTER_VALIDATE_BOOLEAN),
                'pwa_name' => $stored->get('pwa.name', $defaults['pwa_name']),
                'pwa_short_name' => $stored->get('pwa.short_name', $defaults['pwa_short_name']),
                'pwa_theme_color' => $stored->get('pwa.theme_color', $stored->get('branding.primary_color', $defaults['pwa_theme_color'])),
                'pwa_background' => $stored->get('pwa.background_color', $defaults['pwa_background']),
                'pwa_display' => $stored->get('pwa.display', $defaults['pwa_display'] ?? 'standalone'),
            ]);

            foreach (['logo_login', 'logo_admin', 'logo_client', 'favicon', 'pwa_icon_192', 'pwa_icon_512', 'apple_touch_icon', 'login_bg', 'login_banner'] as $asset) {
                $path = $stored->get("branding.{$asset}") ?? $stored->get("pwa.{$asset}");
                $data[$asset] = $path;
                $data["{$asset}_url"] = $path ? Storage::disk('public')->url($path) : null;
            }

            // Ponte com o módulo "App PWA do Cliente" (client_pwa): quando o módulo
            // está ativo, sua configuração passa a controlar o PWA. Quando inativo,
            // mantém o comportamento atual baseado no branding.
            $data['pwa_push_enabled'] = false;
            $data['pwa_offline'] = true;

            try {
                $modules = app(ModuleService::class);
                if ($modules->isEnabled($companyId, 'client_pwa')) {
                    $m = app(ModuleSettingsService::class)->all($companyId, 'client_pwa');
                    $data['pwa_enabled'] = (bool) ($m['enabled'] ?? true);
                    if (!empty($m['app_name'])) {
                        $data['pwa_name'] = $m['app_name'];
                        $data['pwa_short_name'] = $m['app_name'];
                    }
                    if (!empty($m['theme_color'])) {
                        $data['pwa_theme_color'] = $m['theme_color'];
                    }
                    $data['pwa_push_enabled'] = (bool) ($m['enable_push'] ?? false);
                    $data['pwa_offline'] = (bool) ($m['offline_support'] ?? true);
                }
            } catch (\Throwable $e) {
                // Em caso de erro na resolução do módulo, mantém o branding atual.
            }

            return $data;
        });
    }

    public function saveBranding(int $companyId, array $data): void
    {
        $keys = [
            'company_name', 'primary_color', 'secondary_color', 'accent_color',
            'sidebar_start', 'sidebar_end', 'login_gradient_start', 'login_gradient_end',
        ];

        foreach ($keys as $key) {
            if (array_key_exists($key, $data)) {
                Setting::set($companyId, 'branding', $key, $data[$key]);
            }
        }

        $this->clearCache($companyId);
    }

    public function savePwa(int $companyId, array $data): void
    {
        foreach (['name', 'short_name', 'theme_color', 'background_color', 'display'] as $key) {
            if (array_key_exists($key, $data)) {
                Setting::set($companyId, 'pwa', $key, $data[$key]);
            }
        }

        if (array_key_exists('enabled', $data)) {
            Setting::set($companyId, 'pwa', 'enabled', (bool) $data['enabled'], 'boolean');
        }

        $this->clearCache($companyId);
    }

    public function uploadAsset(int $companyId, string $type, UploadedFile $file): string
    {
        $dir = "branding/{$companyId}";

        if ($type === 'pwa_icon') {
            $this->generatePwaIcons($companyId, $file);
            $path = "{$dir}/pwa-512.png";
            Setting::set($companyId, 'branding', 'pwa_icon_512', $path);
            Setting::set($companyId, 'branding', 'pwa_icon_192', "{$dir}/pwa-192.png");
            Setting::set($companyId, 'branding', 'apple_touch_icon', "{$dir}/apple-touch.png");
            $this->clearCache($companyId);

            return $path;
        }

        $ext = $file->getClientOriginalExtension() ?: 'png';
        $filename = match ($type) {
            'logo_login' => 'login.' . $ext,
            'logo_admin' => 'admin.' . $ext,
            'logo_client' => 'client.' . $ext,
            'favicon' => 'favicon.' . $ext,
            default => $type . '.' . $ext,
        };

        $path = $file->storeAs($dir, $filename, 'public');
        Setting::set($companyId, 'branding', $type, $path);
        $this->clearCache($companyId);

        return $path;
    }

    public function themeCss(int $companyId): string
    {
        $b = $this->get($companyId);

        return <<<CSS
:root {
    --accent-primary: {$b['primary_color']};
    --accent-secondary: {$b['secondary_color']};
    --cv-accent: {$b['accent_color']};
    --sidebar-gradient-start: {$b['sidebar_start']};
    --sidebar-gradient-end: {$b['sidebar_end']};
    --login-gradient-start: {$b['login_gradient_start']};
    --login-gradient-end: {$b['login_gradient_end']};
    --pwa-theme-color: {$b['pwa_theme_color']};
}
.cv-btn-primary, .btn-primary {
    background: linear-gradient(135deg, {$b['primary_color']} 0%, {$b['secondary_color']} 100%) !important;
    border-color: {$b['primary_color']} !important;
}
.text-primary { color: {$b['primary_color']} !important; }
.bg-primary { background-color: {$b['primary_color']} !important; }
CSS;
    }

    public function manifest(int $companyId): array
    {
        $b = $this->get($companyId);
        $icons = [];

        if (!empty($b['pwa_icon_192_url'])) {
            $icons[] = ['src' => $b['pwa_icon_192_url'], 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable'];
        }
        if (!empty($b['pwa_icon_512_url'])) {
            $icons[] = ['src' => $b['pwa_icon_512_url'], 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable'];
        }

        if (empty($icons)) {
            $icons[] = ['src' => url('/favicon.ico'), 'sizes' => '64x64', 'type' => 'image/x-icon'];
        }

        return [
            'name' => $b['pwa_name'] ?? $b['company_name'],
            'short_name' => $b['pwa_short_name'] ?? 'CentralVix',
            'description' => 'CentralVix — Sistema de gestão e billing',
            'start_url' => url('/'),
            'scope' => url('/'),
            'display' => $b['pwa_display'] ?? 'standalone',
            'orientation' => 'portrait-primary',
            'theme_color' => $b['pwa_theme_color'],
            'background_color' => $b['pwa_background'],
            'lang' => 'pt-BR',
            'icons' => $icons,
        ];
    }

    public function clearCache(int $companyId): void
    {
        Cache::forget("branding_{$companyId}");
        Cache::forget("company_settings_{$companyId}");
    }

    private function generatePwaIcons(int $companyId, UploadedFile $file): void
    {
        $dir = storage_path("app/public/branding/{$companyId}");
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        try {
            $manager = new ImageManager(new Driver());
            $image = $manager->read($file->getRealPath());

            $image->cover(512, 512)->save("{$dir}/pwa-512.png");
            $manager->read($file->getRealPath())->cover(192, 192)->save("{$dir}/pwa-192.png");
            $manager->read($file->getRealPath())->cover(180, 180)->save("{$dir}/apple-touch.png");
        } catch (\Throwable) {
            $file->storeAs("branding/{$companyId}", 'pwa-512.png', 'public');
            copy(storage_path("app/public/branding/{$companyId}/pwa-512.png"), "{$dir}/pwa-192.png");
            copy(storage_path("app/public/branding/{$companyId}/pwa-512.png"), "{$dir}/apple-touch.png");
        }
    }
}
