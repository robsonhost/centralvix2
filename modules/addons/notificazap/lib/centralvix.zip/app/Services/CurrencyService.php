<?php

namespace App\Services;

use App\Models\Client;
use App\Models\Setting;

class CurrencyService
{
    public const SUPPORTED = ['BRL', 'USD', 'EUR'];

    private const SYMBOLS = ['BRL' => 'R$', 'USD' => 'US$', 'EUR' => '€'];

    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function isEnabled(int $companyId): bool
    {
        return $this->modules->isEnabled($companyId, 'multi_currency');
    }

    public function config(int $companyId): array
    {
        return $this->settings->all($companyId, 'multi_currency');
    }

    public function baseCurrency(int $companyId): string
    {
        $base = $this->config($companyId)['base_currency'] ?? 'BRL';

        return in_array($base, self::SUPPORTED, true) ? $base : 'BRL';
    }

    /**
     * Moedas que a empresa aceita (sempre inclui a base).
     *
     * @return string[]
     */
    public function enabledCurrencies(int $companyId): array
    {
        $base = $this->baseCurrency($companyId);
        if (!$this->isEnabled($companyId)) {
            return [$base];
        }

        $cfg = $this->config($companyId);
        $list = [$base];
        if (($cfg['enable_usd'] ?? false) && !in_array('USD', $list, true)) {
            $list[] = 'USD';
        }
        if (($cfg['enable_eur'] ?? false) && !in_array('EUR', $list, true)) {
            $list[] = 'EUR';
        }

        return $list;
    }

    public function symbol(string $currency): string
    {
        return self::SYMBOLS[strtoupper($currency)] ?? strtoupper($currency);
    }

    /**
     * Taxa armazenada: quantidade da moeda BASE equivalente a 1 unidade da moeda informada.
     * Ex.: base BRL, USD => 5.20 significa 1 USD = R$ 5,20.
     */
    public function storedRate(int $companyId, string $currency): ?float
    {
        if (strtoupper($currency) === $this->baseCurrency($companyId)) {
            return 1.0;
        }

        $value = Setting::get($companyId, 'currency_rates', 'rate_' . strtoupper($currency));

        return $value !== null && is_numeric($value) ? (float) $value : null;
    }

    public function setRate(int $companyId, string $currency, float $rate): void
    {
        Setting::set($companyId, 'currency_rates', 'rate_' . strtoupper($currency), $rate, 'string');
    }

    /**
     * Taxa efetiva (com margem de câmbio aplicada) para conversão base -> moeda.
     * A margem encarece o valor cobrado na moeda estrangeira.
     */
    public function effectiveRate(int $companyId, string $currency): ?float
    {
        $rate = $this->storedRate($companyId, $currency);
        if ($rate === null || $rate <= 0) {
            return null;
        }

        if (strtoupper($currency) === $this->baseCurrency($companyId)) {
            return 1.0;
        }

        $markup = (float) ($this->config($companyId)['exchange_markup_percent'] ?? 0);

        return $rate * (1 - $markup / 100);
    }

    /**
     * Converte um valor da moeda BASE para a moeda informada.
     */
    public function convertFromBase(int $companyId, float $amountBase, string $currency): float
    {
        $currency = strtoupper($currency);
        if ($currency === $this->baseCurrency($companyId)) {
            return round($amountBase, 2);
        }

        $rate = $this->effectiveRate($companyId, $currency);
        if (!$rate) {
            return round($amountBase, 2);
        }

        return round($amountBase / $rate, 2);
    }

    /**
     * Define a moeda da fatura para um cliente, respeitando as moedas habilitadas.
     */
    public function resolveForClient(Client $client): string
    {
        $companyId = (int) $client->company_id;
        $base = $this->baseCurrency($companyId);

        if (!$this->isEnabled($companyId)) {
            return $base;
        }

        $clientCurrency = strtoupper((string) ($client->currency ?? ''));
        $enabled = $this->enabledCurrencies($companyId);

        if ($clientCurrency && in_array($clientCurrency, $enabled, true) && $this->effectiveRate($companyId, $clientCurrency)) {
            return $clientCurrency;
        }

        return $base;
    }

    /**
     * Taxa a ser persistida na fatura (base por 1 unidade da moeda da fatura).
     */
    public function invoiceRate(int $companyId, string $currency): float
    {
        return $this->effectiveRate($companyId, $currency) ?? 1.0;
    }

    public function format(float $amount, string $currency = 'BRL'): string
    {
        $symbol = $this->symbol($currency);
        $formatted = number_format($amount, 2, ',', '.');

        // Padrão pt-BR: símbolo antes do valor.
        return trim($symbol . ' ' . $formatted);
    }
}
