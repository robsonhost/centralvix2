<?php

namespace App\Services;

class TaxService
{
    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function isEnabled(int $companyId): bool
    {
        return $this->modules->isEnabled($companyId, 'tax_management');
    }

    public function config(int $companyId): array
    {
        return $this->settings->all($companyId, 'tax_management');
    }

    /**
     * Alíquota de ISS efetiva (0 se o módulo estiver desativado ou ISS desligado).
     */
    public function issRate(int $companyId): float
    {
        if (!$this->isEnabled($companyId)) {
            return 0.0;
        }

        $cfg = $this->config($companyId);
        if (!($cfg['apply_iss'] ?? false)) {
            return 0.0;
        }

        return (float) ($cfg['default_iss_percent'] ?? 0);
    }

    /**
     * Calcula o imposto sobre um valor base.
     *
     * @return array{rate: float, amount: float}
     */
    public function calculate(int $companyId, float $base): array
    {
        $rate = $this->issRate($companyId);
        $amount = $rate > 0 ? round($base * $rate / 100, 2) : 0.0;

        return ['rate' => $rate, 'amount' => $amount];
    }

    public function showOnInvoice(int $companyId): bool
    {
        return $this->isEnabled($companyId) && (bool) ($this->config($companyId)['show_taxes_on_invoice'] ?? true);
    }

    public function withheldIss(int $companyId): bool
    {
        return $this->isEnabled($companyId) && (bool) ($this->config($companyId)['withhold_iss'] ?? false);
    }

    public function withheldFederal(int $companyId): bool
    {
        return $this->isEnabled($companyId) && (bool) ($this->config($companyId)['withhold_federal'] ?? false);
    }
}
