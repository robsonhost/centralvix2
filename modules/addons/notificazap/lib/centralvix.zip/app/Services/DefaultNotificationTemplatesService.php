<?php

namespace App\Services;

use App\Models\Company;
use App\Models\EmailTemplate;
use App\Models\WhatsappTemplate;

class DefaultNotificationTemplatesService
{
    /**
     * Instala ou atualiza templates de e-mail e WhatsApp para provisionamento.
     */
    public function installForCompany(int $companyId): array
    {
        $email = 0;
        $whatsapp = 0;

        foreach ($this->emailTemplates() as $tpl) {
            EmailTemplate::updateOrCreate(
                ['company_id' => $companyId, 'slug' => $tpl['slug']],
                array_merge($tpl, ['company_id' => $companyId, 'status' => 'active'])
            );
            $email++;
        }

        foreach ($this->whatsappTemplates() as $tpl) {
            WhatsappTemplate::updateOrCreate(
                ['company_id' => $companyId, 'slug' => $tpl['slug']],
                array_merge($tpl, [
                    'company_id' => $companyId,
                    'is_active' => true,
                    'is_default' => true,
                ])
            );
            $whatsapp++;
        }

        return ['email' => $email, 'whatsapp' => $whatsapp];
    }

    public function installForAllCompanies(): array
    {
        $totals = ['companies' => 0, 'email' => 0, 'whatsapp' => 0];

        Company::query()->pluck('id')->each(function (int $companyId) use (&$totals) {
            $result = $this->installForCompany($companyId);
            $totals['companies']++;
            $totals['email'] += $result['email'];
            $totals['whatsapp'] += $result['whatsapp'];
        });

        return $totals;
    }

    /** @return array<int, array<string, mixed>> */
    public function emailTemplates(): array
    {
        return [
            [
                'name' => 'Serviço Ativado (Hospedagem)',
                'slug' => 'service_activated',
                'subject' => '🎉 Serviço ativado: {service_name}',
                'variables' => $this->serviceVariables(),
                'body_html' => <<<'HTML'
<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;color:#1a202c;">
  <div style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:24px;border-radius:12px 12px 0 0;">
    <h1 style="margin:0;font-size:22px;">Serviço ativado com sucesso!</h1>
    <p style="margin:8px 0 0;opacity:.95;">Olá, {client_name}! Sua hospedagem já está pronta.</p>
  </div>
  <div style="border:1px solid #e2e8f0;border-top:none;padding:24px;border-radius:0 0 12px 12px;background:#fff;">
    <p><strong>Serviço:</strong> {service_name}</p>
    <p><strong>Domínio:</strong> {domain}</p>
    <p><strong>Servidor:</strong> {server}</p>
    <div style="background:#f7fafc;border-left:4px solid #667eea;padding:16px;margin:20px 0;border-radius:6px;">
      <p style="margin:0 0 8px;font-weight:bold;">Dados de acesso cPanel</p>
      <p style="margin:4px 0;"><strong>Usuário:</strong> {username}</p>
      <p style="margin:4px 0;"><strong>Senha:</strong> {password}</p>
      <p style="margin:4px 0;"><strong>URL cPanel:</strong> <a href="{cpanel_url}">{cpanel_url}</a></p>
      <p style="margin:4px 0;"><strong>Nameservers:</strong> {nameserver1} / {nameserver2}</p>
    </div>
    <p style="text-align:center;margin:28px 0;">
      <a href="{service_url}" style="background:#667eea;color:#fff;text-decoration:none;padding:14px 28px;border-radius:8px;font-weight:bold;">Acessar área do cliente</a>
    </p>
    <p style="font-size:13px;color:#718096;">Equipe {company_name}</p>
  </div>
</div>
HTML,
                'body_text' => <<<'TEXT'
Olá, {client_name}!

Seu serviço {service_name} foi ativado.

Domínio: {domain}
Usuário cPanel: {username}
Senha: {password}
URL cPanel: {cpanel_url}
Nameservers: {nameserver1} / {nameserver2}

Acesse: {service_url}

{company_name}
TEXT,
            ],
            [
                'name' => 'Serviço Reativado',
                'slug' => 'service_reactivated',
                'subject' => '✅ Serviço reativado: {service_name}',
                'variables' => $this->serviceVariables(),
                'body_html' => <<<'HTML'
<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
  <h2>Serviço reativado</h2>
  <p>Olá, {client_name}! O serviço <strong>{service_name}</strong> ({domain}) foi reativado após confirmação do pagamento.</p>
  <p><strong>Usuário:</strong> {username}<br><strong>cPanel:</strong> <a href="{cpanel_url}">{cpanel_url}</a></p>
  <p><a href="{service_url}">Abrir área do cliente</a></p>
</div>
HTML,
                'body_text' => "Olá, {client_name}!\n\nServiço {service_name} reativado.\nUsuário: {username}\n{cPanel}: {cpanel_url}\n\n{service_url}",
            ],
        ];
    }

    /** @return array<int, array<string, mixed>> */
    public function whatsappTemplates(): array
    {
        return [
            [
                'name' => 'Serviço Ativado',
                'slug' => 'service_activated',
                'category' => 'hospedagem',
                'type' => 'text',
                'variables' => $this->serviceVariables(),
                'content' => <<<'WA'
🎉 *Serviço ativado — {{company_name}}*

Olá, {{client_name}}! Sua hospedagem *{{service_name}}* está pronta.

🌐 *Domínio:* {{domain}}
👤 *Usuário:* {{username}}
🔑 *Senha:* {{password}}
🖥️ *cPanel:* {{cpanel_url}}
📡 *NS1:* {{nameserver1}}
📡 *NS2:* {{nameserver2}}

👉 Acesse sua área: {{service_url}}

Guarde estes dados em local seguro.
WA,
            ],
            [
                'name' => 'Serviço Reativado',
                'slug' => 'service_reactivated',
                'category' => 'hospedagem',
                'type' => 'text',
                'variables' => $this->serviceVariables(),
                'content' => <<<'WA'
✅ *Serviço reativado — {{company_name}}*

Olá, {{client_name}}! O serviço *{{service_name}}* ({{domain}}) foi reativado.

👤 Usuário: {{username}}
🖥️ cPanel: {{cpanel_url}}

👉 {{service_url}}
WA,
            ],
            [
                'name' => 'Streaming Ativado',
                'slug' => 'service_activated_streaming',
                'category' => 'servicos',
                'type' => 'text',
                'variables' => array_merge($this->serviceVariables(), ['stream_url', 'streaming_panel_url']),
                'content' => <<<'WA'
🎵 *Streaming ativado — {{company_name}}*

Serviço: *{{service_name}}*
👤 Usuário: {{username}}
🔑 Senha: {{password}}
🔗 Stream: {{stream_url}}
🎛️ Painel: {{streaming_panel_url}}

👉 {{service_url}}
WA,
            ],
        ];
    }

    /** @return array<int, string> */
    public function serviceVariables(): array
    {
        return [
            'client_name', 'company_name', 'service_name', 'domain', 'username', 'password',
            'server', 'cpanel_url', 'control_panel_url', 'whm_url', 'nameservers',
            'nameserver1', 'nameserver2', 'service_url', 'stream_url', 'streaming_panel_url',
        ];
    }
}
