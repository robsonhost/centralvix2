<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;

class AddonService
{
    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function isEnabled(int $companyId): bool
    {
        return $this->modules->isEnabled($companyId, 'addon_marketplace');
    }

    public function config(int $companyId): array
    {
        return $this->settings->all($companyId, 'addon_marketplace');
    }

    public function showOnCheckout(int $companyId): bool
    {
        return $this->isEnabled($companyId) && (bool) ($this->config($companyId)['show_on_checkout'] ?? true);
    }

    public function showInClientArea(int $companyId): bool
    {
        return $this->isEnabled($companyId) && (bool) ($this->config($companyId)['show_in_client_area'] ?? true);
    }

    /**
     * Add-ons em destaque para upsell, respeitando o limite configurado.
     *
     * @return Collection<int, Product>
     */
    public function featured(int $companyId, ?int $excludeProductId = null): Collection
    {
        if (!$this->hasAddonColumn()) {
            return collect();
        }

        $limit = (int) ($this->config($companyId)['max_featured'] ?? 6);

        return Product::where('company_id', $companyId)
            ->where('status', 'active')
            ->where('is_addon', true)
            ->when($excludeProductId, fn ($q) => $q->where('id', '!=', $excludeProductId))
            ->orderByDesc('featured')
            ->orderBy('order')
            ->limit(max(1, $limit))
            ->get();
    }

    /**
     * Todos os add-ons ativos (para a área do cliente).
     *
     * @return Collection<int, Product>
     */
    public function all(int $companyId): Collection
    {
        if (!$this->hasAddonColumn()) {
            return collect();
        }

        return Product::where('company_id', $companyId)
            ->where('status', 'active')
            ->where('is_addon', true)
            ->orderByDesc('featured')
            ->orderBy('order')
            ->get();
    }

    private function hasAddonColumn(): bool
    {
        return Schema::hasColumn('products', 'is_addon');
    }
}
