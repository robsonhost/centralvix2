<?php

namespace App\Services;

use App\Services\WhatsApp\EvolutionGoService;
use Illuminate\Support\Facades\Log;

/**
 * Evolution API Service - Integração WhatsApp
 *
 * Camada de conveniência para envio de mensagens. Delega a comunicação ao
 * EvolutionGoService, que conhece os endpoints corretos do Evolution Go
 * (GestãoVix) — diferentes da Evolution API clássica.
 */
class EvolutionWhatsAppService
{
    protected string $instance;
    protected bool $enabled;
    protected EvolutionGoService $go;
    protected ?array $lastResult = null;

    public function __construct()
    {
        $this->enabled  = (bool) config('whatsapp.evolution_go.enabled', config('services.evolution.enabled', false));
        $this->instance = (string) (config('whatsapp.evolution_go.instance') ?: config('services.evolution.instance', 'centralvix'));
        $this->go       = new EvolutionGoService();
    }

    /**
     * Mensagem de erro detalhada da última tentativa de envio.
     */
    public function getLastError(): ?string
    {
        if (!$this->lastResult) {
            return null;
        }

        $msg = $this->lastResult['message'] ?? null;
        $status = $this->lastResult['status'] ?? null;

        if ($msg && $status) {
            return "{$msg} (HTTP {$status})";
        }

        return $msg;
    }

    /**
     * Verifica se Evolution está habilitado e configurado
     */
    public function isEnabled(): bool
    {
        return $this->enabled && $this->go->hasValidConfig();
    }

    /**
     * Envia mensagem de texto
     */
    public function sendText(string $phone, string $message): bool
    {
        $this->lastResult = null;

        if (!$this->isEnabled()) {
            $this->lastResult = ['message' => 'WhatsApp não habilitado ou sem configuração válida (EVOLUTION_GO_*).'];
            Log::warning('Evolution API desabilitado ou sem configuração válida');
            return false;
        }

        try {
            $result = $this->go->sendText($this->instance, $phone, $message);
            $this->lastResult = $result;

            if ($result['success'] ?? false) {
                Log::info('WhatsApp enviado com sucesso', ['phone' => $phone]);
                return true;
            }

            Log::error('Erro ao enviar WhatsApp', [
                'phone'   => $phone,
                'status'  => $result['status'] ?? null,
                'message' => $result['message'] ?? null,
            ]);

            return false;
        } catch (\Exception $e) {
            $this->lastResult = ['message' => $e->getMessage()];
            Log::error('Exceção ao enviar WhatsApp: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Envia código de verificação
     */
    public function sendVerificationCode(string $phone, string $code, int $expiryMinutes = 30): bool
    {
        $message = "🔐 *" . config('app.name') . "*\n\n";
        $message .= "Seu código de verificação é:\n\n";
        $message .= "*{$code}*\n\n";
        $message .= "⏰ Válido por {$expiryMinutes} minutos\n\n";
        $message .= "⚠️ Não compartilhe este código com ninguém!\n\n";
        $message .= "Se você não solicitou, ignore esta mensagem.";

        return $this->sendText($phone, $message);
    }

    /**
     * Envia mensagem de boas-vindas
     */
    public function sendWelcome(string $phone, string $name, string $email, string $password): bool
    {
        $message = "🎉 *Bem-vindo ao " . config('app.name') . "!*\n\n";
        $message .= "Olá *{$name}*! 👋\n\n";
        $message .= "Sua conta foi criada com sucesso!\n\n";
        $message .= "📧 *Email:* {$email}\n";
        $message .= "🔑 *Senha:* {$password}\n\n";
        $message .= "🌐 *Acesse:* " . config('app.url') . "\n\n";
        $message .= "⚠️ *Importante:* Altere sua senha no primeiro acesso!\n\n";
        $message .= "Precisa de ajuda? Entre em contato com nosso suporte! 💬";

        return $this->sendText($phone, $message);
    }

    /**
     * Envia notificação de ticket aberto
     */
    public function sendTicketOpened(string $phone, int $ticketId, string $subject): bool
    {
        $message = "🎫 *Ticket Aberto*\n\n";
        $message .= "Seu ticket foi registrado com sucesso!\n\n";
        $message .= "📌 *Número:* #{$ticketId}\n";
        $message .= "📋 *Assunto:* {$subject}\n\n";
        $message .= "⏱️ Nossa equipe responderá em breve.\n\n";
        $message .= "Você será notificado quando houver uma resposta! 🔔";

        return $this->sendText($phone, $message);
    }

    /**
     * Envia notificação de resposta em ticket
     */
    public function sendTicketReply(string $phone, int $ticketId, string $subject): bool
    {
        $message = "💬 *Nova Resposta no Ticket #{$ticketId}*\n\n";
        $message .= "📋 {$subject}\n\n";
        $message .= "Nossa equipe respondeu seu ticket!\n\n";
        $message .= "🌐 Acesse: " . config('app.url') . "/client/tickets/{$ticketId}\n\n";
        $message .= "Clique no link acima para ver a resposta completa.";

        return $this->sendText($phone, $message);
    }

    /**
     * Envia notificação de fatura
     */
    public function sendInvoice(string $phone, string $invoiceNumber, float $amount, string $dueDate): bool
    {
        $message = "💰 *Nova Fatura Disponível*\n\n";
        $message .= "📄 *Fatura:* #{$invoiceNumber}\n";
        $message .= "💵 *Valor:* R$ " . number_format($amount, 2, ',', '.') . "\n";
        $message .= "📅 *Vencimento:* {$dueDate}\n\n";
        $message .= "🌐 Acesse sua área para visualizar e pagar:\n";
        $message .= config('app.url') . "/client/invoices\n\n";
        $message .= "Pague antes do vencimento e evite juros! 💳";

        return $this->sendText($phone, $message);
    }

    /**
     * Verifica status da instância
     */
    public function getInstanceStatus(): ?array
    {
        if (!$this->isEnabled()) {
            return null;
        }

        try {
            $result = $this->go->getConnectionState($this->instance);

            if ($result['success'] ?? false) {
                return $result['data'] ?? $result;
            }

            return null;
        } catch (\Exception $e) {
            Log::error('Erro ao verificar status Evolution: ' . $e->getMessage());
            return null;
        }
    }
}
