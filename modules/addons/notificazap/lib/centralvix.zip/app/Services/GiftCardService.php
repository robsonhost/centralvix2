<?php

namespace App\Services;

use App\Models\Client;
use App\Models\GiftCard;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class GiftCardService
{
    public function __construct(
        private ModuleSettingsService $settings,
        private WalletService $wallet,
    ) {}

    /**
     * Gera um novo gift card com código único.
     */
    public function generate(int $companyId, float $value, ?string $notes = null, ?int $createdBy = null): GiftCard
    {
        $cfg = $this->settings->all($companyId, 'gift_cards');

        $value = round($value, 2);
        $validityDays = (int) ($cfg['validity_days'] ?? 365);
        $length = (int) ($cfg['code_length'] ?? 12);

        return GiftCard::create([
            'company_id'    => $companyId,
            'code'          => $this->uniqueCode($length),
            'initial_value' => $value,
            'balance'       => $value,
            'status'        => 'active',
            'expires_at'    => $validityDays > 0 ? now()->addDays($validityDays)->toDateString() : null,
            'created_by'    => $createdBy,
            'notes'         => $notes,
        ]);
    }

    /**
     * Resgata um gift card creditando o saldo na carteira do cliente.
     *
     * @return array{success: bool, message: string, amount?: float}
     */
    public function redeem(string $code, Client $client): array
    {
        $code = strtoupper(trim($code));

        return DB::transaction(function () use ($code, $client) {
            $card = GiftCard::where('company_id', $client->company_id)
                ->where('code', $code)
                ->lockForUpdate()
                ->first();

            if (!$card) {
                return ['success' => false, 'message' => 'Código inválido ou inexistente.'];
            }

            if ($card->status === 'cancelled') {
                return ['success' => false, 'message' => 'Este gift card foi cancelado.'];
            }

            if ($card->status === 'redeemed') {
                return ['success' => false, 'message' => 'Este gift card já foi resgatado.'];
            }

            if ($card->isExpired()) {
                $card->update(['status' => 'expired']);
                return ['success' => false, 'message' => 'Este gift card está expirado.'];
            }

            $amount = (float) $card->balance;
            if ($amount <= 0) {
                return ['success' => false, 'message' => 'Gift card sem saldo disponível.'];
            }

            $this->wallet->credit(
                $client,
                $amount,
                'bonus',
                "Resgate de gift card {$card->code}",
                null,
                $client->id,
            );

            $card->update([
                'balance'     => 0,
                'status'      => 'redeemed',
                'redeemed_by' => $client->id,
                'redeemed_at' => now(),
            ]);

            return ['success' => true, 'message' => 'Gift card resgatado! Saldo adicionado à sua carteira.', 'amount' => $amount];
        });
    }

    private function uniqueCode(int $length): string
    {
        $length = max(6, min(40, $length));

        do {
            $code = strtoupper(Str::random($length));
        } while (GiftCard::where('code', $code)->exists());

        return $code;
    }
}
