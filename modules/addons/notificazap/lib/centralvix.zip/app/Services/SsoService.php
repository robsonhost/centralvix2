<?php

namespace App\Services;

use App\Models\Company;
use Illuminate\Http\Request;

class SsoService
{
    public const PROVIDERS = ['google', 'microsoft'];

    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function isEnabled(int $companyId): bool
    {
        return $this->modules->isEnabled($companyId, 'sso');
    }

    public function config(int $companyId): array
    {
        return $this->settings->all($companyId, 'sso');
    }

    public function resolveCompany(Request $request): ?Company
    {
        $host = $request->getHost();
        $byDomain = Company::where('domain', $host)->first();
        if ($byDomain) {
            return $byDomain;
        }

        return Company::where('status', 'active')->orderBy('id')->first();
    }

    /**
     * Provedores realmente utilizáveis (habilitados + com credenciais).
     *
     * @return string[]
     */
    public function enabledProviders(int $companyId): array
    {
        if (!$this->isEnabled($companyId)) {
            return [];
        }

        $cfg = $this->config($companyId);
        $providers = [];

        foreach (self::PROVIDERS as $provider) {
            if (($cfg["{$provider}_enabled"] ?? false) && $this->credentials($companyId, $provider)) {
                $providers[] = $provider;
            }
        }

        return $providers;
    }

    public function isProviderEnabled(int $companyId, string $provider): bool
    {
        return in_array($provider, $this->enabledProviders($companyId), true);
    }

    /**
     * Credenciais OAuth do provedor (config do módulo, com fallback no services.php).
     *
     * @return array{client_id: string, client_secret: string}|null
     */
    public function credentials(int $companyId, string $provider): ?array
    {
        $cfg = $this->config($companyId);

        $clientId = $cfg["{$provider}_client_id"] ?? '';
        $clientSecret = $cfg["{$provider}_client_secret"] ?? '';

        if ($clientId === '' || $clientSecret === '') {
            $clientId = (string) config("services.{$provider}.client_id", '');
            $clientSecret = (string) config("services.{$provider}.client_secret", '');
        }

        if ($clientId === '' || $clientSecret === '') {
            return null;
        }

        return ['client_id' => $clientId, 'client_secret' => $clientSecret];
    }

    public function autoCreate(int $companyId): bool
    {
        return (bool) ($this->config($companyId)['auto_create_account'] ?? true);
    }

    public function restrictDomain(int $companyId): string
    {
        return trim((string) ($this->config($companyId)['restrict_domain'] ?? ''));
    }

    public function providerLabel(string $provider): string
    {
        return match ($provider) {
            'google' => 'Google',
            'microsoft' => 'Microsoft',
            default => ucfirst($provider),
        };
    }
}
