<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;

class LicenseService
{
    private static $cacheKey = 'system_license_check';
    private static $cacheDuration = 3600; // 1 hora

    public static function check(): bool
    {
        return Cache::remember(self::$cacheKey, self::$cacheDuration, function () {
            return self::validateLicense();
        });
    }

    private static function validateLicense(): bool
    {
        try {
            $license = DB::table('system_licenses')
                ->where(function ($query) {
                    $query->where('domain', request()->getHost())
                        ->orWhere('ip_address', request()->server('SERVER_ADDR'))
                        ->orWhere(function ($q) {
                            $q->whereNull('domain')->whereNull('ip_address');
                        });
                })
                ->where('status', 'active')
                ->where(function ($query) {
                    $query->whereNull('expires_at')
                        ->orWhere('expires_at', '>', now());
                })
                ->first();

            if (!$license) {
                return false;
            }

            // Atualiza heartbeat
            DB::table('system_licenses')
                ->where('id', $license->id)
                ->update([
                    'last_check' => now(),
                    'check_count' => DB::raw('check_count + 1')
                ]);

            // Log check
            DB::table('license_checks')->insert([
                'license_id' => $license->id,
                'check_type' => 'heartbeat',
                'status' => 'success',
                'ip_address' => request()->server('SERVER_ADDR'),
                'domain' => request()->getHost(),
                'checked_at' => now()
            ]);

            return true;

        } catch (\Exception $e) {
            \Log::error('License check failed: ' . $e->getMessage());
            return false;
        }
    }

    public static function getInfo(): ?array
    {
        try {
            $license = DB::table('system_licenses')
                ->where(function ($query) {
                    $query->where('domain', request()->getHost())
                        ->orWhere('ip_address', request()->server('SERVER_ADDR'))
                        ->orWhere(function ($q) {
                            $q->whereNull('domain')->whereNull('ip_address');
                        });
                })
                ->where('status', 'active')
                ->first();

            if (!$license) {
                return null;
            }

            return [
                'valid' => true,
                'client_name' => $license->client_name,
                'license_key' => $license->license_key,
                'plan_type' => $license->plan_type,
                'status' => $license->status,
                'issued_at' => $license->issued_at,
                'expires_at' => $license->expires_at,
                'max_clients' => $license->max_clients,
                'max_services' => $license->max_services,
                'days_remaining' => $license->expires_at 
                    ? now()->diffInDays($license->expires_at, false) 
                    : null
            ];

        } catch (\Exception $e) {
            \Log::error('License info failed: ' . $e->getMessage());
            return null;
        }
    }

    public static function clearCache(): void
    {
        Cache::forget(self::$cacheKey);
    }

    public static function isExpiring(int $days = 30): bool
    {
        $info = self::getInfo();
        
        if (!$info || !$info['expires_at']) {
            return false;
        }

        return $info['days_remaining'] !== null && $info['days_remaining'] <= $days;
    }

    public static function canAddClient(): bool
    {
        $info = self::getInfo();
        
        if (!$info || $info['max_clients'] === 0) {
            return true; // Ilimitado
        }

        $currentClients = DB::table('clients')->count();
        return $currentClients < $info['max_clients'];
    }

    public static function canAddService(): bool
    {
        $info = self::getInfo();
        
        if (!$info || $info['max_services'] === 0) {
            return true; // Ilimitado
        }

        $currentServices = DB::table('services')->count();
        return $currentServices < $info['max_services'];
    }

    public static function getPlanName(): string
    {
        $info = self::getInfo();
        
        if (!$info) {
            return 'Sem Licença';
        }

        return match($info['plan_type']) {
            'trial' => 'Trial',
            'basic' => 'Basic',
            'professional' => 'Professional',
            'enterprise' => 'Enterprise',
            'lifetime' => 'Lifetime',
            default => 'Unknown'
        };
    }
}
