<?php

namespace App\Services;

use App\Models\Invoice;
use App\Models\Service;
use Illuminate\Support\Facades\Log;

/**
 * Centraliza provisionamento e reativação após pagamento de fatura
 * (PagHiper, admin manual, ASAAS, etc.).
 */
class InvoiceFulfillmentService
{
    public function __construct(private ProvisioningService $provisioningService) {}

    public function fulfill(Invoice $invoice): void
    {
        $invoice->loadMissing(['items.service.product', 'client']);

        foreach ($invoice->items as $item) {
            if (!$item->service_id) {
                continue;
            }

            /** @var Service|null $service */
            $service = $item->service;
            if (!$service) {
                continue;
            }

            try {
                if ($service->status === 'pending') {
                    if (!$service->module) {
                        $service->update(['status' => 'active']);
                        continue;
                    }

                    $this->provisioningService->provision($service->fresh(['product', 'server']));
                } elseif ($service->status === 'suspended' && !$this->serviceHasUnpaidInvoices($service, $invoice->id)) {
                    $this->provisioningService->unsuspend($service->fresh(['product', 'server']));
                }
            } catch (\Throwable $e) {
                Log::error('Invoice fulfillment failed', [
                    'invoice_id' => $invoice->id,
                    'service_id' => $service->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }

    private function serviceHasUnpaidInvoices(Service $service, int $excludeInvoiceId): bool
    {
        return $service->invoiceItems()
            ->whereHas('invoice', function ($query) use ($excludeInvoiceId) {
                $query->where('id', '!=', $excludeInvoiceId)
                    ->whereIn('status', ['unpaid', 'overdue', 'partial']);
            })
            ->exists();
    }
}
