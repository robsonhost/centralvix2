<?php

namespace App\Services;

use App\Models\Invoice;
use App\Models\PaymentGateway;
use App\Models\Transaction;
use App\Events\InvoicePaid;
use App\Services\PaymentGateways\C6BankGateway;
use App\Services\PaymentGateways\PagHiperGateway;
use Illuminate\Support\Str;

class PaymentService
{
    /**
     * Inicia um pagamento para uma fatura
     */
    public function initiatePayment(Invoice $invoice, PaymentGateway $gateway, array $data = []): array
    {
        // Verifica se a fatura pode ser paga
        if ($invoice->isPaid()) {
            throw new \Exception('Esta fatura já foi paga.');
        }

        if ($invoice->balance_due <= 0) {
            throw new \Exception('Esta fatura não possui saldo em aberto.');
        }

        if ($invoice->status === 'cancelled') {
            throw new \Exception('Esta fatura foi cancelada e não pode ser paga.');
        }

        // Cria transação pendente
        $transaction = $this->createTransaction($invoice, $gateway, $data);

        // Processa pagamento de acordo com o gateway
        $result = match (strtolower($gateway->module)) {
            'mercadopago', 'mercado_pago' => $this->processMercadoPago($invoice, $gateway, $transaction, $data),
            'pagseguro', 'pag_seguro'     => $this->processPagSeguro($invoice, $gateway, $transaction, $data),
            'asaas'                        => $this->processAsaas($invoice, $gateway, $transaction, $data),
            'paghiper'                     => $this->processPagHiper($invoice, $gateway, $transaction, $data),
            'c6bank', 'c6_bank'            => $this->processC6Bank($invoice, $gateway, $transaction, $data),
            'pix'                          => $this->processPix($invoice, $gateway, $transaction, $data),
            'boleto'                       => $this->processBoleto($invoice, $gateway, $transaction, $data),
            'stripe'                       => $this->processStripe($invoice, $gateway, $transaction, $data),
            'paypal'                       => $this->processPayPal($invoice, $gateway, $transaction, $data),
            'credit', 'saldo', 'credit_balance' => $this->processCredit($invoice, $gateway, $transaction, $data),
            default                        => throw new \Exception('Gateway de pagamento não suportado: ' . $gateway->module),
        };

        return $result;
    }

    /**
     * Cria uma transação
     */
    private function createTransaction(Invoice $invoice, PaymentGateway $gateway, array $data): Transaction
    {
        return Transaction::create([
            'company_id'  => $invoice->company_id,
            'client_id'   => $invoice->client_id,
            'invoice_id'  => $invoice->id,
            'gateway'     => $gateway->module,
            'type'        => 'payment',
            'amount'      => $invoice->total,
            'currency'    => $invoice->currency ?? 'BRL',
            'status'      => 'pending',
            'description' => 'Fatura #' . ($invoice->invoice_number ?? $invoice->id),
            'gateway_response' => [
                'payment_method' => $data['payment_method'] ?? null,
                'metadata'       => $data['metadata'] ?? null,
            ],
        ]);
    }

    /** Mescla credenciais do registro DB com fallback em config/payment.php. */
    private function gatewaySettings(PaymentGateway $gateway, string $module): array
    {
        $cfg = config("payment.{$module}", []);
        $db  = is_array($gateway->settings) ? $gateway->settings : [];

        $merged = array_merge($cfg, $db);

        // Aliases comuns salvos no admin
        if ($module === 'paghiper') {
            $merged['api_key'] = trim((string) ($merged['api_key'] ?? $merged['apiKey'] ?? $merged['api_key_paghiper'] ?? ''));
            $merged['token']   = trim((string) ($merged['token'] ?? $merged['api_token'] ?? $merged['token_paghiper'] ?? ''));
        }

        return array_filter($merged, fn ($v) => $v !== null && $v !== '');
    }

    /**
     * Processa pagamento via Mercado Pago
     */
    private function processMercadoPago(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        $accessToken = $gateway->getSetting('access_token');
        
        if (!$accessToken) {
            throw new \Exception('Mercado Pago não configurado corretamente.');
        }

        // Cria preferência de pagamento
        $preference = [
            'items' => [[
                'title' => 'Fatura #' . $invoice->invoice_number,
                'quantity' => 1,
                'currency_id' => 'BRL',
                'unit_price' => (float) $invoice->total,
            ]],
            'payer' => [
                'name' => $invoice->client->firstname ?? '',
                'surname' => $invoice->client->lastname ?? '',
                'email' => $invoice->client->email ?? '',
            ],
            'back_urls' => [
                'success' => route('client.payment.success', ['transaction' => $transaction->id]),
                'failure' => route('client.payment.failure', ['transaction' => $transaction->id]),
                'pending' => route('client.payment.pending', ['transaction' => $transaction->id]),
            ],
            'auto_return' => 'approved',
            'external_reference' => $transaction->transaction_id,
            'notification_url' => route('webhooks.mercadopago'),
        ];

        $url = $gateway->isTestMode() 
            ? 'https://api.mercadopago.com/checkout/preferences'
            : 'https://api.mercadopago.com/checkout/preferences';

        $response = \Http::withToken($accessToken)
            ->timeout(30)
            ->post($url, $preference);

        if (!$response->successful()) {
            \Log::error('Erro no Mercado Pago', [
                'response' => $response->body(),
                'status' => $response->status()
            ]);
            throw new \Exception('Erro ao processar pagamento. Tente novamente.');
        }

        $responseData = $response->json();

        // Atualiza transação com dados do Mercado Pago
        $transaction->update([
            'gateway_transaction_id' => $responseData['id'] ?? null,
            'metadata' => array_merge($transaction->metadata ?? [], [
                'preference_id' => $responseData['id'] ?? null,
                'init_point' => $responseData['init_point'] ?? null,
            ]),
        ]);

        return [
            'success' => true,
            'redirect_url' => $responseData['init_point'] ?? null,
            'transaction' => $transaction,
            'gateway_data' => $responseData,
        ];
    }

    /**
     * Processa pagamento via PagSeguro
     */
    private function processPagSeguro(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        $email = $gateway->getSetting('email');
        $token = $gateway->getSetting('token');

        if (!$email || !$token) {
            throw new \Exception('PagSeguro não configurado corretamente.');
        }

        // Implementar integração com PagSeguro
        // Documentação: https://dev.pagseguro.uol.com.br/

        return [
            'success' => true,
            'redirect_url' => '#',
            'transaction' => $transaction,
            'message' => 'PagSeguro: Implementação em desenvolvimento',
        ];
    }

    /**
     * Processa pagamento via ASAAS
     */
    private function processAsaas(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        $apiKey = $gateway->getSetting('api_key');
        
        if (!$apiKey) {
            throw new \Exception('ASAAS não configurado corretamente.');
        }

        $baseUrl = $gateway->isTestMode() 
            ? 'https://sandbox.asaas.com/api/v3'
            : 'https://www.asaas.com/api/v3';

        // Cria cobrança no ASAAS
        $payload = [
            'customer' => $this->getOrCreateAsaasCustomer($invoice->client, $gateway),
            'billingType' => $data['billing_type'] ?? 'UNDEFINED', // PIX, BOLETO, CREDIT_CARD
            'value' => (float) $invoice->total,
            'dueDate' => $invoice->due_date->format('Y-m-d'),
            'description' => 'Fatura #' . $invoice->invoice_number,
            'externalReference' => $transaction->transaction_id,
            'postalService' => false,
        ];

        $response = \Http::withToken($apiKey)
            ->timeout(30)
            ->post("{$baseUrl}/payments", $payload);

        if (!$response->successful()) {
            \Log::error('Erro no ASAAS', [
                'response' => $response->body(),
                'status' => $response->status()
            ]);
            throw new \Exception('Erro ao processar pagamento via ASAAS.');
        }

        $responseData = $response->json();

        // Atualiza transação
        $transaction->update([
            'gateway_transaction_id' => $responseData['id'] ?? null,
            'metadata' => array_merge($transaction->metadata ?? [], [
                'asaas_payment_id' => $responseData['id'] ?? null,
                'invoice_url' => $responseData['invoiceUrl'] ?? null,
                'bank_slip_url' => $responseData['bankSlipUrl'] ?? null,
                'pix_qr_code' => $responseData['pixQrCode'] ?? null,
            ]),
        ]);

        return [
            'success' => true,
            'transaction' => $transaction,
            'invoice_url' => $responseData['invoiceUrl'] ?? null,
            'bank_slip_url' => $responseData['bankSlipUrl'] ?? null,
            'pix_code' => $responseData['pixCopyPaste'] ?? null,
            'qr_code' => $responseData['pixQrCodeBase64'] ?? null,
            'gateway_data' => $responseData,
        ];
    }

    /**
     * Obtém ou cria cliente no ASAAS
     */
    private function getOrCreateAsaasCustomer($client, PaymentGateway $gateway): string
    {
        $apiKey = $gateway->getSetting('api_key');
        $baseUrl = $gateway->isTestMode() 
            ? 'https://sandbox.asaas.com/api/v3'
            : 'https://www.asaas.com/api/v3';

        // Verifica se já tem ID do ASAAS
        if ($client->asaas_customer_id) {
            return $client->asaas_customer_id;
        }

        // Cria cliente
        $payload = [
            'name' => $client->firstname . ' ' . ($client->lastname ?? ''),
            'email' => $client->email,
            'cpfCnpj' => $client->cpf ?? $client->cnpj ?? null,
            'phone' => $client->phone ?? null,
            'mobilePhone' => $client->mobile ?? null,
            'address' => $client->address ?? null,
            'addressNumber' => $client->address_number ?? null,
            'province' => $client->district ?? null,
            'postalCode' => $client->zipcode ?? null,
        ];

        $response = \Http::withToken($apiKey)
            ->timeout(30)
            ->post("{$baseUrl}/customers", $payload);

        if ($response->successful()) {
            $data = $response->json();
            $customerId = $data['id'] ?? null;
            
            if ($customerId) {
                $client->update(['asaas_customer_id' => $customerId]);
                return $customerId;
            }
        }

        throw new \Exception('Erro ao criar cliente no ASAAS.');
    }

    /**
     * Processa pagamento via PagHiper (PIX ou Boleto Híbrido).
     */
    private function processPagHiper(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        $settings = $this->gatewaySettings($gateway, 'paghiper');

        if (empty($settings['api_key']) || empty($settings['token'])) {
            throw new \Exception('PagHiper não configurado. Informe API Key e Token no painel admin.');
        }

        if (strcasecmp($settings['api_key'], $settings['token']) === 0) {
            throw new \Exception('PagHiper: API Key e Token estão iguais. A ApiKey (apk_...) está em Minha conta → Credenciais; o Token é outro valor.');
        }

        if (!str_starts_with(strtolower($settings['api_key']), 'apk_')) {
            throw new \Exception('PagHiper: API Key inválida (deve começar com apk_). Copie em Minha conta → Credenciais — não use o Token no campo API Key.');
        }

        $service = new PagHiperGateway($settings);
        $method  = $data['payment_method'] ?? 'pix';
        $result  = $method === 'boleto'
            ? $service->generateBoleto(['invoice_id' => $invoice->id])
            : $service->generatePix(['invoice_id' => $invoice->id]);

        if (!($result['success'] ?? false)) {
            throw new \Exception($result['message'] ?? 'Erro ao processar pagamento via PagHiper.');
        }

        // Garantir que campos de texto do PIX/boleto sejam sempre string ou null
        $pixCode   = $result['pix_copy_paste'] ?? null;
        $qrCode    = $result['pix_qrcode'] ?? null;
        $digitLine = $result['boleto_digitable_line'] ?? null;

        $responsePayload = [
            'payment_method' => $method === 'boleto' ? 'boleto' : 'pix',
            'pix_code'       => is_string($pixCode) ? $pixCode : null,
            'qr_code'        => is_string($qrCode) ? $qrCode : null,
            'bank_slip_url'  => $result['boleto_url'] ?? null,
            'digitable_line' => is_string($digitLine) ? $digitLine : null,
            'barcode'        => $result['boleto_barcode'] ?? null,
            'expires_at'     => $result['expires_at'] ?? ($result['due_date'] ?? null),
            'gateway_raw'    => $result['data'] ?? null,
        ];

        $transaction->update([
            'gateway_transaction_id' => $result['charge_id'] ?? null,
            'gateway_response'     => array_merge($transaction->gateway_response ?? [], $responsePayload),
        ]);

        return [
            'success'        => true,
            'transaction'    => $transaction,
            'payment_method' => $responsePayload['payment_method'],
            'pix_code'       => $responsePayload['pix_code'],
            'qr_code'        => $responsePayload['qr_code'],
            'bank_slip_url'  => $responsePayload['bank_slip_url'],
            'digitable_line' => $responsePayload['digitable_line'],
            'gateway_data'   => $result,
        ];
    }

    /**
     * Processa pagamento via C6 Bank PIX.
     */
    private function processC6Bank(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        $settings = $this->gatewaySettings($gateway, 'c6bank');

        if (empty($settings['client_id']) || empty($settings['client_secret']) || empty($settings['pix_key'])) {
            throw new \Exception('C6 Bank não configurado. Informe Client ID, Client Secret e Chave PIX.');
        }

        $service = new C6BankGateway($settings);
        $result  = $service->generatePix(['invoice_id' => $invoice->id]);

        if (!($result['success'] ?? false)) {
            throw new \Exception($result['message'] ?? 'Erro ao gerar PIX C6 Bank.');
        }

        $responsePayload = [
            'payment_method' => 'pix',
            'pix_code'       => $result['pix_copy_paste'] ?? null,
            'qr_code'        => $result['pix_qrcode'] ?? null,
            'expires_at'     => $result['expires_at'] ?? null,
            'gateway_raw'    => $result['data'] ?? null,
        ];

        $transaction->update([
            'gateway_transaction_id' => $result['charge_id'] ?? null,
            'gateway_response'     => array_merge($transaction->gateway_response ?? [], $responsePayload),
        ]);

        return [
            'success'        => true,
            'transaction'    => $transaction,
            'payment_method' => 'pix',
            'pix_code'       => $responsePayload['pix_code'],
            'qr_code'        => $responsePayload['qr_code'],
            'gateway_data'   => $result,
        ];
    }

    /**
     * Processa pagamento via PIX
     */
    private function processPix(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        // Gera código PIX (QR Code)
        // Pode usar Mercado Pago, PagSeguro ou outro provedor de PIX

        return [
            'success' => true,
            'transaction' => $transaction,
            'pix_code' => 'PIX_CODE_HERE',
            'qr_code' => 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
            'message' => 'Escaneie o QR Code ou copie o código PIX para pagar',
        ];
    }

    /**
     * Processa pagamento via Boleto
     */
    private function processBoleto(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        // Gera boleto bancário
        // Pode usar Mercado Pago, PagSeguro ou outro provedor

        return [
            'success' => true,
            'transaction' => $transaction,
            'boleto_url' => '#',
            'barcode' => '12345678901234567890123456789012345678901234567890',
            'message' => 'Boleto gerado com sucesso',
        ];
    }

    /**
     * Processa pagamento com saldo (crédito) do cliente
     */
    private function processCredit(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        $client = $invoice->client;

        if (!$client) {
            throw new \Exception('Cliente não encontrado para esta fatura.');
        }

        $amount = (float) $invoice->total;

        if (!$client->deductCredit($amount)) {
            throw new \Exception('Saldo insuficiente na conta para pagar esta fatura.');
        }

        $this->confirmPayment($transaction, [
            'method'  => 'credit',
            'paid_at' => now()->toIso8601String(),
        ]);

        return [
            'success'      => true,
            'redirect_url' => route('client.invoices.show', $invoice),
            'transaction'  => $transaction->fresh(),
            'message'      => 'Fatura paga com saldo da conta.',
        ];
    }

    /**
     * Processa pagamento via Stripe (Checkout Session)
     */
    private function processStripe(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        $settings = $this->gatewaySettings($gateway, 'stripe');
        $secretKey = $settings['secret_key'] ?? $gateway->getSetting('secret_key');

        if (!$secretKey) {
            throw new \Exception('Stripe não configurado corretamente.');
        }

        $currency = strtolower($invoice->currency ?? 'brl');
        $successUrl = route('client.invoices.show', $invoice) . '?paid=1&session_id={CHECKOUT_SESSION_ID}';
        $cancelUrl = route('client.payment.checkout', $invoice);

        $response = \Http::asForm()
            ->withBasicAuth($secretKey, '')
            ->timeout(30)
            ->post('https://api.stripe.com/v1/checkout/sessions', [
                'mode' => 'payment',
                'success_url' => $successUrl,
                'cancel_url' => $cancelUrl,
                'client_reference_id' => (string) $transaction->id,
                'metadata[invoice_id]' => (string) $invoice->id,
                'metadata[transaction_id]' => (string) $transaction->transaction_id,
                'line_items[0][price_data][currency]' => $currency,
                'line_items[0][price_data][product_data][name]' => 'Fatura #' . ($invoice->invoice_number ?? $invoice->id),
                'line_items[0][price_data][unit_amount]' => (int) round((float) $invoice->total * 100),
                'line_items[0][quantity]' => 1,
            ]);

        if (!$response->successful()) {
            \Log::error('Stripe Checkout Session failed', ['body' => $response->body()]);
            throw new \Exception('Erro ao iniciar pagamento no Stripe.');
        }

        $session = $response->json();
        $sessionId = $session['id'] ?? null;
        $redirectUrl = $session['url'] ?? null;

        if (!$redirectUrl) {
            throw new \Exception('Stripe não retornou URL de pagamento.');
        }

        $transaction->update([
            'gateway_transaction_id' => $sessionId,
            'gateway_response' => array_merge($transaction->gateway_response ?? [], [
                'stripe_session_id' => $sessionId,
                'checkout_url' => $redirectUrl,
            ]),
        ]);

        return [
            'success' => true,
            'redirect_url' => $redirectUrl,
            'transaction' => $transaction->fresh(),
            'message' => 'Redirecionando para o Stripe...',
        ];
    }

    /**
     * Processa pagamento via PayPal (Checkout redirect)
     */
    private function processPayPal(Invoice $invoice, PaymentGateway $gateway, Transaction $transaction, array $data): array
    {
        $paypal = new \Modules\Billing\Gateways\PayPalGateway($gateway);
        $result = $paypal->charge($invoice, $data);

        if (empty($result['redirect_url'])) {
            throw new \Exception($result['error'] ?? 'Erro ao iniciar pagamento no PayPal.');
        }

        $transaction->update([
            'gateway_transaction_id' => $result['transaction_id'] ?? null,
            'gateway_response' => array_merge($transaction->gateway_response ?? [], [
                'paypal_order_id' => $result['transaction_id'] ?? null,
                'redirect_url' => $result['redirect_url'],
            ]),
        ]);

        return [
            'success' => true,
            'redirect_url' => $result['redirect_url'],
            'transaction' => $transaction->fresh(),
            'message' => 'Redirecionando para o PayPal...',
        ];
    }

    /**
     * Confirma um pagamento (chamado pelo webhook)
     */
    public function confirmPayment(Transaction $transaction, array $webhookData = []): bool
    {
        if ($transaction->status === 'completed') {
            return true;
        }

        $transaction->update([
            'status'           => 'completed',
            'gateway_response' => array_merge($transaction->gateway_response ?? [], $webhookData, ['paid_at' => now()->toIso8601String()]),
        ]);

        // Atualiza fatura
        $invoice = $transaction->invoice;
        $invoice->update([
            'status' => 'paid',
            'date_paid' => now(),
            'payment_gateway' => $transaction->gateway,
        ]);

        // Ativa serviços associados via serviço centralizado
        try {
            app(InvoiceFulfillmentService::class)->fulfill($invoice);
        } catch (\Throwable $e) {
            \Log::error('Invoice fulfillment failed after payment', [
                'invoice_id' => $invoice->id,
                'error' => $e->getMessage(),
            ]);
        }

        // Notificação de pagamento (e-mail + WhatsApp com auto login)
        try {
            InvoicePaid::dispatch($invoice);
        } catch (\Exception $e) {
            \Log::error('Erro ao disparar notificação de pagamento: ' . $e->getMessage());
        }

        // Log da atividade
        activity()
            ->performedOn($invoice)
            ->causedBy($invoice->client)
            ->log('Pagamento confirmado via ' . $transaction->gateway);

        return true;
    }

    /**
     * Consulta gateways e atualiza status da fatura quando o pagamento foi confirmado.
     */
    public function syncInvoiceStatus(Invoice $invoice): bool
    {
        if ($invoice->isPaid()) {
            return true;
        }

        $transaction = $invoice->transactions()
            ->whereIn('status', ['pending', 'processing'])
            ->whereNotNull('gateway_transaction_id')
            ->latest()
            ->first();

        if (!$transaction) {
            return false;
        }

        $paid = $this->syncTransactionWithGateway($transaction);

        if ($paid) {
            $this->confirmPayment($transaction);
            $invoice->refresh();

            return true;
        }

        return false;
    }

    /**
     * Sincroniza uma transação pendente com o gateway (PIX/boleto).
     */
    public function syncTransactionWithGateway(Transaction $transaction): bool
    {
        if (in_array($transaction->status, ['completed', 'paid'], true)) {
            return true;
        }

        $chargeId = $transaction->gateway_transaction_id;
        if (!$chargeId) {
            return false;
        }

        $gateway = PaymentGateway::where('company_id', $transaction->company_id)
            ->where('module', $transaction->gateway)
            ->where('status', 'active')
            ->first();

        if (!$gateway) {
            return false;
        }

        $module = strtolower((string) $transaction->gateway);

        try {
            if ($module === 'paghiper') {
                $service = new PagHiperGateway($this->gatewaySettings($gateway, 'paghiper'));
                $result = $service->getCharge($chargeId);
                if (!($result['success'] ?? false)) {
                    return false;
                }
                $status = strtolower((string) ($result['data']['status'] ?? ''));

                return in_array($status, ['paid', 'completed', 'confirmed'], true);
            }

            if (in_array($module, ['c6bank', 'c6_bank'], true)) {
                $service = new C6BankGateway($this->gatewaySettings($gateway, 'c6bank'));
                $result = $service->getCharge($chargeId);
                if (!($result['success'] ?? false)) {
                    return false;
                }
                $status = strtoupper((string) ($result['data']['status'] ?? ''));

                return $status === 'CONCLUIDA';
            }

            if ($module === 'asaas') {
                $settings = $this->gatewaySettings($gateway, 'asaas');
                $apiKey = $settings['api_key'] ?? null;
                if (!$apiKey) {
                    return false;
                }
                $sandbox = filter_var($settings['sandbox'] ?? true, FILTER_VALIDATE_BOOLEAN);
                $baseUrl = $sandbox
                    ? 'https://sandbox.asaas.com/api/v3'
                    : 'https://www.asaas.com/api/v3';
                $response = \Http::withToken($apiKey)->timeout(15)->get("{$baseUrl}/payments/{$chargeId}");
                if (!$response->successful()) {
                    return false;
                }
                $status = strtoupper((string) ($response->json()['status'] ?? ''));

                return in_array($status, ['RECEIVED', 'CONFIRMED'], true);
            }
        } catch (\Throwable $e) {
            \Log::warning('syncTransactionWithGateway: ' . $e->getMessage(), [
                'transaction_id' => $transaction->id,
                'gateway' => $module,
            ]);
        }

        return false;
    }

    /**
     * Processa webhook de pagamento (compatível com jobs legados).
     */
    public function processWebhookPayment(string $gateway, array $payload): bool
    {
        $module = strtolower($gateway);

        if ($module === 'paghiper') {
            $apiKey        = trim((string) ($payload['apiKey'] ?? $payload['api_key'] ?? ''));
            $transactionId = $payload['transaction_id'] ?? null;
            $settings      = config('payment.paghiper', []);

            if ($apiKey) {
                $gateways = PaymentGateway::where('module', 'paghiper')
                    ->where('status', 'active')
                    ->get();

                foreach ($gateways as $gw) {
                    $s        = is_array($gw->settings) ? $gw->settings : [];
                    $gwApiKey = trim((string) ($s['api_key'] ?? $s['apiKey'] ?? ''));
                    if ($gwApiKey === $apiKey) {
                        $settings = array_merge($settings, $s);
                        break;
                    }
                }
            } elseif ($transactionId) {
                $txn = Transaction::where('gateway_transaction_id', $transactionId)
                    ->where('gateway', 'paghiper')
                    ->latest()
                    ->first();

                if ($txn) {
                    $gw = PaymentGateway::where('company_id', $txn->company_id)
                        ->where('module', 'paghiper')
                        ->where('status', 'active')
                        ->first();

                    if ($gw) {
                        $settings = array_merge($settings, is_array($gw->settings) ? $gw->settings : []);
                    }
                }
            }

            $service = new PagHiperGateway($settings);
            $service->processWebhook($payload, $this);

            return true;
        }

        return false;
    }
}
