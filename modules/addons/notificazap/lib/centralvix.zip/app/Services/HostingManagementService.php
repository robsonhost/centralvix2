<?php

namespace App\Services;

use App\Models\Service;
use RuntimeException;

class HostingManagementService
{
    public function __construct(private ProvisioningService $provisioning)
    {
    }

    public function isManageable(Service $service): bool
    {
        return $service->isHostingManageable();
    }

    public function assertAccess(Service $service): void
    {
        if (!auth()->user()?->canAccessClientRecord($service->client)) {
            abort(403);
        }

        if (!$this->isManageable($service)) {
            abort(404, 'Gestão de hospedagem não disponível para este serviço.');
        }
    }

    public function assertMutable(Service $service): void
    {
        $this->assertAccess($service);

        if (!$service->canMutateHosting()) {
            abort(403, 'Alterações bloqueadas enquanto o serviço estiver suspenso.');
        }
    }

    public function module(Service $service): object
    {
        $service->loadMissing(['server', 'product']);

        if (!$service->server) {
            throw new RuntimeException('Servidor não configurado para este serviço.');
        }

        return $this->provisioning->getModule($service);
    }

    public function call(Service $service, string $method, array $args = []): mixed
    {
        $module = $this->module($service);

        if (!method_exists($module, $method)) {
            throw new RuntimeException("Recurso não suportado pelo módulo de hospedagem.");
        }

        return $module->{$method}($service, ...$args);
    }

    public function getOverview(Service $service): array
    {
        $stats = [];
        $account = null;

        try {
            if (method_exists($this->module($service), 'getStats')) {
                $stats = $this->call($service, 'getStats') ?: [];
            }
        } catch (\Throwable $e) {
            logger()->warning('Hosting stats unavailable', ['service_id' => $service->id, 'error' => $e->getMessage()]);
        }

        try {
            if (method_exists($this->module($service), 'getAccountInfo')) {
                $account = $this->call($service, 'getAccountInfo');
            }
        } catch (\Throwable $e) {
            // opcional
        }

        return [
            'stats' => $stats,
            'account' => $account,
            'nameservers' => $service->module_data['nameservers'] ?? $service->server?->settings['nameservers'] ?? [],
            'cpanel_url' => $service->module_data['cpanel_url'] ?? null,
        ];
    }

    public function listDnsRecords(Service $service): array
    {
        return $this->call($service, 'listDnsRecords') ?: [];
    }

    public function addDnsRecord(Service $service, array $record): bool
    {
        return (bool) $this->call($service, 'addDnsRecord', [$record]);
    }

    public function deleteDnsRecord(Service $service, int $line): bool
    {
        return (bool) $this->call($service, 'deleteDnsRecord', [$line]);
    }

    public function listEmailAccounts(Service $service): array
    {
        return $this->call($service, 'listEmailAccounts') ?: [];
    }

    public function createEmailAccount(Service $service, string $localPart, string $password, int $quotaMb = 250): bool
    {
        return (bool) $this->call($service, 'createEmailAccount', [$localPart, $password, $quotaMb]);
    }

    public function deleteEmailAccount(Service $service, string $email): bool
    {
        return (bool) $this->call($service, 'deleteEmailAccount', [$email]);
    }

    public function changeEmailPassword(Service $service, string $email, string $password): bool
    {
        return (bool) $this->call($service, 'changeEmailPassword', [$email, $password]);
    }

    public function listFtpAccounts(Service $service): array
    {
        return $this->call($service, 'listFtpAccounts') ?: [];
    }

    public function createFtpAccount(Service $service, string $user, string $password, string $directory = ''): bool
    {
        return (bool) $this->call($service, 'createFtpAccount', [$user, $password, $directory]);
    }

    public function deleteFtpAccount(Service $service, string $user): bool
    {
        return (bool) $this->call($service, 'deleteFtpAccount', [$user]);
    }

    public function listSslCertificates(Service $service): array
    {
        return $this->call($service, 'listSslCertificates') ?: [];
    }

    public function runAutoSsl(Service $service): bool
    {
        return (bool) $this->call($service, 'runAutoSsl');
    }

    public function changeHostingPassword(Service $service, string $password): bool
    {
        return $this->provisioning->changePassword($service, $password);
    }
}
