<?php

namespace App\Services;

use App\Models\Invoice;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Schema;

/**
 * Cálculo e aplicação de multa e juros em faturas vencidas.
 *
 * Estratégia idempotente: a "base" da fatura é sempre reconstituída como
 * total - encargos atuais, então recalcular todos os dias não acumula erro.
 */
class LateFeeService
{
    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function isEnabled(int $companyId): bool
    {
        return $this->modules->isEnabled($companyId, 'late_fees');
    }

    public function config(int $companyId): array
    {
        return $this->settings->all($companyId, 'late_fees');
    }

    private function dueColumn(): string
    {
        return Schema::hasColumn('invoices', 'date_due') ? 'date_due' : 'due_date';
    }

    /**
     * Calcula multa e juros (sem persistir).
     *
     * @return array{fine: float, interest: float, days_overdue: int, base: float}
     */
    public function calculate(Invoice $invoice, ?array $cfg = null, ?Carbon $asOf = null): array
    {
        $cfg ??= $this->config($invoice->company_id);
        $asOf = ($asOf ?? now())->copy()->startOfDay();

        $base = (float) $invoice->base_amount;
        $dueRaw = $invoice->{$this->dueColumn()};

        $result = ['fine' => 0.0, 'interest' => 0.0, 'days_overdue' => 0, 'base' => $base];

        if (!$dueRaw || $base <= 0) {
            return $result;
        }

        $due = Carbon::parse($dueRaw)->startOfDay();
        if ($asOf->lessThanOrEqualTo($due)) {
            return $result;
        }

        $daysOverdue = $due->diffInDays($asOf);
        $result['days_overdue'] = $daysOverdue;

        $grace = (int) ($cfg['grace_days'] ?? 0);
        if ($daysOverdue <= $grace) {
            return $result;
        }

        $finePct = (float) ($cfg['fine_percent'] ?? 0);
        $interestPct = (float) ($cfg['interest_percent_month'] ?? 0);

        $fine = round($base * $finePct / 100, 2);
        // Juros pro-rata por dia (mês comercial = 30 dias).
        $interest = round($base * ($interestPct / 100) * ($daysOverdue / 30), 2);

        // Teto total de encargos.
        $maxPct = (int) ($cfg['max_total_percent'] ?? 0);
        if ($maxPct > 0) {
            $cap = round($base * $maxPct / 100, 2);
            if (($fine + $interest) > $cap) {
                if ($fine > $cap) {
                    $fine = $cap;
                    $interest = 0.0;
                } else {
                    $interest = round($cap - $fine, 2);
                }
            }
        }

        $result['fine'] = $fine;
        $result['interest'] = $interest;

        return $result;
    }

    /**
     * Aplica (persiste) multa e juros de forma idempotente.
     * Retorna true se houve alteração.
     */
    public function apply(Invoice $invoice, ?array $cfg = null, ?Carbon $asOf = null): bool
    {
        if (in_array($invoice->status, ['paid', 'cancelled', 'refunded', 'draft'], true)) {
            return false;
        }

        $calc = $this->calculate($invoice, $cfg, $asOf);

        $newFee = $calc['fine'];
        $newInterest = $calc['interest'];

        $unchanged = abs((float) $invoice->late_fee - $newFee) < 0.005
            && abs((float) $invoice->interest - $newInterest) < 0.005;

        if ($unchanged) {
            return false;
        }

        $invoice->late_fee = $newFee;
        $invoice->interest = $newInterest;
        $invoice->total = round($calc['base'] + $newFee + $newInterest, 2);
        $invoice->late_fee_updated_at = now();
        $invoice->save();

        return true;
    }

    /**
     * Remove encargos e restaura o valor base (ex.: renegociação/perdão).
     */
    public function clear(Invoice $invoice): void
    {
        $base = (float) $invoice->base_amount;

        $invoice->late_fee = 0;
        $invoice->interest = 0;
        $invoice->total = round($base, 2);
        $invoice->late_fee_updated_at = now();
        $invoice->save();
    }
}
