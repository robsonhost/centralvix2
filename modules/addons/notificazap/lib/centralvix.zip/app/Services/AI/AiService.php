<?php

namespace App\Services\AI;

use App\Models\AiInteraction;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * CentralVix AI Service
 *
 * Supports: OpenAI (GPT), Anthropic (Claude), Google (Gemini)
 */
class AiService
{
    private string $provider;

    public function __construct(?string $provider = null)
    {
        $this->provider = $provider ?? config('ai.provider', 'openai');
    }

    /**
     * Generic completion — returns string response.
     */
    public function complete(
        string $prompt,
        string $systemPrompt = '',
        ?int   $companyId    = null,
        ?int   $clientId     = null,
        string $contextType  = '',
        int    $contextId    = 0
    ): string {
        if (!config('ai.enabled')) {
            return '';
        }

        $interaction = AiInteraction::create([
            'company_id'   => $companyId,
            'client_id'    => $clientId,
            'provider'     => $this->provider,
            'model'        => $this->getModel(),
            'context_type' => $contextType ?: null,
            'context_id'   => $contextId ?: null,
            'prompt'       => $prompt,
            'status'       => 'pending',
        ]);

        try {
            $result = match ($this->provider) {
                'openai'    => $this->openai($prompt, $systemPrompt),
                'anthropic' => $this->anthropic($prompt, $systemPrompt),
                'gemini'    => $this->gemini($prompt, $systemPrompt),
                default     => throw new \InvalidArgumentException("Provider {$this->provider} not supported."),
            };

            $interaction->update([
                'response'    => $result['text'],
                'tokens_used' => $result['tokens'] ?? 0,
                'cost_usd'    => $result['cost'] ?? 0,
                'status'      => 'completed',
            ]);

            return $result['text'];
        } catch (\Exception $e) {
            Log::error("AI completion failed [{$this->provider}]: " . $e->getMessage());

            $interaction->update([
                'status' => 'failed',
                'error'  => $e->getMessage(),
            ]);

            return '';
        }
    }

    /**
     * Summarize a ticket thread.
     */
    public function summarizeTicket(string $ticketContent, int $companyId): string
    {
        $system = config('ai.prompts.ticket_summary');
        return $this->complete($ticketContent, $system, $companyId, null, 'ticket');
    }

    /**
     * Generate a ticket reply suggestion.
     */
    public function suggestTicketReply(string $customerMessage, int $companyId): string
    {
        $system = config('ai.prompts.ticket_reply');
        return $this->complete($customerMessage, $system, $companyId, null, 'ticket');
    }

    /**
     * Summarize a contract.
     */
    public function summarizeContract(string $contractContent, int $companyId): string
    {
        $system = config('ai.prompts.contract_summary');
        return $this->complete($contractContent, $system, $companyId, null, 'contract');
    }

    /**
     * Generate billing message.
     */
    public function generateBillingMessage(array $invoiceData, int $companyId): string
    {
        $system  = config('ai.prompts.billing_message');
        $prompt  = "Dados da fatura: " . json_encode($invoiceData, JSON_UNESCAPED_UNICODE);
        return $this->complete($prompt, $system, $companyId, null, 'invoice');
    }

    /**
     * Auto-reply for WhatsApp.
     */
    public function whatsappReply(string $customerMessage, array $context = [], int $companyId = 0): string
    {
        $system  = config('ai.prompts.whatsapp_reply');
        $ctx     = !empty($context) ? "\n\nContexto: " . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
        return $this->complete($customerMessage . $ctx, $system, $companyId, null, 'whatsapp');
    }

    // ============================
    // PROVIDERS
    // ============================

    private function openai(string $prompt, string $system = ''): array
    {
        $cfg  = config('ai.openai');
        $msgs = [];

        if ($system) {
            $msgs[] = ['role' => 'system', 'content' => $system];
        }
        $msgs[] = ['role' => 'user', 'content' => $prompt];

        $response = Http::withToken($cfg['api_key'])
            ->timeout(60)
            ->post($cfg['base_url'] . '/chat/completions', [
                'model'      => $cfg['model'],
                'messages'   => $msgs,
                'max_tokens' => $cfg['max_tokens'],
            ]);

        if (!$response->successful()) {
            throw new \RuntimeException("OpenAI error: " . $response->body());
        }

        $data   = $response->json();
        $tokens = $data['usage']['total_tokens'] ?? 0;

        // Cost approximation for gpt-4o: $2.50/1M input + $10/1M output
        $cost = ($data['usage']['prompt_tokens'] ?? 0) * 0.0000025
              + ($data['usage']['completion_tokens'] ?? 0) * 0.00001;

        return [
            'text'   => $data['choices'][0]['message']['content'] ?? '',
            'tokens' => $tokens,
            'cost'   => $cost,
        ];
    }

    private function anthropic(string $prompt, string $system = ''): array
    {
        $cfg = config('ai.anthropic');

        $body = [
            'model'      => $cfg['model'],
            'max_tokens' => $cfg['max_tokens'],
            'messages'   => [['role' => 'user', 'content' => $prompt]],
        ];

        if ($system) {
            $body['system'] = $system;
        }

        $response = Http::withHeaders([
            'x-api-key'         => $cfg['api_key'],
            'anthropic-version' => '2023-06-01',
            'Content-Type'      => 'application/json',
        ])->timeout(60)->post($cfg['base_url'] . '/v1/messages', $body);

        if (!$response->successful()) {
            throw new \RuntimeException("Anthropic error: " . $response->body());
        }

        $data   = $response->json();
        $tokens = ($data['usage']['input_tokens'] ?? 0) + ($data['usage']['output_tokens'] ?? 0);

        // Claude 3.5 Sonnet: $3/1M input + $15/1M output
        $cost = ($data['usage']['input_tokens'] ?? 0) * 0.000003
              + ($data['usage']['output_tokens'] ?? 0) * 0.000015;

        return [
            'text'   => $data['content'][0]['text'] ?? '',
            'tokens' => $tokens,
            'cost'   => $cost,
        ];
    }

    private function gemini(string $prompt, string $system = ''): array
    {
        $cfg       = config('ai.gemini');
        $fullPrompt = ($system ? $system . "\n\n" : '') . $prompt;

        $response = Http::timeout(60)
            ->post($cfg['base_url'] . "/models/{$cfg['model']}:generateContent?key={$cfg['api_key']}", [
                'contents' => [
                    ['parts' => [['text' => $fullPrompt]]],
                ],
                'generationConfig' => [
                    'maxOutputTokens' => 2000,
                    'temperature'     => 0.7,
                ],
            ]);

        if (!$response->successful()) {
            throw new \RuntimeException("Gemini error: " . $response->body());
        }

        $data = $response->json();
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

        return [
            'text'   => $text,
            'tokens' => $data['usageMetadata']['totalTokenCount'] ?? 0,
            'cost'   => 0,
        ];
    }

    private function getModel(): string
    {
        return match ($this->provider) {
            'openai'    => config('ai.openai.model'),
            'anthropic' => config('ai.anthropic.model'),
            'gemini'    => config('ai.gemini.model'),
            default     => 'unknown',
        };
    }
}
