<?php

namespace App\Services;

use App\Models\Domain;
use App\Models\DomainPricing;
use Illuminate\Support\Str;

class DomainService
{
    public function resolveRegistrar(string $domain): string
    {
        $domain = strtolower(trim($domain));

        if (Str::endsWith($domain, '.br') || Str::endsWith($domain, '.com.br')) {
            return 'RegistroBrRegistrar';
        }

        return 'GenericRdapRegistrar';
    }

    public function checkAvailability(string $domain, int $companyId): array
    {
        $domain = strtolower(trim($domain));
        $domain = preg_replace('/^https?:\/\//', '', $domain);
        $domain = rtrim($domain, '/');

        if (!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/', $domain)) {
            return [
                'available' => false,
                'domain' => $domain,
                'message' => 'Formato de domínio inválido.',
                'price' => null,
                'tld' => null,
            ];
        }

        if (Domain::where('company_id', $companyId)->where('domain', $domain)->exists()) {
            return [
                'available' => false,
                'domain' => $domain,
                'message' => 'Este domínio já está cadastrado no sistema.',
                'price' => null,
                'tld' => $this->extractTld($domain),
            ];
        }

        $tld = $this->extractTld($domain);
        $pricing = DomainPricing::where('company_id', $companyId)
            ->where('active', true)
            ->where(function ($q) use ($tld) {
                $q->where('tld', $tld)
                  ->orWhere('tld', ltrim($tld, '.'))
                  ->orWhere('tld', '.' . ltrim($tld, '.'));
            })
            ->first();

        try {
            $registrarName = $this->resolveRegistrar($domain);
            $registrar = $this->loadRegistrar($registrarName);
            $available = $registrar->checkAvailability($domain);

            return [
                'available' => $available,
                'domain' => $domain,
                'message' => $available
                    ? 'Domínio disponível para registro!'
                    : 'Domínio indisponível ou já registrado.',
                'price' => $pricing?->register_price,
                'renew_price' => $pricing?->renew_price,
                'tld' => $tld,
                'registrar' => $registrarName,
            ];
        } catch (\Exception $e) {
            logger()->error("Domain availability check failed: " . $e->getMessage());

            return [
                'available' => false,
                'domain' => $domain,
                'message' => 'Erro ao verificar disponibilidade. Tente novamente.',
                'price' => $pricing?->register_price,
                'tld' => $tld,
            ];
        }
    }

    public function register(array $data, int $companyId): Domain
    {
        $domainName = strtolower(trim($data['domain']));
        $years = (int) ($data['years'] ?? 1);
        $registrarName = $data['registrar'] ?? $this->resolveRegistrar($domainName);

        $domain = Domain::create([
            'company_id' => $companyId,
            'client_id' => $data['client_id'],
            'domain' => $domainName,
            'tld' => $this->extractTld($domainName),
            'registrar' => $this->registrarLabel($registrarName),
            'status' => 'pending',
            'registration_date' => now(),
            'expiry_date' => now()->addYears($years),
            'next_due_date' => now()->addYears($years),
            'auto_renew' => $data['auto_renew'] ?? true,
            'privacy_protection' => $data['privacy_protection'] ?? false,
            'nameservers' => $data['nameservers'] ?? null,
        ]);

        try {
            if ($registrarName !== 'Manual') {
                $registrar = $this->loadRegistrar($registrarName);
                $registrar->register($domain);
            }

            $domain->update(['status' => 'active']);
        } catch (\Exception $e) {
            logger()->error("Domain registration failed for {$domainName}: " . $e->getMessage());
            $domain->update([
                'status' => 'active',
                'registrar_data' => ['warning' => 'Registrado localmente. API do registrar pendente.'],
            ]);
        }

        return $domain->fresh();
    }

    public function activateRegistration(Domain $domain, int $years = 1): Domain
    {
        try {
            if ($domain->registrar && $domain->registrar !== 'Manual') {
                $registrar = $this->loadRegistrar($this->registrarClass($domain->registrar));
                $registrar->register($domain);
            }
        } catch (\Exception $e) {
            logger()->error("Domain registration API failed for {$domain->domain}: " . $e->getMessage());
        }

        $domain->update([
            'status' => 'active',
            'registration_date' => $domain->registration_date ?? now(),
            'expiry_date' => now()->addYears($years),
            'next_due_date' => now()->addYears($years),
        ]);

        return $domain->fresh();
    }

    public function renew(Domain $domain, int $years = 1): bool
    {
        try {
            if ($domain->registrar && $domain->registrar !== 'Manual') {
                $registrar = $this->loadRegistrar($this->registrarClass($domain->registrar));
                $registrar->renew($domain, $years);
            }

            $baseDate = $domain->expiry_date && $domain->expiry_date->isFuture()
                ? $domain->expiry_date
                : now();

            $domain->update([
                'expiry_date' => $baseDate->copy()->addYears($years),
                'next_due_date' => $baseDate->copy()->addYears($years),
                'status' => 'active',
            ]);

            return true;
        } catch (\Exception $e) {
            logger()->error("Domain renewal failed for {$domain->domain}: " . $e->getMessage());
            throw $e;
        }
    }

    public function updateNameservers(Domain $domain, array $nameservers): bool
    {
        $nameservers = array_values(array_filter(array_map('trim', $nameservers)));

        if ($domain->registrar && $domain->registrar !== 'Manual') {
            try {
                $registrar = $this->loadRegistrar($this->registrarClass($domain->registrar));
                $registrar->updateNameservers($domain, $nameservers);
            } catch (\Exception $e) {
                logger()->error("Update nameservers failed: " . $e->getMessage());
            }
        }

        $domain->update(['nameservers' => $nameservers]);
        return true;
    }

    public function getEppCode(Domain $domain): ?string
    {
        if (!$domain->registrar || $domain->registrar === 'Manual') {
            return $domain->epp_code;
        }

        try {
            $registrar = $this->loadRegistrar($this->registrarClass($domain->registrar));
            return $registrar->getEppCode($domain);
        } catch (\Exception $e) {
            logger()->error("Get EPP code failed for {$domain->domain}: " . $e->getMessage());
            return $domain->epp_code;
        }
    }

    public function getWhoisInfo(Domain $domain): array
    {
        try {
            $registrarName = $this->registrarClass($domain->registrar ?? '');
            $registrar = $this->loadRegistrar($registrarName);
            return $registrar->getInfo($domain->domain);
        } catch (\Exception $e) {
            return [];
        }
    }

    private function extractTld(string $domain): string
    {
        $parts = explode('.', $domain);
        if (count($parts) >= 3 && end($parts) === 'br') {
            return '.' . $parts[count($parts) - 2] . '.br';
        }
        return '.' . end($parts);
    }

    private function registrarLabel(string $className): string
    {
        return match ($className) {
            'RegistroBrRegistrar' => 'Registro.br',
            'GenericRdapRegistrar' => 'RDAP',
            default => 'Manual',
        };
    }

    private function registrarClass(string $label): string
    {
        return match ($label) {
            'Registro.br', 'RegistroBrRegistrar' => 'RegistroBrRegistrar',
            'RDAP', 'GenericRdapRegistrar' => 'GenericRdapRegistrar',
            default => 'GenericRdapRegistrar',
        };
    }

    private function loadRegistrar(string $registrarName): object
    {
        $class = "Modules\\Domain\\Registrars\\{$registrarName}";

        if (!class_exists($class)) {
            throw new \RuntimeException("Registrar {$registrarName} not found.");
        }

        return new $class();
    }
}
