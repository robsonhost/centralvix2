<?php

namespace App\Events;

use App\Models\Service;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Event fired when a service is suspended (automatically or manually)
 * 
 * Requirements: 63.1 - Domain Events structure
 */
class ServiceSuspended
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public Service $service;
    public string $reason;
    public bool $isAutomatic;
    public ?int $suspendedByAdminId;

    /**
     * Create a new event instance.
     */
    public function __construct(
        Service $service,
        string $reason = 'automatic_overdue',
        bool $isAutomatic = true,
        ?int $suspendedByAdminId = null
    ) {
        $this->service = $service;
        $this->reason = $reason;
        $this->isAutomatic = $isAutomatic;
        $this->suspendedByAdminId = $suspendedByAdminId;
    }
}
