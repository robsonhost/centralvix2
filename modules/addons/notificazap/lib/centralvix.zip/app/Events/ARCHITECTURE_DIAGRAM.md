# Domain Events Architecture Diagram

## Event Flow Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                        BUSINESS ACTION                              │
│  (Service Suspended, Invoice Paid, Service Provisioned, etc.)      │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             │ event(new ServiceSuspended($service))
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      DOMAIN EVENT FIRED                             │
│  ServiceSuspended / InvoicePaid / ServiceProvisioned / etc.         │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             │ Laravel Event System
                             │
            ┌────────────────┼────────────────┐
            │                │                │
            ▼                ▼                ▼
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
    │  Listener 1  │  │  Listener 2  │  │  Listener 3  │
    │   (Sync)     │  │   (Queued)   │  │   (Queued)   │
    └──────┬───────┘  └──────┬───────┘  └──────┬───────┘
           │                 │                 │
           │ Execute         │ Push to         │ Push to
           │ Immediately     │ Queue           │ Queue
           │                 │                 │
           ▼                 ▼                 ▼
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
    │   Log to     │  │  Redis Queue │  │  Redis Queue │
    │   File       │  │              │  │              │
    └──────────────┘  └──────┬───────┘  └──────┬───────┘
                             │                 │
                      ┌──────┴─────────────────┘
                      │ Queue Worker Processing
                      │ (Laravel Horizon)
                      │
            ┌─────────┴──────────┬──────────────┐
            │                    │              │
            ▼                    ▼              ▼
    ┌──────────────┐    ┌──────────────┐  ┌──────────────┐
    │    Send      │    │   Check      │  │   Trigger    │
    │ Notification │    │ Reactivation │  │   Webhook    │
    └──────────────┘    └──────────────┘  └──────────────┘
```

## ServiceSuspended Event Flow

```
┌───────────────────────────────────────────────────────────────────┐
│  TRIGGER: SuspensionAutomationEngine->suspendService()            │
│           OR Admin clicks "Suspend" button                        │
└────────────────────────┬──────────────────────────────────────────┘
                         │
                         ▼
         event(new ServiceSuspended($service, $reason, $isAuto))
                         │
        ┌────────────────┴────────────────┐
        │                                 │
        ▼                                 ▼
┌───────────────────────┐      ┌──────────────────────────┐
│ LogServiceSuspension  │      │ SendServiceSuspended     │
│      (Sync)           │      │    Notification          │
│                       │      │    (Queued)              │
│ - Log to Laravel Log  │      │                          │
│ - Create SuspensionLog│      │ - Queue notification job │
│   record              │      │ - Send email             │
│                       │      │ - Send WhatsApp          │
└───────────────────────┘      │ - Send SMS               │
                               │ - Create NotificationLog  │
                               └──────────────────────────┘
```

## InvoicePaid Event Flow

```
┌───────────────────────────────────────────────────────────────────┐
│  TRIGGER: Payment Gateway Webhook OR Admin marks paid             │
└────────────────────────┬──────────────────────────────────────────┘
                         │
                         ▼
        event(new InvoicePaid($invoice, $transaction, $method))
                         │
        ┌────────────────┼────────────────┬────────────────┐
        │                │                │                │
        ▼                ▼                ▼                ▼
┌───────────────┐  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐
│ LogInvoice    │  │ SendInvoice │  │CheckService  │  │TriggerWebhook│
│ Paid (Sync)   │  │ Paid        │  │Reactivation  │  │ForInvoice    │
│               │  │Notification │  │Eligibility   │  │Paid (Queued) │
│- Log payment  │  │(Queued)     │  │(Queued)      │  │              │
│  transaction  │  │             │  │              │  │- Call Webhook│
│               │  │- Send       │  │- Query       │  │  Service     │
│               │  │  receipt    │  │  suspended   │  │- POST to     │
│               │  │- Update     │  │  services    │  │  external URL│
│               │  │  notification│  │- Check all   │  │- Retry on    │
│               │  │  log        │  │  invoices    │  │  failure     │
│               │  │             │  │  paid        │  │              │
└───────────────┘  └─────────────┘  │- Trigger     │  └──────────────┘
                                    │  reactivation│
                                    │  if eligible │
                                    └──────────────┘
```

## ServiceProvisioned Event Flow

```
┌───────────────────────────────────────────────────────────────────┐
│  TRIGGER: WHMIntegrationService->createAccount() succeeds          │
└────────────────────────┬──────────────────────────────────────────┘
                         │
                         ▼
              event(new ServiceProvisioned($service))
                         │
        ┌────────────────┴────────────────┐
        │                                 │
        ▼                                 ▼
┌───────────────────────┐      ┌──────────────────────────┐
│ LogServiceProvisioned │      │ SendServiceProvisioned   │
│      (Sync)           │      │    Notification          │
│                       │      │    (Queued)              │
│ - Log provisioning    │      │                          │
│   details             │      │ - Send welcome email     │
│ - Record in audit log │      │ - Include access details │
│                       │      │ - Send WhatsApp message  │
└───────────────────────┘      └──────────────────────────┘
```

## Listener Execution Models

### Synchronous Listeners (Execute Immediately)
- **LogServiceProvisioned**
- **LogServiceSuspension**
- **LogServiceReactivation**
- **LogInvoicePaid**
- **LogInvoiceGenerated**

**Characteristics**:
- Execute in same process/request
- Block until completion
- No retry mechanism
- Used for critical logging

### Asynchronous Listeners (Queued)
- **SendServiceProvisionedNotification**
- **SendServiceSuspendedNotification**
- **SendServiceReactivatedNotification**
- **SendInvoicePaidNotification**
- **SendInvoiceGeneratedNotification**
- **CheckServiceReactivationEligibility**
- **TriggerWebhookForInvoicePaid**
- **TriggerWebhookForInvoiceGenerated**

**Characteristics**:
- Pushed to Redis queue
- Processed by queue worker
- Non-blocking
- Automatic retry on failure
- Exponential backoff

## Queue Processing

```
┌─────────────────────────────────────────────────────────────┐
│                    REDIS QUEUE                              │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │
│  │  Job 1   │  │  Job 2   │  │  Job 3   │  │  Job 4   │  │
│  │SendEmail │  │SendSMS   │  │Webhook   │  │Check     │  │
│  │          │  │          │  │          │  │Reactive  │  │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘  │
└────────────┬────────────────────────────────────────────────┘
             │
             │ Laravel Horizon (Queue Worker)
             │
    ┌────────┴────────┬──────────┬──────────┐
    │                 │          │          │
    ▼                 ▼          ▼          ▼
┌────────┐      ┌────────┐  ┌────────┐  ┌────────┐
│Worker 1│      │Worker 2│  │Worker 3│  │Worker N│
│        │      │        │  │        │  │        │
│Process │      │Process │  │Process │  │Process │
│Job     │      │Job     │  │Job     │  │Job     │
└────┬───┘      └────┬───┘  └────┬───┘  └────┬───┘
     │               │           │           │
     │ Success       │ Failed    │ Success   │ Success
     │               │           │           │
     ▼               ▼           ▼           ▼
┌─────────┐    ┌──────────┐  ┌─────────┐  ┌─────────┐
│Complete │    │ Retry    │  │Complete │  │Complete │
│         │    │ (Backoff)│  │         │  │         │
└─────────┘    └────┬─────┘  └─────────┘  └─────────┘
                    │
                    │ Max retries exceeded
                    ▼
               ┌──────────┐
               │  Failed  │
               │  Jobs    │
               │  Table   │
               └──────────┘
```

## Integration Points

### Current System Components

```
┌────────────────────────────────────────────────────────────────┐
│                    EventServiceProvider                        │
│  - Registers all events and listeners                          │
│  - Maps event classes to listener classes                      │
└────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌───────────────┐    ┌────────────────┐    ┌──────────────┐
│  Domain       │    │   Listeners    │    │   Queue      │
│  Events       │    │   (13 files)   │    │   System     │
│  (5 files)    │    │                │    │   (Redis)    │
└───────────────┘    └────────────────┘    └──────────────┘
```

### Future Integration (Pending)

```
┌────────────────────────────────────────────────────────────────┐
│                  FUTURE COMPONENTS (To be built)                │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────┐      ┌──────────────────────┐       │
│  │ NotificationService  │      │ WebhookService       │       │
│  │ (Task 15.2)          │      │ (Task 62)            │       │
│  │                      │      │                      │       │
│  │ - sendServiceSuspended│     │ - dispatch()         │       │
│  │ - sendInvoicePaid    │      │ - retry logic        │       │
│  │ - sendServiceActivated│     │ - HMAC signature     │       │
│  └──────────────────────┘      └──────────────────────┘       │
│                                                                 │
│  ┌──────────────────────┐      ┌──────────────────────┐       │
│  │ SuspensionLog Model  │      │ WHMIntegrationService│       │
│  │ (Task 26.2)          │      │ (Task 5)             │       │
│  │                      │      │                      │       │
│  │ - Audit trail        │      │ - suspendAccount()   │       │
│  │ - Compliance reports │      │ - unsuspendAccount() │       │
│  └──────────────────────┘      └──────────────────────┘       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Benefits of This Architecture

### 1. Scalability
- Async processing prevents blocking
- Multiple queue workers can process jobs in parallel
- Easy to add more workers under load

### 2. Reliability
- Automatic retry on failure
- Dead letter queue for permanently failed jobs
- Detailed logging at each step

### 3. Maintainability
- Clear separation of concerns
- Easy to add/remove listeners
- Testable in isolation

### 4. Flexibility
- New functionality added without changing core code
- Third-party integrations via listeners
- Easy to disable specific listeners

### 5. Observability
- Comprehensive logging
- Queue monitoring via Horizon
- Event tracking for analytics
