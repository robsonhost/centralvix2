# Domain Events Documentation

This directory contains the Domain Events for the CentralVix billing system's event-driven architecture.

## Overview

Domain Events enable decoupled, asynchronous processing of business logic. When significant actions occur in the system (like service provisioning, suspensions, or invoice payments), events are fired and multiple listeners can react independently.

**Requirements Coverage**: Requisito 63.1 - Domain Events structure

## Available Events

### 1. ServiceProvisioned
**Fired when**: A service is successfully provisioned on a server (e.g., cPanel account created)

**Properties**:
- `service`: The Service model instance

**Listeners**:
- `LogServiceProvisioned`: Logs the provisioning event
- `SendServiceProvisionedNotification`: Sends activation notification to client

**Usage**:
```php
use App\Events\ServiceProvisioned;

// After provisioning a service
event(new ServiceProvisioned($service));
```

---

### 2. ServiceSuspended
**Fired when**: A service is suspended (automatically due to non-payment or manually by admin)

**Properties**:
- `service`: The Service model instance
- `reason`: Suspension reason (e.g., 'automatic_overdue', 'manual_admin')
- `isAutomatic`: Whether suspension was automatic (true) or manual (false)
- `suspendedByAdminId`: ID of admin who suspended (null for automatic)

**Listeners**:
- `LogServiceSuspension`: Creates suspension log record
- `SendServiceSuspendedNotification`: Sends suspension notification to client

**Usage**:
```php
use App\Events\ServiceSuspended;

// Automatic suspension
event(new ServiceSuspended($service, 'automatic_overdue', true));

// Manual suspension by admin
event(new ServiceSuspended($service, 'abuse_complaint', false, $adminId));
```

---

### 3. ServiceReactivated
**Fired when**: A suspended service is reactivated (after payment or manually)

**Properties**:
- `service`: The Service model instance
- `reason`: Reactivation reason (default: 'payment_received')
- `reactivatedByAdminId`: ID of admin who reactivated (null for automatic)

**Listeners**:
- `LogServiceReactivation`: Creates reactivation log record
- `SendServiceReactivatedNotification`: Sends reactivation notification to client

**Usage**:
```php
use App\Events\ServiceReactivated;

// Automatic reactivation after payment
event(new ServiceReactivated($service, 'payment_received'));

// Manual reactivation by admin
event(new ServiceReactivated($service, 'manual_reactivation', $adminId));
```

---

### 4. InvoicePaid
**Fired when**: An invoice is marked as paid

**Properties**:
- `invoice`: The Invoice model instance
- `transaction`: The PaymentTransaction (optional)
- `paymentMethod`: Payment method used (e.g., 'pix', 'credit_card', 'manual')

**Listeners**:
- `LogInvoicePaid`: Logs the payment event
- `SendInvoicePaidNotification`: Sends payment receipt to client
- `CheckServiceReactivationEligibility`: Checks if suspended services should be reactivated
- `TriggerWebhookForInvoicePaid`: Triggers external webhooks

**Usage**:
```php
use App\Events\InvoicePaid;

// With transaction
event(new InvoicePaid($invoice, $transaction, 'pix'));

// Manual payment by admin
event(new InvoicePaid($invoice, null, 'manual'));
```

---

### 5. InvoiceGenerated
**Fired when**: A new invoice is created

**Properties**:
- `invoice`: The Invoice model instance
- `isRecurring`: Whether this is a recurring invoice (default: false)

**Listeners**:
- `LogInvoiceGenerated`: Logs the invoice generation
- `SendInvoiceGeneratedNotification`: Sends invoice notification to client
- `TriggerWebhookForInvoiceGenerated`: Triggers external webhooks

**Usage**:
```php
use App\Events\InvoiceGenerated;

// New invoice
event(new InvoiceGenerated($invoice));

// Recurring invoice
event(new InvoiceGenerated($invoice, true));
```

---

## Listener Execution

Listeners implement `ShouldQueue` interface execute asynchronously via queues (Redis). This ensures:
- Non-blocking operations
- Retry capability on failure
- Better performance and scalability

Synchronous listeners (without `ShouldQueue`) execute immediately:
- Logging listeners (need immediate execution)
- Critical business logic that must complete before returning

## Testing Events

```php
use Illuminate\Support\Facades\Event;
use App\Events\ServiceSuspended;

// In tests, fake events
Event::fake();

// Execute code that fires events
$this->suspensionEngine->run();

// Assert event was dispatched
Event::assertDispatched(ServiceSuspended::class, function ($event) use ($service) {
    return $event->service->id === $service->id;
});
```

## Migration Notes

Legacy string-based events (e.g., `'App\Events\InvoicePaid'`) should be migrated to use the new class-based events:

**Before**:
```php
event('App\Events\InvoicePaid', $invoice);
```

**After**:
```php
use App\Events\InvoicePaid;
event(new InvoicePaid($invoice, $transaction, 'pix'));
```

## Future Events

As the system grows, additional domain events should be added:
- `DomainRegistered` / `DomainRenewed` / `DomainTransferred`
- `TicketCreated` / `TicketReplied` / `TicketClosed`
- `ClientCreated` / `ClientVerified`
- `PaymentFailed` / `PaymentRefunded`

## Related Requirements

- **Requisito 63.1**: Event-Driven Architecture - Domain Events structure
- **Requisito 63.2**: Queue system for async processing
- **Requisito 13**: Suspension/reactivation logging and audit
- **Requisito 4**: Automatic reactivation after payment
- **Requisito 62**: Webhook integration for external systems
