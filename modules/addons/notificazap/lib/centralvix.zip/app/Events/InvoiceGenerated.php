<?php

namespace App\Events;

use App\Models\Invoice;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Event fired when a new invoice is generated
 * 
 * Requirements: 63.1 - Domain Events structure
 */
class InvoiceGenerated
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public Invoice $invoice;
    public bool $isRecurring;

    /**
     * Create a new event instance.
     */
    public function __construct(Invoice $invoice, bool $isRecurring = false)
    {
        $this->invoice = $invoice;
        $this->isRecurring = $isRecurring;
    }
}
