<?php

namespace App\Events;

use App\Models\Service;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Event fired when a service is successfully provisioned
 * 
 * Requirements: 63.1 - Domain Events structure
 */
class ServiceProvisioned
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public Service $service;

    public ?string $plaintextPassword;

    /**
     * Create a new event instance.
     */
    public function __construct(Service $service, ?string $plaintextPassword = null)
    {
        $this->service = $service;
        $this->plaintextPassword = $plaintextPassword;
    }
}
