<?php

namespace App\Events;

use App\Models\Invoice;
use App\Models\PaymentTransaction;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Event fired when an invoice is marked as paid
 * 
 * Requirements: 63.1 - Domain Events structure
 */
class InvoicePaid
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public Invoice $invoice;
    public ?PaymentTransaction $transaction;
    public string $paymentMethod;

    /**
     * Create a new event instance.
     */
    public function __construct(
        Invoice $invoice,
        ?PaymentTransaction $transaction = null,
        string $paymentMethod = 'manual'
    ) {
        $this->invoice = $invoice;
        $this->transaction = $transaction;
        $this->paymentMethod = $paymentMethod;
    }
}
