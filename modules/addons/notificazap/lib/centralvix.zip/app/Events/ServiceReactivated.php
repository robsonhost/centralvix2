<?php

namespace App\Events;

use App\Models\Service;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Event fired when a service is reactivated after payment or manual action
 * 
 * Requirements: 63.1 - Domain Events structure
 */
class ServiceReactivated
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public Service $service;
    public string $reason;
    public ?int $reactivatedByAdminId;

    /**
     * Create a new event instance.
     */
    public function __construct(
        Service $service,
        string $reason = 'payment_received',
        ?int $reactivatedByAdminId = null
    ) {
        $this->service = $service;
        $this->reason = $reason;
        $this->reactivatedByAdminId = $reactivatedByAdminId;
    }
}
