<?php

namespace App\Helpers;

use App\Services\CacheService;

/**
 * Cache Helper Functions
 * 
 * Provides convenient global access to CacheService methods
 * for use throughout the application.
 */
class CacheHelper
{
    /**
     * Get the CacheService instance
     */
    public static function service(): CacheService
    {
        return app(CacheService::class);
    }

    /**
     * Cache products for a company
     */
    public static function products(int $companyId, callable $callback): mixed
    {
        return self::service()->getProducts($companyId, $callback);
    }

    /**
     * Cache WHM packages for a server
     */
    public static function whmPackages(int $companyId, int $serverId, callable $callback): mixed
    {
        return self::service()->getWhmPackages($companyId, $serverId, $callback);
    }

    /**
     * Cache a single setting
     */
    public static function setting(int $companyId, string $group, string $key, callable $callback): mixed
    {
        return self::service()->getSetting($companyId, $group, $key, $callback);
    }

    /**
     * Cache all settings for a company
     */
    public static function allSettings(int $companyId, callable $callback): mixed
    {
        return self::service()->getAllSettings($companyId, $callback);
    }

    /**
     * Cache dashboard statistics
     */
    public static function dashboardStats(int $companyId, callable $callback): mixed
    {
        return self::service()->getDashboardStats($companyId, $callback);
    }

    /**
     * Cache clients list
     */
    public static function clientsList(int $companyId, array $filters, int $page, callable $callback): mixed
    {
        return self::service()->getClientsList($companyId, $filters, $page, $callback);
    }

    /**
     * Cache invoices list
     */
    public static function invoicesList(int $companyId, array $filters, int $page, callable $callback): mixed
    {
        return self::service()->getInvoicesList($companyId, $filters, $page, $callback);
    }

    /**
     * Cache services list
     */
    public static function servicesList(int $companyId, array $filters, int $page, callable $callback): mixed
    {
        return self::service()->getServicesList($companyId, $filters, $page, $callback);
    }

    /**
     * Cache servers list
     */
    public static function serversList(int $companyId, callable $callback): mixed
    {
        return self::service()->getServersList($companyId, $callback);
    }

    /**
     * Invalidate products cache
     */
    public static function invalidateProducts(int $companyId): void
    {
        self::service()->invalidateProducts($companyId);
    }

    /**
     * Invalidate WHM packages cache
     */
    public static function invalidateWhmPackages(int $companyId, ?int $serverId = null): void
    {
        self::service()->invalidateWhmPackages($companyId, $serverId);
    }

    /**
     * Invalidate settings cache
     */
    public static function invalidateSettings(int $companyId): void
    {
        self::service()->invalidateSettings($companyId);
    }

    /**
     * Invalidate dashboard cache
     */
    public static function invalidateDashboard(int $companyId): void
    {
        self::service()->invalidateDashboard($companyId);
    }

    /**
     * Invalidate clients list cache
     */
    public static function invalidateClientsList(int $companyId): void
    {
        self::service()->invalidateClientsList($companyId);
    }

    /**
     * Invalidate invoices list cache
     */
    public static function invalidateInvoicesList(int $companyId): void
    {
        self::service()->invalidateInvoicesList($companyId);
    }

    /**
     * Invalidate services list cache
     */
    public static function invalidateServicesList(int $companyId): void
    {
        self::service()->invalidateServicesList($companyId);
    }

    /**
     * Invalidate servers list cache
     */
    public static function invalidateServersList(int $companyId): void
    {
        self::service()->invalidateServersList($companyId);
    }

    /**
     * Invalidate all cache for a company
     */
    public static function invalidateAll(int $companyId): void
    {
        self::service()->invalidateAll($companyId);
    }

    /**
     * Clear entire cache (use with extreme caution)
     */
    public static function clearAll(): void
    {
        self::service()->clearAll();
    }
}
