<?php

namespace App\Helpers;

/**
 * Log Context Helper
 * 
 * Requirements: 65.1, 65.2
 * 
 * Provides helper methods to create structured log context arrays
 * for consistent logging across the application.
 * 
 * Usage examples:
 * 
 * // API logging
 * Log::channel('api')->info('API request received', LogContext::api([
 *     'endpoint' => '/api/v1/clients',
 *     'response_time_ms' => 150
 * ]));
 * 
 * // WHM operations
 * Log::channel('whm')->info('Account suspended', LogContext::whm([
 *     'server_id' => $server->id,
 *     'username' => $username,
 *     'operation' => 'suspend'
 * ]));
 * 
 * // Billing operations
 * Log::channel('billing')->info('Invoice generated', LogContext::billing([
 *     'invoice_id' => $invoice->id,
 *     'client_id' => $client->id,
 *     'amount' => $invoice->total
 * ]));
 * 
 * // Security events
 * Log::channel('security')->warning('Failed login attempt', LogContext::security([
 *     'email' => $email,
 *     'ip' => request()->ip()
 * ]));
 */
class LogContext
{
    /**
     * Create API log context
     *
     * @param array $context Additional context data
     * @return array
     */
    public static function api(array $context = []): array
    {
        return self::buildContext('api', $context);
    }

    /**
     * Create WHM operation log context
     *
     * @param array $context Additional context data
     * @return array
     */
    public static function whm(array $context = []): array
    {
        return self::buildContext('whm', $context);
    }

    /**
     * Create billing operation log context
     *
     * @param array $context Additional context data
     * @return array
     */
    public static function billing(array $context = []): array
    {
        return self::buildContext('billing', $context);
    }

    /**
     * Create security event log context
     *
     * @param array $context Additional context data
     * @return array
     */
    public static function security(array $context = []): array
    {
        return self::buildContext('security', $context);
    }

    /**
     * Build structured log context with common fields
     *
     * @param string $channel Log channel name
     * @param array $context Additional context data
     * @return array
     */
    protected static function buildContext(string $channel, array $context): array
    {
        $baseContext = [
            'channel' => $channel,
            'timestamp' => now()->toIso8601String(),
        ];

        // Add user context if authenticated
        if (auth()->check()) {
            $baseContext['user_id'] = auth()->id();
            $baseContext['user_email'] = auth()->user()->email;
        }

        // Add company/tenant context if available
        if (app()->bound('request') && request()->attributes->has('company_id')) {
            $baseContext['company_id'] = request()->attributes->get('company_id');
        }

        // Add request context if available
        if (app()->bound('request')) {
            $request = request();
            $baseContext['ip'] = $request->ip();
            $baseContext['url'] = $request->fullUrl();
            $baseContext['method'] = $request->method();
        }

        // Merge with additional context
        return array_merge($baseContext, $context);
    }

    /**
     * Create context for service operations
     *
     * @param int $serviceId
     * @param array $context
     * @return array
     */
    public static function service(int $serviceId, array $context = []): array
    {
        return array_merge(['service_id' => $serviceId], $context);
    }

    /**
     * Create context for client operations
     *
     * @param int $clientId
     * @param array $context
     * @return array
     */
    public static function client(int $clientId, array $context = []): array
    {
        return array_merge(['client_id' => $clientId], $context);
    }

    /**
     * Create context for invoice operations
     *
     * @param int $invoiceId
     * @param array $context
     * @return array
     */
    public static function invoice(int $invoiceId, array $context = []): array
    {
        return array_merge(['invoice_id' => $invoiceId], $context);
    }

    /**
     * Create context for server operations
     *
     * @param int $serverId
     * @param array $context
     * @return array
     */
    public static function server(int $serverId, array $context = []): array
    {
        return array_merge(['server_id' => $serverId], $context);
    }

    /**
     * Create context with duration measurement
     *
     * @param float $startTime Start time from microtime(true)
     * @param array $context Additional context
     * @return array
     */
    public static function withDuration(float $startTime, array $context = []): array
    {
        $duration = (microtime(true) - $startTime) * 1000; // Convert to milliseconds
        return array_merge($context, ['duration_ms' => round($duration, 2)]);
    }

    /**
     * Create context for error logging
     *
     * @param \Throwable $exception
     * @param array $context
     * @return array
     */
    public static function exception(\Throwable $exception, array $context = []): array
    {
        return array_merge($context, [
            'exception' => get_class($exception),
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString(),
        ]);
    }
}
