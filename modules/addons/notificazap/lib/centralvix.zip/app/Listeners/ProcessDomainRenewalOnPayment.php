<?php

namespace App\Listeners;

use App\Events\InvoicePaid;
use App\Services\DomainBillingService;
use App\Services\DomainService;
use Illuminate\Contracts\Queue\ShouldQueue;

class ProcessDomainRenewalOnPayment implements ShouldQueue
{
    public function __construct(
        private DomainBillingService $domainBilling,
        private DomainService $domainService,
    ) {
    }

    public function handle(InvoicePaid $event): void
    {
        $invoice = $event->invoice->loadMissing('items.domain');

        if (!$this->domainBilling->isDomainInvoice($invoice)) {
            return;
        }

        try {
            $this->domainBilling->processPaidRenewal($invoice, $this->domainService);
        } catch (\Throwable $e) {
            logger()->error('Falha ao renovar domínio após pagamento', [
                'invoice_id' => $invoice->id,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
