<?php

namespace App\Listeners;

use App\Events\InvoicePaid;
use App\Services\AffiliateService;
use Illuminate\Contracts\Queue\ShouldQueue;

class ProcessAffiliateCommission implements ShouldQueue
{
    public function __construct(private AffiliateService $affiliateService)
    {
    }

    public function handle(InvoicePaid $event): void
    {
        $invoice = $event->invoice->loadMissing('client');

        if (!$invoice->client) {
            return;
        }

        try {
            $this->affiliateService->processCommission($invoice);
        } catch (\Throwable $e) {
            logger()->error('Falha ao processar comissão de afiliado', [
                'invoice_id' => $invoice->id,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
