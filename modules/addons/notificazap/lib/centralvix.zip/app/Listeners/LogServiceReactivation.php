<?php

namespace App\Listeners;

use App\Events\ServiceReactivated;
use App\Models\SuspensionLog;
use Illuminate\Support\Facades\Log;

/**
 * Listener to log service reactivation events
 * 
 * Requirements: 63.1 - Domain Events listeners
 * Requirements: 13 - Log and audit suspensions/reactivations
 */
class LogServiceReactivation
{
    /**
     * Handle the event.
     */
    public function handle(ServiceReactivated $event): void
    {
        // Log to Laravel log
        Log::info('Service reactivated', [
            'service_id' => $event->service->id,
            'client_id' => $event->service->client_id,
            'reason' => $event->reason,
            'reactivated_by_admin_id' => $event->reactivatedByAdminId,
        ]);

        // Create suspension log record if the model exists
        // SuspensionLog will be created in task 26.2
        /*
        SuspensionLog::create([
            'company_id' => $event->service->company_id ?? null,
            'service_id' => $event->service->id,
            'client_id' => $event->service->client_id,
            'action' => 'reactivated',
            'reason' => $event->reason,
            'whm_result' => 'success',
            'suspended_by_admin_id' => $event->reactivatedByAdminId,
        ]);
        */
    }
}
