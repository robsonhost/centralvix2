<?php

namespace App\Listeners;

use App\Events\InvoiceGenerated;
use Illuminate\Support\Facades\Log;

/**
 * Listener to log invoice generation events
 * 
 * Requirements: 63.1 - Domain Events listeners
 */
class LogInvoiceGenerated
{
    /**
     * Handle the event.
     */
    public function handle(InvoiceGenerated $event): void
    {
        Log::info('Invoice generated', [
            'invoice_id' => $event->invoice->id,
            'client_id' => $event->invoice->client_id,
            'amount' => $event->invoice->total,
            'due_date' => $event->invoice->date_due?->format('Y-m-d'),
            'is_recurring' => $event->isRecurring,
        ]);
    }
}
