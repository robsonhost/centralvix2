<?php

namespace App\Listeners;

use App\Events\ServiceProvisioned;
use App\Services\NotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendServiceProvisionedNotification implements ShouldQueue
{
    public function __construct(private NotificationService $notificationService) {}

    public function handle(ServiceProvisioned $event): void
    {
        $this->notificationService->dispatchServiceProvisioned(
            $event->service,
            $event->plaintextPassword
        );
    }
}
