<?php

namespace App\Listeners;

use App\Events\ServiceSuspended;
use App\Services\NotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;

/**
 * Listener to send notifications when a service is suspended
 * 
 * Requirements: 63.1 - Domain Events listeners
 * Requirements: 6 - Service suspended notification
 */
class SendServiceSuspendedNotification implements ShouldQueue
{
    protected NotificationService $notificationService;

    /**
     * Create the event listener.
     */
    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Handle the event.
     */
    public function handle(ServiceSuspended $event): void
    {
        try {
            $service = $event->service->loadMissing('client');
            $client = $service->client;

            if (!$client) {
                return;
            }

            $this->notificationService->notifyServiceSuspended($service);

            app(\App\Services\WhatsApp\WhatsappNotificationService::class)->notifyClient(
                $client,
                'service_suspended',
                [
                    'service_name' => $service->name,
                    'reason' => 'Fatura(s) em atraso',
                ],
                'service',
                (int) $service->id,
            );
        } catch (\Throwable $e) {
            logger()->error('SendServiceSuspendedNotification failed: ' . $e->getMessage());
        }
    }
}
