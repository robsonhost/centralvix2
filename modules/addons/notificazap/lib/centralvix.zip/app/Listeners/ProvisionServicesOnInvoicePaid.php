<?php

namespace App\Listeners;

use App\Events\InvoicePaid;
use App\Services\InvoiceFulfillmentService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Log;

/**
 * Provisiona serviços pendentes quando a fatura é marcada como paga
 * por caminhos que não passam pelo PaymentService::confirmPayment.
 */
class ProvisionServicesOnInvoicePaid implements ShouldQueue
{
    public function handle(InvoicePaid $event): void
    {
        $invoice = $event->invoice->fresh(['items.service']);

        $hasPending = $invoice->items->contains(fn ($item) => $item->service?->status === 'pending');

        if (!$hasPending) {
            return;
        }

        try {
            app(InvoiceFulfillmentService::class)->fulfill($invoice);
        } catch (\Throwable $e) {
            Log::error('ProvisionServicesOnInvoicePaid failed', [
                'invoice_id' => $invoice->id,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
