<?php

namespace App\Listeners;

use App\Events\InvoicePaid;
use Illuminate\Support\Facades\Log;

/**
 * Listener to log invoice payment events
 * 
 * Requirements: 63.1 - Domain Events listeners
 */
class LogInvoicePaid
{
    /**
     * Handle the event.
     */
    public function handle(InvoicePaid $event): void
    {
        Log::info('Invoice paid', [
            'invoice_id' => $event->invoice->id,
            'client_id' => $event->invoice->client_id,
            'amount' => $event->invoice->total,
            'payment_method' => $event->paymentMethod,
            'transaction_id' => $event->transaction?->id,
        ]);
    }
}
