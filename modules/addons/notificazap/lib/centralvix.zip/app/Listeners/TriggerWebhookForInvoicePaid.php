<?php

namespace App\Listeners;

use App\Events\InvoicePaid;
use Illuminate\Contracts\Queue\ShouldQueue;

/**
 * Listener to trigger webhooks when an invoice is paid
 * 
 * Requirements: 63.1 - Domain Events listeners
 * Requirements: 62 - Webhook integration
 */
class TriggerWebhookForInvoicePaid implements ShouldQueue
{
    /**
     * Handle the event.
     */
    public function handle(InvoicePaid $event): void
    {
        // Trigger webhooks for invoice.paid event
        // This will be implemented when WebhookService is created
        // WebhookService::dispatch('invoice.paid', [
        //     'invoice_id' => $event->invoice->id,
        //     'client_id' => $event->invoice->client_id,
        //     'amount' => $event->invoice->total,
        //     'payment_method' => $event->paymentMethod,
        // ]);
    }
}
