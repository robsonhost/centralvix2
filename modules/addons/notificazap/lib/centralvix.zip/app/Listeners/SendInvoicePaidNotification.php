<?php

namespace App\Listeners;

use App\Events\InvoicePaid;
use App\Mail\InvoicePaidMail;
use App\Models\EmailTemplate;
use App\Services\NotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

/**
 * Listener to send notifications when an invoice is paid
 * 
 * Requirements: 63.1 - Domain Events listeners
 */
class SendInvoicePaidNotification implements ShouldQueue
{
    protected NotificationService $notificationService;

    /**
     * Create the event listener.
     */
    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Handle the event.
     */
    public function handle(InvoicePaid $event): void
    {
        $invoice = $event->invoice->loadMissing('client');
        $notifications = app(NotificationService::class);

        $hasTemplate = $invoice->client && EmailTemplate::where('company_id', $invoice->client->company_id)
            ->where('slug', 'payment_confirmed')
            ->where('status', 'active')
            ->exists();

        if (!$hasTemplate && $invoice->client?->email) {
            try {
                Mail::to($invoice->client->email)->send(new InvoicePaidMail($invoice));
            } catch (\Throwable $e) {
                logger()->error('InvoicePaidMail falhou: ' . $e->getMessage());
            }
            $notifications->dispatchInvoicePaid($invoice, emailTemplate: false);
            return;
        }

        $notifications->dispatchInvoicePaid($invoice);
    }
}
