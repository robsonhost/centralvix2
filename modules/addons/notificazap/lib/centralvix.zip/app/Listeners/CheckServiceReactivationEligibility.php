<?php

namespace App\Listeners;

use App\Events\InvoicePaid;
use App\Models\Service;
use App\Services\ProvisioningService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Log;

class CheckServiceReactivationEligibility implements ShouldQueue
{
    public function handle(InvoicePaid $event): void
    {
        $invoice = $event->invoice;

        $serviceIds = $invoice->items()->whereNotNull('service_id')->pluck('service_id');

        $services = Service::whereIn('id', $serviceIds)
            ->where('status', 'suspended')
            ->where('override_auto_suspend', false)
            ->get();

        if ($services->isEmpty()) {
            return;
        }

        $provisioningService = app(ProvisioningService::class);

        foreach ($services as $service) {
            $hasUnpaid = $service->invoiceItems()
                ->whereHas('invoice', function ($query) use ($invoice) {
                    $query->where('id', '!=', $invoice->id)
                        ->whereIn('status', ['unpaid', 'overdue', 'partial']);
                })
                ->exists();

            if ($hasUnpaid) {
                continue;
            }

            try {
                $provisioningService->unsuspend($service);
                Log::info('Service reactivated by InvoicePaid listener', [
                    'service_id' => $service->id,
                    'invoice_id' => $invoice->id,
                ]);
            } catch (\Throwable $e) {
                Log::error('Failed to reactivate service on InvoicePaid', [
                    'service_id' => $service->id,
                    'invoice_id' => $invoice->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }
}
