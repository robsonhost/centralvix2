<?php

namespace App\Listeners;

use App\Events\ServiceProvisioned;
use Illuminate\Support\Facades\Log;

/**
 * Listener to log service provisioning events
 * 
 * Requirements: 63.1 - Domain Events listeners
 */
class LogServiceProvisioned
{
    /**
     * Handle the event.
     */
    public function handle(ServiceProvisioned $event): void
    {
        Log::info('Service provisioned', [
            'service_id' => $event->service->id,
            'client_id' => $event->service->client_id,
            'product_id' => $event->service->product_id,
            'domain' => $event->service->domain,
            'status' => $event->service->status,
        ]);
    }
}
