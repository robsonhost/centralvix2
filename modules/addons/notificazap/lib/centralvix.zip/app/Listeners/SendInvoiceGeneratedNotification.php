<?php

namespace App\Listeners;

use App\Events\InvoiceGenerated;
use App\Services\NotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;

/**
 * Listener to send notifications when an invoice is generated
 * 
 * Requirements: 63.1 - Domain Events listeners
 */
class SendInvoiceGeneratedNotification implements ShouldQueue
{
    protected NotificationService $notificationService;

    /**
     * Create the event listener.
     */
    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Handle the event.
     */
    public function handle(InvoiceGenerated $event): void
    {
        app(NotificationService::class)->dispatchInvoiceCreated($event->invoice);
    }
}
