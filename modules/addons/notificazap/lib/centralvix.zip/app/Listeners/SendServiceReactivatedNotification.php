<?php

namespace App\Listeners;

use App\Events\ServiceReactivated;
use App\Services\NotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendServiceReactivatedNotification implements ShouldQueue
{
    public function __construct(private NotificationService $notificationService) {}

    public function handle(ServiceReactivated $event): void
    {
        $this->notificationService->dispatchServiceReactivated($event->service);
    }
}
