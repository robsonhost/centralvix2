<?php

namespace App\Listeners;

use App\Events\ServiceSuspended;
use App\Models\SuspensionLog;
use Illuminate\Support\Facades\Log;

/**
 * Listener to log service suspension events
 * 
 * Requirements: 63.1 - Domain Events listeners
 * Requirements: 13 - Log and audit suspensions
 */
class LogServiceSuspension
{
    /**
     * Handle the event.
     */
    public function handle(ServiceSuspended $event): void
    {
        // Log to Laravel log
        Log::warning('Service suspended', [
            'service_id' => $event->service->id,
            'client_id' => $event->service->client_id,
            'reason' => $event->reason,
            'is_automatic' => $event->isAutomatic,
            'suspended_by_admin_id' => $event->suspendedByAdminId,
        ]);

        // Create suspension log record if the model exists
        // SuspensionLog will be created in task 26.2
        /*
        SuspensionLog::create([
            'company_id' => $event->service->company_id ?? null,
            'service_id' => $event->service->id,
            'client_id' => $event->service->client_id,
            'action' => 'suspended',
            'reason' => $event->reason,
            'whm_result' => 'success',
            'suspended_by_admin_id' => $event->suspendedByAdminId,
        ]);
        */
    }
}
