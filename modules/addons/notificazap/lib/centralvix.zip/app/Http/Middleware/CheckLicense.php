<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Services\LicenseService;

class CheckLicense
{
    public function handle(Request $request, Closure $next)
    {
        // Pula verificação para rotas de licença
        if ($request->is('license/*') || $request->is('api/license/*')) {
            return $next($request);
        }

        // Verifica se a licença é válida
        if (!LicenseService::check()) {
            // Se for requisição AJAX, retorna JSON
            if ($request->expectsJson()) {
                return response()->json([
                    'error' => 'Licença inválida ou expirada',
                    'message' => 'Este sistema requer uma licença válida para funcionar.'
                ], 503);
            }

            // Se for navegador, mostra página de erro
            return response()->view('errors.license', [
                'title' => 'Erro de Licença',
                'message' => 'Este sistema requer uma licença válida para funcionar.',
                'contact' => 'Entre em contato com o suporte: suporte@centralvix.com.br'
            ], 503);
        }

        // Verifica se a licença está expirando (aviso)
        if (LicenseService::isExpiring(7)) {
            $info = LicenseService::getInfo();
            session()->flash('license_warning', [
                'message' => "Atenção: Sua licença expira em {$info['days_remaining']} dias!",
                'type' => 'warning'
            ]);
        }

        return $next($request);
    }
}
