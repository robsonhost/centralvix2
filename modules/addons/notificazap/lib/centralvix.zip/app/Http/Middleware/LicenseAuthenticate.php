<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class LicenseAuthenticate
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::guard('licenses')->check()) {
            if ($request->expectsJson()) {
                return response()->json(['message' => 'Não autenticado'], 401);
            }

            return redirect()->route('licenses.login')
                ->with('error', 'Você precisa fazer login para acessar esta área');
        }

        return $next($request);
    }
}
