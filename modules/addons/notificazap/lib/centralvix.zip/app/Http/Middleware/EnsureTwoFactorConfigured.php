<?php

namespace App\Http\Middleware;

use App\Services\TwoFactorService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureTwoFactorConfigured
{
    public function __construct(private TwoFactorService $twoFactor) {}

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if (!$user || !$this->twoFactor->moduleEnabled($user->company_id)) {
            return $next($request);
        }

        if ($user->isTwoFactorEnabled()) {
            return $next($request);
        }

        if ($request->routeIs('two-factor.*', 'logout', 'admin.clients.stop-impersonating')) {
            return $next($request);
        }

        $this->twoFactor->startGracePeriodIfNeeded($user);
        $user->refresh();

        if ($this->twoFactor->isInGracePeriod($user)) {
            if ($msg = $this->twoFactor->graceMessage($user)) {
                session()->flash('info', $msg);
            }

            return $next($request);
        }

        if ($this->twoFactor->mustSetup($user)) {
            $intended = $user->isAdmin() ? route('admin.dashboard') : route('client.dashboard');

            return redirect()
                ->route('two-factor.setup')
                ->with('warning', 'Configure a verificação em duas etapas para continuar usando o painel.');
        }

        return $next($request);
    }
}
