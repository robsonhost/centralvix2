<?php

namespace App\Http\Middleware;

use App\Models\LoginAttempt;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckIpBlocked
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $ip = $request->ip();

        if (LoginAttempt::isBlocked($ip)) {
            $blockedUntil = LoginAttempt::getBlockedUntil($ip);
            
            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'Seu IP foi bloqueado temporariamente devido a múltiplas tentativas de login falhadas.',
                    'blocked_until' => $blockedUntil?->format('d/m/Y H:i:s'),
                ], 429);
            }

            return back()->withErrors([
                'blocked' => 'Seu IP foi bloqueado temporariamente até ' . 
                            $blockedUntil?->format('d/m/Y H:i:s') . 
                            ' devido a múltiplas tentativas de login falhadas.'
            ]);
        }

        return $next($request);
    }
}
