<?php

namespace App\Http\Middleware;

use App\Models\Company;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckCompany
{
    public function handle(Request $request, Closure $next): Response
    {
        if (auth()->check() && auth()->user()->company_id) {
            $company = Company::find(auth()->user()->company_id);

            if (!$company || $company->status !== 'active') {
                auth()->logout();
                return redirect()->route('login')
                    ->withErrors(['email' => 'Empresa inativa ou não encontrada.']);
            }

            // Share company with all views
            view()->share('currentCompany', $company);
        }

        return $next($request);
    }
}
