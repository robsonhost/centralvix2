<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ClientAuthenticate
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $user = auth()->user();

        // ⭐ SE ADMIN ESTÁ IMPERSONANDO, PERMITIR ACESSO
        if ($request->session()->has('impersonate_from')) {
            return $next($request);
        }

        // Se é admin acessando área de cliente (sem impersonation), permitir
        if ($user->isAdmin()) {
            return $next($request);
        }

        if ($user->status === 'banned') {
            auth()->logout();
            return redirect()->route('login')->withErrors(['email' => 'Sua conta foi banida.']);
        }

        if ($user->status === 'suspended') {
            auth()->logout();
            return redirect()->route('login')->withErrors(['email' => 'Sua conta está suspensa.']);
        }

        return $next($request);
    }
}
