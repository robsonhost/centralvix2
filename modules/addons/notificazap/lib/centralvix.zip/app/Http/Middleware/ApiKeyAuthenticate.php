<?php

namespace App\Http\Middleware;

use App\Models\ApiKey;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiKeyAuthenticate
{
    public function handle(Request $request, Closure $next): Response
    {
        $key = $request->header('X-API-Key') ?? $request->query('api_key');

        if (!$key) {
            return response()->json(['error' => 'API key required.'], 401);
        }

        $apiKey = ApiKey::where('key', hash('sha256', $key))->first();

        if (!$apiKey || !$apiKey->isActive()) {
            return response()->json(['error' => 'Invalid or expired API key.'], 401);
        }

        $apiKey->markAsUsed();

        // Attach API key context to request
        $request->merge(['_api_key' => $apiKey]);

        return $next($request);
    }
}
