<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckLicenseStatus
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Verificar se o usuário está autenticado
        if (!Auth::check()) {
            return $next($request);
        }

        $user = Auth::user();
        $company = $user->company;

        // Se não houver empresa vinculada, permitir acesso
        if (!$company) {
            return $next($request);
        }

        // Verificar se a licença está inativa
        if ($company->license_status === 'inactive') {
            // Se for admin, permitir acesso
            if ($user->isAdmin()) {
                session()->flash('warning', 'Licença inativa! Ative a licença para o sistema funcionar.');
                return $next($request);
            }

            // Para clientes, bloquear acesso
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('system.license-inactive');
        }

        // Verificar se está bloqueado
        if ($company->status === 'blocked') {
            // Se for admin, permitir acesso
            if ($user->isAdmin()) {
                session()->flash('danger', 'Sistema bloqueado! Verifique a situação.');
                return $next($request);
            }

            // Para clientes, bloquear acesso
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('system.blocked');
        }

        // Verificar se está suspenso
        if ($company->status === 'suspended') {
            // Se for admin, permitir acesso
            if ($user->isAdmin()) {
                session()->flash('warning', 'Sistema suspenso! Regularize os pagamentos.');
                return $next($request);
            }

            // Para clientes, bloquear acesso
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('system.suspended');
        }

        // Verificar data de vencimento da licença
        if ($company->license_expires_at && $company->license_expires_at->isPast()) {
            // Se for admin, apenas mostrar aviso mas permitir acesso
            if ($user->isAdmin()) {
                session()->flash('warning', 'Licença expirada! Renove para continuar usando o sistema.');
                return $next($request);
            }

            // Para clientes, bloquear acesso
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('license.expired')
                ->with('error', 'A licença do sistema expirou. Entre em contato com o administrador.');
        }

        return $next($request);
    }
}
