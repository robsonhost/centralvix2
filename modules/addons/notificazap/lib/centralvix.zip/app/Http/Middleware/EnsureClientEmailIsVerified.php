<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureClientEmailIsVerified
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        // Se não está logado, deixa passar (outro middleware vai tratar)
        if (!$user) {
            return $next($request);
        }

        // ⭐ SE ADMIN ESTÁ IMPERSONANDO, PULAR VERIFICAÇÃO
        if ($request->session()->has('impersonate_from')) {
            return $next($request);
        }

        // Se é admin, não precisa verificar
        if ($user->isAdmin()) {
            return $next($request);
        }

        // Busca o cliente associado
        $client = \App\Models\Client::where('email', $user->email)->first();

        // Se não encontrou cliente, deixa passar
        if (!$client) {
            return $next($request);
        }

        // Se o email não foi verificado, redireciona
        if (!$client->hasVerifiedEmail()) {
            // Permite acessar rotas de verificação e logout
            if ($request->routeIs('verification.*') || $request->routeIs('logout')) {
                return $next($request);
            }

            return redirect()->route('verification.notice')
                ->with('warning', 'Por favor, verifique seu email para continuar.');
        }

        return $next($request);
    }
}
