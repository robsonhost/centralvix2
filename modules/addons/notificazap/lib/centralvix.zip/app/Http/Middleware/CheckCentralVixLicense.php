<?php

namespace App\Http\Middleware;

use App\Services\License\CentralVixLicenseService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckCentralVixLicense
{
    public function __construct(
        private CentralVixLicenseService $licenseService
    ) {}

    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check() || !auth()->user()->company_id) {
            return $next($request);
        }

        if ($request->routeIs(
            'admin.help.license',
            'admin.help.license.update',
            'admin.help.license.force-update',
            'admin.help.license.status',
            'logout'
        )) {
            return $next($request);
        }

        $companyId = (int) auth()->user()->company_id;

        if ($this->licenseService->isCompliant($companyId)) {
            return $next($request);
        }

        $message = $this->licenseService->blockMessage($companyId);

        if ($request->expectsJson()) {
            return response()->json([
                'success' => false,
                'message' => $message,
                'license_required' => true,
            ], 403);
        }

        return redirect()
            ->route('admin.help.license')
            ->with('error', $message);
    }
}
