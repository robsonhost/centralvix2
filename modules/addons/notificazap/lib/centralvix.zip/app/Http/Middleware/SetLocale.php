<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class SetLocale
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next)
    {
        // Priority:
        // 1. Session language (user selected)
        // 2. User's preferred language (authenticated)
        // 3. Browser language (auto-detect)
        // 4. Default language (config)

        $locale = null;

        // 1. Check session
        if (Session::has('locale')) {
            $locale = Session::get('locale');
        }
        // 2. Check authenticated user
        elseif (auth()->check() && auth()->user()->preferred_language) {
            $locale = auth()->user()->preferred_language;
        }
        // 3. Auto-detect from browser
        elseif ($request->hasHeader('Accept-Language')) {
            $browserLang = substr($request->header('Accept-Language'), 0, 2);
            $availableLanguages = ['pt', 'en', 'es'];
            
            if (in_array($browserLang, $availableLanguages)) {
                $locale = $browserLang;
            }
        }

        // 4. Default fallback
        if (!$locale) {
            $locale = config('app.locale', 'pt');
        }

        // Set application locale
        App::setLocale($locale);

        return $next($request);
    }
}
