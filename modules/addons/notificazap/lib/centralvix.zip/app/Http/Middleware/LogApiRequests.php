<?php

namespace App\Http\Middleware;

use App\Helpers\LogContext;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

/**
 * Log API Requests Middleware
 * 
 * Requirements: 65.1, 65.2
 * 
 * Automatically logs all API requests to the 'api' channel with structured context.
 * Includes request details, response status, and execution time.
 */
class LogApiRequests
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $startTime = microtime(true);
        
        // Process the request
        $response = $next($request);
        
        // Calculate duration
        $duration = (microtime(true) - $startTime) * 1000; // milliseconds
        
        // Prepare log context
        $context = LogContext::api([
            'endpoint' => $request->path(),
            'method' => $request->method(),
            'status_code' => $response->getStatusCode(),
            'duration_ms' => round($duration, 2),
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);
        
        // Add authenticated user info if available
        if ($request->user()) {
            $context['user_id'] = $request->user()->id;
            $context['user_email'] = $request->user()->email;
        }
        
        // Add company context if multi-tenant
        if ($request->attributes->has('company_id')) {
            $context['company_id'] = $request->attributes->get('company_id');
        }
        
        // Add request payload for non-GET requests (excluding sensitive data)
        if (!$request->isMethod('GET') && $request->getContentType() === 'json') {
            $payload = $request->except(['password', 'password_confirmation', 'token', 'api_key', 'secret']);
            if (!empty($payload)) {
                $context['payload'] = $payload;
            }
        }
        
        // Log based on response status
        if ($response->isSuccessful()) {
            Log::channel('api')->info('API request completed', $context);
        } elseif ($response->isClientError()) {
            Log::channel('api')->warning('API request failed (client error)', $context);
        } elseif ($response->isServerError()) {
            Log::channel('api')->error('API request failed (server error)', $context);
        }
        
        return $response;
    }
}
