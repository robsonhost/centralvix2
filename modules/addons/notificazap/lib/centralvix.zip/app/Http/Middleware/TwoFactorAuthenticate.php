<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TwoFactorAuthenticate
{
    public function handle(Request $request, Closure $next): Response
    {
        if (auth()->check() && auth()->user()->hasEnabledTwoFactor()) {
            if (!$request->session()->has('2fa_verified')) {
                return redirect()->route('auth.2fa');
            }
        }

        return $next($request);
    }
}
