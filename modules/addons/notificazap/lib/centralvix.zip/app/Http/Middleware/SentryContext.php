<?php

namespace App\Http\Middleware;

use App\Facades\Sentry;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * SentryContext Middleware
 * 
 * Requirement 65.3: Automatically add user and company context to Sentry errors
 * 
 * This middleware automatically enriches Sentry error reports with:
 * - User information (ID, email, role)
 * - Company/tenant information (for multi-tenancy support)
 * - Request context (IP, URL, method)
 */
class SentryContext
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Only add context if Sentry is enabled
        if (!Sentry::isEnabled()) {
            return $next($request);
        }

        // Add user context if authenticated
        if (auth()->check()) {
            $user = auth()->user();
            
            Sentry::setUser(
                $user->id,
                $user->email,
                [
                    'role' => $user->role ?? 'user',
                    'name' => $user->name ?? null,
                ]
            );

            // Add company context if multi-tenant and user has company_id
            if (isset($user->company_id) && $user->company_id) {
                Sentry::setCompanyContext(
                    $user->company_id,
                    $user->company?->name ?? null
                );
            }
        }

        // Add request context
        Sentry::addContext([
            'request' => [
                'url' => $request->fullUrl(),
                'method' => $request->method(),
                'ip' => $request->ip(),
                'user_agent' => $request->userAgent(),
            ],
        ]);

        return $next($request);
    }
}

