<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\NotificationLog;
use App\Services\WhatsApp\WhatsappNotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class NotificationLogController extends Controller
{
    public function __construct(private WhatsappNotificationService $whatsapp) {}

    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = NotificationLog::with('client')
            ->where('company_id', $companyId);

        if ($request->filled('channel'))  $query->where('channel', $request->channel);
        if ($request->filled('status'))   $query->where('status', $request->status);
        if ($request->filled('event'))    $query->where('event', $request->event);
        if ($request->filled('search'))   {
            $s = $request->search;
            $query->where(fn($q) => $q->where('recipient', 'like', "%{$s}%")
                ->orWhereHas('client', fn($c) => $c->where('email', 'like', "%{$s}%")));
        }
        if ($request->filled('date_from')) $query->whereDate('created_at', '>=', $request->date_from);
        if ($request->filled('date_to'))   $query->whereDate('created_at', '<=', $request->date_to);

        $logs = $query->latest()->paginate(30);

        $stats = [
            'total'     => NotificationLog::where('company_id', $companyId)->count(),
            'sent'      => NotificationLog::where('company_id', $companyId)->where('status', 'sent')->count(),
            'delivered' => NotificationLog::where('company_id', $companyId)->where('status', 'delivered')->count(),
            'read'      => NotificationLog::where('company_id', $companyId)->where('status', 'read')->count(),
            'failed'    => NotificationLog::where('company_id', $companyId)->where('status', 'failed')->count(),
        ];

        return view('admin.notifications.logs.index', compact('logs', 'stats'));
    }

    public function show(NotificationLog $notificationLog): View
    {
        if ($notificationLog->company_id !== auth()->user()->company_id) abort(403);
        return view('admin.notifications.logs.show', ['log' => $notificationLog->load('client')]);
    }

    public function resend(NotificationLog $notificationLog): RedirectResponse|JsonResponse
    {
        if ($notificationLog->company_id !== auth()->user()->company_id) abort(403);

        $client = $notificationLog->client;
        if (!$client) {
            if (request()->expectsJson()) {
                return response()->json(['message' => 'Cliente não encontrado.'], 422);
            }
            return back()->with('error', 'Cliente não encontrado.');
        }

        $this->whatsapp->dispatch(
            $client,
            $notificationLog->event ?? $notificationLog->type,
            [],
            $notificationLog->context_type ?? '',
            (int) ($notificationLog->context_id ?? 0)
        );

        if (request()->expectsJson()) {
            return response()->json(['message' => 'Notificação reenviada!']);
        }

        return back()->with('success', 'Notificação reenviada!');
    }

    public function showBulkForm(): View
    {
        $companyId = auth()->user()->company_id;

        $templates = \App\Models\WhatsappTemplate::where('company_id', $companyId)
            ->where('is_active', true)
            ->orderBy('category')
            ->orderBy('name')
            ->get()
            ->groupBy('category');

        $counts = [
            'all'     => Client::where('company_id', $companyId)->count(),
            'active'  => Client::where('company_id', $companyId)->where('status', 'active')->count(),
            'overdue' => Client::where('company_id', $companyId)
                ->whereHas('invoices', fn ($q) => $q->where('status', 'overdue'))
                ->count(),
        ];

        return view('admin.notifications.bulk-send', compact('templates', 'counts'));
    }

    public function sendBulk(Request $request): RedirectResponse
    {
        $companyId = auth()->user()->company_id;

        $request->validate([
            'template_slug' => 'required|string',
            'target'        => 'required|in:all,active,overdue,specific',
            'client_ids'    => 'nullable|array',
            'client_ids_raw'=> 'nullable|string',
            'message'       => 'nullable|string|max:4096',
        ]);

        $query = Client::where('company_id', $companyId);

        if ($request->target === 'active') {
            $query->where('status', 'active');
        } elseif ($request->target === 'overdue') {
            $query->whereHas('invoices', fn($q) => $q->where('status', 'overdue'));
        } elseif ($request->target === 'specific') {
            $ids = $request->client_ids ?? [];
            if ($request->filled('client_ids_raw')) {
                $rawIds = array_filter(array_map('trim', explode(',', $request->client_ids_raw)));
                $ids    = array_merge($ids, $rawIds);
            }
            if (empty($ids)) {
                return back()->with('error', 'Informe ao menos um cliente.');
            }
            $query->whereIn('id', $ids);
        }

        $clients = $query->get();
        $count   = 0;

        foreach ($clients as $client) {
            $this->whatsapp->dispatch($client, $request->template_slug, [
                'custom_message' => $request->message ?? '',
            ]);
            $count++;
        }

        return redirect()->route('admin.notifications.logs.index')
            ->with('success', "Notificação enviada para {$count} cliente(s)!");
    }

    public function stats(): JsonResponse
    {
        $companyId = auth()->user()->company_id;
        $today     = today();

        return response()->json([
            'today'   => NotificationLog::where('company_id', $companyId)->whereDate('created_at', $today)->count(),
            'week'    => NotificationLog::where('company_id', $companyId)->whereBetween('created_at', [$today->copy()->subDays(7), $today])->count(),
            'failed'  => NotificationLog::where('company_id', $companyId)->where('status', 'failed')->whereDate('created_at', $today)->count(),
            'by_channel' => NotificationLog::where('company_id', $companyId)
                ->selectRaw('channel, COUNT(*) as total')
                ->groupBy('channel')
                ->pluck('total', 'channel'),
        ]);
    }
}
