<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GiftCard;
use App\Services\GiftCardService;
use App\Services\ModuleSettingsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class GiftCardController extends Controller
{
    public function __construct(
        private GiftCardService $service,
        private ModuleSettingsService $settings,
    ) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $cards = GiftCard::forCompany($companyId)->latest()->paginate(20);

        $stats = [
            'total'    => GiftCard::forCompany($companyId)->count(),
            'active'   => GiftCard::forCompany($companyId)->where('status', 'active')->count(),
            'redeemed' => GiftCard::forCompany($companyId)->where('status', 'redeemed')->count(),
        ];

        $cfg = $this->settings->all($companyId, 'gift_cards');

        return view('admin.gift-cards.index', compact('cards', 'stats', 'cfg'));
    }

    public function store(Request $request): RedirectResponse
    {
        $companyId = auth()->user()->company_id;
        $cfg = $this->settings->all($companyId, 'gift_cards');

        $min = (float) ($cfg['min_value'] ?? 0.01);
        $max = (float) ($cfg['max_value'] ?? 100000);

        $data = $request->validate([
            'value'    => ['required', 'numeric', "min:{$min}", "max:{$max}"],
            'quantity' => ['nullable', 'integer', 'min:1', 'max:100'],
            'notes'    => ['nullable', 'string', 'max:255'],
        ]);

        $qty = (int) ($data['quantity'] ?? 1);

        for ($i = 0; $i < $qty; $i++) {
            $this->service->generate($companyId, (float) $data['value'], $data['notes'] ?? null, auth()->id());
        }

        return back()->with('success', "{$qty} gift card(s) gerado(s) com sucesso!");
    }

    public function cancel(GiftCard $giftCard): RedirectResponse
    {
        abort_unless($giftCard->company_id === auth()->user()->company_id, 403);

        if ($giftCard->status === 'active') {
            $giftCard->update(['status' => 'cancelled']);
        }

        return back()->with('success', 'Gift card cancelado.');
    }
}
