<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WhatsappTemplate;
use App\Services\EvolutionWhatsAppService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class WhatsappTemplateController extends Controller
{
    public function __construct(private EvolutionWhatsAppService $whatsapp) {}

    private function categories(): array
    {
        return [
            'financeiro' => 'Financeiro',
            'clientes'   => 'Clientes',
            'servicos'   => 'Serviços',
            'hospedagem' => 'Hospedagem',
            'vps'        => 'VPS',
            'dominios'   => 'Domínios',
            'ssl'        => 'SSL',
            'tickets'    => 'Tickets',
            'contratos'  => 'Contratos',
            'seguranca'  => 'Segurança',
            'geral'      => 'Geral',
        ];
    }

    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $templates = WhatsappTemplate::where('company_id', $companyId)
            ->latest()
            ->paginate(20);

        $stats = [
            'total'    => WhatsappTemplate::where('company_id', $companyId)->count(),
            'active'   => WhatsappTemplate::where('company_id', $companyId)->where('is_active', true)->count(),
            'inactive' => WhatsappTemplate::where('company_id', $companyId)->where('is_active', false)->count(),
        ];

        $byType = WhatsappTemplate::where('company_id', $companyId)
            ->select('type', \DB::raw('count(*) as total'))
            ->groupBy('type')
            ->get()
            ->pluck('total', 'type');

        return view('admin.whatsapp.templates.index', compact('templates', 'stats', 'byType'));
    }

    public function create(): View
    {
        $types = $this->eventTypes();
        $categories = $this->categories();

        return view('admin.whatsapp.templates.create', compact('types', 'categories'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name'     => 'required|string|max:255',
            'slug'     => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'type'     => 'required|string|max:255',
            'content'  => 'required|string',
            'footer'   => 'nullable|string|max:200',
            'is_active' => 'boolean',
        ]);

        $validated['company_id'] = auth()->user()->company_id;
        $validated['is_active'] = $request->has('is_active');
        $validated['slug'] = Str::slug($validated['slug']);

        WhatsappTemplate::create($validated);

        return redirect()
            ->route('admin.whatsapp.templates.index')
            ->with('success', 'Template criado com sucesso!');
    }

    public function show(WhatsappTemplate $template): View
    {
        $this->authorizeTemplate($template);
        return view('admin.whatsapp.templates.show', compact('template'));
    }

    public function edit(WhatsappTemplate $template): View
    {
        $this->authorizeTemplate($template);
        $types = $this->eventTypes();
        $categories = $this->categories();

        return view('admin.whatsapp.templates.edit', compact('template', 'types', 'categories'));
    }

    public function update(Request $request, WhatsappTemplate $template): RedirectResponse
    {
        $this->authorizeTemplate($template);

        $validated = $request->validate([
            'name'     => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'type'     => 'required|string|max:255',
            'content'  => 'required|string',
            'footer'   => 'nullable|string|max:200',
            'is_active' => 'boolean',
        ]);

        $validated['is_active'] = $request->has('is_active');
        $template->update($validated);

        return redirect()
            ->route('admin.whatsapp.templates.index')
            ->with('success', 'Template atualizado com sucesso!');
    }

    public function destroy(WhatsappTemplate $template): RedirectResponse
    {
        $this->authorizeTemplate($template);
        $template->delete();

        return redirect()
            ->route('admin.whatsapp.templates.index')
            ->with('success', 'Template excluído com sucesso!');
    }

    public function duplicate(WhatsappTemplate $template): RedirectResponse
    {
        $this->authorizeTemplate($template);

        $newTemplate = $template->replicate();
        $newTemplate->name = $template->name . ' (Cópia)';
        $newTemplate->slug = $template->slug . '_copy_' . Str::random(4);
        $newTemplate->is_default = false;
        $newTemplate->save();

        return redirect()
            ->route('admin.whatsapp.templates.edit', $newTemplate)
            ->with('success', 'Template duplicado com sucesso!');
    }

    public function preview(Request $request, WhatsappTemplate $template = null): JsonResponse
    {
        $message = $request->input('content', $request->input('message', $template?->content ?? ''));

        $variables = [
            '{{client_name}}'    => 'João Silva',
            '{{client_email}}'   => 'joao@email.com',
            '{{invoice_number}}' => '#1234',
            '{{invoice_total}}'  => 'R$ 150,00',
            '{{due_date}}'       => '15/06/2026',
            '{{service_name}}'   => 'Hospedagem Premium',
            '{{ticket_id}}'      => '#5678',
            '{{company_name}}'   => config('app.name'),
        ];

        $preview = str_replace(array_keys($variables), array_values($variables), $message);

        return response()->json(['preview' => $preview, 'length' => mb_strlen($message)]);
    }

    public function sendTest(Request $request, WhatsappTemplate $template): JsonResponse
    {
        $this->authorizeTemplate($template);

        $request->validate(['phone' => 'required|string']);

        if (!$this->whatsapp->isEnabled()) {
            return response()->json([
                'success' => false,
                'message' => 'WhatsApp não configurado. Defina EVOLUTION_URL, EVOLUTION_API_KEY e EVOLUTION_INSTANCE no .env.',
            ], 422);
        }

        $variables = [
            '{{client_name}}'    => 'João Silva',
            '{{client_email}}'   => 'joao@email.com',
            '{{invoice_number}}' => '#1234',
            '{{invoice_total}}'  => 'R$ 150,00',
            '{{due_date}}'       => '15/06/2026',
            '{{service_name}}'   => 'Hospedagem Premium',
            '{{ticket_id}}'      => '#5678',
            '{{company_name}}'   => config('app.name'),
        ];

        $message = str_replace(array_keys($variables), array_values($variables), $template->content);
        if ($template->footer) {
            $message .= "\n\n_" . $template->footer . '_';
        }
        $message = "[TESTE] " . config('app.name') . "\n\n" . $message;

        $sent = $this->whatsapp->sendText($request->phone, $message);

        if (!$sent) {
            $detail = $this->whatsapp->getLastError();
            return response()->json([
                'success' => false,
                'message' => 'Falha ao enviar WhatsApp: ' . ($detail ?: 'verifique se a instância Evolution está conectada.'),
            ], 500);
        }

        return response()->json([
            'success' => true,
            'message' => 'Mensagem de teste enviada para ' . $request->phone,
        ]);
    }

    private function authorizeTemplate(WhatsappTemplate $template): void
    {
        if ($template->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }

    private function eventTypes(): array
    {
        return [
            'invoice_created'   => 'Fatura Criada',
            'invoice_due'       => 'Fatura Vencendo',
            'invoice_overdue'   => 'Fatura Vencida',
            'invoice_paid'      => 'Fatura Paga',
            'service_created'   => 'Serviço Criado',
            'service_suspended' => 'Serviço Suspenso',
            'service_cancelled' => 'Serviço Cancelado',
            'ticket_opened'     => 'Ticket Aberto',
            'ticket_replied'    => 'Ticket Respondido',
            'ticket_closed'     => 'Ticket Fechado',
            'custom'            => 'Personalizado',
        ];
    }
}
