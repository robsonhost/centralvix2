<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Services\WhatsAppService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WhatsAppVerificationController extends Controller
{
    protected $whatsappService;

    public function __construct(WhatsAppService $whatsappService)
    {
        $this->whatsappService = $whatsappService;
    }

    /**
     * Enviar código de verificação
     */
    public function sendCode(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Número de telefone inválido',
                'errors' => $validator->errors()
            ], 422);
        }

        $phone = $request->input('phone');

        // Primeiro verificar se o número existe no WhatsApp
        $checkResult = $this->whatsappService->checkNumberExists($phone);
        
        if (!$checkResult['success']) {
            return response()->json([
                'success' => false,
                'message' => $checkResult['message']
            ], 400);
        }

        if (!isset($checkResult['exists']) || !$checkResult['exists']) {
            return response()->json([
                'success' => false,
                'message' => 'Este número não está registrado no WhatsApp'
            ], 400);
        }

        // Enviar código
        $result = $this->whatsappService->sendVerificationCode($phone);

        if ($result['success']) {
            return response()->json([
                'success' => true,
                'message' => 'Código enviado! Verifique seu WhatsApp.',
                'code_for_testing' => $result['code_for_testing'] ?? null
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => $result['message']
        ], 400);
    }

    /**
     * Verificar código
     */
    public function verifyCode(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string',
            'code' => 'required|string|size:6',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $phone = $request->input('phone');
        $code = $request->input('code');

        $verified = $this->whatsappService->verifyCode($phone, $code);

        if ($verified) {
            return response()->json([
                'success' => true,
                'message' => 'Número verificado com sucesso!'
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Código inválido ou expirado'
        ], 400);
    }

    /**
     * Verificar status da conexão da instância do WhatsApp
     */
    public function connectionStatus(): JsonResponse
    {
        $status = $this->whatsappService->checkConnectionStatus();

        return response()->json([
            'success' => true,
            'connected' => $status['connected'] ?? false,
            'message' => $status['message'] ?? null,
        ]);
    }

    /**
     * Verificar status de verificação
     */
    public function checkVerificationStatus(Request $request): JsonResponse
    {
        $phone = $request->input('phone');

        if (!$phone) {
            return response()->json([
                'success' => false,
                'verified' => false
            ]);
        }

        $verified = $this->whatsappService->isNumberVerified($phone);

        return response()->json([
            'success' => true,
            'verified' => $verified,
            'message' => $verified ? 'Número verificado' : 'Número não verificado'
        ]);
    }
}
