<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\ClientQuery;
use App\Models\QueryType;
use App\Services\QueryService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class QueryController extends Controller
{
    public function __construct(private QueryService $queryService) {}

    /**
     * Página principal de consultas (Nova Consulta)
     */
    public function index(): View
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        abort_unless(
            app(\App\Services\ModuleService::class)->isEnabled($client->company_id, 'consultas'),
            404
        );

        \Database\Seeders\ConsultasModuleSeeder::seedForCompany($client->company_id);

        $queryTypes = QueryType::forCompany($client->company_id)
            ->active()
            ->orderBy('category')
            ->orderBy('order')
            ->get()
            ->groupBy('category');

        return view('client.queries.index', [
            'client' => $client,
            'queryTypes' => $queryTypes,
            'balance' => (float) $client->credit_balance,
        ]);
    }

    /**
     * Executa uma consulta
     */
    public function execute(Request $request): JsonResponse
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        abort_unless(
            app(\App\Services\ModuleService::class)->isEnabled($client->company_id, 'consultas'),
            404
        );

        $validated = $request->validate([
            'query_type_id' => 'required|exists:query_types,id',
            'search_term' => 'required|string|min:3|max:100',
        ]);

        $queryType = QueryType::where('id', $validated['query_type_id'])
            ->where('company_id', $client->company_id)
            ->where('active', true)
            ->first();

        if (!$queryType) {
            return response()->json([
                'success' => false,
                'message' => 'Tipo de consulta não encontrado ou inativo',
            ], 404);
        }

        $searchTerm = preg_replace('/[^0-9a-zA-Z@.\-_\s]/', '', $validated['search_term']);

        $result = $this->queryService->execute(
            $client,
            $queryType,
            $searchTerm,
            $request->ip()
        );

        $statusCode = $result['success'] ? 200 : ($result['needs_recharge'] ?? false ? 402 : 400);

        return response()->json($result, $statusCode);
    }

    /**
     * Histórico de consultas
     */
    public function history(Request $request): View
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        $queries = ClientQuery::where('client_id', $client->id)
            ->with('queryType')
            ->latest()
            ->paginate(20);

        return view('client.queries.history', [
            'client' => $client,
            'queries' => $queries,
        ]);
    }

    /**
     * Detalhes de uma consulta
     */
    public function show(ClientQuery $query): View
    {
        if (!auth()->user()->canAccessClientRecord($query->client)) {
            abort(403);
        }

        $query->load('queryType');

        return view('client.queries.show', [
            'query' => $query,
        ]);
    }

    /**
     * API: Retorna saldo atual do cliente
     */
    public function balance(): JsonResponse
    {
        $client = auth()->user()->resolveClient();

        return response()->json([
            'balance' => $client ? (float) $client->credit_balance : 0,
            'formatted' => $client ? 'R$ ' . number_format($client->credit_balance, 2, ',', '.') : 'R$ 0,00',
        ]);
    }
}
