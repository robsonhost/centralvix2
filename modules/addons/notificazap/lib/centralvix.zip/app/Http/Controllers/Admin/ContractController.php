<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Contract;
use App\Models\ContractTemplate;
use App\Models\Service;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Barryvdh\DomPDF\Facade\Pdf;

class ContractController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Contract::with(['client', 'template'])
            ->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('number', 'like', "%{$search}%")
                    ->orWhere('title', 'like', "%{$search}%")
                    ->orWhereHas('client', function ($c) use ($search) {
                        $c->where('firstname', 'like', "%{$search}%")
                            ->orWhere('lastname', 'like', "%{$search}%")
                            ->orWhere('email', 'like', "%{$search}%")
                            ->orWhere('companyname', 'like', "%{$search}%");
                    });
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $contracts = $query->latest()->paginate(20)->withQueryString();

        $baseQuery = Contract::where('company_id', $companyId);

        $stats = [
            'active'    => (clone $baseQuery)->whereIn('status', ['sent', 'viewed'])->count(),
            'draft'     => (clone $baseQuery)->where('status', 'draft')->count(),
            'signed'    => (clone $baseQuery)->where('status', 'signed')->count(),
            'expired'   => (clone $baseQuery)->where('status', 'expired')->count(),
            'cancelled' => (clone $baseQuery)->where('status', 'cancelled')->count(),
        ];

        return view('admin.contracts.index', compact('contracts', 'stats'));
    }

    public function create(Request $request): View
    {
        $companyId = auth()->user()->company_id;
        $templates = ContractTemplate::where('company_id', $companyId)->where('is_active', true)->get();
        $clients = Client::where('company_id', $companyId)->orderBy('firstname')->get();
        $selectedClient = $request->filled('client_id')
            ? Client::where('company_id', $companyId)->find($request->client_id)
            : null;
        $services = $selectedClient
            ? Service::where('client_id', $selectedClient->id)->get()
            : collect();

        return view('admin.contracts.create', compact('templates', 'clients', 'services', 'selectedClient'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'client_id'   => 'required|exists:clients,id',
            'template_id' => 'nullable|exists:contract_templates,id',
            'service_id'  => 'nullable|exists:services,id',
            'title'       => 'required|string|max:255',
            'content'     => 'required|string',
            'expiry_days' => 'nullable|integer|min:1',
            'signature_methods' => 'nullable|array',
        ]);

        $companyId = auth()->user()->company_id;

        $contract = Contract::create([
            'company_id'        => $companyId,
            'client_id'         => $validated['client_id'],
            'template_id'       => $validated['template_id'] ?? null,
            'service_id'        => $validated['service_id'] ?? null,
            'title'             => $validated['title'],
            'content'           => $validated['content'],
            'status'            => 'draft',
            'signature_methods' => $validated['signature_methods'] ?? ['link'],
            'expires_at'        => now()->addDays($validated['expiry_days'] ?? 30),
        ]);

        $this->generatePdf($contract);

        return redirect()
            ->route('admin.contracts.show', $contract)
            ->with('success', 'Contrato criado com sucesso!');
    }

    public function getTemplateContent(Request $request): JsonResponse
    {
        $request->validate([
            'id'        => 'required|exists:contract_templates,id',
            'client_id' => 'nullable|exists:clients,id',
        ]);

        $template = ContractTemplate::findOrFail($request->id);
        $client = $request->client_id ? Client::find($request->client_id) : null;

        $data = [
            'client_name'  => $client?->display_name ?? '{{client_name}}',
            'client_email' => $client?->email ?? '{{client_email}}',
            'client_cpf'   => $client?->cpf ?? '{{client_cpf}}',
            'client_cnpj'  => $client?->cnpj ?? '{{client_cnpj}}',
            'company_name' => config('app.name'),
            'today'        => now()->format('d/m/Y'),
        ];

        return response()->json([
            'title'   => $template->name,
            'content' => $template->render($data),
        ]);
    }

    public function show(Contract $contract): View
    {
        $contract->load(['client', 'template']);

        return view('admin.contracts.show', compact('contract'));
    }

    public function edit(Contract $contract): View
    {
        return view('admin.contracts.edit', compact('contract'));
    }

    public function update(Request $request, Contract $contract): RedirectResponse
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        $contract->update($validated);

        $this->generatePdf($contract);

        return redirect()
            ->route('admin.contracts.show', $contract)
            ->with('success', 'Contrato atualizado com sucesso!');
    }

    public function destroy(Contract $contract): RedirectResponse
    {
        if ($contract->pdf_path && Storage::exists($contract->pdf_path)) {
            Storage::delete($contract->pdf_path);
        }

        $contract->delete();

        return redirect()
            ->route('admin.contracts.index')
            ->with('success', 'Contrato excluído com sucesso!');
    }

    public function send(Contract $contract): RedirectResponse
    {
        if ($contract->status === 'sent' || $contract->status === 'signed') {
            return back()->with('warning', 'Contrato já foi enviado ou assinado.');
        }

        $contract->update([
            'status' => 'sent',
            'sent_at' => now(),
        ]);

        return back()->with('success', 'Contrato enviado para o cliente!');
    }

    public function download(Contract $contract)
    {
        if (!$contract->pdf_path || !Storage::exists($contract->pdf_path)) {
            $this->generatePdf($contract);
        }

        return Storage::download($contract->pdf_path, "contrato_{$contract->id}.pdf");
    }

    protected function generatePdf(Contract $contract): void
    {
        $content = $this->replaceVariables($contract->content, $contract);

        $pdf = Pdf::loadView('pdf.contract', [
            'contract' => $contract,
            'content' => $content,
        ]);

        $filename = "contracts/contract_{$contract->id}_" . time() . ".pdf";
        
        Storage::put($filename, $pdf->output());

        $contract->update(['pdf_path' => $filename]);
    }

    protected function replaceVariables(string $content, Contract $contract): string
    {
        $client = $contract->client;

        $variables = [
            '{client_name}' => $client->display_name ?? $client->firstname,
            '{client_email}' => $client->email,
            '{client_phone}' => $client->phone,
            '{client_cpf}' => $client->cpf ?? $client->cnpj,
            '{client_address}' => $client->address,
            '{contract_id}' => $contract->id,
            '{contract_date}' => $contract->created_at->format('d/m/Y'),
            '{company_name}' => config('app.name'),
            '{current_date}' => now()->format('d/m/Y'),
        ];

        return str_replace(
            array_keys($variables),
            array_values($variables),
            $content
        );
    }
}
