<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Services\HostingManagementService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ServiceHostingController extends Controller
{
    public function __construct(private HostingManagementService $hosting)
    {
    }

    public function overview(Service $service): View
    {
        $this->hosting->assertAccess($service);
        $service->load(['product', 'server', 'domains']);

        $overview = $this->hosting->getOverview($service);

        return view('client.services.hosting.overview', [
            'service' => $service,
            'overview' => $overview,
            'tab' => 'overview',
        ]);
    }

    public function dns(Service $service): View
    {
        $this->hosting->assertAccess($service);
        $service->load(['product', 'server']);

        $records = [];
        $error = null;

        try {
            $records = $this->hosting->listDnsRecords($service);
        } catch (\Throwable $e) {
            $error = 'Não foi possível carregar os registros DNS. Tente novamente mais tarde.';
            logger()->error('DNS list failed', ['service_id' => $service->id, 'error' => $e->getMessage()]);
        }

        return view('client.services.hosting.dns', compact('service', 'records', 'error') + ['tab' => 'dns']);
    }

    public function storeDnsRecord(Request $request, Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'type' => ['required', 'in:A,AAAA,CNAME,MX,TXT,NS,SRV'],
            'address' => ['required', 'string', 'max:500'],
            'ttl' => ['nullable', 'integer', 'min:60', 'max:86400'],
        ]);

        $ok = $this->hosting->addDnsRecord($service, [
            'name' => $data['name'],
            'type' => $data['type'],
            'address' => $data['address'],
            'ttl' => $data['ttl'] ?? 14400,
        ]);

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Registro DNS adicionado com sucesso.'
            : 'Falha ao adicionar registro DNS.');
    }

    public function destroyDnsRecord(Request $request, Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $data = $request->validate([
            'line' => ['required', 'integer', 'min:1'],
        ]);

        $ok = $this->hosting->deleteDnsRecord($service, (int) $data['line']);

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Registro DNS removido.'
            : 'Falha ao remover registro DNS.');
    }

    public function email(Service $service): View
    {
        $this->hosting->assertAccess($service);
        $service->load(['product', 'server']);

        $accounts = [];
        $error = null;

        try {
            $accounts = $this->hosting->listEmailAccounts($service);
        } catch (\Throwable $e) {
            $error = 'Não foi possível carregar as contas de e-mail.';
            logger()->error('Email list failed', ['service_id' => $service->id, 'error' => $e->getMessage()]);
        }

        return view('client.services.hosting.email', compact('service', 'accounts', 'error') + ['tab' => 'email']);
    }

    public function storeEmailAccount(Request $request, Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $data = $request->validate([
            'local_part' => ['required', 'string', 'max:64', 'regex:/^[a-zA-Z0-9._-]+$/'],
            'password' => ['required', 'string', 'min:8', 'max:128'],
            'quota_mb' => ['nullable', 'integer', 'min:0', 'max:10240'],
        ]);

        $ok = $this->hosting->createEmailAccount(
            $service,
            $data['local_part'],
            $data['password'],
            (int) ($data['quota_mb'] ?? 250),
        );

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Conta de e-mail criada com sucesso.'
            : 'Falha ao criar conta de e-mail.');
    }

    public function destroyEmailAccount(Request $request, Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $data = $request->validate([
            'email' => ['required', 'string', 'max:255'],
        ]);

        $ok = $this->hosting->deleteEmailAccount($service, $data['email']);

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Conta de e-mail removida.'
            : 'Falha ao remover conta de e-mail.');
    }

    public function updateEmailPassword(Request $request, Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $data = $request->validate([
            'email' => ['required', 'string', 'max:255'],
            'password' => ['required', 'string', 'min:8', 'max:128', 'confirmed'],
        ]);

        $ok = $this->hosting->changeEmailPassword($service, $data['email'], $data['password']);

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Senha do e-mail alterada.'
            : 'Falha ao alterar senha do e-mail.');
    }

    public function ftp(Service $service): View
    {
        $this->hosting->assertAccess($service);
        $service->load(['product', 'server']);

        $accounts = [];
        $error = null;

        try {
            $accounts = $this->hosting->listFtpAccounts($service);
        } catch (\Throwable $e) {
            $error = 'Não foi possível carregar as contas FTP.';
            logger()->error('FTP list failed', ['service_id' => $service->id, 'error' => $e->getMessage()]);
        }

        return view('client.services.hosting.ftp', compact('service', 'accounts', 'error') + ['tab' => 'ftp']);
    }

    public function storeFtpAccount(Request $request, Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $data = $request->validate([
            'user' => ['required', 'string', 'max:64', 'regex:/^[a-zA-Z0-9._-]+$/'],
            'password' => ['required', 'string', 'min:8', 'max:128', 'confirmed'],
            'directory' => ['nullable', 'string', 'max:255'],
        ]);

        $ok = $this->hosting->createFtpAccount(
            $service,
            $data['user'],
            $data['password'],
            $data['directory'] ?? 'public_html',
        );

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Conta FTP criada com sucesso.'
            : 'Falha ao criar conta FTP.');
    }

    public function destroyFtpAccount(Request $request, Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $data = $request->validate([
            'user' => ['required', 'string', 'max:255'],
        ]);

        $ok = $this->hosting->deleteFtpAccount($service, $data['user']);

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Conta FTP removida.'
            : 'Falha ao remover conta FTP.');
    }

    public function ssl(Service $service): View
    {
        $this->hosting->assertAccess($service);
        $service->load(['product', 'server', 'sslCertificates']);

        $certificates = [];
        $error = null;

        try {
            $certificates = $this->hosting->listSslCertificates($service);
        } catch (\Throwable $e) {
            $error = 'Não foi possível carregar os certificados SSL.';
            logger()->error('SSL list failed', ['service_id' => $service->id, 'error' => $e->getMessage()]);
        }

        return view('client.services.hosting.ssl', compact('service', 'certificates', 'error') + ['tab' => 'ssl']);
    }

    public function runAutoSsl(Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $ok = $this->hosting->runAutoSsl($service);

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Verificação AutoSSL iniciada. O certificado pode levar alguns minutos.'
            : 'Falha ao iniciar AutoSSL.');
    }

    public function password(Service $service): View
    {
        $this->hosting->assertAccess($service);
        $service->load(['product', 'server']);

        return view('client.services.hosting.password', compact('service') + ['tab' => 'password']);
    }

    public function updatePassword(Request $request, Service $service): RedirectResponse
    {
        $this->hosting->assertMutable($service);

        $data = $request->validate([
            'password' => ['required', 'string', 'min:10', 'max:128', 'confirmed'],
        ]);

        try {
            $ok = $this->hosting->changeHostingPassword($service, $data['password']);
        } catch (\Throwable $e) {
            logger()->error('Hosting password change failed', ['service_id' => $service->id, 'error' => $e->getMessage()]);
            return back()->with('error', 'Falha ao alterar senha da hospedagem.');
        }

        return back()->with($ok ? 'success' : 'error', $ok
            ? 'Senha da hospedagem alterada com sucesso.'
            : 'Falha ao alterar senha da hospedagem.');
    }
}
