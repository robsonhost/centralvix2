<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Services\ProvisioningService;
use Illuminate\View\View;

class ServiceController extends Controller
{
    public function index(): View
    {
        $client = auth()->user()->resolveClient() ?? abort(404);
        $services = $client->services()->with(['product', 'server'])->latest()->paginate(10);

        $summary = [
            'total' => $client->services()->count(),
            'active' => $client->services()->where('status', 'active')->count(),
            'suspended' => $client->services()->where('status', 'suspended')->count(),
            'monthly' => (float) $client->services()->where('status', 'active')->sum('amount'),
        ];

        return view('client.services.index', compact('services', 'summary'));
    }

    public function show(Service $service): View
    {
        if (!auth()->user()->canAccessClientRecord($service->client)) {
            abort(403);
        }
        $service->load(['product', 'server', 'invoiceItems.invoice', 'domains']);
        return view('client.services.show', compact('service'));
    }

    public function panelLogin(Service $service, ProvisioningService $provisioningService): \Illuminate\Http\RedirectResponse
    {
        if (!auth()->user()->canAccessClientRecord($service->client)) {
            abort(403);
        }

        if (!$service->server || !in_array($service->status, ['active', 'suspended'], true)) {
            abort(403, 'Painel indisponível para este serviço.');
        }

        $url = $provisioningService->createLoginSession($service);

        if (!$url) {
            return back()->with('error', 'Não foi possível abrir o painel de controle. Tente novamente ou abra um ticket.');
        }

        return redirect()->away($url);
    }

    public function whmLogin(Service $service, ProvisioningService $provisioningService): \Illuminate\Http\RedirectResponse
    {
        if (!auth()->user()->canAccessClientRecord($service->client)) {
            abort(403);
        }

        if (!$service->isReseller() || !$service->server || !in_array($service->status, ['active', 'suspended'], true)) {
            abort(403, 'WHM disponível apenas para planos reseller ativos.');
        }

        if (!$service->username) {
            return back()->with('error', 'Conta ainda não provisionada no servidor.');
        }

        $url = $provisioningService->createWhmLoginSession($service);

        if (!$url) {
            return back()->with('error', 'Não foi possível abrir o WHM. Verifique se a conta reseller está ativa.');
        }

        return redirect()->away($url);
    }

    public function requestCancellation(Service $service): \Illuminate\Http\RedirectResponse
    {
        $client = auth()->user()->resolveClient() ?? abort(404);
        if (!auth()->user()->canAccessClientRecord($service->client)) {
            abort(403);
        }

        // Create a cancellation ticket
        $ticket = $client->tickets()->create([
            'uuid' => \Illuminate\Support\Str::uuid(),
            'company_id' => $client->company_id,
            'subject' => 'Solicitação de Cancelamento - ' . $service->name,
            'status' => 'open',
            'priority' => 'medium',
            'service_id' => $service->id,
        ]);

        return redirect()->route('client.tickets.show', $ticket)
            ->with('info', 'Solicitação de cancelamento enviada. Nossa equipe irá processar em breve.');
    }
}
