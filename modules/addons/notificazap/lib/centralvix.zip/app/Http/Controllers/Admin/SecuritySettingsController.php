<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Services\EvolutionWhatsAppService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SecuritySettingsController extends Controller
{
    public function __construct(private EvolutionWhatsAppService $whatsapp) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $settings = Setting::where('company_id', $companyId)
            ->whereIn('group', ['verification', 'notifications'])
            ->get()
            ->groupBy('group');

        return view('admin.settings.security', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            // Verificação
            'verification.enabled' => 'required|boolean',
            'verification.method' => 'required|in:email,whatsapp,both,disabled',
            'verification.code_expiry_minutes' => 'required|integer|min:5|max:120',
            'verification.code_length' => 'required|integer|min:4|max:8',
            'verification.max_attempts' => 'required|integer|min:3|max:10',
            
            // Notificações de boas-vindas
            'notifications.welcome_email_enabled' => 'required|boolean',
            'notifications.welcome_whatsapp_enabled' => 'required|boolean',
        ]);

        $companyId = auth()->user()->company_id;

        foreach ($validated as $group => $settings) {
            foreach ($settings as $key => $value) {
                Setting::updateOrCreate(
                    [
                        'company_id' => $companyId,
                        'group' => $group,
                        'key' => $key,
                    ],
                    [
                        'value' => is_bool($value) ? ($value ? 'true' : 'false') : $value,
                        'updated_at' => now(),
                    ]
                );
            }
        }

        activity()
            ->causedBy(auth()->user())
            ->log('Configurações de segurança e verificação atualizadas');

        return redirect()
            ->route('admin.settings.security')
            ->with('success', '✓ Configurações de segurança atualizadas com sucesso!');
    }

    public function testVerificationEmail(Request $request): RedirectResponse
    {
        $request->validate(['email' => 'required|email']);

        try {
            $code = rand(100000, 999999);
            
            \Mail::to($request->email)->send(
                new \App\Mail\VerificationCodeMail($code, 30)
            );

            return back()->with('success', '✓ Email de teste enviado para ' . $request->email);
        } catch (\Exception $e) {
            return back()->with('error', '❌ Erro ao enviar: ' . $e->getMessage());
        }
    }

    public function testVerificationWhatsapp(Request $request): RedirectResponse
    {
        $request->validate(['phone' => 'required|string']);

        try {
            $code = (string) rand(100000, 999999);
            $expiry = (int) (Setting::where('company_id', auth()->user()->company_id)
                ->where('group', 'verification')
                ->where('key', 'code_expiry_minutes')
                ->value('value') ?? 30);

            if (!$this->whatsapp->isEnabled()) {
                return back()->with('error', '❌ WhatsApp não configurado. Defina EVOLUTION_URL, EVOLUTION_API_KEY e EVOLUTION_INSTANCE no .env.');
            }

            $sent = $this->whatsapp->sendVerificationCode($request->phone, $code, $expiry);

            if (!$sent) {
                $detail = $this->whatsapp->getLastError();
                return back()->with('error', '❌ Falha ao enviar WhatsApp: ' . ($detail ?: 'verifique se a instância Evolution está conectada.'));
            }

            return back()->with('success', '✓ WhatsApp de teste enviado para ' . $request->phone);
        } catch (\Exception $e) {
            return back()->with('error', '❌ Erro ao enviar: ' . $e->getMessage());
        }
    }
}
