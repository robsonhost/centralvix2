<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\WhatsappChat;
use App\Models\WhatsappInstance;
use App\Models\WhatsappMessage;
use App\Services\AI\AiService;
use App\Services\WhatsApp\EvolutionGoService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class WhatsappWebhookController extends Controller
{
    public function __construct(private AiService $ai) {}

    public function handle(Request $request, string $instanceKey): JsonResponse
    {
        $payload = $request->all();
        $event   = $payload['event'] ?? $payload['type'] ?? '';

        $instance = WhatsappInstance::where('instance_key', $instanceKey)->first();
        if (!$instance) {
            return response()->json(['status' => 'unknown_instance'], 404);
        }

        match ($event) {
            'MESSAGES_UPSERT', 'messages.upsert' => $this->handleIncomingMessage($instance, $payload),
            'MESSAGES_UPDATE', 'messages.update' => $this->handleMessageUpdate($instance, $payload),
            'CONNECTION_UPDATE', 'connection.update' => $this->handleConnectionUpdate($instance, $payload),
            'QRCODE_UPDATED', 'qrcode.updated' => $this->handleQrCodeUpdate($instance, $payload),
            'SEND_MESSAGE' => null, // outbound confirmation
            default => null,
        };

        return response()->json(['status' => 'ok']);
    }

    private function handleIncomingMessage(WhatsappInstance $instance, array $payload): void
    {
        $data = $payload['data'] ?? $payload;

        // Support both Evolution formats
        $messages = $data['messages'] ?? [$data];

        foreach ($messages as $msg) {
            // Skip outbound messages
            if ($msg['key']['fromMe'] ?? false) continue;

            $from    = $msg['key']['remoteJid'] ?? '';
            $number  = preg_replace('/[@\w.]+$/', '', $from);
            $number  = preg_replace('/\D/', '', $number);
            $body    = $msg['message']['conversation']
                       ?? $msg['message']['extendedTextMessage']['text']
                       ?? $msg['message']['imageMessage']['caption']
                       ?? '[mídia]';

            $msgId   = $msg['key']['id'] ?? null;
            $pushName = $msg['pushName'] ?? null;

            // Find or create chat
            $chat = WhatsappChat::firstOrCreate(
                ['instance_id' => $instance->id, 'phone_number' => $number],
                [
                    'company_id'      => $instance->company_id,
                    'contact_name'    => $pushName,
                    'status'          => 'open',
                    'ai_enabled'      => false,
                    'unread_count'    => 0,
                    'last_message_at' => now(),
                ]
            );

            // Try to link client
            if (!$chat->client_id) {
                $client = Client::where('company_id', $instance->company_id)
                    ->where(fn($q) => $q->where('whatsapp', 'like', "%{$number}%")
                        ->orWhere('mobile', 'like', "%{$number}%")
                        ->orWhere('phone', 'like', "%{$number}%"))
                    ->first();

                if ($client) {
                    $chat->update(['client_id' => $client->id]);
                }
            }

            $chat->increment('unread_count');
            $chat->update([
                'last_message'    => $body,
                'last_message_at' => now(),
                'status'          => 'open',
                'contact_name'    => $pushName ?? $chat->contact_name,
            ]);

            // Store message
            WhatsappMessage::create([
                'uuid'        => Str::uuid(),
                'company_id'  => $instance->company_id,
                'instance_id' => $instance->id,
                'client_id'   => $chat->client_id,
                'to_number'   => $number,
                'type'        => 'text',
                'content'     => $body,
                'message_id'  => $msgId,
                'status'      => 'delivered',
                'sent_by'     => null, // inbound = null
                'sent_at'     => now(),
                'raw_response' => $msg,
            ]);

            // AI auto-reply if enabled
            if ($chat->ai_enabled && config('ai.enabled')) {
                $this->triggerAiReply($instance, $chat, $number, $body);
            } else {
                // Chatbot rule-based (módulo "Chatbot WhatsApp"), quando a IA não está ativa.
                try {
                    app(\App\Services\ChatbotService::class)->handle($instance, $chat, $number, $body);
                } catch (\Throwable $e) {
                    logger()->error('Chatbot handle falhou: ' . $e->getMessage());
                }
            }
        }
    }

    private function handleMessageUpdate(WhatsappInstance $instance, array $payload): void
    {
        $updates = $payload['data'] ?? [];
        if (!isset($updates[0])) $updates = [$updates];

        foreach ($updates as $update) {
            $msgId  = $update['key']['id'] ?? null;
            $status = $update['update']['status'] ?? null;

            if (!$msgId || !$status) continue;

            $map = ['DELIVERY_ACK' => 'delivered', 'READ' => 'read', 'PLAYED' => 'read'];
            $newStatus = $map[$status] ?? null;

            if ($newStatus) {
                WhatsappMessage::where('message_id', $msgId)->where('company_id', $instance->company_id)
                    ->update([
                        'status'       => $newStatus,
                        'delivered_at' => $newStatus === 'delivered' ? now() : null,
                        'read_at'      => $newStatus === 'read' ? now() : null,
                    ]);

                // Update notification log too
                \App\Models\NotificationLog::where('external_id', $msgId)
                    ->where('company_id', $instance->company_id)
                    ->update(['status' => $newStatus]);
            }
        }
    }

    private function handleConnectionUpdate(WhatsappInstance $instance, array $payload): void
    {
        $state = $payload['data']['state'] ?? $payload['state'] ?? null;

        if ($state) {
            $map    = ['open' => 'connected', 'connecting' => 'connecting', 'close' => 'disconnected'];
            $status = $map[$state] ?? 'disconnected';

            $instance->update([
                'status'       => $status,
                'connected_at' => $status === 'connected' ? now() : null,
                'qr_code'      => $status === 'connected' ? null : $instance->qr_code,
            ]);
        }
    }

    private function handleQrCodeUpdate(WhatsappInstance $instance, array $payload): void
    {
        $qr = $payload['data']['qrcode']['base64'] ?? $payload['qrcode']['base64'] ?? null;
        if ($qr) {
            $instance->update(['qr_code' => $qr, 'status' => 'connecting']);
        }
    }

    private function triggerAiReply(WhatsappInstance $instance, WhatsappChat $chat, string $number, string $message): void
    {
        try {
            $context = [];
            if ($chat->client_id) {
                $client    = Client::find($chat->client_id);
                $context[] = "Cliente: {$client?->display_name}";
            }

            $reply = $this->ai->whatsappReply($message, $context, $instance->company_id);

            if (!$reply) return;

            $evolution = new EvolutionGoService($instance);
            $result    = $evolution->sendText($instance->instance_key, $number, $reply);

            WhatsappMessage::create([
                'uuid'        => Str::uuid(),
                'company_id'  => $instance->company_id,
                'instance_id' => $instance->id,
                'client_id'   => $chat->client_id,
                'to_number'   => $number,
                'type'        => 'text',
                'content'     => $reply,
                'message_id'  => $result['key']['id'] ?? null,
                'status'      => 'sent',
                'sent_by'     => 'IA',
                'sent_at'     => now(),
            ]);

            $chat->update(['last_message' => $reply, 'last_message_at' => now()]);
        } catch (\Exception $e) {
            logger()->error("AI WhatsApp reply failed: " . $e->getMessage());
        }
    }
}
