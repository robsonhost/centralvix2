<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\License\CentralVixLicenseService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class HelpController extends Controller
{
    public function __construct(
        private CentralVixLicenseService $licenseService
    ) {}

    public function documentation(): View
    {
        return view('admin.help.documentation');
    }

    public function license(): View
    {
        $companyId = (int) auth()->user()->company_id;
        $license = $this->licenseService->getOrCreateForCompany($companyId);

        return view('admin.help.license', compact('license'));
    }

    public function updateLicense(Request $request): JsonResponse|RedirectResponse
    {
        $request->validate([
            'license_key' => 'required|string|min:8|max:255',
        ]);

        $companyId = (int) auth()->user()->company_id;
        $result = $this->licenseService->activateForCompany($companyId, $request->input('license_key'));

        if ($request->expectsJson()) {
            return response()->json($result, ($result['success'] ?? false) ? 200 : 422);
        }

        if ($result['success'] ?? false) {
            return redirect()->route('admin.help.license')->with('success', $result['message']);
        }

        return back()->withErrors(['license_key' => $result['message'] ?? 'Erro ao validar licença']);
    }

    public function forceUpdate(Request $request): JsonResponse|RedirectResponse
    {
        $companyId = (int) auth()->user()->company_id;
        $result = $this->licenseService->forceVerify($companyId);

        if ($request->expectsJson()) {
            $status = ($result['success'] ?? false) ? 200 : 422;
            return response()->json([
                'success' => $result['success'] ?? false,
                'message' => $result['message'] ?? 'Verificação concluída',
            ], $status);
        }

        if ($result['success'] ?? false) {
            return redirect()->route('admin.help.license')->with('success', $result['message']);
        }

        return redirect()->route('admin.help.license')->with('error', $result['message'] ?? 'Falha na verificação');
    }

    public function licenseStatus(): JsonResponse
    {
        $companyId = (int) auth()->user()->company_id;
        $compliant = $this->licenseService->isCompliant($companyId);
        $license = \App\Models\CompanyLicense::where('company_id', $companyId)->first();

        return response()->json([
            'compliant' => $compliant,
            'blocked' => $license ? $license->isBlocked() : true,
            'remote_status' => $license?->remote_status,
            'is_compliant' => (bool) ($license?->is_compliant),
            'message' => $compliant ? null : $this->licenseService->blockMessage($companyId),
            'last_verified_at' => $license?->last_verified_at?->toIso8601String(),
            'check_interval_minutes' => (int) config('license.check_interval_minutes', 1),
        ]);
    }
}
