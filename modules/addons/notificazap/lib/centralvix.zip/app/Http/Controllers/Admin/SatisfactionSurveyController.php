<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SatisfactionSurvey;
use Illuminate\View\View;

class SatisfactionSurveyController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $base = SatisfactionSurvey::forCompany($companyId);

        $total = (clone $base)->count();
        $sent = (clone $base)->whereNotNull('sent_at')->count();
        $answered = (clone $base)->answered()->count();
        $responseRate = $sent > 0 ? round(($answered / $sent) * 100, 1) : 0.0;

        // Médias / NPS calculados sobre respostas.
        $csatAvg = (float) (clone $base)->answered()->where('type', 'csat')->avg('score');

        $npsAnswered = (clone $base)->answered()->where('type', 'nps');
        $npsTotal = (clone $npsAnswered)->count();
        $promoters = (clone $npsAnswered)->where('score', '>=', 9)->count();
        $detractors = (clone $npsAnswered)->where('score', '<=', 6)->count();
        $npsScore = $npsTotal > 0 ? round((($promoters - $detractors) / $npsTotal) * 100) : null;

        $surveys = (clone $base)
            ->with(['client', 'ticket'])
            ->latest()
            ->paginate(20);

        return view('admin.surveys.index', [
            'total' => $total,
            'sent' => $sent,
            'answered' => $answered,
            'responseRate' => $responseRate,
            'csatAvg' => $csatAvg,
            'npsScore' => $npsScore,
            'npsTotal' => $npsTotal,
            'surveys' => $surveys,
        ]);
    }
}
