<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\ValidationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ValidationApiController extends Controller
{
    public function __construct(private ValidationService $validation) {}

    public function cpf(Request $request): JsonResponse
    {
        $request->validate(['cpf' => 'required|string']);
        $cpf   = preg_replace('/\D/', '', $request->cpf);
        $valid = $this->validation->validateCpf($cpf);

        return response()->json([
            'valid'     => $valid,
            'formatted' => $valid ? $this->validation->formatCpf($cpf) : null,
            'message'   => $valid ? 'CPF válido' : 'CPF inválido',
        ]);
    }

    public function cnpj(Request $request): JsonResponse
    {
        $request->validate(['cnpj' => 'required|string']);
        $cnpj  = preg_replace('/\D/', '', $request->cnpj);
        $valid = $this->validation->validateCnpj($cnpj);

        $data = ['valid' => $valid, 'formatted' => null, 'company' => null];

        if ($valid) {
            $data['formatted'] = $this->validation->formatCnpj($cnpj);
            try {
                $company = $this->validation->lookupCnpj($cnpj);
                if ($company) {
                    $data['company'] = [
                        'razao_social'   => $company['razao_social'] ?? $company['nome'] ?? '',
                        'nome_fantasia'  => $company['nome_fantasia'] ?? '',
                        'situacao'       => $company['descricao_situacao_cadastral'] ?? $company['situacao'] ?? '',
                        'logradouro'     => $company['logradouro'] ?? '',
                        'municipio'      => $company['municipio'] ?? '',
                        'uf'             => $company['uf'] ?? '',
                        'cep'            => $company['cep'] ?? '',
                    ];
                }
            } catch (\Exception) {}
        }

        return response()->json($data);
    }

    public function cep(Request $request): JsonResponse
    {
        $request->validate(['cep' => 'required|string']);

        $address = $this->validation->lookupCep(preg_replace('/\D/', '', $request->cep));

        if (!$address) {
            return response()->json(['error' => 'CEP não encontrado'], 404);
        }

        return response()->json($address);
    }

    public function ddd(Request $request): JsonResponse
    {
        $request->validate(['ddd' => 'required|string|size:2']);
        $result = $this->validation->lookupDdd($request->ddd);
        return response()->json($result);
    }

    public function geoip(Request $request): JsonResponse
    {
        $ip     = $request->input('ip', $request->ip());
        $result = $this->validation->geolocateIp($ip);
        return response()->json($result);
    }
}
