<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\WalletTransaction;
use App\Services\GiftCardService;
use App\Services\ModuleService;
use App\Services\WalletService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class WalletController extends Controller
{
    public function __construct(
        private WalletService $wallet,
        private GiftCardService $giftCards,
        private ModuleService $modules,
    ) {}

    public function index(): View
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        $transactions = WalletTransaction::where('client_id', $client->id)
            ->latest()
            ->paginate(15);

        $openInvoices = $client->invoices()
            ->whereIn('status', ['unpaid', 'pending', 'overdue'])
            ->orderBy('total')
            ->get();

        $giftCardsEnabled = $this->modules->isEnabled($client->company_id, 'gift_cards');

        return view('client.wallet.index', compact('client', 'transactions', 'openInvoices', 'giftCardsEnabled'));
    }

    public function redeem(Request $request): RedirectResponse
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        abort_unless($this->modules->isEnabled($client->company_id, 'gift_cards'), 404);

        $data = $request->validate(['code' => ['required', 'string', 'max:40']]);

        $result = $this->giftCards->redeem($data['code'], $client);

        return back()->with($result['success'] ? 'success' : 'error', $result['message']);
    }

    public function payInvoice(Invoice $invoice): RedirectResponse
    {
        abort_unless(auth()->user()->canAccessClientRecord($invoice->client), 403);

        $result = $this->wallet->payInvoice($invoice, auth()->id());

        return back()->with($result['success'] ? 'success' : 'error', $result['message']);
    }
}
