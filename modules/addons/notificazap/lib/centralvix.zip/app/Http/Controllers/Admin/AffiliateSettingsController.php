<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class AffiliateSettingsController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        // Buscar configurações de afiliados
        $settings = DB::table('affiliate_settings')
            ->where('company_id', $companyId)
            ->first();
        
        // Se não existir, criar com valores padrão
        if (!$settings) {
            DB::table('affiliate_settings')->insert([
                'company_id' => $companyId,
                'commission_percentage' => 10,
                'cookie_lifetime' => 30,
                'min_withdrawal' => 50,
                'is_active' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            
            $settings = DB::table('affiliate_settings')
                ->where('company_id', $companyId)
                ->first();
        }
        
        // Buscar banners
        $banners = DB::table('affiliate_banners')
            ->where('company_id', $companyId)
            ->orderBy('created_at', 'desc')
            ->get();
        
        return view('admin.affiliates.settings', compact('settings', 'banners'));
    }
    
    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'commission_percentage' => 'required|numeric|min:0|max:100',
            'cookie_lifetime' => 'required|integer|min:1|max:365',
            'min_withdrawal' => 'required|numeric|min:0',
            'is_active' => 'boolean',
        ]);
        
        $companyId = auth()->user()->company_id;
        
        DB::table('affiliate_settings')
            ->where('company_id', $companyId)
            ->update(array_merge($validated, [
                'is_active' => $request->boolean('is_active', false),
                'updated_at' => now(),
            ]));
        
        return back()->with('success', 'Configurações atualizadas com sucesso!');
    }
    
    public function storeBanner(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'width' => 'required|integer',
            'height' => 'required|integer',
            'link_url' => 'nullable|url',
        ]);
        
        $companyId = auth()->user()->company_id;
        
        // Upload da imagem
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '_' . $image->getClientOriginalName();
            $uploadPath = public_path('assets/affiliate-banners');
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $image->move($uploadPath, $imageName);
            
            DB::table('affiliate_banners')->insert([
                'company_id' => $companyId,
                'name' => $validated['name'],
                'image_path' => '/assets/affiliate-banners/' . $imageName,
                'width' => $validated['width'],
                'height' => $validated['height'],
                'link_url' => $validated['link_url'] ?? null,
                'is_active' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        
        return back()->with('success', 'Banner criado com sucesso!');
    }
    
    public function deleteBanner($id): RedirectResponse
    {
        $companyId = auth()->user()->company_id;
        
        $banner = DB::table('affiliate_banners')
            ->where('id', $id)
            ->where('company_id', $companyId)
            ->first();
        
        if ($banner) {
            // Deletar arquivo físico
            if (file_exists(public_path($banner->image_path))) {
                unlink(public_path($banner->image_path));
            }
            
            DB::table('affiliate_banners')
                ->where('id', $id)
                ->delete();
        }
        
        return back()->with('success', 'Banner removido com sucesso!');
    }
}
