<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\OrderStatus;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class OrderStatusController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        $statuses = OrderStatus::where('company_id', $companyId)
            ->orderBy('order')
            ->orderBy('name')
            ->get();

        return view('admin.settings.order-statuses.index', compact('statuses'));
    }

    public function create(): View
    {
        return view('admin.settings.order-statuses.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'color' => 'required|string|size:7|regex:/^#[0-9A-F]{6}$/i',
            'description' => 'nullable|string',
            'is_default' => 'boolean',
            'send_email' => 'boolean',
            'email_template' => 'nullable|string',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $validated['company_id'] = auth()->user()->company_id;
        $validated['slug'] = Str::slug($validated['name']);

        // If is_default is true, set all other statuses to false
        if ($validated['is_default'] ?? false) {
            OrderStatus::where('company_id', $validated['company_id'])
                ->update(['is_default' => false]);
        }

        OrderStatus::create($validated);

        return redirect()->route('admin.settings.order-statuses.index')
            ->with('success', 'Status criado com sucesso!');
    }

    public function edit(OrderStatus $orderStatus): View
    {
        return view('admin.settings.order-statuses.edit', compact('orderStatus'));
    }

    public function update(Request $request, OrderStatus $orderStatus): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'color' => 'required|string|size:7|regex:/^#[0-9A-F]{6}$/i',
            'description' => 'nullable|string',
            'is_default' => 'boolean',
            'send_email' => 'boolean',
            'email_template' => 'nullable|string',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $validated['slug'] = Str::slug($validated['name']);

        // If is_default is true, set all other statuses to false
        if ($validated['is_default'] ?? false) {
            OrderStatus::where('company_id', $orderStatus->company_id)
                ->where('id', '!=', $orderStatus->id)
                ->update(['is_default' => false]);
        }

        $orderStatus->update($validated);

        return redirect()->route('admin.settings.order-statuses.index')
            ->with('success', 'Status atualizado com sucesso!');
    }

    public function destroy(OrderStatus $orderStatus): RedirectResponse
    {
        $orderStatus->delete();

        return redirect()->route('admin.settings.order-statuses.index')
            ->with('success', 'Status removido com sucesso!');
    }
}
