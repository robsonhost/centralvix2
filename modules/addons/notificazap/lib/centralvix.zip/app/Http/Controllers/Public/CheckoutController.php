<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductGroup;
use App\Services\AddonService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CheckoutController extends Controller
{
    /**
     * Página de checkout direto por produto (estilo WHMCS)
     * URL: /checkout/{product_slug}
     */
    public function show(string $slug): View
    {
        // Buscar produto pelo slug
        $product = Product::where('slug', $slug)
            ->where('status', 'active')
            ->with(['group', 'features'])
            ->firstOrFail();
        
        $companyId = $product->company_id;
        
        // Buscar todos os grupos de produtos da mesma empresa
        $groups = ProductGroup::where('company_id', $companyId)
            ->active()
            ->with(['products' => function ($query) {
                $query->where('status', 'active')->orderBy('order');
            }])
            ->orderBy('order')
            ->get();
        
        // Produtos relacionados (mesmo grupo)
        $relatedProducts = Product::where('company_id', $companyId)
            ->where('group_id', $product->group_id)
            ->where('id', '!=', $product->id)
            ->where('status', 'active')
            ->orderBy('order')
            ->limit(3)
            ->get();

        // Upsell: add-ons recomendados (módulo "Marketplace de Add-ons").
        $addonService = app(AddonService::class);
        $addons = $addonService->showOnCheckout($companyId)
            ? $addonService->featured($companyId, $product->id)
            : collect();

        return view('public.checkout.product', compact('product', 'groups', 'relatedProducts', 'addons'));
    }
    
    /**
     * Processar checkout (adicionar ao carrinho/pedido)
     */
    public function process(Request $request, string $slug)
    {
        $product = Product::where('slug', $slug)
            ->where('status', 'active')
            ->firstOrFail();
        
        $validated = $request->validate([
            'billing_cycle' => 'required|in:monthly,quarterly,semiannually,annually,biennially,triennially',
            'quantity' => 'integer|min:1|max:100',
            'domain' => 'nullable|string',
            'configoptions' => 'array',
        ]);

        $domainRules = \App\Support\HostingRules::domainValidationRules($product);
        $request->validate(['domain' => $domainRules]);
        $validated['domain'] = \App\Support\HostingRules::normalizeDomain($validated['domain'] ?? null);
        
        // Calcular preço baseado no ciclo
        $price = match($validated['billing_cycle']) {
            'monthly' => $product->price_monthly,
            'quarterly' => $product->price_quarterly,
            'semiannually' => $product->price_semiannually,
            'annually' => $product->price_annually,
            'biennially' => $product->price_biennially,
            'triennially' => $product->price_triennially,
            default => $product->price_monthly,
        };
        
        // Aqui você pode adicionar ao carrinho ou criar pedido direto
        // Por enquanto, vou redirecionar para a página de novo pedido do cliente
        
        session()->put('checkout_product', [
            'product_id' => $product->id,
            'billing_cycle' => $validated['billing_cycle'],
            'price' => $price,
            'quantity' => $validated['quantity'] ?? 1,
            'domain' => $validated['domain'] ?? null,
        ]);
        
        // Se usuário não estiver logado, redirecionar para registro
        if (!auth()->guard('client')->check()) {
            return redirect()->route('register')
                ->with('info', 'Faça login ou crie uma conta para continuar com a compra.');
        }
        
        // Se estiver logado, redirecionar para confirmação do pedido
        return redirect()->route('client.orders.create')
            ->with('success', 'Produto adicionado! Finalize seu pedido.');
    }
}
