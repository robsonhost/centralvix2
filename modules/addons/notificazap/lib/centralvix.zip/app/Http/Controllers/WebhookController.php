<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WebhookController extends Controller
{
    public function __construct(private PaymentService $paymentService) {}

    /**
     * Webhook do Mercado Pago
     */
    public function mercadoPago(Request $request): JsonResponse
    {
        \Log::info('Webhook Mercado Pago recebido', $request->all());

        try {
            $type = $request->input('type');
            $dataId = $request->input('data.id');

            if ($type !== 'payment') {
                return response()->json(['status' => 'ignored'], 200);
            }

            // Busca informações do pagamento na API do Mercado Pago
            $externalReference = $request->input('data.external_reference');
            
            if (!$externalReference) {
                \Log::warning('Webhook Mercado Pago sem external_reference');
                return response()->json(['status' => 'error', 'message' => 'Missing external_reference'], 400);
            }

            // Busca transação
            $transaction = Transaction::where('transaction_id', $externalReference)->first();

            if (!$transaction) {
                \Log::warning('Transação não encontrada: ' . $externalReference);
                return response()->json(['status' => 'error', 'message' => 'Transaction not found'], 404);
            }

            // Busca detalhes do pagamento na API
            $gateway = \App\Models\PaymentGateway::where('company_id', $transaction->company_id)
                ->where('module', 'mercadopago')
                ->first();

            if (!$gateway) {
                \Log::error('Gateway Mercado Pago não encontrado');
                return response()->json(['status' => 'error'], 500);
            }

            $accessToken = $gateway->getSetting('access_token');
            $response = \Http::withToken($accessToken)
                ->timeout(30)
                ->get("https://api.mercadopago.com/v1/payments/{$dataId}");

            if (!$response->successful()) {
                \Log::error('Erro ao buscar pagamento no Mercado Pago', [
                    'response' => $response->body()
                ]);
                return response()->json(['status' => 'error'], 500);
            }

            $payment = $response->json();
            $status = $payment['status'] ?? null;

            // Atualiza transação de acordo com o status
            if ($status === 'approved') {
                $this->paymentService->confirmPayment($transaction, [
                    'payment_id' => $dataId,
                    'status' => $status,
                    'payment_data' => $payment,
                ]);
                
                \Log::info('Pagamento confirmado via Mercado Pago', [
                    'transaction_id' => $transaction->id,
                    'payment_id' => $dataId,
                ]);
            } elseif ($status === 'rejected') {
                $transaction->update(['status' => 'failed']);
                
                \Log::info('Pagamento rejeitado via Mercado Pago', [
                    'transaction_id' => $transaction->id,
                    'payment_id' => $dataId,
                ]);
            } elseif ($status === 'pending') {
                $transaction->update(['status' => 'processing']);
            }

            return response()->json(['status' => 'success'], 200);

        } catch (\Exception $e) {
            \Log::error('Erro no webhook Mercado Pago', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Webhook do PagSeguro
     */
    public function pagSeguro(Request $request): JsonResponse
    {
        \Log::info('Webhook PagSeguro recebido', $request->all());

        try {
            $notificationCode = $request->input('notificationCode');
            $notificationType = $request->input('notificationType');

            if (!$notificationCode || $notificationType !== 'transaction') {
                return response()->json(['status' => 'ignored'], 200);
            }

            // Busca informações da transação na API do PagSeguro
            // Implementar conforme documentação: https://dev.pagseguro.uol.com.br/

            return response()->json(['status' => 'success'], 200);

        } catch (\Exception $e) {
            \Log::error('Erro no webhook PagSeguro', [
                'error' => $e->getMessage(),
            ]);

            return response()->json(['status' => 'error'], 500);
        }
    }

    /**
     * Webhook do Stripe
     */
    public function stripe(Request $request): JsonResponse
    {
        \Log::info('Webhook Stripe recebido', $request->all());

        try {
            $event = $request->all();
            $type = $event['type'] ?? null;

            if ($type === 'checkout.session.completed') {
                // Pagamento confirmado
                $session = $event['data']['object'] ?? [];
                $clientReferenceId = $session['client_reference_id'] ?? null;

                if ($clientReferenceId) {
                    $transaction = Transaction::where('transaction_id', $clientReferenceId)->first();
                    
                    if ($transaction) {
                        $this->paymentService->confirmPayment($transaction, [
                            'stripe_session_id' => $session['id'] ?? null,
                            'stripe_payment_intent' => $session['payment_intent'] ?? null,
                        ]);
                    }
                }
            }

            return response()->json(['status' => 'success'], 200);

        } catch (\Exception $e) {
            \Log::error('Erro no webhook Stripe', [
                'error' => $e->getMessage(),
            ]);

            return response()->json(['status' => 'error'], 500);
        }
    }

    /**
     * Webhook genérico (PIX, Boleto via outros provedores)
     */
    public function generic(Request $request): JsonResponse
    {
        \Log::info('Webhook genérico recebido', $request->all());

        return response()->json(['status' => 'received'], 200);
    }
}
