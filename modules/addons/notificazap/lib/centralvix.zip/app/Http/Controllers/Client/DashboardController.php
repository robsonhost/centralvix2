<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $client = $user->resolveClient();

        // Admin logado sem vinculação a um Client (e sem impersonar) —
        // volta pro dashboard admin em vez de estourar 404.
        if (!$client) {
            if ($user->isAdmin() && !session()->has('impersonate_from')) {
                return redirect()->route('admin.dashboard')
                    ->with('info', 'Você está logado como administrador. Use "Ver como cliente" para acessar o painel do cliente.');
            }
            abort(404, 'Nenhum perfil de cliente vinculado à sua conta.');
        }

        $consultasAvailable = consultas_available($client->company_id);

        // Update profile completion
        $user->updateProfileCompletion();

        // Estatísticas otimizadas
        $stats = [
            'services' => $client->services()->count(),
            'active_services' => $client->services()->where('status', 'active')->count(),
            'monthly_recurring' => (float) $client->services()->where('status', 'active')->sum('amount'),
            'pending_invoices' => $client->invoices()->whereIn('status', ['unpaid', 'overdue'])->count(),
            'unpaid_invoices' => $client->invoices()->whereIn('status', ['unpaid', 'overdue'])->count(),
            'unpaid_total' => $client->invoices()->whereIn('status', ['unpaid', 'overdue'])->sum('total'),
            'open_tickets' => $client->tickets()->whereNotIn('status', ['closed'])->count(),
            'domains' => $client->domains()->where('status', 'active')->count(),
            'active_domains' => $client->domains()->where('status', 'active')->count(),
            'total_spent' => $client->invoices()->where('status', 'paid')->sum('total'),
        ];

        // Dados recentes - SUPER otimizados com toArray() para evitar overhead de Collection
        $invoices = $client->invoices()
            ->select('id', 'invoice_number', 'total', 'date_due', 'status')
            ->whereIn('status', ['unpaid', 'overdue'])
            ->latest('date_created')
            ->limit(3)
            ->get()
            ->map(function($invoice) {
                return [
                    'id' => $invoice->id,
                    'invoice_number' => $invoice->invoice_number,
                    'total' => $invoice->total,
                    'date_due' => $invoice->date_due,
                    'status' => $invoice->status,
                    'status_label' => $invoice->status_label,
                ];
            });

        $services = $client->services()
            ->select('services.id', 'services.domain', 'services.status', 'services.next_due_date', 'products.name as product_name')
            ->join('products', 'services.product_id', '=', 'products.id')
            ->where('services.status', 'active')
            ->latest('services.created_at')
            ->limit(3)
            ->get()
            ->map(function($service) {
                return [
                    'id' => $service->id,
                    'domain' => $service->domain,
                    'status' => $service->status,
                    'next_due_date' => $service->next_due_date,
                    'product_name' => $service->product_name,
                ];
            });

        // Profile completion data
        $profileCompletion = $user->profile_completion_percentage;
        $missingFields = $user->getMissingProfileFields();
        $showProfileAlert = $profileCompletion < 100;

        $urgentInvoice = null;
        $urgentModel = $client->invoices()
            ->whereIn('status', ['unpaid', 'overdue'])
            ->orderByRaw("CASE WHEN status = 'overdue' THEN 0 WHEN status = 'unpaid' THEN 1 ELSE 2 END")
            ->orderBy('date_due')
            ->first();

        if ($urgentModel) {
            $latestTx = $urgentModel->transactions()->latest()->first();
            $gr = is_array($latestTx?->gateway_response) ? $latestTx->gateway_response : [];
            $urgentInvoice = [
                'id'             => $urgentModel->id,
                'invoice_number' => $urgentModel->invoice_number,
                'total'          => (float) $urgentModel->total,
                'date_due'       => $urgentModel->date_due,
                'status'         => $urgentModel->status,
                'status_label'   => $urgentModel->status_label,
                'boleto_url'     => $gr['bank_slip_url'] ?? null,
                'digitable_line' => $gr['digitable_line'] ?? null,
                'pdf_url'        => route('client.invoices.pdf', $urgentModel),
                'pay_url'        => route('client.invoices.show', $urgentModel),
            ];
        }

        return view('client.dashboard', compact(
            'client',
            'stats', 
            'invoices',
            'services',
            'profileCompletion',
            'missingFields',
            'showProfileAlert',
            'consultasAvailable',
            'urgentInvoice',
        ));
    }
}
