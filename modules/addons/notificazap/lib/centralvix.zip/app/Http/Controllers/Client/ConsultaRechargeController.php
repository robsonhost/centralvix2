<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\RechargeOrder;
use App\Models\RechargePackage;
use App\Services\RechargeService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ConsultaRechargeController extends Controller
{
    public function __construct(private RechargeService $service) {}

    private function ensureModule(): void
    {
        $client = auth()->user()->resolveClient();
        abort_unless($client && consultas_available($client->company_id), 404);
    }

    /**
     * Tela "Recarga" — exibe pacotes de saldo disponíveis.
     */
    public function index(): View
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $packages = RechargePackage::active()
            ->where(function ($q) use ($client) {
                $q->whereNull('company_id')->orWhere('company_id', $client->company_id);
            })
            ->orderBy('sort_order')
            ->orderBy('amount')
            ->get();

        $recentOrders = RechargeOrder::where('client_id', $client->id)
            ->latest()
            ->limit(5)
            ->get();

        return view('client.consultas.recharge', compact('client', 'packages', 'recentOrders'));
    }

    /**
     * Cria pedido de recarga e redireciona para o checkout da fatura.
     */
    public function checkout(Request $request): RedirectResponse
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $data = $request->validate([
            'package_id' => ['required', 'exists:recharge_packages,id'],
        ]);

        $package = RechargePackage::findOrFail($data['package_id']);

        $result = $this->service->createOrder($client, $package);

        if (! $result['success']) {
            return back()->with('error', $result['message']);
        }

        return redirect()
            ->route('client.payment.checkout', $result['invoice'])
            ->with('success', 'Pedido de recarga criado. Escolha a forma de pagamento.');
    }

    /**
     * Histórico de pagamentos / recargas do cliente.
     */
    public function payments(): View
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $orders = RechargeOrder::where('client_id', $client->id)
            ->with(['package', 'invoice'])
            ->latest()
            ->paginate(20);

        return view('client.consultas.payments', compact('orders', 'client'));
    }
}
