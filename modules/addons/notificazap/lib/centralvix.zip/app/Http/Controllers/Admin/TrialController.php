<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class TrialController extends Controller
{
    public function __construct(
        protected ModuleService $modules,
        protected ModuleSettingsService $settings,
    ) {}

    public function index(Request $request): View
    {
        $companyId = (int) auth()->user()->company_id;

        abort_unless($this->modules->isEnabled($companyId, 'service_trial'), 404, 'Módulo de Período de Teste desativado.');

        $cfg = $this->settings->all($companyId, 'service_trial');

        $filter = (string) $request->query('filter', 'active');

        $query = Service::where('company_id', $companyId)
            ->where('is_trial', true)
            ->with(['client:id,name,email', 'product:id,name'])
            ->orderByDesc('trial_ends_at');

        match ($filter) {
            'expired'   => $query->whereNotNull('trial_ends_at')->where('trial_ends_at', '<', now())->whereNull('trial_converted_at'),
            'converted' => $query->whereNotNull('trial_converted_at'),
            'all'       => null,
            default     => $query->whereNull('trial_converted_at')->where(function ($q) {
                $q->whereNull('trial_ends_at')->orWhere('trial_ends_at', '>=', now());
            }),
        };

        $services = $query->paginate(20)->withQueryString();

        $stats = [
            'active' => Service::where('company_id', $companyId)->where('is_trial', true)
                ->whereNull('trial_converted_at')
                ->where(fn ($q) => $q->whereNull('trial_ends_at')->orWhere('trial_ends_at', '>=', now()))
                ->count(),
            'expired' => Service::where('company_id', $companyId)->where('is_trial', true)
                ->whereNull('trial_converted_at')
                ->whereNotNull('trial_ends_at')->where('trial_ends_at', '<', now())
                ->count(),
            'converted' => Service::where('company_id', $companyId)->where('is_trial', true)
                ->whereNotNull('trial_converted_at')->count(),
            'total' => Service::where('company_id', $companyId)->where('is_trial', true)->count(),
        ];

        return view('admin.trials.index', compact('services', 'stats', 'cfg', 'filter'));
    }

    public function start(Request $request, Service $service): RedirectResponse
    {
        $this->authorizeService($service);

        $cfg  = $this->settings->all($service->company_id, 'service_trial');
        $days = (int) $request->input('trial_days', $cfg['trial_days'] ?? 7);
        $days = max(1, min(90, $days));

        $service->update([
            'is_trial' => true,
            'trial_started_at' => now(),
            'trial_ends_at'    => now()->addDays($days),
            'trial_notified_at'=> null,
            'trial_converted_at' => null,
            'status' => $service->status === 'pending' ? 'active' : $service->status,
        ]);

        return back()->with('success', "Trial iniciado: {$days} dias para o serviço #{$service->id}.");
    }

    public function extend(Request $request, Service $service): RedirectResponse
    {
        $this->authorizeService($service);
        abort_unless($service->is_trial, 400, 'Este serviço não está em trial.');

        $extra = max(1, min(60, (int) $request->input('days', 3)));

        $base = $service->trial_ends_at && $service->trial_ends_at->isFuture()
            ? $service->trial_ends_at
            : now();

        $service->update([
            'trial_ends_at'     => $base->copy()->addDays($extra),
            'trial_notified_at' => null,
        ]);

        return back()->with('success', "Trial estendido em {$extra} dia(s).");
    }

    public function convert(Service $service): RedirectResponse
    {
        $this->authorizeService($service);
        abort_unless($service->is_trial, 400, 'Este serviço não está em trial.');

        $service->update([
            'trial_converted_at' => now(),
            'status' => 'active',
            'next_due_date' => now()->addMonth()->toDateString(),
        ]);

        return back()->with('success', 'Trial convertido em assinatura ativa.');
    }

    public function cancel(Service $service): RedirectResponse
    {
        $this->authorizeService($service);
        abort_unless($service->is_trial, 400, 'Este serviço não está em trial.');

        $service->update([
            'is_trial' => false,
            'status'   => 'cancelled',
        ]);

        return back()->with('success', 'Trial cancelado.');
    }

    protected function authorizeService(Service $service): void
    {
        abort_unless($service->company_id === (int) auth()->user()->company_id, 403);
    }
}
