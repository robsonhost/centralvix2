<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Affiliate;
use App\Models\Commission;
use App\Models\Referral;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AffiliateController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $client = $user->client;

        Affiliate::firstOrCreate(
            ['client_id' => $client->id, 'company_id' => $client->company_id],
            [
                'status'           => 'active',
                'commission_type'  => 'percentage',
                'commission_value' => 10,
                'url'              => config('app.url') . '/register?ref=',
            ]
        );

        // Configurações do programa de afiliados (definidas pelo admin)
        $settings = null;
        if (Schema::hasTable('affiliate_settings')) {
            $settings = DB::table('affiliate_settings')
                ->where('company_id', $client->company_id)
                ->first();
        }

        $commissionPercentage = $settings->commission_percentage ?? 10;
        $minWithdrawal = $settings->min_withdrawal ?? 50;

        // Banners cadastrados pelo admin
        $banners = collect();
        if (Schema::hasTable('affiliate_banners')) {
            $banners = DB::table('affiliate_banners')
                ->where('company_id', $client->company_id)
                ->where('is_active', true)
                ->orderByDesc('created_at')
                ->get();
        }

        // Estatísticas
        $stats = [
            'total_referrals' => Referral::where('referrer_id', $client->id)->count(),
            'total_commission' => Commission::where('client_id', $client->id)
                ->where('status', 'paid')
                ->sum('amount'),
            'pending_commission' => Commission::where('client_id', $client->id)
                ->where('status', 'pending')
                ->sum('amount'),
            'conversion_rate' => $this->calculateConversionRate($client),
        ];

        // Link de referência
        $referralLink = config('app.url') . '/register?ref=' . $client->uuid;

        // Histórico de comissões
        $commissions = Commission::where('client_id', $client->id)
            ->with(['referral.client', 'service.product'])
            ->latest()
            ->paginate(20);

        return view('client.affiliate.index-NOVO', compact(
            'stats',
            'referralLink',
            'commissions',
            'banners',
            'commissionPercentage',
            'minWithdrawal'
        ));
    }
    
    private function calculateConversionRate($client): float
    {
        $totalReferrals = Referral::where('referrer_id', $client->id)->count();
        
        if ($totalReferrals === 0) {
            return 0;
        }
        
        $convertedReferrals = Referral::where('referrer_id', $client->id)
            ->whereHas('services')
            ->count();
        
        return round(($convertedReferrals / $totalReferrals) * 100, 1);
    }
}
