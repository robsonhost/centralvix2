<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class ProfileCompletionController extends Controller
{
    /**
     * Show the profile completion page
     */
    public function show(): View
    {
        $user = Auth::user();
        $user->updateProfileCompletion();
        
        $missingFields = $user->getMissingProfileFields();
        $completion = $user->profile_completion_percentage;

        return view('client.profile.complete', compact('user', 'missingFields', 'completion'));
    }

    /**
     * Update the profile with additional information
     */
    public function update(Request $request): RedirectResponse
    {
        $user = Auth::user();

        $validated = $request->validate([
            'phone' => 'nullable|string|max:20',
            'whatsapp' => 'nullable|string|max:20',
            'cpf_cnpj' => 'nullable|string|max:18',
            'birth_date' => 'nullable|date',
            'zip' => 'nullable|string|max:10',
            'address' => 'nullable|string|max:255',
            'address_number' => 'nullable|string|max:20',
            'address_complement' => 'nullable|string|max:100',
            'neighborhood' => 'nullable|string|max:100',
            'city' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:2',
            'country' => 'nullable|string|max:2',
        ]);

        $user->update($validated);
        $user->updateProfileCompletion();

        // Update client profile as well
        if ($user->client) {
            $user->client->update([
                'phone' => $validated['phone'] ?? null,
                'whatsapp' => $validated['whatsapp'] ?? null,
                'cpf_cnpj' => $validated['cpf_cnpj'] ?? null,
                'address' => $validated['address'] ?? null,
                'address2' => $validated['address_number'] ?? null,
                'city' => $validated['city'] ?? null,
                'state' => $validated['state'] ?? null,
                'postcode' => $validated['zip'] ?? null,
                'country' => $validated['country'] ?? 'BR',
            ]);
        }

        if ($user->isProfileComplete()) {
            return redirect()->route('client.dashboard')
                ->with('success', 'Perfil completado com sucesso! Agora você tem acesso a todos os recursos.');
        }

        return redirect()->route('client.profile.complete')
            ->with('success', 'Informações atualizadas! Continue completando seu perfil.');
    }

    /**
     * Skip profile completion for now
     */
    public function skip(): RedirectResponse
    {
        return redirect()->route('client.dashboard')
            ->with('info', 'Você pode completar seu perfil a qualquer momento nas configurações.');
    }
}
