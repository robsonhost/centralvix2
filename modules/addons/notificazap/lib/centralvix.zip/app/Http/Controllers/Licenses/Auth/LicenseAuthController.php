<?php

namespace App\Http\Controllers\Licenses\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class LicenseAuthController extends Controller
{
    /**
     * Show login form
     */
    public function showLogin()
    {
        // Se já está autenticado, redireciona
        if (Auth::guard('licenses')->check()) {
            return redirect()->route('licenses.dashboard');
        }

        return view('licenses.auth.login');
    }

    /**
     * Process login
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|min:6',
        ], [
            'email.required' => 'O email é obrigatório',
            'email.email' => 'Email inválido',
            'password.required' => 'A senha é obrigatória',
            'password.min' => 'A senha deve ter no mínimo 6 caracteres',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // Buscar usuário
        $user = User::where('email', $request->email)
                    ->where('role', 'admin')
                    ->where('is_active', true)
                    ->first();

        // Verificar senha
        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Email ou senha incorretos'
            ], 401);
        }

        // Fazer login
        Auth::guard('licenses')->login($user, $request->filled('remember'));

        // Log de atividade
        activity()
            ->causedBy($user)
            ->log('Login no painel de licenças');

        return response()->json([
            'success' => true,
            'message' => 'Login realizado com sucesso',
            'redirect' => route('licenses.dashboard')
        ]);
    }

    /**
     * Logout
     */
    public function logout(Request $request)
    {
        $user = Auth::guard('licenses')->user();

        if ($user) {
            activity()
                ->causedBy($user)
                ->log('Logout do painel de licenças');
        }

        Auth::guard('licenses')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('licenses.login')
            ->with('success', 'Logout realizado com sucesso');
    }

    /**
     * Show forgot password form
     */
    public function showForgotPassword()
    {
        return view('licenses.auth.forgot-password');
    }

    /**
     * Send password reset link
     */
    public function sendResetLink(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
        ], [
            'email.required' => 'O email é obrigatório',
            'email.email' => 'Email inválido',
            'email.exists' => 'Email não encontrado',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // Aqui você implementaria o envio do email
        // Password::sendResetLink($request->only('email'));

        return response()->json([
            'success' => true,
            'message' => 'Link de recuperação enviado para seu email'
        ]);
    }
}
