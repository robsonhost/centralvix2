<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\License;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class LicenseApiController extends Controller
{
    /**
     * Valida uma licença
     * 
     * POST /api/v1/licenses/validate
     * {
     *   "license_key": "CVIX-ABCD-1234-EFGH-5678",
     *   "domain": "exemplo.com.br",
     *   "ip": "192.168.1.1"
     * }
     */
    public function validateLicense(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'license_key' => 'required|string',
            'domain' => 'required|string',
            'ip' => 'nullable|ip',
        ]);

        $license = License::where('license_key', $validated['license_key'])->first();

        if (!$license) {
            return response()->json([
                'valid' => false,
                'message' => 'Licença não encontrada',
            ], 404);
        }

        $ip = $validated['ip'] ?? $request->ip();
        $result = $license->validate($validated['domain'], $ip);

        return response()->json($result);
    }

    /**
     * Consulta informações de uma licença
     * 
     * GET /api/v1/licenses/{license_key}
     */
    public function show(string $licenseKey): JsonResponse
    {
        $license = License::where('license_key', $licenseKey)->first();

        if (!$license) {
            return response()->json([
                'error' => 'Licença não encontrada',
            ], 404);
        }

        return response()->json([
            'license_key' => $license->license_key,
            'product_name' => $license->product_name,
            'status' => $license->status,
            'issued_at' => $license->issued_at->toDateTimeString(),
            'expires_at' => $license->expires_at?->toDateTimeString(),
            'days_remaining' => $license->daysUntilExpiry(),
            'is_active' => $license->isActive(),
            'is_expired' => $license->isExpired(),
        ]);
    }

    /**
     * Verifica status rápido da licença
     * 
     * GET /api/v1/licenses/{license_key}/status
     */
    public function status(string $licenseKey): JsonResponse
    {
        $license = License::where('license_key', $licenseKey)->first();

        if (!$license) {
            return response()->json(['status' => 'not_found'], 404);
        }

        return response()->json([
            'status' => $license->status,
            'is_active' => $license->isActive(),
            'is_expired' => $license->isExpired(),
        ]);
    }
}
