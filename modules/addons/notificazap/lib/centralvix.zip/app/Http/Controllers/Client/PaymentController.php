<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\PaymentGateway;
use App\Models\Transaction;
use App\Services\PaymentService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PaymentController extends Controller
{
    public function __construct(private PaymentService $paymentService) {}

    /**
     * Exibe a página de checkout
     */
    public function checkout(Invoice $invoice, Request $request): View
    {
        if (!auth()->user()->canAccessClientRecord($invoice->client)) {
            abort(403, 'Você não tem permissão para pagar esta fatura.');
        }

        // Verifica se a fatura pode ser paga
        if ($invoice->isPaid()) {
            return redirect()->route('client.invoices.show', $invoice)
                ->with('info', 'Esta fatura já foi paga.');
        }

        if ($invoice->status === 'cancelled') {
            return redirect()->route('client.invoices.show', $invoice)
                ->with('error', 'Esta fatura foi cancelada.');
        }

        // Busca gateways disponíveis
        $gateways = PaymentGateway::where('company_id', $invoice->client?->company_id ?? auth()->user()->company_id)
            ->where('status', 'active')
            ->orderBy('order')
            ->get();

        // Gateway selecionado (se vier da query string)
        $selectedGateway = null;
        if ($request->has('gateway')) {
            $selectedGateway = $gateways->firstWhere('id', $request->gateway);
        }

        $invoice->load(['items', 'client']);

        $paymentOptions = [];
        foreach ($gateways as $gw) {
            foreach ($gw->checkoutMethods() as $method => $meta) {
                $paymentOptions[] = array_merge($meta, [
                    'gateway_id'   => $gw->id,
                    'method'       => $method,
                    'gateway_name' => $gw->display_name ?: $gw->name,
                    'test_mode'    => $gw->test_mode,
                    'module'       => $gw->module,
                ]);
            }
        }

        $clientBalance = (float) ($invoice->client?->credit_balance ?? 0);

        return view('client.payment.checkout', compact(
            'invoice', 'gateways', 'selectedGateway', 'paymentOptions', 'clientBalance'
        ));
    }

    /**
     * Processa o pagamento
     */
    public function process(Invoice $invoice, Request $request): RedirectResponse
    {
        if (!auth()->user()->canAccessClientRecord($invoice->client)) {
            abort(403, 'Você não tem permissão para pagar esta fatura.');
        }

        $validated = $request->validate([
            'gateway_id'     => 'required|exists:payment_gateways,id',
            'payment_method' => 'nullable|string|in:pix,boleto,credit,default',
        ]);

        $gateway = PaymentGateway::findOrFail($validated['gateway_id']);
        $method  = $validated['payment_method'] ?? null;

        if (!$method || $method === 'default') {
            $methods = array_keys($gateway->checkoutMethods());
            $method  = $methods[0] ?? 'pix';
        }

        // Verifica se o gateway está ativo
        if (!$gateway->isActive()) {
            return back()->with('error', 'Este método de pagamento não está disponível no momento.');
        }

        try {
            $result = $this->paymentService->initiatePayment($invoice, $gateway, [
                'payment_method' => $method,
                'metadata' => [
                    'ip' => $request->ip(),
                    'user_agent' => $request->userAgent(),
                ],
            ]);

            // Saldo em conta — redireciona direto para fatura paga
            if ($method === 'credit' || strtolower($gateway->module) === 'credit') {
                return redirect()->route('client.invoices.show', $invoice)
                    ->with('success', 'Pagamento realizado com saldo da conta!');
            }

            // Se houver URL de redirecionamento (Mercado Pago, etc)
            if (isset($result['redirect_url'])) {
                return redirect()->away($result['redirect_url']);
            }

            // PIX, Boleto ou gateways com QR — exibe tela de pagamento
            $showGateways = ['pix', 'boleto', 'paghiper', 'c6bank', 'c6_bank', 'asaas', 'efi'];
            if (in_array(strtolower($gateway->module), $showGateways, true)
                || !empty($result['pix_code'])
                || !empty($result['qr_code'])
                || !empty($result['bank_slip_url'])
                || !empty($result['digitable_line'])) {
                return redirect()->route('client.payment.show', [
                    'transaction' => $result['transaction']->id,
                ]);
            }

            return back()->with('success', 'Pagamento iniciado com sucesso!');

        } catch (\Exception $e) {
            \Log::error('Erro ao processar pagamento', [
                'error' => $e->getMessage(),
                'invoice' => $invoice->id,
                'gateway' => $gateway->id,
            ]);

            return back()->with('error', 'Erro ao processar pagamento: ' . $e->getMessage());
        }
    }

    /**
     * Exibe detalhes de uma transação (PIX, Boleto, etc)
     */
    public function show(Transaction $transaction): View
    {
        if (!auth()->user()->canAccessClientRecord($transaction->client)) {
            abort(403);
        }

        $transaction->load(['invoice', 'invoice.items']);

        return view('client.payment.show', compact('transaction'));
    }

    /**
     * Retorna o status atual da transação em JSON (para atualização automática
     * na tela de pagamento, sem recarregar a página inteira).
     */
    public function status(Transaction $transaction): \Illuminate\Http\JsonResponse
    {
        if (!auth()->user()->canAccessClientRecord($transaction->client)) {
            abort(403);
        }

        $paymentService = app(PaymentService::class);
        if ($transaction->invoice) {
            $paymentService->syncInvoiceStatus($transaction->invoice);
            $transaction->refresh();
        } elseif ($transaction->gateway_transaction_id) {
            if ($paymentService->syncTransactionWithGateway($transaction)) {
                $paymentService->confirmPayment($transaction);
                $transaction->refresh();
            }
        }

        $status = (string) $transaction->status;
        $paid   = $status === 'completed' || $status === 'paid';

        return response()->json([
            'status'   => $paid ? 'paid' : $status,
            'label'    => $transaction->status_label ?? ucfirst($status),
            'paid'     => $paid,
            'finished' => $paid || in_array($status, ['failed', 'refunded', 'cancelled'], true),
        ]);
    }

    /**
     * Página de sucesso (retorno do gateway)
     */
    public function success(Transaction $transaction, Request $request): RedirectResponse
    {
        if (!auth()->user()->canAccessClientRecord($transaction->client)) {
            abort(403);
        }

        // Atualiza status da transação se ainda estiver pendente
        if ($transaction->status === 'pending') {
            $transaction->update(['status' => 'processing']);
        }

        return redirect()->route('client.invoices.show', $transaction->invoice_id)
            ->with('success', 'Pagamento processado com sucesso! Aguarde a confirmação.');
    }

    /**
     * Página de falha (retorno do gateway)
     */
    public function failure(Transaction $transaction, Request $request): RedirectResponse
    {
        if (!auth()->user()->canAccessClientRecord($transaction->client)) {
            abort(403);
        }

        $transaction->update(['status' => 'failed']);

        return redirect()->route('client.invoices.show', $transaction->invoice_id)
            ->with('error', 'Pagamento não foi concluído. Tente novamente.');
    }

    /**
     * Página de pendente (retorno do gateway)
     */
    public function pending(Transaction $transaction, Request $request): RedirectResponse
    {
        if (!auth()->user()->canAccessClientRecord($transaction->client)) {
            abort(403);
        }

        return redirect()->route('client.invoices.show', $transaction->invoice_id)
            ->with('warning', 'Pagamento pendente. Você receberá uma notificação quando for confirmado.');
    }
}
