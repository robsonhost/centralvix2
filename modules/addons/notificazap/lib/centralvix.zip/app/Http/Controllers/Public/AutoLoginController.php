<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\AutoLoginToken;
use App\Services\AutoLoginService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AutoLoginController extends Controller
{
    public function __construct(private AutoLoginService $autoLogin) {}

    public function handle(Request $request, string $token)
    {
        $record = AutoLoginToken::where('token', $token)->first();

        if ($record) {
            $this->autoLogin->recordClick($record, $request);
        }

        $resolved = $this->autoLogin->resolve($token);

        if (!$resolved) {
            $this->autoLogin->logAccess($record, $request, false, 'expired_or_used');
            return view('public.autologin.expired');
        }

        $client = $resolved->client;
        if (!$client || !$client->user) {
            $this->autoLogin->logAccess($resolved, $request, false, 'no_user');
            return view('public.autologin.expired');
        }

        if (!$this->autoLogin->isEnabled($client->company_id)) {
            $this->autoLogin->logAccess($resolved, $request, false, 'module_disabled');
            return view('public.autologin.expired');
        }

        if (!$this->autoLogin->clientCanAutoLogin($client)) {
            $this->autoLogin->logAccess($resolved, $request, false, 'no_active_service');
            return view('public.autologin.expired');
        }

        $user = $client->user;
        Auth::login($user);
        $request->session()->regenerate();

        $this->autoLogin->logAccess($resolved, $request, true);

        $redirect = $resolved->redirect_to ?? route('client.dashboard');

        if ($this->autoLogin->config($client->company_id)['open_new_tab'] ?? false) {
            return view('public.autologin.redirect', compact('redirect'));
        }

        return redirect($redirect);
    }
}
