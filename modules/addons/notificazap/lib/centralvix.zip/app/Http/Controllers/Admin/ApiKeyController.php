<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiKey;
use App\Services\ModuleService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ApiKeyController extends Controller
{
    public function __construct(protected ModuleService $modules) {}

    public function index(Request $request): View
    {
        $companyId = (int) auth()->user()->company_id;

        abort_unless($this->modules->isEnabled($companyId, 'api_access'), 404, 'Módulo de Acesso à API desativado.');

        $query = ApiKey::where('company_id', $companyId)
            ->with(['client:id,firstname,lastname,email,company_name,type', 'user:id,name,email'])
            ->latest();

        if ($status = $request->query('status')) {
            $query->where('status', $status);
        }

        if ($search = trim((string) $request->query('q'))) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhereHas('client', fn ($q) => $q
                      ->where('firstname', 'like', "%{$search}%")
                      ->orWhere('lastname', 'like', "%{$search}%")
                      ->orWhere('email', 'like', "%{$search}%")
                      ->orWhere('company_name', 'like', "%{$search}%"));
            });
        }

        $apiKeys = $query->paginate(25)->withQueryString();

        $stats = [
            'total'   => ApiKey::where('company_id', $companyId)->count(),
            'active'  => ApiKey::where('company_id', $companyId)->where('status', 'active')->count(),
            'revoked' => ApiKey::where('company_id', $companyId)->where('status', 'revoked')->count(),
            'inactive'=> ApiKey::where('company_id', $companyId)->where('status', 'inactive')->count(),
        ];

        return view('admin.api-keys.index', compact('apiKeys', 'stats'));
    }

    public function revoke(ApiKey $apiKey): RedirectResponse
    {
        abort_unless($apiKey->company_id === (int) auth()->user()->company_id, 403);

        $apiKey->update(['status' => 'revoked']);

        return back()->with('success', "Chave \"{$apiKey->name}\" revogada com sucesso.");
    }

    public function destroy(ApiKey $apiKey): RedirectResponse
    {
        abort_unless($apiKey->company_id === (int) auth()->user()->company_id, 403);

        $name = $apiKey->name;
        $apiKey->delete();

        return back()->with('success', "Chave \"{$name}\" removida.");
    }
}
