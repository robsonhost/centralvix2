<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\Brazilian\CepService;
use App\Services\Brazilian\CpfCnpjValidator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BrazilianController extends Controller
{
    public function __construct(
        private CepService $cepService,
        private CpfCnpjValidator $cpfCnpjValidator
    ) {}
    
    /**
     * Buscar CEP
     * GET /api/brazilian/cep/{cep}
     */
    public function buscarCep(string $cep): JsonResponse
    {
        $resultado = $this->cepService->buscar($cep);
        
        if (!$resultado) {
            return response()->json([
                'success' => false,
                'message' => 'CEP não encontrado ou inválido',
            ], 404);
        }
        
        return response()->json([
            'success' => true,
            'data' => $resultado,
        ]);
    }
    
    /**
     * Validar CPF
     * POST /api/brazilian/validar-cpf
     */
    public function validarCpf(Request $request): JsonResponse
    {
        $cpf = $request->input('cpf');
        
        if (!$cpf) {
            return response()->json([
                'success' => false,
                'message' => 'CPF não informado',
            ], 400);
        }
        
        $valido = $this->cpfCnpjValidator->validarCpf($cpf);
        
        if (!$valido) {
            return response()->json([
                'success' => false,
                'valido' => false,
                'message' => 'CPF inválido',
            ]);
        }
        
        // Verificar duplicidade (exceto o próprio cliente ao editar)
        $clienteId = $request->input('cliente_id');
        $duplicidade = $this->cpfCnpjValidator->verificarDuplicidade($cpf, $clienteId);
        
        if ($duplicidade['duplicado']) {
            return response()->json([
                'success' => false,
                'valido' => true,
                'duplicado' => true,
                'message' => 'CPF já cadastrado no sistema',
                'cliente' => [
                    'nome' => $duplicidade['cliente_nome'],
                    'email' => $duplicidade['cliente_email'],
                ],
            ]);
        }
        
        return response()->json([
            'success' => true,
            'valido' => true,
            'duplicado' => false,
            'formatado' => $this->cpfCnpjValidator->formatarCpf($cpf),
            'message' => 'CPF válido',
        ]);
    }
    
    /**
     * Validar CNPJ
     * POST /api/brazilian/validar-cnpj
     */
    public function validarCnpj(Request $request): JsonResponse
    {
        $cnpj = $request->input('cnpj');
        
        if (!$cnpj) {
            return response()->json([
                'success' => false,
                'message' => 'CNPJ não informado',
            ], 400);
        }
        
        $valido = $this->cpfCnpjValidator->validarCnpj($cnpj);
        
        if (!$valido) {
            return response()->json([
                'success' => false,
                'valido' => false,
                'message' => 'CNPJ inválido',
            ]);
        }
        
        // Verificar duplicidade
        $clienteId = $request->input('cliente_id');
        $duplicidade = $this->cpfCnpjValidator->verificarDuplicidade($cnpj, $clienteId);
        
        if ($duplicidade['duplicado']) {
            return response()->json([
                'success' => false,
                'valido' => true,
                'duplicado' => true,
                'message' => 'CNPJ já cadastrado no sistema',
                'cliente' => [
                    'nome' => $duplicidade['cliente_nome'],
                    'email' => $duplicidade['cliente_email'],
                ],
            ]);
        }
        
        return response()->json([
            'success' => true,
            'valido' => true,
            'duplicado' => false,
            'formatado' => $this->cpfCnpjValidator->formatarCnpj($cnpj),
            'message' => 'CNPJ válido',
        ]);
    }
    
    /**
     * Validar CPF ou CNPJ automaticamente
     * POST /api/brazilian/validar-documento
     */
    public function validarDocumento(Request $request): JsonResponse
    {
        $documento = $request->input('documento');
        
        if (!$documento) {
            return response()->json([
                'success' => false,
                'message' => 'Documento não informado',
            ], 400);
        }
        
        $tipo = $this->cpfCnpjValidator->getTipo($documento);
        
        if (!$tipo) {
            return response()->json([
                'success' => false,
                'message' => 'Documento inválido (deve ser CPF ou CNPJ)',
            ], 400);
        }
        
        if ($tipo === 'cpf') {
            return $this->validarCpf($request);
        }
        
        return $this->validarCnpj($request);
    }
}
