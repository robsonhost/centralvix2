<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PaymentGateway;
use App\Models\PaymentTransaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;

class PaymentGatewayController extends Controller
{
    /**
     * Listar gateways disponíveis
     */
    public function index()
    {
        $gateways = config('payment');
        
        // Estatísticas por gateway
        $stats = [];
        foreach (array_keys($gateways) as $gateway) {
            $stats[$gateway] = [
                'total_transactions' => PaymentTransaction::where('gateway', $gateway)->count(),
                'total_paid' => PaymentTransaction::where('gateway', $gateway)
                    ->where('status', 'paid')
                    ->sum('amount'),
                'total_pending' => PaymentTransaction::where('gateway', $gateway)
                    ->where('status', 'pending')
                    ->count(),
            ];
        }

        return view('admin.settings.gateways.index', compact('gateways', 'stats'));
    }

    /**
     * Configurar gateway específico
     */
    public function configure(string $gateway)
    {
        $config = config("payment.{$gateway}");
        
        if (!$config) {
            return redirect()
                ->route('admin.settings.gateways')
                ->with('error', 'Gateway não encontrado');
        }

        return view('admin.settings.gateways.configure', [
            'gateway' => $gateway,
            'config' => $config,
        ]);
    }

    /**
     * Salvar configurações do gateway
     */
    public function save(Request $request, string $gateway)
    {
        $envPath = base_path('.env');
        
        if (!File::exists($envPath)) {
            return back()->with('error', 'Arquivo .env não encontrado');
        }

        $envContent = File::get($envPath);
        
        // Verificar limite de gateways ativos (máximo 3)
        if ($request->has('enabled') && $request->enabled) {
            $activeCount = collect(config('payment'))->filter(function($gw, $key) use ($gateway) {
                return $key !== $gateway && ($gw['enabled'] ?? false);
            })->count();
            
            if ($activeCount >= 3) {
                return back()
                    ->withInput()
                    ->with('error', 'Você já possui 3 gateways ativos. Desative um antes de ativar outro.');
            }
        }
        
        // Validação PagHiper: API Key e Token são credenciais diferentes
        if ($gateway === 'paghiper') {
            $apiKey = trim((string) ($request->input('api_key') ?? ''));
            $token  = trim((string) ($request->input('token') ?? ''));

            if ($apiKey === '' || $token === '') {
                return back()->withInput()->with('error', 'PagHiper: informe API Key e Token.');
            }

            if (strcasecmp($apiKey, $token) === 0) {
                return back()->withInput()->with(
                    'error',
                    'PagHiper: API Key e Token não podem ser iguais. A ApiKey (apk_...) está em Minha conta → Credenciais; o Token é outro valor na mesma tela ou em Ferramentas → Token.'
                );
            }

            if (!str_starts_with(strtolower($apiKey), 'apk_')) {
                return back()->withInput()->with(
                    'error',
                    'PagHiper: a API Key deve começar com apk_. Acesse Minha conta → Credenciais em paghiper.com/painel/credenciais — não use o Token no campo API Key.'
                );
            }
        }

        // Mapear campos do formulário para variáveis .env
        $envVars = $this->getEnvVarsForGateway($gateway, $request->all());
        
        foreach ($envVars as $key => $value) {
            $value = is_bool($value) ? ($value ? 'true' : 'false') : $value;
            
            // Se a variável já existe, atualiza
            if (preg_match("/^{$key}=.*/m", $envContent)) {
                $envContent = preg_replace(
                    "/^{$key}=.*/m",
                    "{$key}={$value}",
                    $envContent
                );
            } else {
                // Se não existe, adiciona
                $envContent .= "\n{$key}={$value}";
            }
        }
        
        File::put($envPath, $envContent);
        
        // Limpar cache de configuração
        Artisan::call('config:clear');

        // Sincroniza registro em payment_gateways (usado no checkout do cliente)
        $this->syncPaymentGatewayRecord($gateway, $request->all());
        
        return redirect()
            ->route('admin.settings.gateways')
            ->with('success', 'Configurações salvas com sucesso!');
    }

    /**
     * Ver transações de um gateway
     */
    public function transactions(Request $request, string $gateway)
    {
        $config = config("payment.{$gateway}");

        if (!$config) {
            return redirect()
                ->route('admin.settings.gateways')
                ->with('error', 'Gateway não encontrado');
        }

        $baseQuery = PaymentTransaction::where('gateway', $gateway);

        $stats = [
            'total'       => (clone $baseQuery)->count(),
            'paid'        => (clone $baseQuery)->where('status', 'paid')->count(),
            'pending'     => (clone $baseQuery)->where('status', 'pending')->count(),
            'failed'      => (clone $baseQuery)->whereIn('status', ['failed', 'cancelled'])->count(),
            'total_paid'  => (clone $baseQuery)->where('status', 'paid')->sum('amount'),
            'total_pending' => (clone $baseQuery)->where('status', 'pending')->sum('amount'),
        ];

        $query = PaymentTransaction::where('gateway', $gateway)
            ->with('invoice.client');

        if ($request->filled('status') && $request->status !== 'all') {
            if ($request->status === 'failed') {
                $query->whereIn('status', ['failed', 'cancelled']);
            } else {
                $query->where('status', $request->status);
            }
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('transaction_id', 'like', "%{$search}%")
                    ->orWhereHas('invoice', fn ($iq) => $iq->where('invoice_number', 'like', "%{$search}%"))
                    ->orWhereHas('invoice.client', fn ($cq) => $cq
                        ->where('email', 'like', "%{$search}%")
                        ->orWhere('firstname', 'like', "%{$search}%")
                        ->orWhere('lastname', 'like', "%{$search}%")
                    );
            });
        }

        $transactions = $query
            ->orderBy('created_at', 'desc')
            ->paginate(25)
            ->withQueryString();

        return view('admin.settings.gateways.transactions', [
            'gateway' => $gateway,
            'config' => $config,
            'stats' => $stats,
            'transactions' => $transactions,
            'filters' => [
                'status' => $request->get('status', 'all'),
                'search' => $request->get('search', ''),
            ],
        ]);
    }

    /**
     * Mapear campos do formulário para variáveis .env
     */
    private function getEnvVarsForGateway(string $gateway, array $data): array
    {
        $prefix = strtoupper($gateway);
        
        $vars = [
            "{$prefix}_ENABLED" => $data['enabled'] ?? false,
            "{$prefix}_IS_DEFAULT" => $data['is_default'] ?? false,
        ];
        
        switch ($gateway) {
            case 'asaas':
                $vars["{$prefix}_API_KEY"] = $data['api_key'] ?? '';
                $vars["{$prefix}_SANDBOX"] = $data['sandbox'] ?? true;
                $vars["{$prefix}_WEBHOOK_TOKEN"] = $data['webhook_token'] ?? '';
                $vars["{$prefix}_MULTA"] = $data['multa'] ?? 2;
                $vars["{$prefix}_JUROS"] = $data['juros'] ?? 1;
                break;
                
            case 'paghiper':
                $vars["{$prefix}_API_KEY"]       = trim((string) ($data['api_key'] ?? ''));
                $vars["{$prefix}_TOKEN"]          = trim((string) ($data['token'] ?? ''));
                $vars["{$prefix}_SANDBOX"]        = filter_var($data['sandbox'] ?? true, FILTER_VALIDATE_BOOLEAN);
                $vars["{$prefix}_PARTNER_ID"]     = trim((string) ($data['partner_id'] ?? ''));
                $vars["{$prefix}_MULTA"]          = $data['multa'] ?? 2;
                $vars["{$prefix}_DESCONTO"]       = $data['desconto'] ?? 0;
                $vars["{$prefix}_DISABLE_BOLETO"] = filter_var($data['disable_boleto'] ?? false, FILTER_VALIDATE_BOOLEAN);
                break;

            case 'c6bank':
                $vars["{$prefix}_CLIENT_ID"] = $data['client_id'] ?? '';
                $vars["{$prefix}_CLIENT_SECRET"] = $data['client_secret'] ?? '';
                $vars["{$prefix}_PIX_KEY"] = $data['pix_key'] ?? '';
                $vars["{$prefix}_CERT_PATH"] = $data['certificate_path'] ?? '';
                $vars["{$prefix}_KEY_PATH"] = $data['private_key_path'] ?? '';
                $vars["{$prefix}_SANDBOX"] = $data['sandbox'] ?? true;
                $vars["{$prefix}_PIX_EXPIRATION"] = $data['pix_expiration'] ?? 3600;
                break;

            case 'mercadopago':
                $vars["{$prefix}_API_KEY"] = $data['api_key'] ?? '';
                $vars["{$prefix}_ACCESS_TOKEN"] = $data['access_token'] ?? '';
                $vars["{$prefix}_SANDBOX"] = $data['sandbox'] ?? true;
                break;

            case 'pagseguro':
                $vars["{$prefix}_API_KEY"] = $data['api_key'] ?? '';
                $vars["{$prefix}_TOKEN"] = $data['secret_key'] ?? $data['token'] ?? '';
                $vars["{$prefix}_EMAIL"] = $data['email'] ?? '';
                $vars["{$prefix}_SANDBOX"] = $data['sandbox'] ?? true;
                break;

            case 'stripe':
                $vars["{$prefix}_API_KEY"] = $data['api_key'] ?? '';
                $vars["{$prefix}_SECRET_KEY"] = $data['secret_key'] ?? '';
                $vars["{$prefix}_WEBHOOK_SECRET"] = $data['webhook_secret'] ?? '';
                $vars["{$prefix}_SANDBOX"] = $data['sandbox'] ?? true;
                break;

            case 'paypal':
                $vars["{$prefix}_CLIENT_ID"] = $data['api_key'] ?? '';
                $vars["{$prefix}_CLIENT_SECRET"] = $data['secret_key'] ?? '';
                $vars["{$prefix}_SANDBOX"] = $data['sandbox'] ?? true;
                break;

            case 'efi':
                $vars["{$prefix}_CLIENT_ID"] = $data['api_key'] ?? '';
                $vars["{$prefix}_CLIENT_SECRET"] = $data['secret_key'] ?? '';
                $vars["{$prefix}_SANDBOX"] = $data['sandbox'] ?? true;
                break;

            case 'pix':
                $vars["{$prefix}_CHAVE"] = $data['pix_key'] ?? $data['api_key'] ?? '';
                break;

            case 'transferencia':
                $vars["{$prefix}_BANK_DETAILS"] = $data['bank_details'] ?? '';
                break;

            case 'crypto':
                $vars["{$prefix}_API_KEY"] = $data['api_key'] ?? '';
                break;

            default:
                $vars["{$prefix}_API_KEY"] = $data['api_key'] ?? '';
                if (isset($data['secret_key'])) {
                    $vars["{$prefix}_SECRET_KEY"] = $data['secret_key'];
                }
                if (isset($data['sandbox'])) {
                    $vars["{$prefix}_SANDBOX"] = $data['sandbox'];
                }
                break;
        }
        
        return $vars;
    }

    /**
     * Testar conexão com o gateway
     */
    public function test(Request $request, string $gateway): JsonResponse
    {
        try {
            $saved = config("payment.{$gateway}", []);
            $data = array_merge($saved, $request->all());
            
            // Simular teste básico conforme o gateway
            $testResult = match($gateway) {
                'asaas' => $this->testAsaas($data),
                'paghiper' => $this->testPagHiper($data),
                'c6bank' => $this->testC6Bank($data),
                'mercadopago' => $this->testMercadoPago($data),
                'pagseguro' => $this->testPagSeguro($data),
                'stripe' => $this->testStripe($data),
                'paypal' => $this->testPayPal($data),
                default => ['success' => true, 'message' => 'Gateway configurado (teste não disponível)']
            };
            
            return response()->json($testResult);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
    
    private function testAsaas(array $data): array
    {
        $apiKey = $data['api_key'] ?? '';
        $sandbox = $data['sandbox'] ?? true;
        
        if (empty($apiKey)) {
            return ['success' => false, 'message' => 'API Key não fornecida'];
        }
        
        $baseUrl = $sandbox ? 'https://sandbox.asaas.com/api/v3' : 'https://api.asaas.com/v3';
        
        try {
            $ch = curl_init($baseUrl . '/myAccount');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'access_token: ' . $apiKey,
                'Content-Type: application/json'
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200) {
                $account = json_decode($response, true);
                return [
                    'success' => true,
                    'account_name' => $account['name'] ?? 'Conta Asaas',
                    'api_version' => 'v3'
                ];
            }
            
            return ['success' => false, 'message' => 'Credenciais inválidas (HTTP ' . $httpCode . ')'];
            
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Erro ao conectar: ' . $e->getMessage()];
        }
    }
    
    private function testPagHiper(array $data): array
    {
        $apiKey = trim((string) ($data['api_key'] ?? ''));
        $token  = trim((string) ($data['token'] ?? ''));

        if ($apiKey === '' || $token === '') {
            return ['success' => false, 'message' => 'API Key e Token são obrigatórios'];
        }

        if (strcasecmp($apiKey, $token) === 0) {
            return [
                'success' => false,
                'message' => 'API Key e Token não podem ser iguais. A ApiKey (apk_...) fica em PagHiper → Minha conta → Credenciais. O Token é outro campo (mesma tela ou Ferramentas → Token).',
            ];
        }

        if (!str_starts_with(strtolower($apiKey), 'apk_')) {
            return [
                'success' => false,
                'message' => 'API Key inválida: deve começar com apk_. Copie em PagHiper → Minha conta → Credenciais (paghiper.com/painel/credenciais). Não cole o Token neste campo.',
            ];
        }

        try {
            $response = \Illuminate\Support\Facades\Http::timeout(20)
                ->post('https://api.paghiper.com/transaction/status/', [
                    'token'          => $token,
                    'apiKey'         => $apiKey,
                    'transaction_id' => 'cx_test_' . time(),
                ]);

            $body   = $response->json() ?? [];
            $nested = is_array($body['status_request'] ?? null) ? $body['status_request'] : $body;
            $msg    = strtolower((string) ($nested['response_message'] ?? $body['response_message'] ?? ''));

            if (str_contains($msg, 'apikey') || str_contains($msg, 'api key')) {
                return [
                    'success' => false,
                    'message' => 'API Key inválida. Copie a ApiKey (apk_...) em PagHiper → Minha conta → Credenciais.',
                ];
            }

            if (str_contains($msg, 'token')) {
                return [
                    'success' => false,
                    'message' => 'Token inválido. Copie em PagHiper → Minha conta → Credenciais ou Ferramentas → Token.',
                ];
            }

            // Transação inexistente = credenciais aceitas pela API
            if (str_contains($msg, 'not found') || str_contains($msg, 'nao encontrad') || str_contains($msg, 'não encontrad')) {
                return [
                    'success'      => true,
                    'message'      => 'Credenciais PagHiper validadas com sucesso',
                    'account_name' => 'PagHiper',
                    'api_version'  => 'v2',
                ];
            }

            $result = strtolower((string) ($nested['result'] ?? $body['result'] ?? ''));
            if ($result === 'success' || $result === 'reject') {
                return [
                    'success'      => true,
                    'message'      => 'Credenciais PagHiper validadas',
                    'account_name' => 'PagHiper',
                    'api_version'  => 'v2',
                ];
            }

            return [
                'success' => false,
                'message' => (string) ($nested['response_message'] ?? $body['response_message'] ?? 'Não foi possível validar as credenciais PagHiper'),
            ];
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Erro ao conectar com PagHiper: ' . $e->getMessage()];
        }
    }
    
    private function testMercadoPago(array $data): array
    {
        $accessToken = $data['access_token'] ?? $data['api_key'] ?? '';
        
        if (empty($accessToken)) {
            return ['success' => false, 'message' => 'Access Token não fornecido'];
        }
        
        try {
            $ch = curl_init('https://api.mercadopago.com/v1/account');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $accessToken,
                'Content-Type: application/json'
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200) {
                return ['success' => true, 'message' => 'Conexão bem-sucedida com Mercado Pago'];
            }
            
            return ['success' => false, 'message' => 'Token inválido (HTTP ' . $httpCode . ')'];
            
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Erro: ' . $e->getMessage()];
        }
    }
    
    private function testPagSeguro(array $data): array
    {
        return ['success' => true, 'message' => 'Credenciais configuradas (PagSeguro)'];
    }
    
    private function testStripe(array $data): array
    {
        return ['success' => true, 'message' => 'Credenciais configuradas (Stripe)'];
    }
    
    private function testPayPal(array $data): array
    {
        return ['success' => true, 'message' => 'Credenciais configuradas (PayPal)'];
    }

    private function testC6Bank(array $data): array
    {
        $clientId = $data['client_id'] ?? '';
        $secret   = $data['client_secret'] ?? '';
        $pixKey   = $data['pix_key'] ?? '';

        if ($clientId === '' || $secret === '' || $pixKey === '') {
            return ['success' => false, 'message' => 'Client ID, Client Secret e Chave PIX são obrigatórios'];
        }

        return [
            'success' => true,
            'message' => 'Credenciais C6 Bank registradas. Teste completo requer certificado mTLS em produção.',
            'pix_key' => $pixKey,
        ];
    }

    /** Persiste/atualiza gateway na tabela payment_gateways para o checkout. */
    private function syncPaymentGatewayRecord(string $gateway, array $data): void
    {
        $companyId = (int) auth()->user()->company_id;
        $def       = config("payment.{$gateway}", []);

        if (empty($def)) {
            return;
        }

        $settings = match ($gateway) {
            'paghiper' => array_filter([
                'api_key'        => trim((string) ($data['api_key'] ?? '')),
                'token'          => trim((string) ($data['token'] ?? '')),
                'partner_id'     => trim((string) ($data['partner_id'] ?? '')),
                'disable_boleto' => filter_var($data['disable_boleto'] ?? false, FILTER_VALIDATE_BOOLEAN),
                'sandbox'        => filter_var($data['sandbox'] ?? true, FILTER_VALIDATE_BOOLEAN),
            ], fn ($v) => $v !== null && $v !== ''),
            'c6bank' => [
                'client_id'        => $data['client_id'] ?? '',
                'client_secret'    => $data['client_secret'] ?? '',
                'pix_key'          => $data['pix_key'] ?? '',
                'certificate_path' => $data['certificate_path'] ?? '',
                'private_key_path' => $data['private_key_path'] ?? '',
                'sandbox'          => (bool) ($data['sandbox'] ?? true),
            ],
            'asaas' => [
                'api_key' => $data['api_key'] ?? '',
                'sandbox' => (bool) ($data['sandbox'] ?? true),
            ],
            default => array_filter([
                'api_key'    => $data['api_key'] ?? null,
                'secret_key' => $data['secret_key'] ?? null,
                'sandbox'    => $data['sandbox'] ?? null,
            ]),
        };

        PaymentGateway::updateOrCreate(
            ['company_id' => $companyId, 'module' => $gateway],
            [
                'name'         => $def['name'] ?? ucfirst($gateway),
                'display_name' => $def['name'] ?? ucfirst($gateway),
                'status'       => !empty($data['enabled']) ? 'active' : 'inactive',
                'test_mode'    => (bool) ($data['sandbox'] ?? true),
                'settings'     => $settings,
            ]
        );
    }
}
