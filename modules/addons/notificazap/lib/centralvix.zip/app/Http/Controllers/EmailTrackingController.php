<?php

namespace App\Http\Controllers;

use App\Models\EmailCampaignRecipient;
use App\Services\EmailCampaignService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class EmailTrackingController extends Controller
{
    public function __construct(private EmailCampaignService $campaigns) {}

    public function open(string $token): Response
    {
        $recipient = EmailCampaignRecipient::where('token', $token)->first();
        if ($recipient) {
            $this->campaigns->registerOpen($recipient);
        }

        // GIF transparente 1x1.
        $gif = base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');

        return response($gif, 200, [
            'Content-Type' => 'image/gif',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache',
        ]);
    }

    public function unsubscribe(string $token): Response
    {
        $recipient = EmailCampaignRecipient::where('token', $token)->first();
        $done = false;

        if ($recipient && $recipient->client) {
            $recipient->client->update(['marketing_opt_out' => true]);
            $done = true;
        }

        return response()->view('email.unsubscribe', ['done' => $done]);
    }
}
