<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\WhatsappChat;
use App\Models\WhatsappInstance;
use App\Models\WhatsappMessage;
use App\Services\AI\AiService;
use App\Services\WhatsApp\EvolutionGoService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class WhatsappChatController extends Controller
{
    public function __construct(private AiService $ai) {}

    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = WhatsappChat::with(['client', 'instance'])
            ->where('company_id', $companyId);

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(fn($q) => $q->where('phone_number', 'like', "%{$s}%")
                ->orWhere('contact_name', 'like', "%{$s}%")
                ->orWhereHas('client', fn($c) => $c->where('email', 'like', "%{$s}%")));
        }

        $chats = $query->orderByDesc('last_message_at')->paginate(30);
        $instances = WhatsappInstance::where('company_id', $companyId)->where('status', 'connected')->get();
        
        // Stats
        $stats = [
            'total' => WhatsappChat::where('company_id', $companyId)->count(),
            'open' => WhatsappChat::where('company_id', $companyId)->where('status', 'open')->count(),
            'unread' => WhatsappChat::where('company_id', $companyId)->where('unread_count', '>', 0)->sum('unread_count'),
            'ai_active' => WhatsappChat::where('company_id', $companyId)->where('ai_enabled', true)->count(),
        ];

        return view('admin.whatsapp.chats.index', compact('chats', 'instances', 'stats'));
    }

    public function show(WhatsappChat $whatsappChat): View
    {
        if ($whatsappChat->company_id !== auth()->user()->company_id) abort(403);

        $messages = WhatsappMessage::where('company_id', $whatsappChat->company_id)
            ->where('to_number', $whatsappChat->phone_number)
            ->orderBy('created_at')
            ->get();

        $whatsappChat->update(['unread_count' => 0]);

        $agents = \App\Models\User::where('company_id', auth()->user()->company_id)
            ->whereHas('roles', fn($q) => $q->whereIn('name', ['admin', 'support', 'super-admin']))
            ->get();

        return view('admin.whatsapp.chats.show', [
            'chat'     => $whatsappChat->load(['client', 'instance', 'assignedTo']),
            'messages' => $messages,
            'agents'   => $agents,
        ]);
    }

    public function send(Request $request, WhatsappChat $whatsappChat): JsonResponse
    {
        if ($whatsappChat->company_id !== auth()->user()->company_id) abort(403);

        $request->validate(['message' => 'required|string|max:4096']);

        $instance = WhatsappInstance::find($whatsappChat->instance_id);
        if (!$instance || !$instance->isConnected()) {
            return response()->json(['error' => 'Instância desconectada'], 422);
        }

        $evolution = new EvolutionGoService($instance);
        $result    = $evolution->sendText($instance->instance_key, $whatsappChat->phone_number, $request->message);

        $msgId = $result['key']['id'] ?? null;

        $message = WhatsappMessage::create([
            'uuid'        => Str::uuid(),
            'company_id'  => $whatsappChat->company_id,
            'instance_id' => $instance->id,
            'client_id'   => $whatsappChat->client_id,
            'to_number'   => $whatsappChat->phone_number,
            'type'        => 'text',
            'content'     => $request->message,
            'message_id'  => $msgId,
            'status'      => $msgId ? 'sent' : 'failed',
            'sent_by'     => auth()->user()->name,
            'sent_at'     => now(),
            'raw_response' => $result,
        ]);

        $whatsappChat->update([
            'last_message'    => $request->message,
            'last_message_at' => now(),
        ]);

        return response()->json([
            'success' => (bool) $msgId,
            'message' => [
                'id'         => $message->id,
                'content'    => $message->content,
                'status'     => $message->status,
                'sent_by'    => $message->sent_by,
                'created_at' => $message->created_at->format('H:i'),
            ],
        ]);
    }

    public function sendMedia(Request $request, WhatsappChat $whatsappChat): JsonResponse
    {
        if ($whatsappChat->company_id !== auth()->user()->company_id) abort(403);

        $request->validate([
            'type'    => 'required|in:image,document,audio,video',
            'url'     => 'required|url',
            'caption' => 'nullable|string|max:1000',
        ]);

        $instance  = WhatsappInstance::find($whatsappChat->instance_id);
        $evolution = new EvolutionGoService($instance);
        $result    = $evolution->sendMedia(
            $instance->instance_key,
            $whatsappChat->phone_number,
            $request->type,
            $request->url,
            $request->caption ?? ''
        );

        return response()->json(['success' => isset($result['key']['id'])]);
    }

    public function aiSuggest(Request $request, WhatsappChat $whatsappChat): JsonResponse
    {
        if ($whatsappChat->company_id !== auth()->user()->company_id) abort(403);

        $request->validate(['message' => 'required|string']);

        $context = [];
        if ($whatsappChat->client_id) {
            $client    = Client::find($whatsappChat->client_id);
            $context[] = "Cliente: {$client?->display_name}";
            $context[] = "E-mail: {$client?->email}";
        }

        $suggestion = $this->ai->whatsappReply(
            $request->message,
            $context,
            $whatsappChat->company_id
        );

        return response()->json(['suggestion' => $suggestion]);
    }

    public function assign(Request $request, WhatsappChat $whatsappChat): RedirectResponse
    {
        if ($whatsappChat->company_id !== auth()->user()->company_id) abort(403);
        $request->validate(['assigned_to' => 'nullable|exists:users,id']);
        $whatsappChat->update(['assigned_to' => $request->assigned_to]);
        return back()->with('success', 'Chat atribuído.');
    }

    public function close(WhatsappChat $whatsappChat): RedirectResponse
    {
        if ($whatsappChat->company_id !== auth()->user()->company_id) abort(403);
        $whatsappChat->update(['status' => 'closed']);
        return back()->with('success', 'Chat fechado.');
    }

    public function toggleAi(WhatsappChat $whatsappChat): JsonResponse
    {
        if ($whatsappChat->company_id !== auth()->user()->company_id) abort(403);
        $whatsappChat->update(['ai_enabled' => !$whatsappChat->ai_enabled]);
        return response()->json(['ai_enabled' => $whatsappChat->fresh()->ai_enabled]);
    }

    public function messages(WhatsappChat $whatsappChat): JsonResponse
    {
        if ($whatsappChat->company_id !== auth()->user()->company_id) abort(403);

        $messages = WhatsappMessage::where('company_id', $whatsappChat->company_id)
            ->where('to_number', $whatsappChat->phone_number)
            ->orderBy('created_at')
            ->get()
            ->map(fn($m) => [
                'id'         => $m->id,
                'content'    => $m->content,
                'type'       => $m->type,
                'status'     => $m->status,
                'sent_by'    => $m->sent_by,
                'created_at' => $m->created_at->format('d/m H:i'),
                'is_outbound' => $m->sent_by !== null,
            ]);

        return response()->json($messages);
    }
}
