<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use App\Models\TicketDepartment;
use App\Models\TicketReply;
use App\Services\NotificationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\View\View;

class TicketController extends Controller
{
    public function index(): View
    {
        $client = auth()->user()->client ?? abort(404);
        $tickets = $client->tickets()->with('department')->latest()->paginate(15);
        return view('client.tickets.index-NOVO', compact('tickets'));
    }

    public function create(): View
    {
        $client = auth()->user()->client ?? abort(404);
        $departments = TicketDepartment::where('company_id', $client->company_id)
            ->where('status', 'active')
            ->where('hidden', false)
            ->orderBy('order')
            ->get();
        $services = $client->services()->where('status', 'active')->get();
        return view('client.tickets.create', compact('departments', 'services'));
    }

    public function store(Request $request): RedirectResponse
    {
        $client = auth()->user()->client ?? abort(404);

        $validated = $request->validate([
            'department_id' => 'required|exists:ticket_departments,id',
            'subject' => 'required|string|max:255',
            'message' => 'required|string',
            'priority' => 'nullable|in:low,medium,high',
            'service_id' => 'nullable|exists:services,id',
        ]);

        $ticket = Ticket::create([
            'uuid' => Str::uuid(),
            'company_id' => $client->company_id,
            'client_id' => $client->id,
            'department_id' => $validated['department_id'],
            'subject' => $validated['subject'],
            'status' => 'open',
            'priority' => $validated['priority'] ?? 'medium',
            'service_id' => $validated['service_id'] ?? null,
            'last_reply_at' => now(),
        ]);

        TicketReply::create([
            'ticket_id' => $ticket->id,
            'client_id' => $client->id,
            'message' => $validated['message'],
            'type' => 'reply',
        ]);

        try {
            app(NotificationService::class)->dispatchTicketOpened($ticket);
        } catch (\Throwable $e) {
            \Log::warning('Notificação ticket aberto: ' . $e->getMessage());
        }

        // TODO: Enviar notificação WhatsApp legada
        try {
            $whatsapp = app(\App\Services\EvolutionWhatsAppService::class);
            if ($whatsapp->isEnabled() && $client->whatsapp) {
                $whatsapp->sendTicketOpened($client->whatsapp, $ticket->id, $ticket->subject);
            }
        } catch (\Exception $e) {
            Log::error('Erro ao enviar WhatsApp ticket: ' . $e->getMessage());
        }

        // Log activity
        activity()
            ->performedOn($ticket)
            ->causedBy($client)
            ->log('Ticket criado pelo cliente');

        return redirect()->route('client.tickets.index')
            ->with('success', '✓ Ticket #' . $ticket->id . ' aberto com sucesso! Nossa equipe responderá em breve.');
    }

    public function show(Ticket $ticket): View
    {
        $client = auth()->user()->client ?? abort(404);
        if ($ticket->client_id !== $client->id) abort(403);
        $ticket->load(['replies.user', 'replies.client', 'replies.attachments', 'department']);
        return view('client.tickets.show', compact('ticket'));
    }

    public function reply(Request $request, Ticket $ticket): RedirectResponse
    {
        $client = auth()->user()->client ?? abort(404);
        if ($ticket->client_id !== $client->id) abort(403);

        $request->validate(['message' => 'required|string']);

        if (in_array($ticket->status, ['closed'])) {
            $ticket->update(['status' => 'open', 'closed_at' => null]);
        }

        $reply = TicketReply::create([
            'ticket_id' => $ticket->id,
            'client_id' => $client->id,
            'message' => $request->message,
            'type' => 'reply',
        ]);

        $ticket->update([
            'status' => 'client_reply',
            'last_reply_at' => now(),
        ]);

        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('tickets/' . $ticket->id, 'public');
                $reply->attachments()->create([
                    'ticket_id' => $ticket->id,
                    'filename' => basename($path),
                    'original_name' => $file->getClientOriginalName(),
                    'size' => $file->getSize(),
                    'mime_type' => $file->getMimeType(),
                    'path' => $path,
                ]);
            }
        }

        return back()->with('success', 'Resposta enviada!');
    }

    public function close(Ticket $ticket): RedirectResponse
    {
        $client = auth()->user()->client ?? abort(404);
        if ($ticket->client_id !== $client->id) abort(403);
        $ticket->close();
        return back()->with('success', 'Ticket fechado.');
    }
}
