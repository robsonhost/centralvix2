<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Services\AutoLoginService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class LoginController extends Controller
{
    public function showLoginForm(): View
    {
        $branding = app(\App\Services\BrandingService::class)->get();
        $companyId = (int) ($branding['company_id'] ?? 1);
        $autoLogin = app(AutoLoginService::class);

        return view('auth.login', [
            'magicLoginEnabled' => $autoLogin->isEnabled($companyId)
                && ($autoLogin->config($companyId)['magic_login_enabled'] ?? true),
        ]);
    }

    public function login(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'email'    => 'required|email',
            'password' => 'required|min:6',
        ]);

        // Check if IP is blocked
        $ip = $request->ip();
        if (\App\Models\LoginAttempt::isBlocked($ip)) {
            $blockedUntil = \App\Models\LoginAttempt::getBlockedUntil($ip);
            return back()->withErrors([
                'blocked' => 'Seu IP foi bloqueado até ' . $blockedUntil?->format('d/m/Y H:i:s') . 
                            ' devido a múltiplas tentativas falhadas.'
            ])->onlyInput('email');
        }

        // Validação do CAPTCHA
        $sessionCode   = strtoupper(trim(session('captcha_code', '')));
        $submittedCode = strtoupper(trim($request->input('captcha_code', '')));

        if (empty($submittedCode) || $submittedCode !== $sessionCode) {
            // Invalida o CAPTCHA para forçar nova geração
            session()->forget('captcha_code');
            return back()->withErrors([
                'captcha' => 'Código de segurança incorreto. Tente novamente.',
            ])->onlyInput('email');
        }

        // CAPTCHA válido — invalida para uso único
        session()->forget('captcha_code');

        $remember = $request->boolean('remember');

        if (Auth::attempt($credentials, $remember)) {
            // Record successful attempt
            \App\Models\LoginAttempt::record($ip, $request->email, true);
            
            $request->session()->regenerate();

            $user = Auth::user();
            $twoFactor = app(\App\Services\TwoFactorService::class);

            // Check 2FA (respeita o módulo: dispositivos lembrados pulam o desafio).
            if ($twoFactor->shouldChallenge($request, $user)) {
                $request->session()->put('2fa:user_id', $user->id);
                Auth::logout();
                return redirect()->route('auth.2fa');
            }

            if ($twoFactor->mustSetup($user)) {
                return redirect()->route('two-factor.setup');
            }
            if ($msg = $twoFactor->graceMessage($user)) {
                session()->flash('info', $msg);
            }

            // Redirect based on role
            if (method_exists($user, 'isAdmin') && $user->isAdmin()) {
                return redirect()->intended(route('admin.dashboard'));
            }

            return redirect()->intended(route('client.dashboard'));
        }

        // Record failed attempt
        \App\Models\LoginAttempt::record($ip, $request->email, false);
        
        // Get remaining attempts
        $failedAttempts = \App\Models\LoginAttempt::getRecentFailedAttempts($ip);
        $remainingAttempts = max(0, 3 - $failedAttempts);

        $errorMessage = $remainingAttempts > 0 
            ? "Credenciais inválidas. Você tem mais {$remainingAttempts} tentativa(s) antes de ser bloqueado."
            : "Credenciais inválidas. Seu IP foi bloqueado temporariamente.";

        return back()->withErrors([
            'email' => $errorMessage,
        ])->onlyInput('email');
    }

    public function sendMagicLink(Request $request): RedirectResponse
    {
        $request->validate(['email' => 'required|email']);

        $companyId = (int) (app(\App\Services\BrandingService::class)->get()['company_id'] ?? 0);
        $result = app(AutoLoginService::class)->sendMagicLink($request->email, $companyId ?: null);

        return back()->with(
            ($result['success'] ?? false) ? 'success' : 'error',
            $result['message'] ?? 'Não foi possível processar sua solicitação.'
        );
    }

    public function logout(Request $request): RedirectResponse
    {
        $request->session()->forget(['2fa:user_id', '2fa:code_sent', '2fa_setup_secret']);
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }
}
