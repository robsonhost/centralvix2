<?php

namespace App\Http\Controllers\Licenses;

use App\Http\Controllers\Controller;
use App\Models\License;
use App\Models\LicenseValidation;
use App\Models\Client;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->guard('licenses')->user();

        // Estatísticas gerais
        $stats = [
            'total' => License::count(),
            'active' => License::where('status', 'active')->count(),
            'expired' => License::where('status', 'expired')->count(),
            'suspended' => License::where('status', 'suspended')->count(),
            'expiring_soon' => License::where('status', 'active')
                ->where('expires_at', '<=', now()->addDays(30))
                ->count(),
        ];

        // Licenças recentes
        $recentLicenses = License::with('client')
            ->latest()
            ->limit(10)
            ->get();

        // Validações recentes
        $recentValidations = LicenseValidation::with('license.client')
            ->latest()
            ->limit(10)
            ->get();

        // Licenças expirando nos próximos 7 dias
        $expiringSoon = License::with('client')
            ->where('status', 'active')
            ->where('expires_at', '<=', now()->addDays(7))
            ->orderBy('expires_at')
            ->get();

        // Gráfico de validações (últimos 30 dias)
        $validationsByDay = LicenseValidation::select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as count')
            )
            ->where('created_at', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Top clientes por licenças
        $topClients = Client::select('clients.*', DB::raw('COUNT(licenses.id) as licenses_count'))
            ->join('licenses', 'clients.id', '=', 'licenses.client_id')
            ->groupBy('clients.id')
            ->orderByDesc('licenses_count')
            ->limit(5)
            ->get();

        return view('licenses.dashboard', compact(
            'user',
            'stats',
            'recentLicenses',
            'recentValidations',
            'expiringSoon',
            'validationsByDay',
            'topClients'
        ));
    }
}
