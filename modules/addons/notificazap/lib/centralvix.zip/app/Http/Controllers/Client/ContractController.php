<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Contract;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class ContractController extends Controller
{
    public function index(Request $request)
    {
        $client = auth()->user()->resolveClient() ?? abort(404);
        $status = $request->input('status');
        
        $contracts = Contract::where('client_id', $client->id)
            ->with('service.product')
            ->when($status, function($query, $status) {
                if ($status !== 'all') {
                    $query->where('status', $status);
                }
            })
            ->latest()
            ->paginate(15);
        
        return view('client.contracts.index', compact('contracts'));
    }
    
    public function show(Contract $contract)
    {
        if (!auth()->user()->canAccessClientRecord($contract->client)) {
            abort(403);
        }
        
        return view('client.contracts.show', compact('contract'));
    }
    
    public function download(Contract $contract)
    {
        if (!auth()->user()->canAccessClientRecord($contract->client)) {
            abort(403);
        }
        
        $company = $contract->company ?? auth()->user()->company;
        
        $pdf = Pdf::loadView('client.contracts.pdf', compact('contract', 'company'));
        
        return $pdf->download('contrato-' . $contract->contract_number . '.pdf');
    }
    
    public function renew(Contract $contract)
    {
        if (!auth()->user()->canAccessClientRecord($contract->client)) {
            abort(403);
        }
        
        // Lógica de renovação
        // TODO: Implementar renovação de contrato
        
        activity()
            ->causedBy(auth()->user())
            ->performedOn($contract)
            ->log('Solicitou renovação de contrato');
        
        return back()->with('success', 'Renovação solicitada com sucesso!');
    }
    
    public function toggleAutoRenew(Contract $contract)
    {
        if (!auth()->user()->canAccessClientRecord($contract->client)) {
            abort(403);
        }
        
        $contract->update([
            'auto_renew' => !$contract->auto_renew
        ]);
        
        $status = $contract->auto_renew ? 'ativada' : 'desativada';
        
        return back()->with('success', "Renovação automática {$status}!");
    }
}
