<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\PaymentGateway;
use App\Services\InvoiceService;
use App\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class InvoiceController extends Controller
{
    public function __construct(private InvoiceService $invoiceService) {}

    public function index(): View
    {
        $client = auth()->user()->resolveClient() ?? abort(404);
        $invoices = $client->invoices()->latest('date_created')->paginate(15);
        return view('client.invoices.index', compact('invoices'));
    }

    public function show(Invoice $invoice): View
    {
        if (!auth()->user()->canAccessClientRecord($invoice->client)) {
            abort(403, 'Você não tem permissão para acessar esta fatura.');
        }

        $invoice->load(['items', 'transactions']);
        $gateways = PaymentGateway::where('company_id', $invoice->client?->company_id ?? auth()->user()->company_id)
            ->where('status', 'active')
            ->orderBy('order')
            ->get();

        return view('client.invoices.show', compact('invoice', 'gateways'));
    }

    public function pdf(Invoice $invoice): \Illuminate\Http\Response
    {
        if (!auth()->user()->canAccessClientRecord($invoice->client)) {
            abort(403, 'Você não tem permissão para acessar esta fatura.');
        }
        return $this->invoiceService->generatePdf($invoice);
    }

    public function status(Invoice $invoice): JsonResponse
    {
        if (!auth()->user()->canAccessClientRecord($invoice->client)) {
            abort(403);
        }

        app(PaymentService::class)->syncInvoiceStatus($invoice);
        $invoice->refresh();

        $labels = [
            'paid'      => 'Pago',
            'unpaid'    => 'Em aberto',
            'overdue'   => 'Vencida',
            'pending'   => 'Aguardando',
            'cancelled' => 'Cancelada',
        ];

        $activeTx = $invoice->transactions()
            ->whereIn('status', ['pending', 'processing'])
            ->latest()
            ->first();
        $latestTx = $activeTx ?? $invoice->transactions()->latest()->first();
        $gatewayResponse = is_array($latestTx?->gateway_response) ? $latestTx->gateway_response : [];

        return response()->json([
            'status'         => $invoice->status,
            'status_label'   => $invoice->status_label ?: ($labels[$invoice->status] ?? ucfirst($invoice->status)),
            'is_paid'        => $invoice->status === 'paid',
            'invoice_number' => $invoice->invoice_number,
            'total'          => (float) $invoice->total,
            'date_paid'      => $invoice->date_paid?->format('d/m/Y H:i'),
            'boleto_url'     => $gatewayResponse['bank_slip_url'] ?? null,
            'digitable_line' => $gatewayResponse['digitable_line'] ?? null,
            'pix_code'       => $gatewayResponse['pix_code'] ?? null,
            'pdf_url'        => route('client.invoices.pdf', $invoice),
            'pay_url'        => route('client.payment.checkout', $invoice),
        ]);
    }
}
