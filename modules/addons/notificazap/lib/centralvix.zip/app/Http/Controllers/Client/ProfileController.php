<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rules\Password;

class ProfileController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $client = $user->client;
        
        // Calcula completude do perfil
        $completion = $this->calculateCompletion($client);
        $user->profile_completion_percentage = $completion;
        
        return view('client.profile.index-NOVO', compact('user', 'client', 'completion'));
    }

    public function update(Request $request)
    {
        $user = auth()->user();
        $client = $user->client;

        $validated = $request->validate([
            // Dados pessoais
            'firstname' => 'required|string|max:255',
            'lastname' => 'required|string|max:255',
            'cpf' => 'nullable|string|max:14',
            'rg' => 'nullable|string|max:20',
            'date_of_birth' => 'nullable|date',
            'type' => 'required|in:individual,company',
            'cnpj' => 'nullable|string|max:18',
            'company_name' => 'nullable|string|max:255',
            
            // Endereço
            'zip' => 'nullable|string|max:9',
            'address' => 'nullable|string|max:255',
            'address_number' => 'nullable|string|max:20',
            'address_complement' => 'nullable|string|max:255',
            'neighborhood' => 'nullable|string|max:100',
            'city' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:2',
            'country' => 'nullable|string|max:100',
            
            // Contato
            'email_secondary' => 'nullable|email|max:255',
            'whatsapp' => 'nullable|string|max:20',
            'mobile' => 'nullable|string|max:20',
            'phone' => 'nullable|string|max:20',
            
            // Senha
            'current_password' => 'nullable|required_with:password',
            'password' => ['nullable', 'confirmed', Password::min(8)],
            
            // Avatar
            'avatar' => 'nullable|image|max:2048',
            
            // Notificações
            'notifications' => 'nullable|array',
        ]);

        // Atualiza dados do cliente
        $client->update($validated);

        // Atualiza email se mudou
        if ($request->filled('email') && $request->email !== $user->email) {
            $user->update(['email' => $request->email]);
        }

        // Atualiza senha se fornecida
        if ($request->filled('password')) {
            if (!Hash::check($request->current_password, $user->password)) {
                return back()->withErrors(['current_password' => 'Senha atual incorreta']);
            }
            $user->update(['password' => Hash::make($request->password)]);
        }

        // Upload de avatar
        if ($request->hasFile('avatar')) {
            // Deleta avatar antigo
            if ($client->avatar_path) {
                Storage::disk('public')->delete($client->avatar_path);
            }
            
            $path = $request->file('avatar')->store('avatars', 'public');
            $client->update(['avatar_path' => $path]);
        }

        // Salva preferências de notificação
        if ($request->has('notifications')) {
            $client->update(['notification_preferences' => json_encode($request->notifications)]);
        }

        activity()
            ->causedBy($user)
            ->performedOn($client)
            ->log('Perfil atualizado');

        return back()->with('success', '✓ Perfil atualizado com sucesso!');
    }

    public function updatePassword(Request $request)
    {
        $user = auth()->user();

        $validated = $request->validate([
            'current_password' => 'required',
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);

        // Verifica senha atual
        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => 'A senha atual está incorreta']);
        }

        // Atualiza senha
        $user->update([
            'password' => Hash::make($request->password),
        ]);

        activity()
            ->causedBy($user)
            ->log('Senha alterada');

        return back()->with('success', '✓ Senha alterada com sucesso!');
    }

    private function calculateCompletion($client): int
    {
        $fields = [
            'firstname', 'lastname', 'cpf', 'date_of_birth',
            'zip', 'address', 'city', 'state',
            'whatsapp', 'mobile'
        ];
        
        $filled = 0;
        foreach ($fields as $field) {
            if (!empty($client->$field)) {
                $filled++;
            }
        }
        
        return (int) round(($filled / count($fields)) * 100);
    }
}
