<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\AutoLoginToken;
use App\Services\AutoLoginService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ShortLinkController extends Controller
{
    public function __construct(private AutoLoginService $autoLogin) {}

    public function redirect(Request $request, string $code): RedirectResponse|View
    {
        $record = AutoLoginToken::where('short_code', $code)->first();

        if ($record) {
            $this->autoLogin->recordClick($record, $request);
        }

        if (!$record || !$record->isValid()) {
            if ($record) {
                $this->autoLogin->logAccess($record, $request, false, 'expired_or_used');
            }

            return view('public.autologin.expired');
        }

        return redirect()->route('autologin', ['token' => $record->token]);
    }
}
