<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Jobs\SendEmailCampaign;
use App\Models\Client;
use App\Models\EmailCampaign;
use App\Services\EmailCampaignService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class EmailCampaignController extends Controller
{
    public function __construct(private EmailCampaignService $service) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $campaigns = EmailCampaign::forCompany($companyId)->latest()->paginate(20);

        $stats = [
            'total' => EmailCampaign::forCompany($companyId)->count(),
            'sent' => EmailCampaign::forCompany($companyId)->where('status', 'sent')->count(),
            'emails' => (int) EmailCampaign::forCompany($companyId)->sum('sent_count'),
            'opted_out' => Client::where('company_id', $companyId)->where('marketing_opt_out', true)->count(),
        ];

        return view('admin.email-campaigns.index', compact('campaigns', 'stats'));
    }

    public function create(): View
    {
        return view('admin.email-campaigns.create', [
            'counts' => $this->audienceCounts(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validateData($request);
        $data['company_id'] = auth()->user()->company_id;
        $data['created_by'] = auth()->id();
        $data['status'] = 'draft';

        $campaign = EmailCampaign::create($data);

        return redirect()
            ->route('admin.email-campaigns.show', $campaign)
            ->with('success', 'Campanha criada como rascunho.');
    }

    public function show(EmailCampaign $emailCampaign): View
    {
        $this->authorizeCompany($emailCampaign);

        $recent = $emailCampaign->recipients()->latest('sent_at')->limit(50)->get();

        return view('admin.email-campaigns.show', [
            'campaign' => $emailCampaign,
            'recipients' => $recent,
        ]);
    }

    public function edit(EmailCampaign $emailCampaign): View|RedirectResponse
    {
        $this->authorizeCompany($emailCampaign);

        if (!$emailCampaign->isEditable()) {
            return redirect()->route('admin.email-campaigns.show', $emailCampaign)
                ->with('error', 'Esta campanha não pode mais ser editada.');
        }

        return view('admin.email-campaigns.edit', [
            'campaign' => $emailCampaign,
            'counts' => $this->audienceCounts(),
        ]);
    }

    public function update(Request $request, EmailCampaign $emailCampaign): RedirectResponse
    {
        $this->authorizeCompany($emailCampaign);

        if (!$emailCampaign->isEditable()) {
            return redirect()->route('admin.email-campaigns.show', $emailCampaign)
                ->with('error', 'Esta campanha não pode mais ser editada.');
        }

        $emailCampaign->update($this->validateData($request));

        return redirect()->route('admin.email-campaigns.show', $emailCampaign)
            ->with('success', 'Campanha atualizada.');
    }

    public function destroy(EmailCampaign $emailCampaign): RedirectResponse
    {
        $this->authorizeCompany($emailCampaign);
        $emailCampaign->recipients()->delete();
        $emailCampaign->delete();

        return redirect()->route('admin.email-campaigns.index')
            ->with('success', 'Campanha removida.');
    }

    public function send(Request $request, EmailCampaign $emailCampaign): RedirectResponse
    {
        $this->authorizeCompany($emailCampaign);

        if (!$this->service->isEnabled($emailCampaign->company_id)) {
            return back()->with('error', 'Ative o módulo "E-mail Marketing" antes de enviar.');
        }

        if (!in_array($emailCampaign->status, ['draft', 'scheduled'], true)) {
            return back()->with('error', 'Esta campanha já foi enviada ou está em andamento.');
        }

        $total = $this->service->buildRecipients($emailCampaign);
        if ($total === 0) {
            return back()->with('error', 'Nenhum destinatário válido para a audiência selecionada.');
        }

        $scheduledAt = $request->filled('scheduled_at')
            ? \Carbon\Carbon::parse($request->scheduled_at)
            : null;

        if ($scheduledAt && $scheduledAt->isFuture()) {
            $emailCampaign->update(['status' => 'scheduled', 'scheduled_at' => $scheduledAt]);
            SendEmailCampaign::dispatch($emailCampaign->id)->delay($scheduledAt);

            return redirect()->route('admin.email-campaigns.show', $emailCampaign)
                ->with('success', "Campanha agendada para {$scheduledAt->format('d/m/Y H:i')} ({$total} destinatários).");
        }

        $emailCampaign->update(['status' => 'sending']);
        SendEmailCampaign::dispatch($emailCampaign->id);

        return redirect()->route('admin.email-campaigns.show', $emailCampaign)
            ->with('success', "Envio iniciado para {$total} destinatário(s).");
    }

    public function cancel(EmailCampaign $emailCampaign): RedirectResponse
    {
        $this->authorizeCompany($emailCampaign);

        if (in_array($emailCampaign->status, ['scheduled', 'sending'], true)) {
            $emailCampaign->update(['status' => 'cancelled']);
        }

        return back()->with('success', 'Campanha cancelada.');
    }

    private function validateData(Request $request): array
    {
        return $request->validate([
            'name' => 'required|string|max:150',
            'subject' => 'required|string|max:200',
            'body' => 'required|string',
            'audience' => 'required|in:all,active,overdue,specific',
            'client_ids' => 'nullable|array',
            'client_ids.*' => 'integer',
        ]);
    }

    private function audienceCounts(): array
    {
        $companyId = auth()->user()->company_id;

        return [
            'all' => Client::where('company_id', $companyId)->whereNotNull('email')->count(),
            'active' => Client::where('company_id', $companyId)->where('status', 'active')->whereNotNull('email')->count(),
            'overdue' => Client::where('company_id', $companyId)
                ->whereHas('invoices', fn ($q) => $q->where('status', 'overdue'))
                ->count(),
        ];
    }

    private function authorizeCompany(EmailCampaign $campaign): void
    {
        abort_unless($campaign->company_id === auth()->user()->company_id, 403);
    }
}
