<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Services\SsoService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;

class SocialiteController extends Controller
{
    public function __construct(private SsoService $sso) {}

    public function redirect(Request $request, string $provider): RedirectResponse
    {
        if (!in_array($provider, SsoService::PROVIDERS, true)) {
            abort(404);
        }

        $company = $this->sso->resolveCompany($request);
        if (!$company || !$this->sso->isProviderEnabled($company->id, $provider)) {
            return redirect()->route('login')->with('error', 'Login social indisponível.');
        }

        try {
            $driver = $this->driver($company->id, $provider);
        } catch (\Throwable $e) {
            return redirect()->route('login')->with('error', $e->getMessage());
        }

        $request->session()->put('sso_company_id', $company->id);

        return $driver->redirect();
    }

    public function callback(Request $request, string $provider): RedirectResponse
    {
        if (!in_array($provider, SsoService::PROVIDERS, true)) {
            abort(404);
        }

        $companyId = (int) $request->session()->pull('sso_company_id', 0);
        if (!$companyId || !$this->sso->isProviderEnabled($companyId, $provider)) {
            return redirect()->route('login')->with('error', 'Sessão de login social expirada. Tente novamente.');
        }

        try {
            $socialUser = $this->driver($companyId, $provider)->user();
        } catch (\Throwable $e) {
            return redirect()->route('login')->with('error', 'Falha na autenticação com ' . $this->sso->providerLabel($provider) . '.');
        }

        $email = strtolower((string) $socialUser->getEmail());
        if (!$email) {
            return redirect()->route('login')->with('error', 'Não foi possível obter o e-mail da conta social.');
        }

        $restrict = $this->sso->restrictDomain($companyId);
        if ($restrict !== '' && !str_ends_with($email, '@' . ltrim($restrict, '@'))) {
            return redirect()->route('login')->with('error', "Apenas e-mails do domínio {$restrict} são permitidos.");
        }

        $client = Client::where('company_id', $companyId)->where('email', $email)->first();

        if (!$client) {
            if (!$this->sso->autoCreate($companyId)) {
                return redirect()->route('login')->with('error', 'Conta não encontrada. Contate o suporte para criar seu acesso.');
            }
            $client = $this->createClient($companyId, $email, (string) $socialUser->getName());
        }

        if ($client->status === 'inactive' || $client->status === 'banned') {
            return redirect()->route('login')->with('error', 'Sua conta está inativa. Contate o suporte.');
        }

        Auth::guard('client')->login($client, true);

        return redirect()->intended(route('client.dashboard'))
            ->with('success', 'Login realizado com ' . $this->sso->providerLabel($provider) . '.');
    }

    private function createClient(int $companyId, string $email, string $name): Client
    {
        $parts = preg_split('/\s+/', trim($name), 2);

        $client = new Client([
            'company_id' => $companyId,
            'type' => 'individual',
            'firstname' => $parts[0] ?? Str::before($email, '@'),
            'lastname' => $parts[1] ?? '',
            'email' => $email,
            'email_verified_at' => now(),
            'status' => 'active',
        ]);
        $client->password = Hash::make(Str::random(40));
        $client->save();

        return $client;
    }

    /**
     * Constrói o driver Socialite com as credenciais da empresa.
     */
    private function driver(int $companyId, string $provider)
    {
        $creds = $this->sso->credentials($companyId, $provider);
        if (!$creds) {
            throw new \RuntimeException('Credenciais de ' . $this->sso->providerLabel($provider) . ' não configuradas.');
        }

        $config = [
            'client_id' => $creds['client_id'],
            'client_secret' => $creds['client_secret'],
            'redirect' => route('sso.callback', $provider),
        ];

        $providerClass = match ($provider) {
            'google' => \Laravel\Socialite\Two\GoogleProvider::class,
            'microsoft' => 'SocialiteProviders\\Microsoft\\Provider',
            default => null,
        };

        if (!$providerClass || !class_exists($providerClass)) {
            throw new \RuntimeException(
                'Provedor ' . $this->sso->providerLabel($provider) . ' indisponível. '
                . ($provider === 'microsoft' ? 'Instale o pacote socialiteproviders/microsoft.' : '')
            );
        }

        return Socialite::buildProvider($providerClass, $config);
    }
}
