<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WhatsappInstance;
use App\Services\WhatsApp\EvolutionGoService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class WhatsappInstanceController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        WhatsappInstance::where('company_id', $companyId)->each(function (WhatsappInstance $instance) {
            $instance->syncConfigFromEnv();
        });

        $instances = WhatsappInstance::where('company_id', $companyId)
            ->orderByDesc('is_default')
            ->latest()
            ->get();

        $primaryInstance = $instances->firstWhere('is_default', true) ?? $instances->first();

        $stats = [
            'total' => WhatsappInstance::where('company_id', $companyId)->count(),
            'connected' => WhatsappInstance::where('company_id', $companyId)->where('status', 'connected')->count(),
            'disconnected' => WhatsappInstance::where('company_id', $companyId)->where('status', 'disconnected')->count(),
            'connecting' => WhatsappInstance::where('company_id', $companyId)->where('status', 'connecting')->count(),
        ];

        return view('admin.whatsapp.instances.index', compact('instances', 'primaryInstance', 'stats'));
    }

    public function create(): View
    {
        $defaultConfig = [
            'api_url' => config('whatsapp.evolution_go.url') ?: config('services.evolution.url'),
            'api_key' => config('whatsapp.evolution_go.api_key') ?: config('services.evolution.api_key'),
            'instance_key' => config('whatsapp.evolution_go.instance') ?: config('services.evolution.instance'),
            'instance_token' => config('whatsapp.evolution_go.instance_token', ''),
            'provider' => 'evolution_go',
        ];

        return view('admin.whatsapp.instances.create', compact('defaultConfig'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'instance_key' => 'required|string|max:255|unique:whatsapp_instances,instance_key',
            'provider' => 'required|string|in:evolution_go,evolution_api',
            'api_url' => 'nullable|url',
            'api_key' => 'nullable|string',
            'evolution_token' => 'nullable|string|max:255',
        ]);

        $validated['company_id'] = auth()->user()->company_id;
        $validated = $this->normalizeInstanceInput($validated, $request);

        if (!empty($request->input('api_key'))) {
            $validated['api_key'] = encrypt($request->input('api_key'));
        } else {
            unset($validated['api_key']);
        }

        $instance = WhatsappInstance::create($validated);
        $instance = $this->prepareInstance($instance);

        try {
            $evolution = $this->serviceFor($instance);
            $apiName = $this->instanceKey($instance);

            if ($instance->provider === 'evolution_go') {
                $result = $this->linkEvolutionGoInstance($instance, $evolution, $apiName);

                if ($result instanceof RedirectResponse) {
                    return $result;
                }
            } else {
                $result = $evolution->connectInstance($apiName);

                if (!$result['success'] && $this->shouldCreateOnEvolution($result)) {
                    $result = $evolution->createInstance($apiName, ['name' => $instance->name]);
                }

                if (!$result['success'] && $this->instanceAlreadyExists($result)) {
                    $result = $evolution->connectInstance($apiName);
                }
            }

            if (!is_array($result) || !($result['success'] ?? false)) {
                $errorMessage = $result['message'] ?? 'Erro desconhecido ao criar instância na Evolution API';

                $instance->delete();

                return back()
                    ->withInput()
                    ->withErrors(['error' => 'Erro ao criar instância: ' . $errorMessage]);
            }

            $qrCode = $this->extractQrCode($result);
            $status = ($result['data']['connected'] ?? false) || ($result['already_connected'] ?? false)
                ? 'connected'
                : 'created';

            $updates = [
                'status' => $status,
                'qr_code' => $qrCode,
            ];

            if ($status === 'connected') {
                $updates['connected_at'] = $instance->connected_at ?? now();
                if ($phone = $this->extractPhoneFromJid($result['data']['jid'] ?? null)) {
                    $updates['phone_number'] = $phone;
                }
            }

            $instance->update($updates);

            return redirect()
                ->route('admin.whatsapp.instances.show', $instance)
                ->with('success', 'Instância criada com sucesso!');

        } catch (\Exception $e) {
            $instance->delete();

            \Log::error('Erro ao criar instância WhatsApp', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()
                ->withInput()
                ->withErrors(['error' => 'Erro ao criar instância: ' . $e->getMessage()]);
        }
    }

    public function show(WhatsappInstance $instance): View
    {
        $instance = $this->prepareInstance($instance);
        $evolution = $this->serviceFor($instance);
        $info = $evolution->getInstanceInfo($this->instanceKey($instance));

        return view('admin.whatsapp.instances.show', compact('instance', 'info'));
    }

    public function edit(WhatsappInstance $instance): View
    {
        return view('admin.whatsapp.instances.edit', compact('instance'));
    }

    public function update(Request $request, WhatsappInstance $instance): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'api_url' => 'nullable|url',
            'api_key' => 'nullable|string',
        ]);

        if (!empty($validated['api_key'])) {
            $validated['api_key'] = encrypt($validated['api_key']);
        } else {
            unset($validated['api_key']);
        }

        $instance->update($validated);

        return redirect()
            ->route('admin.whatsapp.instances.show', $instance)
            ->with('success', 'Instância atualizada com sucesso!');
    }

    public function destroy(WhatsappInstance $instance): RedirectResponse
    {
        $this->serviceFor($instance)->deleteInstance($this->instanceKey($instance));

        $instance->delete();

        return redirect()
            ->route('admin.whatsapp.instances.index')
            ->with('success', 'Instância excluída com sucesso!');
    }

    public function setDefault(WhatsappInstance $instance): RedirectResponse
    {
        WhatsappInstance::where('company_id', $instance->company_id)
            ->update(['is_default' => false]);

        $instance->update(['is_default' => true]);

        return redirect()
            ->route('admin.whatsapp.instances.index')
            ->with('success', 'Instância definida como padrão!');
    }

    public function connect(WhatsappInstance $instance): JsonResponse
    {
        $instance = $this->prepareInstance($instance);
        $key = $this->instanceKey($instance);
        if ($key === '') {
            return response()->json(['success' => false, 'message' => 'Instância sem chave configurada.'], 422);
        }

        $service = $this->serviceFor($instance);
        $result = $service->connectInstance($key);

        if (!$result['success'] && $instance->provider !== 'evolution_go' && $this->shouldCreateOnEvolution($result)) {
            $result = $service->createInstance($key, ['name' => $instance->name]);
        }

        if ($result['success']) {
            $instance->update([
                'qr_code' => $this->extractQrCode($result),
                'status' => 'connecting',
            ]);
        }

        return $this->jsonResponse($result);
    }

    public function disconnect(WhatsappInstance $instance): JsonResponse
    {
        $result = $this->serviceFor($instance)->disconnectInstance($this->instanceKey($instance));

        if ($result['success']) {
            $instance->update([
                'status' => 'disconnected',
                'qr_code' => null,
            ]);
        }

        return $this->jsonResponse($result);
    }

    public function restart(WhatsappInstance $instance): JsonResponse
    {
        $instance = $this->prepareInstance($instance);
        $result = $this->serviceFor($instance)->restartInstance($this->instanceKey($instance));

        if ($result['success']) {
            $instance->update([
                'status' => 'disconnected',
                'qr_code' => null,
            ]);
        }

        return $this->jsonResponse($result);
    }

    public function status(WhatsappInstance $instance): JsonResponse
    {
        $instance = $this->prepareInstance($instance);
        $result = $this->serviceFor($instance)->getInstanceStatus($this->instanceKey($instance));

        if ($result['success']) {
            $state = $result['data']['state'] ?? 'unknown';
            $status = ($result['data']['connected'] ?? false) ? 'connected' : $state;

            $instance->update(['status' => $status]);

            return response()->json([
                'success' => true,
                'status' => $status,
                'label' => match ($status) {
                    'connected' => 'Conectado',
                    'connecting' => 'Conectando',
                    'disconnected' => 'Desconectado',
                    default => ucfirst($status),
                },
                'data' => $result['data'] ?? [],
            ]);
        }

        return $this->jsonResponse($result);
    }

    public function qrcode(WhatsappInstance $instance): JsonResponse
    {
        $result = $this->serviceFor($instance)->getQrCode($this->instanceKey($instance));
        $qrCode = $this->extractQrCode($result);

        if ($result['success'] && $qrCode) {
            $instance->update(['qr_code' => $qrCode]);
        }

        return $this->jsonResponse($result, $qrCode);
    }

    public function webhook(Request $request, string $instanceName): JsonResponse
    {
        $instance = WhatsappInstance::where('instance_key', $instanceName)
            ->orWhere('instance_name', $instanceName)
            ->first();

        if (!$instance) {
            return response()->json(['error' => 'Instance not found'], 404);
        }

        \Log::info('WhatsApp Webhook received', [
            'instance' => $instanceName,
            'data' => $request->all(),
        ]);

        return response()->json(['status' => 'success']);
    }

    private function linkEvolutionGoInstance(WhatsappInstance $instance, EvolutionGoService $evolution, string $apiName): array|RedirectResponse
    {
        $token = $evolution->resolveInstanceToken($apiName);

        if (!$token) {
            $instance->delete();

            return back()
                ->withInput()
                ->withErrors(['error' => 'Instância "' . $apiName . '" não encontrada no Evolution Go. Confirme o nome no painel ou informe o Token UUID (opções avançadas).']);
        }

        $settings = $instance->settings ?? [];
        $settings['evolution_token'] = $token;
        $settings['evolution_instance_name'] = $apiName;
        $instance->update(['settings' => $settings]);

        $instance = $this->prepareInstance($instance->fresh());
        $evolution = $this->serviceFor($instance);

        $statusResult = $evolution->getInstanceStatus($apiName);

        if ($statusResult['success'] && ($statusResult['data']['connected'] ?? false)) {
            $raw = $statusResult['data']['raw'] ?? [];
            $instance->update([
                'status' => 'connected',
                'connected_at' => $instance->connected_at ?? now(),
                'phone_number' => $this->extractPhoneFromJid($raw['jid'] ?? $raw['Jid'] ?? null) ?: $instance->phone_number,
                'profile_name' => $raw['Name'] ?? $raw['name'] ?? $instance->profile_name,
            ]);

            return redirect()
                ->route('admin.whatsapp.instances.show', $instance)
                ->with('success', 'Instância vinculada! WhatsApp já está conectado no Evolution Go.');
        }

        return $evolution->connectInstance($apiName);
    }

    private function extractPhoneFromJid(?string $jid): ?string
    {
        if (!$jid || !is_string($jid)) {
            return null;
        }

        return preg_match('/^(\d+)/', $jid, $matches) ? $matches[1] : null;
    }

    private function shouldCreateOnEvolution(array $result): bool
    {
        $status = (int) ($result['status'] ?? 0);
        $message = strtolower((string) ($result['message'] ?? ''));

        return $status === 404
            || str_contains($message, 'not found')
            || str_contains($message, 'não encontrada')
            || str_contains($message, 'nao encontrada');
    }

    private function instanceAlreadyExists(array $result): bool
    {
        $message = strtolower((string) ($result['message'] ?? ''));

        return str_contains($message, 'already exists')
            || str_contains($message, 'já existe')
            || str_contains($message, 'ja existe');
    }

    private function serviceFor(WhatsappInstance $instance): EvolutionGoService
    {
        return new EvolutionGoService($instance);
    }

    private function instanceKey(WhatsappInstance $instance): string
    {
        return $instance->getEvolutionApiName();
    }

    private function prepareInstance(WhatsappInstance $instance): WhatsappInstance
    {
        $instance->syncConfigFromEnv();

        return $instance->fresh();
    }

    private function normalizeInstanceInput(array $validated, Request $request): array
    {
        $token = trim((string) $request->input('evolution_token', ''));
        if ($token === '') {
            $token = trim((string) config('whatsapp.evolution_go.instance_token', ''));
        }

        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $validated['instance_key'])) {
            $token = $token ?: $validated['instance_key'];
            $validated['instance_key'] = config('whatsapp.evolution_go.instance', 'centralvix');
        }

        $settings = [];
        if ($token !== '') {
            $settings['evolution_token'] = $token;
        }
        $settings['evolution_instance_name'] = $validated['instance_key'];
        $validated['settings'] = $settings;

        $validated['api_url'] = WhatsappInstance::normalizeApiUrl(
            $validated['api_url']
                ?: config('whatsapp.evolution_go.url')
                ?: config('services.evolution.url', '')
        );

        return $validated;
    }

    private function extractQrCode(array $result): ?string
    {
        $qr = $result['qrcode'] ?? null;

        if (is_array($qr)) {
            $qr = $qr['base64'] ?? $qr['code'] ?? null;
        }

        if (!$qr && isset($result['data']) && is_array($result['data'])) {
            $data = $result['data'];
            $qr = $data['qrcode'] ?? $data['base64'] ?? null;

            if (is_array($qr)) {
                $qr = $qr['base64'] ?? $qr['code'] ?? null;
            }
        }

        if (is_string($qr) && str_starts_with($qr, 'data:image')) {
            $qr = preg_replace('#^data:image/[^;]+;base64,#', '', $qr);
        }

        return is_string($qr) && $qr !== '' ? $qr : null;
    }

    private function jsonResponse(array $result, ?string $qrCode = null): JsonResponse
    {
        $qrCode ??= $this->extractQrCode($result);

        return response()->json([
            'success' => (bool) ($result['success'] ?? false),
            'message' => $result['message'] ?? '',
            'error' => $result['error'] ?? null,
            'qrcode' => $qrCode,
            'qr_code' => $qrCode,
            'status' => $result['data']['state'] ?? ($result['status'] ?? null),
            'data' => $result['data'] ?? null,
        ]);
    }
}
