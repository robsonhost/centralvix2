<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SecurityQuestion;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SecurityQuestionController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        $questions = SecurityQuestion::withCount('answers')
            ->where('company_id', $companyId)
            ->orderBy('order')
            ->orderBy('question')
            ->get();

        return view('admin.settings.security-questions.index', compact('questions'));
    }

    public function create(): View
    {
        return view('admin.settings.security-questions.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'question' => 'required|string',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $validated['company_id'] = auth()->user()->company_id;

        SecurityQuestion::create($validated);

        return redirect()->route('admin.settings.security-questions.index')
            ->with('success', 'Pergunta de segurança criada com sucesso!');
    }

    public function edit(SecurityQuestion $securityQuestion): View
    {
        return view('admin.settings.security-questions.edit', compact('securityQuestion'));
    }

    public function update(Request $request, SecurityQuestion $securityQuestion): RedirectResponse
    {
        $validated = $request->validate([
            'question' => 'required|string',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $securityQuestion->update($validated);

        return redirect()->route('admin.settings.security-questions.index')
            ->with('success', 'Pergunta de segurança atualizada com sucesso!');
    }

    public function destroy(SecurityQuestion $securityQuestion): RedirectResponse
    {
        $securityQuestion->delete();

        return redirect()->route('admin.settings.security-questions.index')
            ->with('success', 'Pergunta de segurança removida com sucesso!');
    }
}
