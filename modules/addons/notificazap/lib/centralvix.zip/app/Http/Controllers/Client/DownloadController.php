<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Download;
use App\Models\DownloadCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DownloadController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $category = $request->input('category');
        $sort = $request->input('sort', 'recent');
        
        $downloads = Download::where('status', 'active')
            ->with('category')
            ->when($search, function($query, $search) {
                $query->where(function($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('description', 'like', "%{$search}%");
                });
            })
            ->when($category && $category !== 'all', function($query) use ($category) {
                $query->where('category_id', $category);
            })
            ->when($sort === 'popular', function($query) {
                $query->orderBy('downloads_count', 'desc');
            })
            ->when($sort === 'name', function($query) {
                $query->orderBy('name');
            })
            ->when($sort === 'size', function($query) {
                $query->orderBy('file_size');
            })
            ->when($sort === 'recent', function($query) {
                $query->latest();
            })
            ->get();
        
        $categories = DownloadCategory::withCount('downloads')->get();
        
        $stats = [
            'total' => Download::count(),
            'by_category' => DownloadCategory::withCount('downloads')->get()
        ];
        
        return view('client.downloads.index', compact('downloads', 'categories', 'stats'));
    }
    
    public function download(Download $download)
    {
        $path = $download->file_path;

        // Caminho ausente ou arquivo não existe → mensagem amigável
        if (! is_string($path) || $path === '' || ! Storage::disk('public')->exists($path)) {
            return back()->withErrors(['error' => 'Arquivo não encontrado.']);
        }

        $download->increment('downloads_count');

        activity()
            ->causedBy(auth()->user())
            ->performedOn($download)
            ->log('Baixou arquivo: ' . $download->name);

        return Storage::disk('public')->download($path, $download->filename ?: basename($path));
    }
}
