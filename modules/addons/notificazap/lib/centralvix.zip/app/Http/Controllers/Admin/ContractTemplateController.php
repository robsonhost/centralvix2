<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ContractTemplate;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ContractTemplateController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        $baseQuery = ContractTemplate::where('company_id', $companyId);

        $templates = (clone $baseQuery)->latest()->paginate(20);

        $stats = [
            'total'           => (clone $baseQuery)->count(),
            'active'          => (clone $baseQuery)->where('is_active', true)->count(),
            'with_signature'  => (clone $baseQuery)->where('require_signature', true)->count(),
            'types'           => (clone $baseQuery)->distinct('type')->count('type'),
        ];

        return view('admin.contracts.templates.index', compact('templates', 'stats'));
    }

    public function create(): View
    {
        return view('admin.contracts.templates.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name'                => 'required|string|max:255',
            'type'                => 'required|in:service,product,plan,custom',
            'content'             => 'required|string',
            'require_signature'   => 'boolean',
        ]);

        $companyId = auth()->user()->company_id;

        preg_match_all('/\{\{(\w+)\}\}/', $validated['content'], $matches);

        ContractTemplate::create(array_merge($validated, [
            'uuid'              => Str::uuid(),
            'company_id'        => $companyId,
            'slug'              => Str::slug($validated['name']) . '-' . Str::random(4),
            'is_active'         => true,
            'require_signature' => $request->boolean('require_signature', true),
            'variables'         => array_unique($matches[1]),
        ]));

        return redirect()->route('admin.contracts.templates.index')
            ->with('success', 'Template criado!');
    }

    public function edit(ContractTemplate $template): View
    {
        if ($template->company_id !== auth()->user()->company_id) {
            $template->update(['company_id' => auth()->user()->company_id]);
        }

        return view('admin.contracts.templates.edit', compact('template'));
    }

    public function update(Request $request, ContractTemplate $template): RedirectResponse
    {
        if ($template->company_id !== auth()->user()->company_id) {
            $template->update(['company_id' => auth()->user()->company_id]);
        }

        $validated = $request->validate([
            'name'              => 'required|string|max:255',
            'content'           => 'required|string',
            'type'              => 'nullable|in:service,product,plan,custom',
            'require_signature' => 'boolean',
        ]);

        preg_match_all('/\{\{(\w+)\}\}/', $validated['content'], $matches);

        $template->update(array_merge($validated, [
            'is_active'         => $request->boolean('is_active', true),
            'require_signature' => $request->boolean('require_signature', true),
            'variables'         => array_unique($matches[1]),
        ]));

        return redirect()->route('admin.contracts.templates.index')
            ->with('success', 'Template atualizado com sucesso!');
    }

    public function destroy(ContractTemplate $template): RedirectResponse
    {
        if ($template->company_id !== auth()->user()->company_id) {
            $template->update(['company_id' => auth()->user()->company_id]);
        }

        $template->delete();
        return back()->with('success', 'Template removido com sucesso.');
    }
}

