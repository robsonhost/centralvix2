<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\ClientGroup;
use App\Models\Company;
use App\Mail\WelcomeClientMail;
use App\Services\WhatsappService;
use App\Services\ClientNotificationTemplates;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Illuminate\Support\Facades\Response;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ClientsExport;
use App\Imports\ClientsImport;

class ClientController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Client::with(['group', 'services'])
            ->where('company_id', $companyId)
            ->withCount('services');

        // Filtro por nome ou empresa
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('firstname', 'like', "%{$search}%")
                  ->orWhere('lastname', 'like', "%{$search}%")
                  ->orWhere('company_name', 'like', "%{$search}%")
                  ->orWhere('client_code', 'like', "%{$search}%")
                  ->orWhere('cpf', 'like', "%{$search}%")
                  ->orWhere('cnpj', 'like', "%{$search}%");
            });
        }

        // Filtro por email
        if ($request->filled('email')) {
            $query->where('email', 'like', "%{$request->email}%");
        }

        // Filtro por telefone
        if ($request->filled('phone')) {
            $phone = preg_replace('/[^0-9]/', '', $request->phone);
            $query->where(function ($q) use ($phone) {
                $q->where('phone', 'like', "%{$phone}%")
                  ->orWhere('mobile', 'like', "%{$phone}%");
            });
        }

        // Filtro por status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filtro por grupo
        if ($request->filled('group')) {
            $query->where('group_id', $request->group);
        }

        // Sorting
        $sort = $request->get('sort', 'created_desc');
        switch ($sort) {
            case 'created_asc':
                $query->oldest();
                break;
            case 'name_asc':
                $query->orderBy('firstname')->orderBy('lastname');
                break;
            case 'name_desc':
                $query->orderByDesc('firstname')->orderByDesc('lastname');
                break;
            case 'id_asc':
                $query->orderBy('id');
                break;
            case 'id_desc':
                $query->orderByDesc('id');
                break;
            default:
                $query->latest();
        }

        $clients = $query->paginate(20);
        $groups = ClientGroup::where('company_id', $companyId)->get();

        // Statistics
        $stats = [
            'total' => Client::where('company_id', $companyId)->count(),
            'active' => Client::where('company_id', $companyId)->where('status', 'active')->count(),
            'suspended' => Client::where('company_id', $companyId)->where('status', 'suspended')->count(),
            'inactive' => Client::where('company_id', $companyId)->where('status', 'inactive')->count(),
            'closed' => Client::where('company_id', $companyId)->where('status', 'closed')->count(),
            'new' => Client::where('company_id', $companyId)->where('created_at', '>=', now()->subDays(30))->count(),
            'total_services' => Client::where('company_id', $companyId)->withCount('services')->get()->sum('services_count'),
        ];

        return view('admin.clients.index', [
            'clients' => $clients,
            'groups' => $groups,
            'stats' => $stats,
            'notificationTemplates' => ClientNotificationTemplates::all(),
            'notificationVariables' => ClientNotificationTemplates::variables(),
        ]);
    }

    public function sendNotification(Request $request, Client $client): JsonResponse
    {
        $this->authorizeCompany($client);

        $validated = $request->validate([
            'template_id' => 'nullable|string|max:64',
            'message'     => 'required|string|min:10|max:4000',
            'channel'     => 'required|in:whatsapp,email',
        ]);

        $message = ClientNotificationTemplates::render($validated['message'], $client);

        $sent = false;
        $error = null;

        try {
            if ($validated['channel'] === 'whatsapp') {
                $phone = $client->mobile ?: $client->phone;
                if (!$phone) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Cliente não possui telefone/WhatsApp cadastrado.',
                    ], 422);
                }
                $sent = WhatsappService::sendMessage($phone, $message);
                if (!$sent) {
                    $error = 'Falha ao enviar via WhatsApp. Verifique se a instância está conectada.';
                }
            } else {
                Mail::raw(strip_tags(str_replace(['*', '`'], '', $message)), function ($mail) use ($client) {
                    $companyName = Company::find($client->company_id)?->name ?? config('app.name');
                    $mail->to($client->email)
                         ->subject('Notificação — ' . $companyName);
                });
                $sent = true;
            }
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao enviar: ' . $e->getMessage(),
            ], 500);
        }

        if (!$sent) {
            return response()->json([
                'success' => false,
                'message' => $error ?? 'Não foi possível enviar a notificação.',
            ], 422);
        }

        return response()->json([
            'success' => true,
            'message' => 'Notificação enviada com sucesso para ' . trim($client->firstname . ' ' . $client->lastname),
        ]);
    }

    public function notificationTemplates(): JsonResponse
    {
        return response()->json([
            'templates'  => ClientNotificationTemplates::all(),
            'variables'  => ClientNotificationTemplates::variables(),
        ]);
    }

    public function create(): View
    {
        $companyId = auth()->user()->company_id;
        $groups = ClientGroup::where('company_id', $companyId)->where('status', 'active')->get();
        return view('admin.clients.create_new', compact('groups'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'type' => 'required|in:individual,company',
            'firstname' => 'required_if:type,individual|string|max:100',
            'lastname' => 'nullable|string|max:100',
            'email' => 'required|email|max:255|unique:clients,email',
            'phone' => 'nullable|string|max:20',
            'mobile' => 'nullable|string|max:20',
            'cpf' => 'required_if:type,individual|nullable|string|max:14',
            'cnpj' => 'required_if:type,company|nullable|string|max:18',
            'company_name' => 'required_if:type,company|nullable|string|max:255',
            'contact_name' => 'nullable|string|max:255',
            'state_registration' => 'nullable|string|max:50',
            'municipal_registration' => 'nullable|string|max:50',
            'address' => 'nullable|string|max:255',
            'address_number' => 'nullable|string|max:20',
            'address_complement' => 'nullable|string|max:100',
            'neighborhood' => 'nullable|string|max:100',
            'city' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:2',
            'zip' => 'nullable|string|max:10',
            'country' => 'nullable|string|max:2',
            'notes' => 'nullable|string',
            'group_id' => 'nullable|exists:client_groups,id',
            'status' => 'nullable|in:active,inactive,suspended',
            'password' => 'nullable|string|min:8|confirmed',
            'send_welcome_email' => 'nullable|boolean',
            'send_whatsapp_notification' => 'nullable|boolean',
        ]);

        $companyId = auth()->user()->company_id;
        
        // Verificar limite de clientes da licença
        $company = auth()->user()->company;
        $currentClientsCount = Client::where('company_id', $companyId)->count();
        $maxClients = $company->max_clients ?? 50; // Padrão: 50 clientes
        
        if ($currentClientsCount >= $maxClients) {
            return redirect()->back()
                ->withInput()
                ->with('error', "Limite de clientes atingido! Sua licença permite até {$maxClients} clientes cadastrados. Atualmente você possui {$currentClientsCount} clientes. Entre em contato para expandir sua licença.");
        }
        
        // Gerar código do cliente
        $clientCode = 'CLI-' . strtoupper(Str::random(8));
        
        // Gerar senha se não fornecida
        $plainPassword = null;
        if ($request->filled('password')) {
            $validated['password'] = Hash::make($request->password);
            $plainPassword = $request->password;
        } else {
            $plainPassword = Str::random(12);
            $validated['password'] = Hash::make($plainPassword);
        }

        // Criar cliente
        $client = Client::create(array_merge($validated, [
            'uuid' => Str::uuid(),
            'client_code' => $clientCode,
            'company_id' => $companyId,
            'currency' => 'BRL',
            'language' => 'pt_BR',
            'status' => $request->status ?? 'active',
        ]));

        // Enviar notificações
        try {
            if ($request->send_welcome_email) {
                Mail::to($client->email)->send(new WelcomeClientMail($client, $plainPassword));
            }

            if ($request->send_whatsapp_notification && $client->mobile) {
                WhatsappService::sendWelcomeMessage($client, $plainPassword);
            }
        } catch (\Exception $e) {
            \Log::error('Erro ao enviar notificação: ' . $e->getMessage());
        }

        $message = 'Cliente criado com sucesso!';
        if ($plainPassword) {
            $message .= ' Senha gerada: ' . $plainPassword;
        }

        // Verificar ação
        if ($request->action === 'save_and_new') {
            return redirect()->route('admin.clients.create')
                ->with('success', $message);
        }

        return redirect()->route('admin.clients.show', $client)
            ->with('success', $message);
    }

    public function show(Client $client): View
    {
        $this->authorizeCompany($client);

        $client->load([
            'services', 'invoices', 'tickets', 'domains', 'orders', 'group'
        ]);

        $stats = [
            'active_services' => $client->services()->where('status', 'active')->count(),
            'unpaid_invoices' => $client->invoices()->whereIn('status', ['unpaid', 'overdue'])->count(),
            'open_tickets' => $client->tickets()->whereNotIn('status', ['closed'])->count(),
            'total_spent' => $client->transactions()->where('status', 'completed')->where('type', 'payment')->sum('amount'),
        ];

        return view('admin.clients.show', [
            'client' => $client,
            'stats' => $stats,
            'notificationTemplates' => ClientNotificationTemplates::all(),
            'notificationVariables' => ClientNotificationTemplates::variables(),
        ]);
    }

    public function edit(Client $client): View
    {
        $this->authorizeCompany($client);

        $companyId = auth()->user()->company_id;
        $groups = ClientGroup::where('company_id', $companyId)->where('status', 'active')->get();

        return view('admin.clients.edit', compact('client', 'groups'));
    }

    public function update(Request $request, Client $client): RedirectResponse
    {
        $this->authorizeCompany($client);

        $validated = $request->validate([
            'firstname' => 'required|string|max:100',
            'lastname' => 'required|string|max:100',
            'email' => 'required|email|max:255',
            'type' => 'required|in:individual,company',
            'phone' => 'nullable|string|max:20',
            'mobile' => 'nullable|string|max:20',
            'cpf' => 'nullable|string|max:14',
            'cnpj' => 'nullable|string|max:18',
            'company_name' => 'nullable|string|max:255',
            'address' => 'nullable|string|max:255',
            'address_number' => 'nullable|string|max:20',
            'city' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:2',
            'zip' => 'nullable|string|max:10',
            'notes' => 'nullable|string',
            'internal_notes' => 'nullable|string',
            'group_id' => 'nullable|exists:client_groups,id',
            'status' => 'required|in:active,suspended,inactive,banned',
        ]);

        $client->update($validated);

        return redirect()->route('admin.clients.show', $client)
            ->with('success', 'Cliente atualizado com sucesso!');
    }

    public function destroy(Client $client): RedirectResponse
    {
        $this->authorizeCompany($client);

        $client->delete();

        return redirect()->route('admin.clients.index')
            ->with('success', 'Cliente removido com sucesso!');
    }

    public function suspend(Client $client): RedirectResponse
    {
        $this->authorizeCompany($client);
        $client->update(['status' => 'suspended']);
        return back()->with('success', 'Cliente suspenso.');
    }

    public function activate(Client $client): RedirectResponse
    {
        $this->authorizeCompany($client);
        $client->update(['status' => 'active']);
        return back()->with('success', 'Cliente ativado.');
    }

    public function addCredit(Request $request, Client $client): RedirectResponse
    {
        $this->authorizeCompany($client);

        $data = $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'description' => 'nullable|string|max:255',
        ]);

        app(\App\Services\WalletService::class)->credit(
            $client,
            (float) $data['amount'],
            'manual',
            $data['description'] ?? 'Crédito adicionado pelo administrador',
            null,
            auth()->id(),
        );

        return back()->with('success', 'Crédito adicionado com sucesso.');
    }

    /**
     * Impersonate (Logar como cliente)
     */
    public function impersonate(Client $client): RedirectResponse
    {
        $this->authorizeCompany($client);

        // Verificar se o cliente tem user_id, se não tiver, criar automaticamente
        if (!$client->user_id) {
            try {
                // Verificar se já existe um usuário com este email
                $existingUser = \App\Models\User::where('email', $client->email)->first();
                
                if ($existingUser) {
                    // Vincular ao usuário existente
                    $client->user_id = $existingUser->id;
                    $client->save();
                    $user = $existingUser;
                } else {
                    // Criar novo usuário automaticamente
                    $user = \App\Models\User::create([
                        'uuid' => \Illuminate\Support\Str::uuid(),
                        'company_id' => $client->company_id,
                        'name' => trim($client->firstname . ' ' . $client->lastname),
                        'email' => $client->email,
                        'email_verified_at' => now(),
                        'password' => \Illuminate\Support\Facades\Hash::make(\Illuminate\Support\Str::random(16)),
                        'phone' => $client->phone ?? $client->mobile ?? $client->whatsapp,
                        'whatsapp' => $client->whatsapp ?? $client->phone ?? $client->mobile,
                        'cpf_cnpj' => $client->cpf ?? $client->cnpj,
                        'status' => $client->status ?? 'active',
                    ]);
                    
                    // Vincular ao cliente
                    $client->user_id = $user->id;
                    $client->save();
                }
                
                \Log::info("Usuário criado/vinculado automaticamente para cliente {$client->id}");
                
            } catch (\Exception $e) {
                \Log::error("Erro ao criar usuário para cliente {$client->id}: " . $e->getMessage());
                return back()->with('error', 'Erro ao criar conta de usuário: ' . $e->getMessage());
            }
        } else {
            // Buscar o user associado
            $user = \App\Models\User::find($client->user_id);
            
            if (!$user) {
                return back()->with('error', 'Usuário do cliente não encontrado.');
            }
        }

        // Verificar se o cliente está ativo
        if ($client->status !== 'active' && $user->status !== 'active') {
            return back()->with('error', 'Não é possível fazer login como um cliente inativo ou suspenso.');
        }

        // Salvar ID do admin na sessão
        session([
            'impersonate_from' => auth()->id(),
            'impersonate_from_guard' => 'web',
            'impersonate_client_id' => $client->id
        ]);

        // Fazer logout do admin
        Auth::guard('web')->logout();

        // Fazer login como o user do cliente
        Auth::guard('web')->login($user);

        return redirect()->route('client.dashboard')
            ->with('success', 'Você está acessando como: ' . $client->display_name);
    }

    /**
     * Parar impersonation (Voltar para admin)
     */
    public function stopImpersonating(): RedirectResponse
    {
        if (!session()->has('impersonate_from')) {
            return redirect()->route('admin.dashboard')
                ->with('error', 'Você não está acessando como cliente.');
        }

        $adminId = session('impersonate_from');
        
        // Fazer logout do cliente
        Auth::guard('web')->logout();
        
        // Limpar sessão
        session()->forget(['impersonate_from', 'impersonate_from_guard', 'impersonate_client_id']);
        
        // Logar novamente como admin
        Auth::guard('web')->loginUsingId($adminId);

        return redirect()->route('admin.clients.index')
            ->with('success', 'Você voltou para sua conta de administrador.');
    }

    /**
     * Resetar senha do cliente
     */
    public function resetPassword(Request $request, Client $client): RedirectResponse
    {
        $this->authorizeCompany($client);

        $request->validate([
            'new_password' => 'required|string|min:8|confirmed',
        ]);

        // Atualizar senha
        $client->password = Hash::make($request->new_password);
        $client->save();

        // Enviar email ao cliente com a nova senha
        try {
            Mail::to($client->email)->send(new \App\Mail\PasswordResetByAdminMail($client, $request->new_password));
        } catch (\Exception $e) {
            \Log::error('Erro ao enviar email de reset de senha: ' . $e->getMessage());
        }

        // Log da atividade
        activity()
            ->performedOn($client)
            ->causedBy(auth()->user())
            ->log('Senha resetada pelo administrador');

        return back()->with('success', 'Senha alterada com sucesso! Um email foi enviado ao cliente.');
    }

    /**
     * Exportar clientes para Excel/XLS
     */
    public function export(Request $request)
    {
        $companyId = auth()->user()->company_id;

        $query = Client::with(['group', 'services'])
            ->where('company_id', $companyId);

        // Aplicar mesmos filtros da listagem
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('firstname', 'like', "%{$search}%")
                  ->orWhere('lastname', 'like', "%{$search}%")
                  ->orWhere('company_name', 'like', "%{$search}%")
                  ->orWhere('client_code', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('group')) {
            $query->where('group_id', $request->group);
        }

        $filename = 'clientes_' . date('Y-m-d_H-i-s') . '.xlsx';

        return Excel::download(new ClientsExport($query), $filename);
    }

    /**
     * Importar clientes de arquivo Excel/XLS
     */
    public function import(Request $request): RedirectResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv|max:10240',
        ]);

        try {
            $companyId = auth()->user()->company_id;
            $import = new ClientsImport($companyId);
            
            Excel::import($import, $request->file('file'));

            $message = "Importação concluída! {$import->imported} clientes importados, {$import->skipped} ignorados, {$import->errors} erros.";
            return redirect()->route('admin.clients.index')->with('success', $message);

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Erro ao importar arquivo: ' . $e->getMessage());
        }
    }

    /**
     * Importar dados do banco WHMCS
     */
    public function importWhmcs(Request $request): RedirectResponse
    {
        try {
            // Executar comando de importação
            \Artisan::call('whmcs:import', [
                '--all' => true
            ]);

            $output = \Artisan::output();

            return redirect()->route('admin.clients.index')
                ->with('success', 'Importação do WHMCS iniciada com sucesso! Verifique o log para detalhes.');

        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Erro ao importar do WHMCS: ' . $e->getMessage());
        }
    }

    private function getStatusLabel($status): string
    {
        $labels = [
            'active' => 'Ativo',
            'inactive' => 'Inativo',
            'suspended' => 'Suspenso',
            'closed' => 'Fechado',
            'banned' => 'Banido',
        ];

        return $labels[$status] ?? $status;
    }

    private function getStatusValue($label): string
    {
        $values = [
            'Ativo' => 'active',
            'Inativo' => 'inactive',
            'Suspenso' => 'suspended',
            'Fechado' => 'closed',
            'Banido' => 'banned',
        ];

        return $values[$label] ?? 'inactive';
    }

    private function authorizeCompany(Client $client): void
    {
        if ($client->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }
}
