<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Download;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class DownloadController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        $downloads = Download::where('company_id', $companyId)->latest()->paginate(20);

        $base = Download::where('company_id', $companyId);
        $stats = [
            'total'           => (clone $base)->count(),
            'public'          => (clone $base)->where('access', 'public')->count(),
            'client'          => (clone $base)->where('access', 'client')->count(),
            'product'         => (clone $base)->where('access', 'product')->count(),
            'total_size'      => (clone $base)->sum('size') ?? 0,
            'total_downloads' => (clone $base)->sum('download_count') ?? 0,
        ];
        
        // Agrupar por tipo
        $byType = $downloads->groupBy(function($download) {
            return $download->mime_type ?? 'other';
        })->map->count();
        
        return view('admin.downloads.index', compact('downloads', 'stats', 'byType'));
    }

    public function create(): View
    {
        return view('admin.downloads.index');
    }

    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'name'   => 'required|string|max:255',
            'file'   => 'required|file|max:102400',
            'access' => 'required|in:public,client,product',
        ]);

        $companyId = auth()->user()->company_id;

        $file = $request->file('file');
        $path = $file->store("downloads/{$companyId}", 'public');

        Download::create([
            'company_id'  => $companyId,
            'name'        => $request->name,
            'description' => $request->description,
            'path'        => $path,
            'filename'    => $file->getClientOriginalName(),
            'size'        => $file->getSize(),
            'mime_type'   => $file->getMimeType(),
            'access'      => $request->access,
            'status'      => 'active',
        ]);

        return back()->with('success', 'Arquivo enviado com sucesso!');
    }

    public function destroy(Download $download): RedirectResponse
    {
        if ($download->company_id !== auth()->user()->company_id) abort(403);
        if ($download->path && Storage::disk('public')->exists($download->path)) {
            Storage::disk('public')->delete($download->path);
        }
        $download->delete();
        return back()->with('success', 'Arquivo removido.');
    }

    public function download(Download $download): StreamedResponse
    {
        if ($download->company_id !== auth()->user()->company_id) abort(403);

        if (!Storage::disk('public')->exists($download->path)) {
            abort(404, 'Arquivo não encontrado.');
        }

        $download->increment('download_count');

        return Storage::disk('public')->download(
            $download->path,
            $download->filename ?? basename($download->path)
        );
    }
}
