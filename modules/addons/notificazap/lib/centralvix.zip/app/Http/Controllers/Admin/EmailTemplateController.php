<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\EmailTemplate;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class EmailTemplateController extends Controller
{
    private function sampleData(): array
    {
        return [
            'client_name' => 'João Silva',
            'client_email' => 'joao@email.com',
            'client_firstname' => 'João',
            'client_lastname' => 'Silva',
            'client_phone' => '(27) 99999-9999',
            'company_name' => config('app.name'),
            'company_email' => config('mail.from.address', 'contato@centralvix.com.br'),
            'company_phone' => '(27) 3333-3333',
            'invoice_number' => 'INV2026001234',
            'invoice_total' => 'R$ 150,00',
            'due_date' => now()->addDays(7)->format('d/m/Y'),
            'payment_link' => config('app.url') . '/client/invoices/1',
            'service_name' => 'Hospedagem Premium',
            'domain' => 'exemplo.com.br',
            'username' => 'exemplo',
            'password' => '********',
            'server_ip' => '192.168.1.1',
            'ticket_id' => '5678',
            'ticket_subject' => 'Suporte Técnico',
            'ticket_link' => config('app.url') . '/client/tickets/5678',
        ];
    }
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        $templates = EmailTemplate::where('company_id', $companyId)->get();
        
        // Estatísticas
        $stats = [
            'total' => $templates->count(),
            'active' => $templates->where('status', 'active')->count(),
            'inactive' => $templates->where('status', 'inactive')->count(),
        ];
        
        // Agrupar por categoria/tipo
        $categorizedTemplates = $templates->groupBy(function($template) {
            return $template->category ?? 'Geral';
        });
        
        return view('admin.email-templates.index', compact('templates', 'stats', 'categorizedTemplates'));
    }

    public function edit(EmailTemplate $emailTemplate): View
    {
        if ($emailTemplate->company_id !== auth()->user()->company_id) abort(403);
        return view('admin.email-templates.edit', compact('emailTemplate'));
    }

    public function update(Request $request, EmailTemplate $emailTemplate): RedirectResponse
    {
        if ($emailTemplate->company_id !== auth()->user()->company_id) abort(403);

        $validated = $request->validate([
            'subject'   => 'required|string|max:500',
            'body_html' => 'required|string',
            'body_text' => 'nullable|string',
            'status'    => 'required|in:active,inactive',
        ]);

        $emailTemplate->update($validated);
        return back()->with('success', 'Template atualizado com sucesso!');
    }

    public function preview(EmailTemplate $emailTemplate): JsonResponse
    {
        if ($emailTemplate->company_id !== auth()->user()->company_id) abort(403);

        $rendered = $emailTemplate->render($this->sampleData());

        return response()->json([
            'success' => true,
            'subject' => $rendered['subject'],
            'body_html' => $rendered['bodyHtml'],
            'body_text' => $rendered['bodyText'],
        ]);
    }

    public function sendTest(Request $request, EmailTemplate $emailTemplate): JsonResponse
    {
        if ($emailTemplate->company_id !== auth()->user()->company_id) abort(403);

        $request->validate(['email' => 'required|email']);

        try {
            $rendered = $emailTemplate->render($this->sampleData());

            \Mail::send([], [], function ($message) use ($request, $rendered, $emailTemplate) {
                $message->to($request->email)
                    ->subject('[TESTE] ' . $rendered['subject'])
                    ->html($rendered['bodyHtml']);
                if (!empty($rendered['bodyText'])) {
                    $message->text($rendered['bodyText']);
                }
            });

            return response()->json([
                'success' => true,
                'message' => 'E-mail de teste enviado para ' . $request->email,
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Erro ao enviar: ' . $e->getMessage()], 500);
        }
    }
}
