<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\KnowledgeBaseArticle;
use App\Models\KnowledgeBaseCategory;
use Illuminate\Http\Request;

class KnowledgebaseController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');

        $client = auth()->user()->client;
        if (!$client) {
            abort(403, 'Cliente não encontrado');
        }

        $companyId = $client->company_id;

        $categories = KnowledgeBaseCategory::withCount(['articles' => function ($q) use ($companyId) {
                $q->where('company_id', $companyId)->where('status', 'published');
            }])
            ->where('company_id', $companyId)
            ->active()
            ->orderBy('order')
            ->get();

        $articles = KnowledgeBaseArticle::where('company_id', $companyId)
            ->where('status', 'published')
            ->with('category')
            ->when($search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('title', 'like', "%{$search}%")
                      ->orWhere('content', 'like', "%{$search}%");
                    if (\Illuminate\Support\Facades\Schema::hasColumn('knowledge_base_articles', 'tags')) {
                        $q->orWhere('tags', 'like', "%{$search}%");
                    }
                });
            })
            ->orderByDesc('views')
            ->limit(20)
            ->get();

        return view('client.knowledgebase.index', compact('categories', 'articles', 'search'));
    }

    public function show(KnowledgeBaseArticle $article)
    {
        $client = auth()->user()->client;
        if (!$client) {
            abort(403, 'Cliente não encontrado');
        }

        abort_unless(
            $article->company_id === $client->company_id && $article->status === 'published',
            404
        );

        $article->increment('views');

        $relatedArticles = KnowledgeBaseArticle::where('company_id', $article->company_id)
            ->where('status', 'published')
            ->where('category_id', $article->category_id)
            ->where('id', '!=', $article->id)
            ->orderByDesc('views')
            ->limit(5)
            ->get();

        return view('client.knowledgebase.show', compact('article', 'relatedArticles'));
    }
}
