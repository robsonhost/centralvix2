<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Service;
use App\Services\UpgradeService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ServiceUpgradeController extends Controller
{
    public function __construct(private UpgradeService $upgradeService)
    {
    }

    public function show(Service $service, Request $request): View
    {
        $this->authorizeService($service);
        $service->load(['product', 'client']);

        $products = Product::where('company_id', $service->company_id)
            ->where('status', 'active')
            ->where('id', '!=', $service->product_id)
            ->orderBy('name')
            ->get();

        $selected = $request->filled('product_id')
            ? Product::find($request->product_id)
            : null;

        $quote = null;
        if ($selected) {
            $cycle = $request->get('billing_cycle', $service->billing_cycle);
            $quote = $this->upgradeService->quote($service, $selected, $cycle);
        }

        return view('client.services.upgrade', compact('service', 'products', 'selected', 'quote'));
    }

    public function apply(Request $request, Service $service): RedirectResponse
    {
        $this->authorizeService($service);

        $data = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'billing_cycle' => ['required', 'string'],
        ]);

        $product = Product::findOrFail($data['product_id']);
        $updated = $this->upgradeService->apply($service, $product, $data['billing_cycle']);

        if ($invoice = $updated->latestUpgradeInvoice ?? null) {
            return redirect()->route('client.invoices.show', $invoice)
                ->with('success', 'Upgrade solicitado. Pague a fatura para concluir.');
        }

        return redirect()->route('client.services.show', $service)
            ->with('success', 'Plano alterado com sucesso.');
    }

    private function authorizeService(Service $service): void
    {
        if (!auth()->user()->canAccessClientRecord($service->client)) {
            abort(403);
        }

        if (!$service->isActive()) {
            abort(403, 'Upgrade disponível apenas para serviços ativos.');
        }
    }
}
