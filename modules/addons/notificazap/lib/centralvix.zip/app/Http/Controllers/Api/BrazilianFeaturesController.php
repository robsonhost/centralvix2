<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Services\ValidationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BrazilianFeaturesController extends Controller
{
    public function __construct(private ValidationService $validation) {}

    /**
     * Buscar CEP
     */
    public function buscarCep(string $cep): JsonResponse
    {
        $cep = preg_replace('/\D/', '', $cep);

        if (strlen($cep) !== 8) {
            return response()->json([
                'success' => false,
                'message' => 'CEP inválido',
            ], 400);
        }

        $dados = $this->validation->lookupCep($cep);

        if (!$dados) {
            return response()->json([
                'success' => false,
                'message' => 'CEP não encontrado',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'cep' => $dados['cep'] ?? $cep,
                'logradouro' => $dados['logradouro'] ?? $dados['street'] ?? '',
                'bairro' => $dados['bairro'] ?? $dados['neighborhood'] ?? '',
                'cidade' => $dados['localidade'] ?? $dados['city'] ?? '',
                'estado' => $dados['uf'] ?? $dados['state'] ?? '',
            ],
        ]);
    }

    /**
     * Validar CPF
     */
    public function validarCpf(Request $request): JsonResponse
    {
        $cpf = preg_replace('/\D/', '', $request->cpf);

        if (strlen($cpf) !== 11) {
            return response()->json([
                'success' => false,
                'valido' => false,
                'message' => 'CPF deve conter 11 dígitos',
            ]);
        }

        $valido = $this->validation->validateCpf($cpf);

        if (!$valido) {
            return response()->json([
                'success' => false,
                'valido' => false,
                'message' => 'CPF inválido',
            ]);
        }

        // Verificar duplicidade
        $clienteId = $request->cliente_id;
        $query = Client::where('cpf', $cpf);
        
        if ($clienteId) {
            $query->where('id', '!=', $clienteId);
        }

        $existente = $query->first();

        if ($existente) {
            return response()->json([
                'success' => true,
                'valido' => true,
                'duplicado' => true,
                'message' => 'CPF já cadastrado',
                'cliente' => [
                    'nome' => $existente->firstname . ' ' . $existente->lastname,
                    'email' => $existente->email,
                    'id' => $existente->id,
                ],
            ]);
        }

        return response()->json([
            'success' => true,
            'valido' => true,
            'duplicado' => false,
            'message' => 'CPF válido',
            'formatado' => $this->validation->formatCpf($cpf),
        ]);
    }

    /**
     * Validar CNPJ
     */
    public function validarCnpj(Request $request): JsonResponse
    {
        $cnpj = preg_replace('/\D/', '', $request->cnpj);

        if (strlen($cnpj) !== 14) {
            return response()->json([
                'success' => false,
                'valido' => false,
                'message' => 'CNPJ deve conter 14 dígitos',
            ]);
        }

        $valido = $this->validation->validateCnpj($cnpj);

        if (!$valido) {
            return response()->json([
                'success' => false,
                'valido' => false,
                'message' => 'CNPJ inválido',
            ]);
        }

        // Verificar duplicidade
        $clienteId = $request->cliente_id;
        $query = Client::where('cnpj', $cnpj);
        
        if ($clienteId) {
            $query->where('id', '!=', $clienteId);
        }

        $existente = $query->first();

        if ($existente) {
            return response()->json([
                'success' => true,
                'valido' => true,
                'duplicado' => true,
                'message' => 'CNPJ já cadastrado',
                'cliente' => [
                    'nome' => $existente->company_name ?? ($existente->firstname . ' ' . $existente->lastname),
                    'email' => $existente->email,
                    'id' => $existente->id,
                ],
            ]);
        }

        // Buscar dados do CNPJ (opcional)
        $dadosCnpj = $this->validation->lookupCnpj($cnpj);

        return response()->json([
            'success' => true,
            'valido' => true,
            'duplicado' => false,
            'message' => 'CNPJ válido',
            'formatado' => $this->validation->formatCnpj($cnpj),
            'dados' => $dadosCnpj ? [
                'razao_social' => $dadosCnpj['razao_social'] ?? $dadosCnpj['nome'] ?? null,
                'nome_fantasia' => $dadosCnpj['nome_fantasia'] ?? $dadosCnpj['fantasia'] ?? null,
                'situacao' => $dadosCnpj['situacao'] ?? $dadosCnpj['status'] ?? null,
            ] : null,
        ]);
    }

    /**
     * Buscar DDD
     */
    public function buscarDdd(string $ddd): JsonResponse
    {
        $dados = $this->validation->lookupDdd($ddd);

        return response()->json([
            'success' => true,
            'data' => $dados,
        ]);
    }
}
