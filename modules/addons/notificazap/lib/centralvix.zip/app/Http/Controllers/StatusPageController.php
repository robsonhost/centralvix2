<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Monitor;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class StatusPageController extends Controller
{
    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function index(Request $request, ?string $slug = null): View
    {
        $company = $this->resolveCompany($request, $slug);
        abort_unless($company, 404);

        abort_unless($this->modules->isEnabled($company->id, 'status_page'), 404);

        $cfg = $this->settings->all($company->id, 'status_page');
        abort_unless($cfg['public_enabled'] ?? true, 404);

        $monitors = Monitor::forCompany($company->id)
            ->active()
            ->orderBy('type')
            ->orderBy('name')
            ->get();

        $overall = $this->overallStatus($monitors);

        return view('status.index', compact('company', 'cfg', 'monitors', 'overall'));
    }

    private function resolveCompany(Request $request, ?string $slug): ?Company
    {
        if ($slug) {
            $company = Company::where('slug', $slug)->orWhere('uuid', $slug)->first();
            if ($company) {
                return $company;
            }
        }

        $host = $request->getHost();
        $byDomain = Company::where('domain', $host)->first();
        if ($byDomain) {
            return $byDomain;
        }

        return Company::where('status', 'active')->first();
    }

    private function overallStatus($monitors): string
    {
        if ($monitors->isEmpty()) {
            return 'unknown';
        }
        if ($monitors->where('status', 'down')->isNotEmpty()) {
            return 'down';
        }
        if ($monitors->where('status', 'warning')->isNotEmpty()) {
            return 'warning';
        }
        if ($monitors->where('status', 'up')->isEmpty()) {
            return 'unknown';
        }

        return 'up';
    }
}
