<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FraudRule;
use App\Models\FraudLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class FraudProtectionController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        $rules = FraudRule::where('company_id', $companyId)
            ->orderBy('priority')
            ->orderBy('name')
            ->get();

        $recentLogs = FraudLog::with(['client', 'order'])
            ->where('company_id', $companyId)
            ->latest()
            ->take(10)
            ->get();

        $stats = [
            'total_rules' => $rules->count(),
            'active_rules' => $rules->where('active', true)->count(),
            'blocked_today' => FraudLog::where('company_id', $companyId)
                ->where('action_taken', 'blocked')
                ->whereDate('created_at', today())
                ->count(),
            'flagged_today' => FraudLog::where('company_id', $companyId)
                ->where('action_taken', 'flagged')
                ->whereDate('created_at', today())
                ->count(),
        ];

        return view('admin.settings.fraud-protection.index', compact('rules', 'recentLogs', 'stats'));
    }

    public function create(): View
    {
        return view('admin.settings.fraud-protection.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'rule_type' => 'required|in:email_domain,ip_address,country,velocity,amount',
            'condition' => 'required|in:contains,equals,not_equals,greater_than,less_than,in_list',
            'value' => 'required|string',
            'action' => 'required|in:block,flag,manual_review',
            'priority' => 'integer',
            'active' => 'boolean',
        ]);

        $validated['company_id'] = auth()->user()->company_id;

        FraudRule::create($validated);

        return redirect()->route('admin.settings.fraud-protection.index')
            ->with('success', 'Regra de fraude criada com sucesso!');
    }

    public function edit(FraudRule $fraudRule): View
    {
        return view('admin.settings.fraud-protection.edit', compact('fraudRule'));
    }

    public function update(Request $request, FraudRule $fraudRule): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'rule_type' => 'required|in:email_domain,ip_address,country,velocity,amount',
            'condition' => 'required|in:contains,equals,not_equals,greater_than,less_than,in_list',
            'value' => 'required|string',
            'action' => 'required|in:block,flag,manual_review',
            'priority' => 'integer',
            'active' => 'boolean',
        ]);

        $fraudRule->update($validated);

        return redirect()->route('admin.settings.fraud-protection.index')
            ->with('success', 'Regra de fraude atualizada com sucesso!');
    }

    public function destroy(FraudRule $fraudRule): RedirectResponse
    {
        $fraudRule->delete();

        return redirect()->route('admin.settings.fraud-protection.index')
            ->with('success', 'Regra de fraude removida com sucesso!');
    }

    public function logs(): View
    {
        $companyId = auth()->user()->company_id;
        
        $logs = FraudLog::with(['client', 'order', 'fraudRule'])
            ->where('company_id', $companyId)
            ->latest()
            ->paginate(50);

        return view('admin.settings.fraud-protection.logs', compact('logs'));
    }
}
