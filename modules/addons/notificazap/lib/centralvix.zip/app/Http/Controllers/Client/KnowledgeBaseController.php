<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\KnowledgebaseCategory;
use App\Models\KnowledgebaseArticle;
use Illuminate\Http\Request;

class KnowledgebaseController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        
        // Categorias com contagem de artigos
        $categories = KnowledgebaseCategory::withCount('articles')
            ->where('active', true)
            ->orderBy('order')
            ->get();
        
        // Artigos mais vistos
        $articles = KnowledgebaseArticle::where('published', true)
            ->with('category')
            ->when($search, function($query, $search) {
                $query->where(function($q) use ($search) {
                    $q->where('title', 'like', "%{$search}%")
                      ->orWhere('content', 'like', "%{$search}%")
                      ->orWhere('tags', 'like', "%{$search}%");
                });
            })
            ->orderBy('views', 'desc')
            ->limit(20)
            ->get();
        
        return view('client.knowledgebase.index-NOVO', compact('categories', 'articles', 'search'));
    }
    
    public function show(KnowledgebaseArticle $article)
    {
        // Incrementa visualizações
        $article->increment('views');
        
        // Artigos relacionados
        $relatedArticles = KnowledgebaseArticle::where('published', true)
            ->where('category_id', $article->category_id)
            ->where('id', '!=', $article->id)
            ->orderBy('views', 'desc')
            ->limit(5)
            ->get();
        
        return view('client.knowledgebase.show', compact('article', 'relatedArticles'));
    }
}
