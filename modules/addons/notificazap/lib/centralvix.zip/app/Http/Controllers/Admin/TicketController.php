<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Ticket;
use App\Models\TicketDepartment;
use App\Models\TicketReply;
use App\Models\User;
use App\Services\NotificationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class TicketController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Ticket::with(['client', 'department', 'assignedTo'])
            ->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('subject', 'like', "%{$search}%")
                  ->orWhereHas('client', fn($c) => $c->where('email', 'like', "%{$search}%")
                      ->orWhere('firstname', 'like', "%{$search}%"));
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('priority')) {
            $query->where('priority', $request->priority);
        }

        if ($request->filled('department')) {
            $query->where('department_id', $request->department);
        }

        $tickets = $query->latest('last_reply_at')->paginate(20);
        $departments = TicketDepartment::where('company_id', $companyId)->get();
        $clients = Client::where('company_id', $companyId)->orderBy('firstname')->get(['id', 'firstname', 'lastname', 'email']);
        
        // Estatísticas
        $allTickets = Ticket::where('company_id', $companyId);
        $stats = [
            'total' => $allTickets->count(),
            'open' => $allTickets->where('status', 'open')->count(),
            'answered' => $allTickets->where('status', 'answered')->count(),
            'client_reply' => $allTickets->where('status', 'client_reply')->count(),
            'closed' => $allTickets->where('status', 'closed')->count(),
            'urgent' => $allTickets->where('priority', 'urgent')->count(),
        ];

        return view('admin.tickets.index', compact('tickets', 'departments', 'stats', 'clients'));
    }

    public function store(Request $request): RedirectResponse
    {
        $companyId = auth()->user()->company_id;

        $validated = $request->validate([
            'client_id'     => 'required|exists:clients,id',
            'department_id' => 'required|exists:ticket_departments,id',
            'priority'      => 'required|in:low,medium,high,urgent',
            'subject'       => 'required|string|max:255',
            'message'       => 'required|string',
        ]);

        $ticket = Ticket::create([
            'company_id'    => $companyId,
            'client_id'     => $validated['client_id'],
            'department_id' => $validated['department_id'],
            'priority'      => $validated['priority'],
            'subject'       => $validated['subject'],
            'status'        => 'open',
            'last_reply_at' => now(),
        ]);

        TicketReply::create([
            'ticket_id' => $ticket->id,
            'user_id'   => auth()->id(),
            'message'   => $validated['message'],
            'type'      => 'reply',
        ]);

        try {
            app(NotificationService::class)->dispatchTicketOpened($ticket);
        } catch (\Throwable $e) {
            \Log::warning('Notificação ticket aberto (admin): ' . $e->getMessage());
        }

        if ($request->expectsJson()) {
            return response()->json([
                'success'  => true,
                'redirect' => route('admin.tickets.show', $ticket),
            ]);
        }

        return redirect()
            ->route('admin.tickets.show', $ticket)
            ->with('success', 'Ticket criado com sucesso!');
    }

    public function show(Ticket $ticket): View
    {
        $this->authorizeCompany($ticket);

        $ticket->load(['client', 'department', 'assignedTo', 'replies.user', 'replies.client', 'replies.attachments', 'service']);

        $companyId = auth()->user()->company_id;
        $agents = User::where('company_id', $companyId)
            ->whereHas('roles', fn($q) => $q->whereIn('name', ['admin', 'support', 'super-admin']))
            ->get();

        return view('admin.tickets.show', compact('ticket', 'agents'));
    }

    public function reply(Request $request, Ticket $ticket): RedirectResponse
    {
        $this->authorizeCompany($ticket);

        $request->validate([
            'message' => 'required|string',
            'type' => 'required|in:reply,note',
        ]);

        $reply = TicketReply::create([
            'ticket_id' => $ticket->id,
            'user_id' => auth()->id(),
            'message' => $request->message,
            'type' => $request->type,
        ]);

        if ($request->type === 'reply') {
            $ticket->update([
                'status' => 'answered',
                'last_reply_at' => now(),
            ]);

            try {
                app(NotificationService::class)->dispatchTicketReplied($ticket, $request->message);
            } catch (\Throwable $e) {
                \Log::warning('Notificação resposta ticket: ' . $e->getMessage());
            }
        }

        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('tickets/' . $ticket->id, 'public');
                $reply->attachments()->create([
                    'ticket_id' => $ticket->id,
                    'filename' => basename($path),
                    'original_name' => $file->getClientOriginalName(),
                    'size' => $file->getSize(),
                    'mime_type' => $file->getMimeType(),
                    'path' => $path,
                ]);
            }
        }

        return back()->with('success', 'Resposta enviada!');
    }

    public function close(Ticket $ticket): RedirectResponse
    {
        $this->authorizeCompany($ticket);
        $ticket->close();
        return back()->with('success', 'Ticket fechado.');
    }

    public function open(Ticket $ticket): RedirectResponse
    {
        $this->authorizeCompany($ticket);
        $ticket->update(['status' => 'open', 'closed_at' => null]);
        return back()->with('success', 'Ticket reaberto.');
    }

    public function assign(Request $request, Ticket $ticket): RedirectResponse
    {
        $this->authorizeCompany($ticket);
        $request->validate(['assigned_to' => 'nullable|exists:users,id']);
        $ticket->update(['assigned_to' => $request->assigned_to]);
        return back()->with('success', 'Ticket atribuído.');
    }

    private function authorizeCompany(Ticket $ticket): void
    {
        if ($ticket->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }
}
