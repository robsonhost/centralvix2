<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ClientQuery;
use App\Models\QueryType;
use App\Models\RechargeOption;
use App\Models\Setting;
use App\Services\ConfereLinkService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class QueryTypeController extends Controller
{
    public function __construct(private ConfereLinkService $confere) {}

    /**
     * Lista tipos de consulta e opções de recarga
     */
    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        \Database\Seeders\ConsultasModuleSeeder::seedForCompany($companyId);

        $types = QueryType::forCompany($companyId)
            ->orderBy('category')
            ->orderBy('order')
            ->get()
            ->groupBy('category');

        $packages = RechargeOption::forCompany($companyId)
            ->orderBy('order')
            ->orderBy('amount')
            ->get();

        $confereToken = (string) Setting::get($companyId, 'confere_link', 'api_token', '');
        $confereConfigured = $confereToken !== '';

        $stats = [
            'total_types'   => QueryType::forCompany($companyId)->count(),
            'active_types'  => QueryType::forCompany($companyId)->where('active', true)->count(),
            'consultas_hoje'=> ClientQuery::where('company_id', $companyId)->whereDate('created_at', today())->count(),
            'consultas_mes' => ClientQuery::where('company_id', $companyId)->whereMonth('created_at', now()->month)->whereYear('created_at', now()->year)->count(),
            'receita_mes'   => ClientQuery::where('company_id', $companyId)->whereMonth('created_at', now()->month)->whereYear('created_at', now()->year)->where('status', 'completed')->sum('amount'),
            'custo_mes'     => (float) DB::table('queries')
                ->join('query_types', 'queries.query_type_id', '=', 'query_types.id')
                ->where('queries.company_id', $companyId)
                ->whereMonth('queries.created_at', now()->month)
                ->whereYear('queries.created_at', now()->year)
                ->where('queries.status', 'completed')
                ->sum('query_types.cost_price'),
        ];

        return view('admin.queries.index', compact('types', 'packages', 'stats', 'confereToken', 'confereConfigured'));
    }

    /**
     * Salva o token da API Confere.link (configurável pelo painel admin).
     */
    public function saveConfereSettings(Request $request): RedirectResponse
    {
        $companyId = auth()->user()->company_id;

        $validated = $request->validate([
            'api_token' => 'nullable|string|max:120',
        ]);

        $this->confere->saveToken($companyId, $validated['api_token'] ?? '');

        // Ativa provedor confere nos tipos suportados quando token informado.
        if (!empty(trim((string) ($validated['api_token'] ?? '')))) {
            QueryType::forCompany($companyId)
                ->whereIn('slug', ['cpf', 'nome', 'email-pessoa', 'email-empresa'])
                ->update(['api_provider' => 'confere']);
        }

        activity()
            ->causedBy(auth()->user())
            ->log('Token Confere.link atualizado');

        return back()->with('success', 'Token da API Confere.link salvo com sucesso!');
    }

    /**
     * Testa conexão com a API Confere.link (CPF de demonstração).
     */
    public function testConfere(): JsonResponse
    {
        $companyId = auth()->user()->company_id;
        $result = $this->confere->test($companyId);

        return response()->json($result, $result['success'] ? 200 : 422);
    }

    /**
     * Form criar tipo de consulta
     */
    public function create(): View
    {
        return view('admin.queries.create');
    }

    /**
     * Salva novo tipo de consulta
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'slug' => 'required|string|max:50|alpha_dash',
            'description' => 'nullable|string|max:255',
            'category' => 'required|in:pessoas,empresas,score',
            'icon' => 'nullable|string|max:50',
            'cost_price' => 'required|numeric|min:0',
            'sell_price' => 'required|numeric|min:0',
            'api_provider' => 'nullable|string|max:50',
            'active' => 'boolean',
        ]);

        $companyId = auth()->user()->company_id;

        if (QueryType::where('company_id', $companyId)->where('slug', $validated['slug'])->exists()) {
            return back()->with('error', 'Já existe uma consulta com este slug.')->withInput();
        }

        $validated['company_id'] = $companyId;
        $validated['active'] = $request->boolean('active', true);
        $validated['order'] = QueryType::where('company_id', $companyId)->max('order') + 1;

        QueryType::create($validated);

        return redirect()->route('admin.queries.index')->with('success', 'Tipo de consulta criado com sucesso!');
    }

    /**
     * Form editar tipo de consulta
     */
    public function edit(QueryType $queryType): View
    {
        if ($queryType->company_id !== auth()->user()->company_id) {
            abort(403);
        }

        return view('admin.queries.edit', compact('queryType'));
    }

    /**
     * Atualiza tipo de consulta
     */
    public function update(Request $request, QueryType $queryType): RedirectResponse
    {
        if ($queryType->company_id !== auth()->user()->company_id) {
            abort(403);
        }

        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'description' => 'nullable|string|max:255',
            'category' => 'required|in:pessoas,empresas,score',
            'icon' => 'nullable|string|max:50',
            'cost_price' => 'required|numeric|min:0',
            'sell_price' => 'required|numeric|min:0',
            'api_provider' => 'nullable|string|max:50',
            'active' => 'boolean',
        ]);

        $validated['active'] = $request->boolean('active', true);

        $queryType->update($validated);

        return redirect()->route('admin.queries.index')->with('success', 'Tipo de consulta atualizado!');
    }

    /**
     * Configura API de um tipo de consulta
     */
    public function configureApi(Request $request, QueryType $queryType): RedirectResponse
    {
        if ($queryType->company_id !== auth()->user()->company_id) {
            abort(403);
        }

        $validated = $request->validate([
            'api_provider' => 'required|string|max:50',
            'api_config' => 'nullable|array',
            'api_config.base_url' => 'nullable|url',
            'api_config.api_key' => 'nullable|string',
            'api_config.endpoint' => 'nullable|string',
        ]);

        $queryType->update([
            'api_provider' => $validated['api_provider'],
            'api_config' => $validated['api_config'] ?? [],
        ]);

        return back()->with('success', 'Configuração de API salva!');
    }

    /**
     * Remove tipo de consulta
     */
    public function destroy(QueryType $queryType): RedirectResponse
    {
        if ($queryType->company_id !== auth()->user()->company_id) {
            abort(403);
        }

        $queryType->delete();

        return redirect()->route('admin.queries.index')->with('success', 'Tipo de consulta removido!');
    }

    /**
     * Salva/atualiza opções de recarga
     */
    public function updateRechargeOptions(Request $request): RedirectResponse
    {
        $companyId = auth()->user()->company_id;

        $validated = $request->validate([
            'options' => 'required|array',
            'options.*.amount' => 'required|numeric|min:1',
            'options.*.bonus' => 'nullable|numeric|min:0',
            'options.*.active' => 'boolean',
        ]);

        RechargeOption::where('company_id', $companyId)->delete();

        foreach ($validated['options'] as $i => $opt) {
            RechargeOption::create([
                'company_id' => $companyId,
                'amount' => $opt['amount'],
                'bonus' => $opt['bonus'] ?? 0,
                'active' => $opt['active'] ?? true,
                'order' => $i,
            ]);
        }

        return back()->with('success', 'Opções de recarga atualizadas!');
    }

    /**
     * Relatório de consultas
     */
    public function report(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $queries = ClientQuery::where('company_id', $companyId)
            ->with(['client', 'queryType'])
            ->when($request->filled('client_id'), fn($q) => $q->where('client_id', $request->client_id))
            ->when($request->filled('type_id'), fn($q) => $q->where('query_type_id', $request->type_id))
            ->when($request->filled('status'), fn($q) => $q->where('status', $request->status))
            ->when($request->filled('date_from'), fn($q) => $q->whereDate('created_at', '>=', $request->date_from))
            ->when($request->filled('date_to'), fn($q) => $q->whereDate('created_at', '<=', $request->date_to))
            ->latest()
            ->paginate(30);

        $types = QueryType::forCompany($companyId)->pluck('name', 'id');

        return view('admin.queries.report', compact('queries', 'types'));
    }
}
