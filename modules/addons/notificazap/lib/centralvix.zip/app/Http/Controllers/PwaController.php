<?php

namespace App\Http\Controllers;

use App\Services\BrandingService;
use Illuminate\Http\Response;

class PwaController extends Controller
{
    public function __construct(private BrandingService $branding) {}

    public function manifest(): Response
    {
        $companyId = (int) request('c', $this->branding->companyId());
        $data = $this->branding->manifest($companyId);

        return response(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), 200, [
            'Content-Type' => 'application/manifest+json',
            'Cache-Control' => 'public, max-age=300',
        ]);
    }

    public function themeCss(): Response
    {
        $companyId = (int) request('c', $this->branding->companyId());

        return response($this->branding->themeCss($companyId), 200, [
            'Content-Type' => 'text/css',
            'Cache-Control' => 'public, max-age=300',
        ]);
    }

    public function serviceWorker(): Response
    {
        $js = file_get_contents(public_path('sw.js')) ?: '';

        return response($js, 200, [
            'Content-Type' => 'application/javascript',
            'Service-Worker-Allowed' => '/',
            'Cache-Control' => 'no-cache',
        ]);
    }
}
