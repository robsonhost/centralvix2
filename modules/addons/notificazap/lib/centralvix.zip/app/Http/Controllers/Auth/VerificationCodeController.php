<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\VerificationCodeMail;
use App\Models\Client;
use App\Models\Setting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\View\View;

class VerificationCodeController extends Controller
{
    public function show(Request $request): View|RedirectResponse
    {
        $user = $request->user();

        if (!$user) {
            return redirect()->route('login');
        }

        if ($user->hasVerifiedEmail()) {
            return redirect()->route('client.dashboard');
        }

        $client = Client::where('user_id', $user->id)->first();

        if (!$client) {
            return redirect()->route('login')->with('error', 'Cliente não encontrado.');
        }

        // Determina onde o código foi enviado
        $method = $this->getVerificationMethod();
        $sentTo = match($method) {
            'email' => $client->email,
            'whatsapp' => $client->whatsapp ?? $client->phone,
            'both' => $client->email . ' e WhatsApp',
            default => $client->email
        };

        return view('auth.verify-code', compact('sentTo'));
    }

    public function verify(Request $request): RedirectResponse
    {
        $request->validate([
            'code' => 'required|string|min:4|max:8'
        ]);

        $user = $request->user();
        $client = Client::where('user_id', $user->id)->first();

        if (!$client) {
            return back()->with('error', 'Cliente não encontrado.');
        }

        // Verifica se já está verificado
        if ($client->hasVerifiedEmail()) {
            return redirect()->route('client.dashboard')->with('info', 'Email já verificado.');
        }

        // Verifica máximo de tentativas
        $maxAttempts = (int) $this->getSetting('verification', 'max_attempts', 5);
        if ($client->hasExceededVerificationAttempts($maxAttempts)) {
            return back()->with('error', '❌ Muitas tentativas. Solicite um novo código.');
        }

        // Verifica se expirou
        if ($client->isVerificationCodeExpired()) {
            return back()->with('error', '⏰ Código expirado. Solicite um novo código.');
        }

        // Valida código
        if ($client->validateVerificationCode($request->code)) {
            activity()
                ->performedOn($client)
                ->causedBy($user)
                ->log('Email verificado com código');

            return redirect()->route('client.dashboard')
                ->with('success', '✓ Email verificado com sucesso! Bem-vindo ao ' . config('app.name') . '!');
        }

        return back()->with('error', '❌ Código incorreto. Tentativa ' . $client->verification_attempts . ' de ' . $maxAttempts);
    }

    public function resend(Request $request): RedirectResponse
    {
        $user = $request->user();
        $client = Client::where('user_id', $user->id)->first();

        if (!$client) {
            return back()->with('error', 'Cliente não encontrado.');
        }

        if ($client->hasVerifiedEmail()) {
            return back()->with('info', 'Email já verificado.');
        }

        // Gera novo código
        $codeLength = (int) $this->getSetting('verification', 'code_length', 6);
        $expiryMinutes = (int) $this->getSetting('verification', 'code_expiry_minutes', 30);
        $code = $client->generateVerificationCode($codeLength, $expiryMinutes);

        // Envia email
        $method = $this->getVerificationMethod();
        if (in_array($method, ['email', 'both'])) {
            try {
                Mail::to($client->email)->send(new VerificationCodeMail($code, $expiryMinutes, $client->full_name));
            } catch (\Exception $e) {
                \Log::error('Erro ao enviar código por email: ' . $e->getMessage());
            }
        }

        // TODO: Enviar WhatsApp
        if (in_array($method, ['whatsapp', 'both'])) {
            // WhatsAppService::sendVerificationCode($client->whatsapp, $code);
        }

        return back()->with('success', '✓ Novo código enviado!');
    }

    private function getVerificationMethod(): string
    {
        return $this->getSetting('verification', 'method', 'email');
    }

    private function getSetting(string $group, string $key, $default = null)
    {
        $companyId = auth()->user()->company_id ?? 1;
        
        return Setting::where('company_id', $companyId)
            ->where('group', $group)
            ->where('key', $key)
            ->value('value') ?? $default;
    }
}
