<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Events\InvoiceGenerated;
use App\Events\InvoicePaid;
use App\Services\AdminExportService;
use App\Services\InvoiceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;

class InvoiceController extends Controller
{
    public function __construct(
        private InvoiceService $invoiceService,
        private AdminExportService $exportService,
    ) {}

    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Invoice::with('client')
            ->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('invoice_number', 'like', "%{$search}%")
                  ->orWhereHas('client', fn($c) => $c->where('email', 'like', "%{$search}%")
                      ->orWhere('firstname', 'like', "%{$search}%"));
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('date_from')) {
            $query->where('date_created', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->where('date_created', '<=', $request->date_to);
        }

        $invoices = $query->latest('date_created')->paginate(20);

        // Statistics
        $stats = [
            'total' => Invoice::where('company_id', $companyId)->count(),
            'paid' => Invoice::where('company_id', $companyId)->where('status', 'paid')->count(),
            'unpaid' => Invoice::where('company_id', $companyId)->whereIn('status', ['unpaid', 'overdue'])->count(),
            'overdue' => Invoice::where('company_id', $companyId)->where('status', 'overdue')->count(),
            'cancelled' => Invoice::where('company_id', $companyId)->where('status', 'cancelled')->count(),
            'total_paid_amount' => Invoice::where('company_id', $companyId)->where('status', 'paid')->sum('total'),
            'total_pending_amount' => Invoice::where('company_id', $companyId)->whereIn('status', ['unpaid', 'overdue'])->sum('total'),
        ];

        return view('admin.invoices.index', compact('invoices', 'stats'));
    }

    public function create(Request $request): View
    {
        $companyId = auth()->user()->company_id;
        $clients = Client::where('company_id', $companyId)->where('status', 'active')->get();
        $selectedClient = $request->filled('client_id')
            ? Client::find($request->client_id)
            : null;

        return view('admin.invoices.create', compact('clients', 'selectedClient'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'date_due' => 'required|date',
            'items' => 'required|array|min:1',
            'items.*.description' => 'required|string',
            'items.*.amount' => 'required|numeric|min:0',
            'notes' => 'nullable|string',
        ]);

        $companyId = auth()->user()->company_id;
        $subtotal = collect($request->items)->sum('amount');

        $invoice = Invoice::create([
            'company_id' => $companyId,
            'client_id' => $validated['client_id'],
            'date_created' => now()->toDateString(),
            'date_due' => $validated['date_due'],
            'subtotal' => $subtotal,
            'discount' => 0,
            'tax' => 0,
            'total' => $subtotal,
            'status' => 'unpaid',
            'notes' => $validated['notes'] ?? null,
        ]);

        foreach ($request->items as $item) {
            InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'description' => $item['description'],
                'amount' => $item['amount'],
                'tax_rate' => 0,
                'tax_amount' => 0,
                'total' => $item['amount'],
            ]);
        }

        InvoiceGenerated::dispatch($invoice);

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('success', 'Fatura criada com sucesso!');
    }

    public function show(Invoice $invoice): View
    {
        $this->authorizeCompany($invoice);
        $invoice->load(['client', 'items', 'transactions']);
        return view('admin.invoices.show', compact('invoice'));
    }

    public function markPaid(Request $request, Invoice $invoice): RedirectResponse|JsonResponse
    {
        $this->authorizeCompany($invoice);

        $request->validate([
            'payment_gateway' => 'nullable|string',
            'transaction_id' => 'nullable|string',
        ]);

        $invoice->markAsPaid(
            $request->payment_gateway ?? 'manual',
            $request->transaction_id
        );

        if (!$invoice->transactions()->where('status', 'completed')->exists()) {
            \App\Models\Transaction::create([
                'company_id' => $invoice->company_id,
                'client_id' => $invoice->client_id,
                'invoice_id' => $invoice->id,
                'gateway' => $request->payment_gateway ?? 'manual',
                'type' => 'payment',
                'amount' => $invoice->total,
                'currency' => $invoice->currency ?? 'BRL',
                'status' => 'completed',
                'description' => 'Pagamento manual — Fatura #' . ($invoice->invoice_number ?? $invoice->id),
            ]);
        }

        app(\App\Services\InvoiceFulfillmentService::class)->fulfill($invoice->fresh(['items.service.product']));

        InvoicePaid::dispatch($invoice->fresh());

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Fatura marcada como paga!',
                'invoice' => $this->invoicePayload($invoice->fresh(['client', 'items', 'transactions'])),
            ]);
        }

        return back()->with('success', 'Fatura marcada como paga!');
    }

    public function cancel(Request $request, Invoice $invoice): RedirectResponse|JsonResponse
    {
        $this->authorizeCompany($invoice);

        if (!in_array($invoice->status, ['unpaid', 'overdue', 'draft'])) {
            if ($request->wantsJson()) {
                return response()->json(['success' => false, 'message' => 'Esta fatura não pode ser cancelada.'], 422);
            }
            return back()->with('error', 'Esta fatura não pode ser cancelada.');
        }

        $invoice->update(['status' => 'cancelled']);

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Fatura cancelada.',
                'invoice' => $this->invoicePayload($invoice->fresh(['client', 'items', 'transactions'])),
            ]);
        }

        return back()->with('success', 'Fatura cancelada.');
    }

    public function pdf(Invoice $invoice): Response
    {
        $this->authorizeCompany($invoice);
        $invoice->load(['client', 'items', 'company']);
        return $this->invoiceService->generatePdf($invoice);
    }

    public function send(Request $request, Invoice $invoice): RedirectResponse|JsonResponse
    {
        $this->authorizeCompany($invoice);
        $this->invoiceService->sendByEmail($invoice);

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Fatura enviada por e-mail para ' . ($invoice->client?->email ?? 'cliente') . '!',
            ]);
        }

        return back()->with('success', 'Fatura enviada por e-mail!');
    }

    public function export(Request $request): \Symfony\Component\HttpFoundation\StreamedResponse|\Illuminate\Http\Response
    {
        $companyId = auth()->user()->company_id;
        $format = $request->get('format', 'csv');

        $query = Invoice::with('client')->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('invoice_number', 'like', "%{$search}%")
                  ->orWhereHas('client', fn ($c) => $c->where('email', 'like', "%{$search}%")
                      ->orWhere('firstname', 'like', "%{$search}%"));
            });
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('date_from')) {
            $query->where('date_created', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->where('date_created', '<=', $request->date_to);
        }

        $headings = ['Número', 'Cliente', 'E-mail', 'Subtotal', 'Desconto', 'Total', 'Status', 'Vencimento', 'Pago em', 'Gateway'];
        $rows = $query->latest('date_created')->get()->map(fn (Invoice $inv) => [
            $inv->invoice_number,
            trim(($inv->client?->firstname ?? '') . ' ' . ($inv->client?->lastname ?? '')) ?: '—',
            $inv->client?->email ?? '—',
            'R$ ' . number_format((float) $inv->subtotal, 2, ',', '.'),
            'R$ ' . number_format((float) $inv->discount, 2, ',', '.'),
            'R$ ' . number_format((float) $inv->total, 2, ',', '.'),
            $inv->status_label ?? ucfirst($inv->status),
            $inv->date_due?->format('d/m/Y') ?? '—',
            $inv->date_paid?->format('d/m/Y H:i') ?? '—',
            $inv->payment_gateway ? strtoupper($inv->payment_gateway) : '—',
        ])->all();

        return $this->exportService->download($format, 'Faturas', $headings, $rows);
    }

    private function invoicePayload(Invoice $invoice): array
    {
        return [
            'id' => $invoice->id,
            'invoice_number' => $invoice->invoice_number,
            'status' => $invoice->status,
            'status_label' => $invoice->status_label,
            'status_badge' => $invoice->status_badge,
            'total' => number_format($invoice->total, 2, ',', '.'),
            'date_paid' => $invoice->date_paid?->format('d/m/Y H:i'),
            'payment_gateway' => $invoice->payment_gateway ? strtoupper($invoice->payment_gateway) : null,
            'transaction_id' => $invoice->transaction_id,
            'is_paid' => $invoice->isPaid(),
            'is_overdue' => $invoice->isOverdue(),
        ];
    }

    private function authorizeCompany(Invoice $invoice): void
    {
        if ($invoice->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }
}
