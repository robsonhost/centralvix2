<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Invoice;
use App\Models\Service;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ReportController extends Controller
{
    public function financial(Request $request): View
    {
        $companyId = auth()->user()->company_id;
        $year  = $request->get('year', now()->year);
        $month = $request->get('month', now()->month);
        return view('admin.reports.financial', compact('year', 'month'));
    }

    public function index(): View
    {
        return view('admin.reports.index');
    }

    public function revenue(Request $request): View
    {
        $companyId = auth()->user()->company_id;
        $year = $request->get('year', now()->year);

        $monthlyRevenue = Transaction::where('company_id', $companyId)
            ->where('status', 'completed')
            ->where('type', 'payment')
            ->whereYear('created_at', $year)
            ->selectRaw('MONTH(created_at) as month, SUM(amount) as total, SUM(fee) as fees, COUNT(*) as count')
            ->groupBy('month')
            ->get()
            ->keyBy('month');

        $data = [];
        for ($i = 1; $i <= 12; $i++) {
            $data[$i] = $monthlyRevenue->get($i) ?? (object)['total' => 0, 'fees' => 0, 'count' => 0];
        }

        $yearTotal = Transaction::where('company_id', $companyId)
            ->where('status', 'completed')
            ->where('type', 'payment')
            ->whereYear('created_at', $year)
            ->sum('amount');

        return view('admin.reports.revenue', compact('data', 'year', 'yearTotal'));
    }

    public function clients(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $stats = [
            'total' => Client::where('company_id', $companyId)->count(),
            'active' => Client::where('company_id', $companyId)->where('status', 'active')->count(),
            'suspended' => Client::where('company_id', $companyId)->where('status', 'suspended')->count(),
            'new_this_month' => Client::where('company_id', $companyId)
                ->whereMonth('created_at', now()->month)
                ->count(),
        ];

        $monthly = Client::where('company_id', $companyId)
            ->whereYear('created_at', now()->year)
            ->selectRaw('MONTH(created_at) as month, COUNT(*) as count')
            ->groupBy('month')
            ->pluck('count', 'month')
            ->toArray();

        return view('admin.reports.clients', compact('stats', 'monthly'));
    }

    public function services(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $stats = [
            'total' => Service::where('company_id', $companyId)->count(),
            'active' => Service::where('company_id', $companyId)->where('status', 'active')->count(),
            'suspended' => Service::where('company_id', $companyId)->where('status', 'suspended')->count(),
            'cancelled' => Service::where('company_id', $companyId)->where('status', 'cancelled')->count(),
            'mrr' => Service::where('company_id', $companyId)
                ->where('status', 'active')
                ->where('billing_cycle', 'monthly')
                ->sum('amount'),
        ];

        return view('admin.reports.services', compact('stats'));
    }
}
