<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\ClientCreditLog;
use App\Models\ConsultaLog;
use App\Models\ConsultaType;
use App\Models\RechargePackage;
use App\Models\Setting;
use App\Services\CacheService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\View\View;

class QueriesController extends Controller
{
    /**
     * Painel de gestão de Consultas (tipos + pacotes + logs).
     */
    public function index(): View
    {
        $this->syncConsultasModule();

        $types = ConsultaType::orderBy('category')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get()
            ->groupBy('category');

        $packages = RechargePackage::orderBy('sort_order')
            ->orderBy('amount')
            ->get();

        $stats = [
            'total_types'    => ConsultaType::count(),
            'active_types'   => ConsultaType::where('active', true)->count(),
            'total_packages' => RechargePackage::count(),
            'consultas_hoje' => ConsultaLog::whereDate('created_at', today())->count(),
            'consultas_mes'  => ConsultaLog::whereMonth('created_at', now()->month)
                ->whereYear('created_at', now()->year)->count(),
            'receita_mes'    => ConsultaLog::whereMonth('created_at', now()->month)
                ->whereYear('created_at', now()->year)
                ->where('status', 'success')
                ->sum('sale_price'),
            'custo_mes'      => ConsultaLog::whereMonth('created_at', now()->month)
                ->whereYear('created_at', now()->year)
                ->where('status', 'success')
                ->sum('cost_price'),
        ];

        return view('admin.queries.index', compact('types', 'packages', 'stats'));
    }

    /**
     * Atualiza preços (custo + venda) de todos os tipos de uma vez.
     */
    public function updatePrices(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'types'                  => ['array'],
            'types.*.cost_price'     => ['nullable', 'numeric', 'min:0'],
            'types.*.sale_price'     => ['nullable', 'numeric', 'min:0'],
            'types.*.active'         => ['nullable', 'boolean'],
        ]);

        foreach ($data['types'] ?? [] as $id => $values) {
            $type = ConsultaType::find($id);
            if (! $type) continue;

            $type->update([
                'cost_price' => $values['cost_price'] ?? $type->cost_price,
                'sale_price' => $values['sale_price'] ?? $type->sale_price,
                'active'     => array_key_exists('active', $values) ? (bool) $values['active'] : $type->active,
            ]);
        }

        $this->syncConsultasModule();

        return back()->with('success', 'Preços das consultas atualizados com sucesso!');
    }

    /**
     * Garante que o módulo consultas fique ativo após configuração no admin.
     */
    protected function syncConsultasModule(): void
    {
        $companyId = (int) auth()->user()->company_id;
        $modules = app(\App\Services\ModuleService::class);

        if (! $modules->isEnabled($companyId, 'consultas')) {
            $modules->toggle($companyId, 'consultas', true);
        }
    }

    /**
     * Edita um tipo individual (incluindo credenciais de API).
     */
    public function editType(ConsultaType $type): View
    {
        return view('admin.queries.type-edit', compact('type'));
    }

    public function updateType(Request $request, ConsultaType $type): RedirectResponse
    {
        $data = $request->validate([
            'name'         => ['required', 'string', 'max:120'],
            'description'  => ['nullable', 'string', 'max:255'],
            'cost_price'   => ['required', 'numeric', 'min:0'],
            'sale_price'   => ['required', 'numeric', 'min:0'],
            'active'       => ['nullable', 'boolean'],
            'icon'         => ['nullable', 'string', 'max:60'],
            'accent'       => ['nullable', 'string', 'max:30'],
            'api_provider' => ['nullable', 'string', 'max:120'],
            'api_endpoint' => ['nullable', 'string', 'max:255'],
            'api_config'   => ['nullable', 'string'],
        ]);

        $config = null;
        if (! empty($data['api_config'])) {
            $decoded = json_decode($data['api_config'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return back()->withInput()->with('error', 'JSON da configuração de API inválido: ' . json_last_error_msg());
            }
            $config = $decoded;
        }

        $type->update([
            'name'         => $data['name'],
            'description'  => $data['description'] ?? null,
            'cost_price'   => $data['cost_price'],
            'sale_price'   => $data['sale_price'],
            'active'       => (bool) ($data['active'] ?? false),
            'icon'         => $data['icon']   ?: $type->icon,
            'accent'       => $data['accent'] ?: $type->accent,
            'api_provider' => $data['api_provider'] ?? null,
            'api_endpoint' => $data['api_endpoint'] ?? null,
            'api_config'   => $config,
        ]);

        $this->syncConsultasModule();

        return redirect()
            ->route('admin.queries.index')
            ->with('success', "Consulta '{$type->name}' atualizada.");
    }

    // ============================================================
    // Pacotes de Recarga
    // ============================================================

    public function storePackage(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name'       => ['nullable', 'string', 'max:120'],
            'amount'     => ['required', 'numeric', 'min:1'],
            'bonus'      => ['nullable', 'numeric', 'min:0'],
            'highlight'  => ['nullable', 'boolean'],
            'active'     => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer'],
        ]);

        RechargePackage::create([
            'company_id' => auth()->user()->company_id,
            'name'       => $data['name']   ?? null,
            'amount'     => $data['amount'],
            'bonus'      => $data['bonus']  ?? 0,
            'highlight'  => (bool) ($data['highlight'] ?? false),
            'active'     => array_key_exists('active', $data) ? (bool) $data['active'] : true,
            'sort_order' => $data['sort_order'] ?? 0,
        ]);

        $this->syncConsultasModule();

        return back()->with('success', 'Pacote de recarga criado!');
    }

    public function updatePackage(Request $request, RechargePackage $package): RedirectResponse
    {
        $data = $request->validate([
            'name'       => ['nullable', 'string', 'max:120'],
            'amount'     => ['required', 'numeric', 'min:1'],
            'bonus'      => ['nullable', 'numeric', 'min:0'],
            'highlight'  => ['nullable', 'boolean'],
            'active'     => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer'],
        ]);

        $package->update([
            'name'       => $data['name']   ?? null,
            'amount'     => $data['amount'],
            'bonus'      => $data['bonus']  ?? 0,
            'highlight'  => (bool) ($data['highlight'] ?? false),
            'active'     => array_key_exists('active', $data) ? (bool) $data['active'] : $package->active,
            'sort_order' => $data['sort_order'] ?? $package->sort_order,
        ]);

        return back()->with('success', 'Pacote atualizado!');
    }

    public function destroyPackage(RechargePackage $package): RedirectResponse
    {
        $package->delete();
        return back()->with('success', 'Pacote removido.');
    }

    // ============================================================
    // Tokens de Provedores (credenciais centralizadas das APIs)
    // ============================================================

    /**
     * Lista de provedores suportados que possuem token global.
     * Para adicionar um novo provedor: cadastre aqui + o ConsultaService já
     * resolve via `resolveProviderToken()`.
     */
    public static function providersCatalog(): array
    {
        return [
            'confere_link' => [
                'name'    => 'Confere.link',
                'url'     => 'https://confere.link',
                'help'    => 'Token (TK) do painel da Confere.link. É usado em CONS_CPF, CONS_NOME, CONS_CNPJ, etc.',
                'icon'    => 'fa-id-card',
                'test_url'    => 'https://confere.link/api/?acao=CONS_CPF&TK=__TOKEN__&DADO=00000000000&TIPO=JSON',
                'test_method' => 'GET',
            ],
        ];
    }

    public function providers(): View
    {
        $companyId = (int) auth()->user()->company_id;
        $catalog   = static::providersCatalog();

        $tokens = [];
        $envs   = [];
        $meta   = [];
        foreach ($catalog as $key => $_) {
            $tokens[$key] = (string) Setting::get($companyId, 'consultas', $key . '_token', '');
            $envs[$key]   = (string) Setting::get($companyId, 'consultas', $key . '_env', 'demo');

            $row = Setting::where('company_id', $companyId)
                ->where('group', 'consultas')
                ->where('key', $key . '_token')
                ->first();
            $meta[$key] = [
                'updated_at' => $row?->updated_at,
                'masked'     => $tokens[$key]
                    ? mb_substr($tokens[$key], 0, 4) . str_repeat('•', max(0, mb_strlen($tokens[$key]) - 8)) . mb_substr($tokens[$key], -4)
                    : null,
            ];
        }

        // Quantos tipos usam cada provedor?
        $usage = ConsultaType::selectRaw('LOWER(api_provider) as provider, COUNT(*) as total')
            ->whereNotNull('api_provider')
            ->groupBy('api_provider')
            ->pluck('total', 'provider');

        return view('admin.queries.providers', compact('catalog', 'tokens', 'envs', 'meta', 'usage'));
    }

    public function saveProviders(Request $request): RedirectResponse
    {
        $companyId = (int) auth()->user()->company_id;
        $catalog   = static::providersCatalog();

        $data = $request->validate([
            'tokens'     => ['array'],
            'tokens.*'   => ['nullable', 'string', 'max:255'],
            'envs'       => ['array'],
            'envs.*'     => ['nullable', 'in:demo,production'],
        ]);

        foreach ($catalog as $key => $_) {
            $token = trim((string) ($data['tokens'][$key] ?? ''));
            $env   = (string) ($data['envs'][$key] ?? 'demo');

            Setting::set($companyId, 'consultas', $key . '_token', $token, 'string');
            Setting::set($companyId, 'consultas', $key . '_env',   $env,   'string');
        }

        // Invalida o cache para que o novo token entre em vigor imediatamente
        // (sem isso, o token antigo poderia ficar até 24h em cache).
        try {
            app(CacheService::class)->invalidateSettings($companyId);
        } catch (\Throwable $e) {
            // segue, salvamento já foi feito
        }

        return back()->with('success', 'Tokens atualizados. As próximas consultas já usarão o novo token.');
    }

    /**
     * Testa um token chamando o endpoint de demonstração do provedor.
     */
    public function testProvider(Request $request, string $provider): JsonResponse
    {
        $companyId = (int) auth()->user()->company_id;
        $catalog   = static::providersCatalog();

        if (! isset($catalog[$provider])) {
            return response()->json(['ok' => false, 'message' => 'Provedor desconhecido.'], 404);
        }

        $token = (string) Setting::get($companyId, 'consultas', $provider . '_token', '');
        if ($token === '') {
            return response()->json(['ok' => false, 'message' => 'Salve o token antes de testar.']);
        }

        $cfg = $catalog[$provider];
        $url = str_replace('__TOKEN__', $token, $cfg['test_url']);

        try {
            $resp = Http::timeout(20)->get($url);
            $body = $resp->json() ?? ['raw' => mb_substr($resp->body(), 0, 500)];

            return response()->json([
                'ok'      => $resp->successful(),
                'status'  => $resp->status(),
                'message' => $resp->successful() ? 'Token respondeu com sucesso!' : 'Provedor retornou erro.',
                'sample'  => $body,
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Falha ao chamar o provedor: ' . $e->getMessage(),
            ]);
        }
    }

    // ============================================================
    // Logs de consultas (auditoria global)
    // ============================================================

    public function logs(Request $request): View
    {
        $query = ConsultaLog::query()
            ->with(['type', 'client'])
            ->where('company_id', auth()->user()->company_id)
            ->latest();

        if ($request->filled('client')) {
            $query->whereHas('client', function ($q) use ($request) {
                $q->where('firstname', 'like', '%' . $request->client . '%')
                    ->orWhere('lastname',  'like', '%' . $request->client . '%')
                    ->orWhere('email',     'like', '%' . $request->client . '%');
            });
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('category')) {
            $query->whereHas('type', fn ($q) => $q->where('category', $request->category));
        }

        $logs = $query->paginate(25)->withQueryString();

        return view('admin.queries.logs', compact('logs'));
    }

    // ============================================================
    // Saldo / crédito manual por cliente
    // ============================================================

    public function clients(Request $request): View
    {
        $this->syncConsultasModule();
        $companyId = (int) auth()->user()->company_id;

        $query = Client::where('company_id', $companyId)
            ->with('user:id,name,email')
            ->orderBy('firstname');

        if ($search = trim((string) $request->query('q'))) {
            $query->where(function ($q) use ($search) {
                $q->where('firstname', 'like', "%{$search}%")
                    ->orWhere('lastname', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('id', $search);
            });
        }

        $clients = $query->paginate(20)->withQueryString();

        $recentCredits = ClientCreditLog::where('company_id', $companyId)
            ->with(['client:id,firstname,lastname,email', 'creator:id,name'])
            ->latest()
            ->limit(10)
            ->get();

        $stats = [
            'total_balance' => (float) Client::where('company_id', $companyId)->sum('credit_balance'),
            'clients_with_balance' => Client::where('company_id', $companyId)->where('credit_balance', '>', 0)->count(),
        ];

        return view('admin.queries.clients', compact('clients', 'recentCredits', 'stats', 'search'));
    }

    public function addCredit(Request $request, Client $client): RedirectResponse
    {
        abort_unless($client->company_id === (int) auth()->user()->company_id, 403);

        $data = $request->validate([
            'amount'      => ['required', 'numeric', 'not_in:0'],
            'description' => ['nullable', 'string', 'max:255'],
        ]);

        $amount = round((float) $data['amount'], 2);

        if ($amount > 0) {
            $client->addCredit($amount);
            $type = 'credit';
        } else {
            $deduct = abs($amount);
            if ((float) $client->credit_balance < $deduct) {
                return back()->with('error', 'Saldo insuficiente para debitar R$ ' . number_format($deduct, 2, ',', '.'));
            }
            $client->deductCredit($deduct);
            $type = 'debit';
        }

        $client->refresh();

        ClientCreditLog::create([
            'client_id'     => $client->id,
            'company_id'    => $client->company_id,
            'created_by'    => auth()->id(),
            'amount'        => $amount,
            'balance_after' => $client->credit_balance,
            'type'          => $type,
            'description'   => $data['description'] ?: ($type === 'credit' ? 'Crédito manual (admin)' : 'Débito manual (admin)'),
        ]);

        activity()
            ->causedBy(auth()->user())
            ->performedOn($client)
            ->withProperties(['amount' => $amount, 'balance' => $client->credit_balance])
            ->log('Saldo de consultas ajustado manualmente');

        $this->syncConsultasModule();

        return back()->with('success', 'Saldo atualizado! Novo saldo de '
            . $client->firstname . ': R$ ' . number_format((float) $client->credit_balance, 2, ',', '.'));
    }
}
