<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PaymentGateway;
use App\Models\Setting;
use App\Services\CronJobManagerService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SettingController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $settings = Setting::where('company_id', $companyId)
            ->get()
            ->groupBy('group');

        return view('admin.settings.index', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $companyId = auth()->user()->company_id;

        foreach ($request->settings ?? [] as $group => $keys) {
            foreach ($keys as $key => $value) {
                Setting::set($companyId, $group, $key, $value);
            }
        }

        return back()->with('success', 'Configurações salvas com sucesso!');
    }

    public function gateways(): View
    {
        $companyId = auth()->user()->company_id;
        $gateways = PaymentGateway::where('company_id', $companyId)->orderBy('order')->get();
        
        // Estatísticas
        $stats = [
            'total' => $gateways->count(),
            'active' => $gateways->where('status', 'active')->count(),
            'inactive' => $gateways->where('status', 'inactive')->count(),
            'sandbox' => $gateways->where('test_mode', true)->count(),
        ];
        
        return view('admin.settings.gateways', compact('gateways', 'stats'));
    }

    public function updateGateway(Request $request, PaymentGateway $gateway): RedirectResponse
    {
        if ($gateway->company_id !== auth()->user()->company_id) {
            abort(403);
        }

        $gateway->update([
            'display_name' => $request->display_name ?? $gateway->display_name,
            'status' => $request->status ?? $gateway->status,
            'test_mode' => $request->boolean('test_mode'),
            'settings' => $request->settings ?? [],
        ]);

        return back()->with('success', 'Gateway atualizado.');
    }

    public function email(): View
    {
        $companyId = auth()->user()->company_id;
        $settings = Setting::where('company_id', $companyId)
            ->where('group', 'email')
            ->get()
            ->keyBy('key');
        return view('admin.settings.email', compact('settings'));
    }

    public function updateEmail(Request $request): RedirectResponse
    {
        $companyId = auth()->user()->company_id;
        $data = $request->validate([
            'from_name' => 'required|string',
            'from_email' => 'required|email',
            'signature' => 'nullable|string',
        ]);

        foreach ($data as $key => $value) {
            Setting::set($companyId, 'email', $key, $value);
        }

        return back()->with('success', 'Configurações de e-mail salvas.');
    }

    /**
     * Show cron jobs configuration page
     */
    public function cronJobs(CronJobManagerService $cronManager): View
    {
        $jobs = collect($cronManager->definitions())->map(function ($job) use ($cronManager) {
            $last = $cronManager->getLastRun($job['slug']);

            return array_merge($job, [
                'last_run' => $last,
            ]);
        });

        return view('admin.settings.cron-jobs', [
            'jobs' => $jobs,
            'grouped' => $cronManager->grouped(),
            'categories' => $cronManager->categories(),
            'stats' => $cronManager->stats(),
            'masterCron' => $cronManager->masterCronCommand(),
            'cronHealthy' => $cronManager->isCronHealthy(),
            'phpVersion' => PHP_VERSION,
            'basePath' => base_path(),
        ]);
    }

    public function runCronJob(Request $request, CronJobManagerService $cronManager): JsonResponse
    {
        $data = $request->validate(['slug' => 'required|string']);

        return response()->json($cronManager->run($data['slug']));
    }

    public function runAllCronJobs(CronJobManagerService $cronManager): JsonResponse
    {
        return response()->json($cronManager->run('schedule-run'));
    }

    public function cronJobLog(string $slug, CronJobManagerService $cronManager): JsonResponse
    {
        return response()->json([
            'success' => true,
            'log' => $cronManager->getLog($slug),
        ]);
    }

    /**
     * Show domain registrars page
     */
    public function registrars(): View
    {
        return view('admin.settings.registrars.index');
    }
}
