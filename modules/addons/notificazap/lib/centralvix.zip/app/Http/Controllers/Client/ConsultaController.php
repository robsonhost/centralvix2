<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\ConsultaLog;
use App\Models\ConsultaType;
use App\Services\ConsultaService;
use App\Support\ConsultaResultPresenter;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class ConsultaController extends Controller
{
    public function __construct(private ConsultaService $service) {}

    private function ensureModule(): void
    {
        $client = auth()->user()->resolveClient();
        abort_unless($client && consultas_available($client->company_id), 404);
    }

    /**
     * Tela principal "Nova Consulta" com abas: Pessoas, Empresas, Score.
     */
    public function index(Request $request): View
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $tab = $request->get('tab', 'pessoas');
        $tab = in_array($tab, ['pessoas', 'empresas', 'score']) ? $tab : 'pessoas';

        $types = ConsultaType::active()
            ->orderBy('category')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get()
            ->groupBy('category');

        $recent = ConsultaLog::where('client_id', $client->id)
            ->with('type')
            ->latest()
            ->limit(8)
            ->get();

        return view('client.consultas.index', compact('client', 'types', 'tab', 'recent'));
    }

    /**
     * Executa a consulta — redireciona para a página de resultado.
     */
    public function search(Request $request): RedirectResponse
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $data = $request->validate([
            'type_id'   => ['required', 'exists:consulta_types,id'],
            'parameter' => ['required', 'string', 'max:255'],
        ]);

        $type = ConsultaType::findOrFail($data['type_id']);

        $result = $this->service->run($client, $type, $data['parameter'], [
            'ip'         => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        if (! $result['success'] && ! isset($result['log'])) {
            return back()->with('error', $result['message']);
        }

        $log = $result['log'] ?? null;
        if (! $log) {
            return back()->with('error', $result['message']);
        }

        return redirect()
            ->route('client.consultas.show', $log->uuid)
            ->with($result['success'] ? 'success' : 'warning', $result['message']);
    }

    /**
     * Mostra o resultado de uma consulta específica.
     */
    public function show(string $uuid): View
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $log = ConsultaLog::where('uuid', $uuid)
            ->where('client_id', $client->id)
            ->with('type')
            ->firstOrFail();

        $presenter = ConsultaResultPresenter::from($log);
        $stats     = $this->buildClientStats($client, $log, $presenter);

        return view('client.consultas.show', compact('log', 'client', 'presenter', 'stats'));
    }

    /** @return array<string, mixed> */
    private function buildClientStats(Client $client, ConsultaLog $current, ConsultaResultPresenter $presenter): array
    {
        $since = now()->subMonths(6);

        $periodLogs = ConsultaLog::where('client_id', $client->id)
            ->where('created_at', '>=', $since)
            ->get();

        $monthly = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = now()->subMonths($i);
            $key   = $month->format('m/Y');
            $monthly[$key] = $periodLogs->filter(
                fn (ConsultaLog $l) => $l->created_at->format('m/Y') === $key
            )->count();
        }

        $byType = ConsultaLog::query()
            ->where('client_id', $client->id)
            ->where('created_at', '>=', $since)
            ->selectRaw('consulta_type_id, COUNT(*) as total')
            ->groupBy('consulta_type_id')
            ->orderByDesc('total')
            ->limit(5)
            ->get()
            ->map(function ($row) {
                $type = ConsultaType::find($row->consulta_type_id);

                return [
                    'name'  => $type?->name ?? 'Consulta',
                    'total' => (int) $row->total,
                ];
            })
            ->values()
            ->all();

        $recent = ConsultaLog::where('client_id', $client->id)
            ->where('id', '!=', $current->id)
            ->with('type')
            ->latest()
            ->limit(5)
            ->get();

        $successCount = $periodLogs->where('status', 'success')->count();
        $failedCount  = $periodLogs->whereIn('status', ['failed', 'no_data'])->count();

        return [
            'total_period'  => $periodLogs->count(),
            'spent_period'  => (float) $periodLogs->sum('sale_price'),
            'success_count' => $successCount,
            'failed_count'  => $failedCount,
            'monthly'       => $monthly,
            'by_type'       => $byType,
            'recent'        => $recent,
            'result'        => $presenter->resultStats(),
            'section_nav'   => $presenter->sectionNav(),
        ];
    }

    /**
     * Serve o PDF gerado por consultas que retornam relatório binário
     * (SERA_OFC, SERA_PREMIUM, etc.). O arquivo fica em storage privado e
     * só pode ser acessado pelo cliente dono do log.
     */
    public function pdf(string $uuid, Request $request): BinaryFileResponse
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $log = ConsultaLog::where('uuid', $uuid)
            ->where('client_id', $client->id)
            ->firstOrFail();

        $result = $log->result ?? [];
        $path   = $result['_path'] ?? null;

        if (! $path || ! Storage::disk('local')->exists($path)) {
            abort(404, 'Arquivo não encontrado.');
        }

        $filename = $result['_filename'] ?? ('consulta-' . $log->uuid . '.pdf');
        $disposition = $request->boolean('download') ? 'attachment' : 'inline';

        return response()->file(
            Storage::disk('local')->path($path),
            [
                'Content-Type'        => 'application/pdf',
                'Content-Disposition' => $disposition . '; filename="' . $filename . '"',
            ]
        );
    }

    /**
     * Histórico geral de consultas realizadas.
     */
    public function history(Request $request): View
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $logs = ConsultaLog::where('client_id', $client->id)
            ->with('type')
            ->latest()
            ->paginate(20);

        return view('client.consultas.history', compact('logs', 'client'));
    }
}
