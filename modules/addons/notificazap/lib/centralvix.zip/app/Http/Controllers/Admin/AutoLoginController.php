<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AutoLoginLog;
use App\Models\AutoLoginToken;
use App\Models\Client;
use App\Services\AutoLoginService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class AutoLoginController extends Controller
{
    public function __construct(private AutoLoginService $service) {}

    public function index(Request $request): View
    {
        $companyId = (int) auth()->user()->company_id;
        abort_unless($this->service->isEnabled($companyId), 404);

        $stats = [
            'active'   => AutoLoginToken::where('company_id', $companyId)->where('expires_at', '>', now())->where('used', false)->count(),
            'used'     => AutoLoginToken::where('company_id', $companyId)->where('used', true)->count(),
            'expired'  => AutoLoginToken::where('company_id', $companyId)->where('expires_at', '<=', now())->count(),
            'clicks'   => (int) AutoLoginToken::where('company_id', $companyId)->sum('click_count'),
            'logins'   => AutoLoginLog::where('company_id', $companyId)->where('success', true)->count(),
        ];

        $recentLogs = AutoLoginLog::where('company_id', $companyId)
            ->with(['client:id,firstname,lastname,email', 'token:id,short_code,sent_via'])
            ->latest()
            ->limit(15)
            ->get();

        $recentTokens = AutoLoginToken::where('company_id', $companyId)
            ->with('client:id,firstname,lastname,email')
            ->latest()
            ->limit(10)
            ->get();

        $clients = Client::where('company_id', $companyId)
            ->where('status', '!=', 'closed')
            ->orderBy('firstname')
            ->limit(300)
            ->get(['id', 'firstname', 'lastname', 'email']);

        $cfg = $this->service->config($companyId);
        $whatsappEnabled = app(\App\Services\ModuleService::class)->isEnabled($companyId, 'whatsapp');

        return view('admin.autologin.index', compact(
            'stats', 'recentLogs', 'recentTokens', 'clients', 'cfg', 'whatsappEnabled'
        ));
    }

    public function tokens(Request $request): View
    {
        $companyId = (int) auth()->user()->company_id;
        abort_unless($this->service->isEnabled($companyId), 404);

        $filter = $request->query('filter', 'active');
        $search = trim((string) $request->query('q', ''));

        $query = AutoLoginToken::where('company_id', $companyId)
            ->with(['client:id,firstname,lastname,email'])
            ->latest();

        if ($search !== '') {
            $query->whereHas('client', function ($q) use ($search) {
                $q->where('email', 'like', "%{$search}%")
                    ->orWhere('firstname', 'like', "%{$search}%")
                    ->orWhere('lastname', 'like', "%{$search}%");
            });
        }

        match ($filter) {
            'used'    => $query->where('used', true),
            'expired' => $query->where('expires_at', '<=', now()),
            'all'     => null,
            default   => $query->where('expires_at', '>', now())->where('used', false),
        };

        $tokens = $query->paginate(25)->withQueryString();

        return view('admin.autologin.tokens', compact('tokens', 'filter', 'search'));
    }

    public function exportTokens(Request $request): StreamedResponse
    {
        $companyId = (int) auth()->user()->company_id;
        abort_unless($this->service->isEnabled($companyId), 404);

        $filter = $request->query('filter', 'active');
        $search = trim((string) $request->query('q', ''));

        $query = AutoLoginToken::where('company_id', $companyId)
            ->with(['client:id,firstname,lastname,email'])
            ->latest();

        if ($search !== '') {
            $query->whereHas('client', function ($q) use ($search) {
                $q->where('email', 'like', "%{$search}%")
                    ->orWhere('firstname', 'like', "%{$search}%")
                    ->orWhere('lastname', 'like', "%{$search}%");
            });
        }

        match ($filter) {
            'used'    => $query->where('used', true),
            'expired' => $query->where('expires_at', '<=', now()),
            'all'     => null,
            default   => $query->where('expires_at', '>', now())->where('used', false),
        };

        $filename = 'autologin-tokens-' . now()->format('Y-m-d-His') . '.csv';

        return response()->streamDownload(function () use ($query) {
            $out = fopen('php://output', 'w');
            fputcsv($out, [
                'ID', 'Cliente', 'E-mail', 'Link curto', 'Cliques', 'Enviado via',
                'Contexto', 'Usado', 'Expira em', 'Criado em',
            ], ';');

            $query->chunk(200, function ($tokens) use ($out) {
                foreach ($tokens as $token) {
                    fputcsv($out, [
                        $token->id,
                        trim(($token->client->firstname ?? '') . ' ' . ($token->client->lastname ?? '')),
                        $token->client->email ?? '',
                        $token->short_code ? url('/l/' . $token->short_code) : '',
                        $token->click_count,
                        $token->sent_via,
                        $token->context_type,
                        $token->used ? 'sim' : 'nao',
                        optional($token->expires_at)->format('d/m/Y H:i'),
                        optional($token->created_at)->format('d/m/Y H:i'),
                    ], ';');
                }
            });

            fclose($out);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function logs(Request $request): View
    {
        $companyId = (int) auth()->user()->company_id;
        abort_unless($this->service->isEnabled($companyId), 404);

        $logs = AutoLoginLog::where('company_id', $companyId)
            ->with(['client:id,firstname,lastname,email', 'token:id,short_code,sent_via'])
            ->latest()
            ->paginate(40);

        return view('admin.autologin.logs', compact('logs'));
    }

    public function generate(Request $request): RedirectResponse
    {
        $companyId = (int) auth()->user()->company_id;
        abort_unless($this->service->isEnabled($companyId), 404);

        $data = $request->validate([
            'client_id'   => ['required', 'exists:clients,id'],
            'redirect_to' => ['nullable', 'url', 'max:500'],
            'channel'     => ['required', 'in:email,whatsapp,copy'],
        ]);

        $client = Client::where('company_id', $companyId)->findOrFail($data['client_id']);

        $result = $this->service->sendLinkToClient(
            $client,
            $data['redirect_to'] ?: null,
            $data['channel'] === 'copy' ? 'manual' : $data['channel'],
            auth()->user(),
        );

        if (!($result['success'] ?? false)) {
            return back()->with('error', $result['message'] ?? 'Erro ao gerar link.');
        }

        return back()->with([
            'success'      => $result['message'],
            'generated_link' => $result['link'] ?? null,
        ]);
    }

    public function revoke(AutoLoginToken $token): RedirectResponse
    {
        abort_unless($token->company_id === (int) auth()->user()->company_id, 403);
        $token->update(['used' => true, 'used_at' => now(), 'expires_at' => now()]);

        return back()->with('success', 'Token revogado.');
    }
}
