<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Contract;
use App\Models\Invoice;
use App\Services\ValidationService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SegundaViaController extends Controller
{
    public function __construct(private ValidationService $validation) {}

    public function index(): View
    {
        return view('public.segunda-via.index');
    }

    public function search(Request $request): View
    {
        $request->validate([
            'query' => 'required|string|min:3|max:50',
            'type'  => 'required|in:email,cpf,invoice',
        ]);

        $searchTerm = trim($request->input('query'));
        $type       = $request->input('type');
        $result     = null;
        $error      = null;

        try {
            $client = null;

            if ($type === 'email') {
                $client = Client::where('email', $searchTerm)->first();
            } elseif ($type === 'cpf') {
                $cpf = preg_replace('/\D/', '', $searchTerm);
                if (!$this->validation->validateCpf($cpf)) {
                    $error = 'CPF inválido.';
                } else {
                    $client = Client::where('cpf', $cpf)->orWhere('cpf', $searchTerm)->first();
                }
            } elseif ($type === 'invoice') {
                $invoice = Invoice::where('invoice_number', $searchTerm)->first();
                if ($invoice) {
                    $client = $invoice->client;
                }
            }

            if (!$error) {
                if (!$client) {
                    $error = 'Nenhum registro encontrado para os dados informados.';
                } else {
                    $result = [
                        'client'    => $client,
                        'invoices'  => $client->invoices()
                            ->whereIn('status', ['unpaid', 'overdue', 'paid'])
                            ->latest('date_created')
                            ->take(10)
                            ->get(),
                        'contracts' => Contract::where('client_id', $client->id)
                            ->whereIn('status', ['sent', 'signed', 'viewed'])
                            ->latest()
                            ->take(5)
                            ->get(),
                    ];
                }
            }
        } catch (\Exception $e) {
            $error = 'Erro ao consultar. Tente novamente.';
            logger()->error('SegundaVia error: ' . $e->getMessage());
        }

        return view('public.segunda-via.index', [
            'result' => $result,
            'error'  => $error,
            'query'  => $searchTerm,
            'type'   => $type,
        ]);
    }

    public function invoice(string $invoiceNumber): View
    {
        $invoice = Invoice::with(['client', 'items', 'transactions'])
            ->where('invoice_number', $invoiceNumber)
            ->firstOrFail();

        return view('public.segunda-via.invoice', compact('invoice'));
    }

    public function contract(string $token): View
    {
        $contract = Contract::where('signature_token', $token)
            ->with(['client', 'template'])
            ->firstOrFail();

        if (!$contract->viewed_at) {
            $contract->update(['viewed_at' => now(), 'status' => 'viewed']);
        }

        return view('public.segunda-via.contract', compact('contract'));
    }

    public function signContract(Request $request, string $token)
    {
        $contract = Contract::where('signature_token', $token)->firstOrFail();

        if ($contract->isSigned()) {
            return back()->with('info', 'Contrato já foi assinado.');
        }

        if ($contract->isExpired()) {
            return back()->with('error', 'Este contrato expirou.');
        }

        $request->validate([
            'agree' => 'required|accepted',
            'name'  => 'required|string|max:200',
        ]);

        $ip     = $request->ip();
        $device = $request->userAgent();
        $geo    = null;

        try {
            $geoData = app(\App\Services\ValidationService::class)->geolocateIp($ip);
            $geo     = "{$geoData['city']}, {$geoData['region']}, {$geoData['country']}";
        } catch (\Exception) {}

        app(\App\Services\ContractService::class)->sign($contract, $ip, $geo, $device);

        return view('public.segunda-via.contract-signed', compact('contract'));
    }
}
