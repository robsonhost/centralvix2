<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\ClientEmailVerificationMail;
use App\Mail\WelcomeClientMail;
use App\Models\Client;
use App\Models\Company;
use App\Models\Setting;
use App\Models\User;
use App\Services\EvolutionWhatsAppService;
use App\Services\ModuleService;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\View\View;

class RegisterController extends Controller
{
    public function showRegistrationForm(): View
    {
        $company = Company::first();
        $validateClients = $company
            ? app(ModuleService::class)->isEnabled($company->id, 'validate_clients')
            : false;

        return view('auth.register', compact('validateClients'));
    }

    public function register(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name'     => 'required|string|max:100',
            'lastname' => 'required|string|max:100',
            'email'    => 'required|email|max:255|unique:users,email',
            'password' => 'required|min:8|confirmed',
            'phone'    => 'nullable|string|max:25',
        ]);

        // Get default company (single tenant) or create for multi-tenant
        $company = Company::first();
        if (!$company) {
            return redirect()->route('login')->with('error', 'Sistema não configurado. Execute os seeders.');
        }

        // Check if email already in use by a client
        $existingClient = Client::where('company_id', $company->id)
            ->where('email', $validated['email'])
            ->exists();

        if ($existingClient) {
            return back()->withErrors(['email' => 'E-mail já cadastrado.'])->onlyInput('email');
        }

        $companyId = $company->id;

        // Lê configurações da página de Segurança e Verificação
        $verificationEnabled    = filter_var(Setting::get($companyId, 'verification', 'enabled', true), FILTER_VALIDATE_BOOLEAN);
        $welcomeEmailEnabled    = filter_var(Setting::get($companyId, 'notifications', 'welcome_email_enabled', true), FILTER_VALIDATE_BOOLEAN);
        $welcomeWhatsappEnabled = filter_var(Setting::get($companyId, 'notifications', 'welcome_whatsapp_enabled', true), FILTER_VALIDATE_BOOLEAN);

        // Telefone (apenas dígitos)
        $phone = $request->filled('phone') ? preg_replace('/\D/', '', $request->input('phone')) : null;

        // Módulo "Valida Clientes": exige e valida CPF/CNPJ (+ telefone)
        $validateClients = app(ModuleService::class)->isEnabled($companyId, 'validate_clients');
        $cpf = null;
        $cnpj = null;
        $personType = 'individual';

        if ($validateClients) {
            $request->validate([
                'person_type' => 'required|in:individual,company',
                'document'    => 'required|string',
            ], [], ['document' => 'CPF/CNPJ']);

            $personType = $request->input('person_type');
            $doc = preg_replace('/\D/', '', (string) $request->input('document'));

            if ($personType === 'company') {
                if (!$this->isValidCnpj($doc)) {
                    return back()->withErrors(['document' => 'CNPJ inválido.'])->withInput();
                }
                $cnpj = $doc;
            } else {
                if (!$this->isValidCpf($doc)) {
                    return back()->withErrors(['document' => 'CPF inválido.'])->withInput();
                }
                $cpf = $doc;
            }

            if (!$phone || strlen($phone) < 10) {
                return back()->withErrors(['phone' => 'Telefone/WhatsApp é obrigatório.'])->withInput();
            }

            // Evita documento duplicado na mesma empresa
            $docExists = Client::where('company_id', $companyId)
                ->when($cpf, fn ($q) => $q->where('cpf', $cpf))
                ->when($cnpj, fn ($q) => $q->where('cnpj', $cnpj))
                ->exists();

            if ($docExists) {
                return back()->withErrors(['document' => 'Este CPF/CNPJ já está cadastrado.'])->withInput();
            }
        }

        // Create user
        $user = User::create([
            'name'       => $validated['name'] . ' ' . $validated['lastname'],
            'email'      => $validated['email'],
            'password'   => Hash::make($validated['password']),
            'company_id' => $company->id,
        ]);

        // Assign client role
        if (method_exists($user, 'assignRole')) {
            $user->assignRole('client');
        }

        // Se a verificação estiver desabilitada, marca como verificado de imediato
        if (!$verificationEnabled) {
            try {
                $user->forceFill(['email_verified_at' => now()])->save();
            } catch (\Exception $e) {
                logger()->error('Erro ao marcar usuário como verificado: ' . $e->getMessage());
            }
        }

        // Create client profile
        $client = Client::create([
            'uuid'              => Str::uuid(),
            'company_id'        => $company->id,
            'user_id'           => $user->id,
            'type'              => $personType,
            'firstname'         => $validated['name'],
            'lastname'          => $validated['lastname'],
            'email'             => $validated['email'],
            'phone'             => $phone,
            'mobile'            => $phone,
            'whatsapp'          => $phone,
            'cpf'               => $cpf,
            'cnpj'              => $cnpj,
            'currency'          => 'BRL',
            'language'          => 'pt_BR',
            'status'            => 'active',
            'email_verified_at' => $verificationEnabled ? null : now(),
        ]);

        // Calculate initial profile completion
        $user->updateProfileCompletion();

        // Envia email de boas-vindas com dados de acesso (se habilitado)
        if ($welcomeEmailEnabled) {
            try {
                Mail::to($client->email)->send(new WelcomeClientMail($client, $validated['password']));
            } catch (\Exception $e) {
                logger()->error("Erro ao enviar email de boas-vindas: " . $e->getMessage());
            }
        }

        // Envia WhatsApp de boas-vindas com dados de acesso (se habilitado e houver telefone)
        if ($welcomeWhatsappEnabled && $phone) {
            try {
                app(EvolutionWhatsAppService::class)->sendWelcome(
                    $phone,
                    $client->firstname,
                    $client->email,
                    $validated['password']
                );
            } catch (\Exception $e) {
                logger()->error("Erro ao enviar WhatsApp de boas-vindas: " . $e->getMessage());
            }
        }

        // Faz login do usuário
        Auth::login($user);

        // Se a verificação não for exigida, vai direto ao painel
        if (!$verificationEnabled) {
            return redirect()->route('client.dashboard')
                ->with('success', 'Conta criada com sucesso! Bem-vindo(a).');
        }

        // Gera token e envia email de verificação
        $token = $client->generateVerificationToken();
        $verificationUrl = route('verification.verify.token', ['token' => $token]);

        try {
            event(new Registered($user));
        } catch (\Exception $e) {
            logger()->error('Erro ao enviar notificação de verificação do Laravel: ' . $e->getMessage());
        }

        try {
            Mail::to($client->email)->send(new ClientEmailVerificationMail($client, $verificationUrl));
        } catch (\Exception $e) {
            logger()->error("Erro ao enviar email de verificação: " . $e->getMessage());
        }

        // Redireciona para página de verificação
        return redirect()->route('verification.notice')
            ->with('success', 'Conta criada com sucesso! Verifique seu email para ativar sua conta e receber seus dados de acesso.');
    }

    /**
     * Valida um CPF (apenas dígitos).
     */
    private function isValidCpf(string $cpf): bool
    {
        if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf)) {
            return false;
        }

        for ($t = 9; $t < 11; $t++) {
            $sum = 0;
            for ($i = 0; $i < $t; $i++) {
                $sum += (int) $cpf[$i] * (($t + 1) - $i);
            }
            $digit = ((10 * $sum) % 11) % 10;
            if ((int) $cpf[$t] !== $digit) {
                return false;
            }
        }

        return true;
    }

    /**
     * Valida um CNPJ (apenas dígitos).
     */
    private function isValidCnpj(string $cnpj): bool
    {
        if (strlen($cnpj) !== 14 || preg_match('/^(\d)\1{13}$/', $cnpj)) {
            return false;
        }

        $weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        $weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];

        $sum = 0;
        foreach ($weights1 as $i => $w) {
            $sum += (int) $cnpj[$i] * $w;
        }
        $d1 = $sum % 11 < 2 ? 0 : 11 - ($sum % 11);
        if ((int) $cnpj[12] !== $d1) {
            return false;
        }

        $sum = 0;
        foreach ($weights2 as $i => $w) {
            $sum += (int) $cnpj[$i] * $w;
        }
        $d2 = $sum % 11 < 2 ? 0 : 11 - ($sum % 11);

        return (int) $cnpj[13] === $d2;
    }
}
