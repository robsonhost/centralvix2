<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ClientGroup;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ClientGroupController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        $groups = ClientGroup::withCount('clients')
            ->where('company_id', $companyId)
            ->orderBy('order')
            ->orderBy('name')
            ->get();

        return view('admin.settings.client-groups.index', compact('groups'));
    }

    public function create(): View
    {
        return view('admin.settings.client-groups.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'color' => 'required|string|size:7|regex:/^#[0-9A-F]{6}$/i',
            'discount_percentage' => 'required|numeric|min:0|max:100',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $validated['company_id'] = auth()->user()->company_id;

        ClientGroup::create($validated);

        return redirect()->route('admin.settings.client-groups.index')
            ->with('success', 'Grupo criado com sucesso!');
    }

    public function edit(ClientGroup $clientGroup): View
    {
        return view('admin.settings.client-groups.edit', compact('clientGroup'));
    }

    public function update(Request $request, ClientGroup $clientGroup): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'color' => 'required|string|size:7|regex:/^#[0-9A-F]{6}$/i',
            'discount_percentage' => 'required|numeric|min:0|max:100',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $clientGroup->update($validated);

        return redirect()->route('admin.settings.client-groups.index')
            ->with('success', 'Grupo atualizado com sucesso!');
    }

    public function destroy(ClientGroup $clientGroup): RedirectResponse
    {
        $clientGroup->delete();

        return redirect()->route('admin.settings.client-groups.index')
            ->with('success', 'Grupo removido com sucesso!');
    }
}
