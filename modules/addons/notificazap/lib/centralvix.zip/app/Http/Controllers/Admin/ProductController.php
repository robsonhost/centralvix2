<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductGroup;
use App\Models\Server;
use App\Services\AdminExportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ProductController extends Controller
{
    public function __construct(private AdminExportService $exportService) {}

    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Product::with('group')
            ->where('company_id', $companyId);

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('group')) {
            $query->where('group_id', $request->group);
        }

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $products = $query->orderBy('order')->paginate(20);
        $groups = ProductGroup::where('company_id', $companyId)->get();

        $stats = [
            'total' => Product::where('company_id', $companyId)->count(),
            'active' => Product::where('company_id', $companyId)->where('status', 'active')->count(),
            'inactive' => Product::where('company_id', $companyId)->where('status', 'inactive')->count(),
            'hidden' => Product::where('company_id', $companyId)->where('status', 'hidden')->count(),
            'low_stock' => Product::where('company_id', $companyId)
                ->where('stock_unlimited', false)
                ->whereRaw('stock <= 5')
                ->count(),
            'total_value' => Product::where('company_id', $companyId)
                ->where('status', 'active')
                ->sum('price_monthly'),
        ];

        return view('admin.products.index', compact('products', 'groups', 'stats'));
    }

    public function show(Request $request, Product $product): View|JsonResponse
    {
        $this->authorizeCompany($product);
        $product->load(['group', 'features', 'services.client']);

        $stats = [
            'services_total' => $product->services()->count(),
            'services_active' => $product->services()->where('status', 'active')->count(),
            'orders_total' => $product->orderItems()->count(),
            'revenue' => $product->orderItems()->sum('total'),
        ];

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'product' => $this->productPayload($product, $stats),
            ]);
        }

        return view('admin.products.show', compact('product', 'stats'));
    }

    public function create(): View
    {
        $companyId = auth()->user()->company_id;
        $groups = ProductGroup::where('company_id', $companyId)->where('status', 'active')->get();
        $servers = Server::where('company_id', $companyId)->where('status', 'active')->get();
        return view('admin.products.create', compact('groups', 'servers'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'group_id' => 'nullable|exists:product_groups,id',
            'type' => 'required|in:hosting,reseller,vps,dedicated,domain,ssl,email,saas,license,custom,streaming_audio,streaming_video',
            'description' => 'nullable|string',
            'short_description' => 'nullable|string|max:500',
            'price_monthly' => 'nullable|numeric|min:0',
            'price_quarterly' => 'nullable|numeric|min:0',
            'price_semiannually' => 'nullable|numeric|min:0',
            'price_annually' => 'nullable|numeric|min:0',
            'price_biennially' => 'nullable|numeric|min:0',
            'price_triennially' => 'nullable|numeric|min:0',
            'price_lifetime' => 'nullable|numeric|min:0',
            'setup_fee' => 'nullable|numeric|min:0',
            'stock' => 'nullable|integer|min:0',
            'stock_unlimited' => 'boolean',
            'module' => 'nullable|string',
            'module_server_id' => 'nullable|integer|exists:servers,id',
            'whm_plan' => 'nullable|string|max:64',
            'status' => 'required|in:active,inactive,hidden',
            'featured' => 'boolean',
            'order' => 'nullable|integer',
        ]);

        $companyId = auth()->user()->company_id;

        $product = Product::create(array_merge($validated, [
            'company_id' => $companyId,
            'stock_unlimited' => $request->boolean('stock_unlimited', true),
            'featured' => $request->boolean('featured', false),
            'module_config' => $this->buildModuleConfig($request),
        ]));

        $this->syncFeatures($product, $request);

        return redirect()->route('admin.products.edit', $product)
            ->with('success', 'Produto criado com sucesso!');
    }

    public function edit(Product $product): View
    {
        $this->authorizeCompany($product);

        $companyId = auth()->user()->company_id;
        $groups = ProductGroup::where('company_id', $companyId)->where('status', 'active')->get();
        $servers = Server::where('company_id', $companyId)->where('status', 'active')->get();
        $product->load('features');

        return view('admin.products.edit', compact('product', 'groups', 'servers'));
    }

    public function update(Request $request, Product $product): RedirectResponse|JsonResponse
    {
        $this->authorizeCompany($product);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'group_id' => 'nullable|exists:product_groups,id',
            'type' => 'required|in:hosting,reseller,vps,dedicated,domain,ssl,email,saas,license,custom,streaming_audio,streaming_video',
            'description' => 'nullable|string',
            'short_description' => 'nullable|string|max:500',
            'price_monthly' => 'nullable|numeric|min:0',
            'price_quarterly' => 'nullable|numeric|min:0',
            'price_semiannually' => 'nullable|numeric|min:0',
            'price_annually' => 'nullable|numeric|min:0',
            'price_biennially' => 'nullable|numeric|min:0',
            'price_triennially' => 'nullable|numeric|min:0',
            'price_lifetime' => 'nullable|numeric|min:0',
            'setup_fee' => 'nullable|numeric|min:0',
            'stock' => 'nullable|integer|min:0',
            'stock_unlimited' => 'boolean',
            'module' => 'nullable|string',
            'module_server_id' => 'nullable|integer|exists:servers,id',
            'whm_plan' => 'nullable|string|max:64',
            'status' => 'required|in:active,inactive,hidden',
            'featured' => 'boolean',
            'order' => 'nullable|integer',
        ]);

        $product->update(array_merge($validated, [
            'stock_unlimited' => $request->boolean('stock_unlimited', true),
            'featured' => $request->boolean('featured', false),
            'module_config' => $this->buildModuleConfig($request, $product),
        ]));

        $this->syncFeatures($product, $request);

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'message' => 'Produto atualizado com sucesso!']);
        }

        return redirect()->route('admin.products.edit', $product)
            ->with('success', 'Produto atualizado com sucesso!');
    }

    public function destroy(Request $request, Product $product): RedirectResponse|JsonResponse
    {
        $this->authorizeCompany($product);

        if ($product->services()->whereIn('status', ['active', 'pending'])->exists()) {
            $message = 'Não é possível excluir: existem serviços ativos vinculados a este produto.';
            if ($request->wantsJson()) {
                return response()->json(['success' => false, 'message' => $message], 422);
            }
            return back()->with('error', $message);
        }

        $product->features()->delete();
        $product->delete();

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'message' => 'Produto excluído com sucesso!']);
        }

        return redirect()->route('admin.products.index')
            ->with('success', 'Produto removido com sucesso!');
    }

    public function duplicate(Product $product): JsonResponse
    {
        $this->authorizeCompany($product);
        $product->load('features');

        $copy = $product->replicate(['uuid', 'slug']);
        $copy->uuid = Str::uuid();
        $copy->name = $product->name . ' (Cópia)';
        $copy->slug = Str::slug($copy->name) . '-' . Str::random(4);
        $copy->status = 'inactive';
        $copy->featured = false;
        $copy->save();

        foreach ($product->features as $feature) {
            $copy->features()->create($feature->only(['name', 'value', 'icon', 'order', 'highlighted']));
        }

        return response()->json([
            'success' => true,
            'message' => 'Produto duplicado com sucesso!',
            'redirect' => route('admin.products.edit', $copy),
        ]);
    }

    public function toggleStatus(Request $request, Product $product): JsonResponse
    {
        $this->authorizeCompany($product);

        $validated = $request->validate([
            'status' => 'nullable|in:active,inactive,hidden',
        ]);

        $newStatus = $validated['status'] ?? ($product->status === 'active' ? 'inactive' : 'active');
        $product->update(['status' => $newStatus]);

        return response()->json([
            'success' => true,
            'message' => 'Status atualizado para ' . match ($newStatus) {
                'active' => 'Ativo',
                'inactive' => 'Inativo',
                'hidden' => 'Oculto',
                default => $newStatus,
            },
            'status' => $newStatus,
        ]);
    }

    public function bulk(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'action' => 'required|in:activate,deactivate,delete',
            'ids' => 'required|array|min:1',
            'ids.*' => 'integer',
        ]);

        $companyId = auth()->user()->company_id;
        $products = Product::where('company_id', $companyId)->whereIn('id', $validated['ids'])->get();

        if ($products->isEmpty()) {
            return response()->json(['success' => false, 'message' => 'Nenhum produto encontrado.'], 404);
        }

        $count = 0;
        $skipped = 0;

        foreach ($products as $product) {
            if ($validated['action'] === 'activate') {
                $product->update(['status' => 'active']);
                $count++;
            } elseif ($validated['action'] === 'deactivate') {
                $product->update(['status' => 'inactive']);
                $count++;
            } elseif ($this->tryDeleteProduct($product)) {
                $count++;
            } else {
                $skipped++;
            }
        }

        $messages = [
            'activate' => "{$count} produto(s) ativado(s).",
            'deactivate' => "{$count} produto(s) desativado(s).",
            'delete' => "{$count} produto(s) excluído(s)." . ($skipped ? " {$skipped} ignorado(s) por terem serviços ativos." : ''),
        ];

        return response()->json([
            'success' => true,
            'message' => $messages[$validated['action']],
            'processed' => $count,
            'skipped' => $skipped,
        ]);
    }

    public function export(Request $request): StreamedResponse|\Illuminate\Http\Response
    {
        $companyId = auth()->user()->company_id;
        $format = $request->get('format', 'csv');

        $query = Product::with('group')->where('company_id', $companyId);

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }
        if ($request->filled('group')) {
            $query->where('group_id', $request->group);
        }
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $headings = ['ID', 'Nome', 'Grupo', 'Tipo', 'Mensal', 'Anual', 'Setup', 'Estoque', 'Módulo', 'Status', 'Destaque', 'Criado em'];
        $rows = $query->orderBy('order')->get()->map(fn (Product $p) => [
            $p->id,
            $p->name,
            $p->group?->name ?? '—',
            $p->getTypeLabel(),
            $p->price_monthly ? number_format((float) $p->price_monthly, 2, ',', '.') : '—',
            $p->price_annually ? number_format((float) $p->price_annually, 2, ',', '.') : '—',
            $p->setup_fee ? number_format((float) $p->setup_fee, 2, ',', '.') : '—',
            $p->stock_unlimited ? 'Ilimitado' : ($p->stock ?? 0),
            $p->module ?? '—',
            match ($p->status) { 'active' => 'Ativo', 'inactive' => 'Inativo', 'hidden' => 'Oculto', default => $p->status },
            $p->featured ? 'Sim' : 'Não',
            $p->created_at?->format('d/m/Y H:i') ?? '—',
        ])->all();

        return $this->exportService->download($format, 'Produtos', $headings, $rows);
    }

    private function tryDeleteProduct(Product $product): bool
    {
        if ($product->services()->whereIn('status', ['active', 'pending'])->exists()) {
            return false;
        }
        $product->features()->delete();
        $product->delete();

        return true;
    }

    private function syncFeatures(Product $product, Request $request): void
    {
        if (!$request->has('features')) {
            return;
        }

        $product->features()->delete();
        foreach ($request->features as $i => $feature) {
            if (!empty($feature['name'])) {
                $product->features()->create([
                    'name' => $feature['name'],
                    'value' => $feature['value'] ?? '',
                    'icon' => $feature['icon'] ?? null,
                    'order' => $i,
                    'highlighted' => !empty($feature['highlighted']),
                ]);
            }
        }
    }

    private function productPayload(Product $product, array $stats): array
    {
        return [
            'id' => $product->id,
            'name' => $product->name,
            'slug' => $product->slug,
            'type' => $product->type,
            'type_label' => $product->getTypeLabel(),
            'status' => $product->status,
            'status_label' => match ($product->status) {
                'active' => 'Ativo', 'inactive' => 'Inativo', 'hidden' => 'Oculto', default => $product->status,
            },
            'featured' => $product->featured,
            'group' => $product->group?->name,
            'module' => $product->module,
            'short_description' => $product->short_description,
            'description' => $product->description,
            'stock' => $product->stock_unlimited ? 'Ilimitado' : ($product->stock ?? 0),
            'setup_fee' => $product->setup_fee ? 'R$ ' . number_format((float) $product->setup_fee, 2, ',', '.') : null,
            'prices' => array_filter([
                'Mensal' => $product->price_monthly,
                'Trimestral' => $product->price_quarterly,
                'Semestral' => $product->price_semiannually,
                'Anual' => $product->price_annually,
                'Bienal' => $product->price_biennially,
                'Trienal' => $product->price_triennially,
                'Vitalício' => $product->price_lifetime,
            ], fn ($v) => $v !== null && (float) $v > 0),
            'features' => $product->features->map(fn ($f) => [
                'name' => $f->name,
                'value' => $f->value,
                'highlighted' => $f->highlighted,
            ]),
            'stats' => $stats,
            'edit_url' => route('admin.products.edit', $product),
            'show_url' => route('admin.products.show', $product),
        ];
    }

    private function authorizeCompany(Product $product): void
    {
        if ($product->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }

    private function buildModuleConfig(Request $request, ?Product $product = null): ?array
    {
        $existing = (array) ($product?->module_config ?? []);
        $module = $request->input('module', $product?->module);
        $type = $request->input('type', $product?->type);

        if ($module === 'CpanelModule' || in_array($type, ['hosting', 'reseller'], true)) {
            $serverId = $request->input('module_server_id', $request->input('server_id'));
            $plan = $request->input('whm_plan', $request->input('module_plan'));

            $config = array_filter([
                'server_id' => $serverId !== null && $serverId !== '' ? (int) $serverId : ($existing['server_id'] ?? null),
                'plan' => $plan ?: ($existing['plan'] ?? null),
            ], fn ($value) => $value !== null && $value !== '');

            if ($config !== []) {
                return array_merge($existing, $config);
            }
        }

        return $existing !== [] ? $existing : null;
    }
}
