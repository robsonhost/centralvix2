<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DashboardWidget;
use App\Models\UserDashboardLayout;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\JsonResponse;

class DashboardCustomController extends Controller
{
    /**
     * Show customize dashboard page
     */
    public function customize(): View
    {
        $userId = auth()->id();
        
        // Get available widgets
        $availableWidgets = DashboardWidget::active()->get();
        
        // Get user's current layout
        $userLayout = UserDashboardLayout::where('user_id', $userId)->first();
        
        // Default layout if none exists
        $layout = $userLayout ? $userLayout->layout : $this->getDefaultLayout();
        $widgetSettings = $userLayout ? $userLayout->widget_settings : [];

        return view('admin.dashboard.customize', compact('availableWidgets', 'layout', 'widgetSettings'));
    }

    /**
     * Save dashboard layout
     */
    public function saveLayout(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'layout' => 'required|array',
            'layout.*.id' => 'required|integer|exists:dashboard_widgets,id',
            'layout.*.x' => 'required|integer|min:0',
            'layout.*.y' => 'required|integer|min:0',
            'layout.*.w' => 'required|integer|min:1|max:12',
            'layout.*.h' => 'required|integer|min:1',
        ]);

        $userId = auth()->id();

        UserDashboardLayout::updateOrCreate(
            ['user_id' => $userId],
            [
                'layout' => $validated['layout'],
                'widget_settings' => $request->input('widget_settings', []),
            ]
        );

        return response()->json([
            'success' => true,
            'message' => 'Layout salvo com sucesso!',
        ]);
    }

    /**
     * Reset to default layout
     */
    public function resetLayout(): JsonResponse
    {
        $userId = auth()->id();
        
        UserDashboardLayout::where('user_id', $userId)->delete();

        return response()->json([
            'success' => true,
            'message' => 'Layout restaurado para o padrão!',
            'layout' => $this->getDefaultLayout(),
        ]);
    }

    /**
     * Update widget settings
     */
    public function updateWidgetSettings(Request $request, int $widgetId): JsonResponse
    {
        $validated = $request->validate([
            'settings' => 'required|array',
        ]);

        $userId = auth()->id();
        $userLayout = UserDashboardLayout::firstOrCreate(['user_id' => $userId]);

        $widgetSettings = $userLayout->widget_settings ?? [];
        $widgetSettings[$widgetId] = $validated['settings'];

        $userLayout->update(['widget_settings' => $widgetSettings]);

        return response()->json([
            'success' => true,
            'message' => 'Configurações do widget atualizadas!',
        ]);
    }

    /**
     * Get default layout
     */
    protected function getDefaultLayout(): array
    {
        return [
            ['id' => 1, 'x' => 0, 'y' => 0, 'w' => 8, 'h' => 4],  // Revenue Chart
            ['id' => 4, 'x' => 8, 'y' => 0, 'w' => 4, 'h' => 2],  // Active Services
            ['id' => 5, 'x' => 8, 'y' => 2, 'w' => 4, 'h' => 2],  // Total Clients
            ['id' => 2, 'x' => 0, 'y' => 4, 'w' => 6, 'h' => 4],  // Recent Orders
            ['id' => 3, 'x' => 6, 'y' => 4, 'w' => 6, 'h' => 4],  // Recent Tickets
        ];
    }

    /**
     * Get widget data
     */
    public function getWidgetData(int $widgetId): JsonResponse
    {
        $widget = DashboardWidget::findOrFail($widgetId);

        // Get data based on widget key
        $data = match($widget->key) {
            'revenue_chart' => $this->getRevenueData(),
            'recent_orders' => $this->getRecentOrders(),
            'recent_tickets' => $this->getRecentTickets(),
            'active_services' => $this->getActiveServices(),
            'total_clients' => $this->getTotalClients(),
            'pending_invoices' => $this->getPendingInvoices(),
            'monthly_revenue' => $this->getMonthlyRevenue(),
            'services_chart' => $this->getServicesChart(),
            'activity_log' => $this->getActivityLog(),
            'quick_stats' => $this->getQuickStats(),
            default => [],
        };

        return response()->json([
            'success' => true,
            'widget' => $widget,
            'data' => $data,
        ]);
    }

    // Data fetching methods (simplified)
    protected function getRevenueData(): array
    {
        // Return revenue data for chart
        return ['labels' => [], 'values' => []];
    }

    protected function getRecentOrders(): array
    {
        return [];
    }

    protected function getRecentTickets(): array
    {
        return [];
    }

    protected function getActiveServices(): int
    {
        return 0;
    }

    protected function getTotalClients(): int
    {
        return 0;
    }

    protected function getPendingInvoices(): int
    {
        return 0;
    }

    protected function getMonthlyRevenue(): float
    {
        return 0.0;
    }

    protected function getServicesChart(): array
    {
        return [];
    }

    protected function getActivityLog(): array
    {
        return [];
    }

    protected function getQuickStats(): array
    {
        return [];
    }
}
