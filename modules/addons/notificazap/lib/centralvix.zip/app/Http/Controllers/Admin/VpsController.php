<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Modules\Provisioning\OvhModule;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class VpsController extends Controller
{
    /**
     * Listar VPS
     */
    public function index()
    {
        $services = Service::whereHas('product', function ($query) {
            $query->where('type', 'vps');
        })
        ->with(['client', 'product', 'server'])
        ->orderBy('created_at', 'desc')
        ->paginate(50);

        return view('admin.vps.index', compact('services'));
    }

    /**
     * Detalhes do VPS
     */
    public function show(Service $service)
    {
        $service->load(['client', 'product', 'server', 'invoices']);

        // Obter informações do provedor
        $providerInfo = null;
        if ($service->product->module === 'ovh') {
            $module = new OvhModule();
            $providerInfo = $module->getServiceInfo($service);
        }

        return view('admin.vps.show', compact('service', 'providerInfo'));
    }

    /**
     * Reiniciar VPS
     */
    public function reboot(Request $request, Service $service): JsonResponse
    {
        try {
            $module = $this->getModule($service);
            $result = $module->rebootService($service);

            if ($result['success']) {
                return response()->json([
                    'success' => true,
                    'message' => $result['message'] ?? 'VPS reiniciado com sucesso',
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => $result['message'] ?? 'Erro ao reiniciar VPS',
            ], 500);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao reiniciar VPS: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Reinstalar VPS
     */
    public function reinstall(Request $request, Service $service): JsonResponse
    {
        $request->validate([
            'template_id' => 'required|string',
        ]);

        try {
            $module = $this->getModule($service);
            $result = $module->reinstallService($service, [
                'template_id' => $request->template_id,
            ]);

            if ($result['success']) {
                return response()->json([
                    'success' => true,
                    'message' => $result['message'] ?? 'VPS reinstalado com sucesso',
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => $result['message'] ?? 'Erro ao reinstalar VPS',
            ], 500);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao reinstalar VPS: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Criar backup
     */
    public function backup(Request $request, Service $service): JsonResponse
    {
        try {
            $module = $this->getModule($service);
            $result = $module->createBackup(
                $service, 
                $request->input('description', 'Backup manual')
            );

            if ($result['success']) {
                return response()->json([
                    'success' => true,
                    'message' => $result['message'] ?? 'Backup criado com sucesso',
                    'snapshot_id' => $result['snapshot_id'] ?? null,
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => $result['message'] ?? 'Erro ao criar backup',
            ], 500);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao criar backup: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Listar templates disponíveis
     */
    public function templates(Service $service): JsonResponse
    {
        try {
            $module = $this->getModule($service);
            $result = $module->getAvailableTemplates($service);

            if ($result['success']) {
                return response()->json([
                    'success' => true,
                    'templates' => $result['templates'],
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => $result['message'] ?? 'Erro ao obter templates',
            ], 500);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao obter templates: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Obter informações atualizadas
     */
    public function info(Service $service): JsonResponse
    {
        try {
            $module = $this->getModule($service);
            $result = $module->getServiceInfo($service);

            if ($result['success']) {
                return response()->json([
                    'success' => true,
                    'data' => $result['data'],
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => $result['message'] ?? 'Erro ao obter informações',
            ], 500);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao obter informações: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Obter módulo do provedor
     */
    private function getModule(Service $service)
    {
        $module = $service->product->module ?? 'cpanel';

        return match($module) {
            'ovh' => new OvhModule(),
            'virtualizor' => new \App\Modules\Provisioning\VirtualizorModule(),
            'proxmox' => new \App\Modules\Provisioning\ProxmoxModule(),
            default => throw new \Exception('Módulo não suportado'),
        };
    }
}
