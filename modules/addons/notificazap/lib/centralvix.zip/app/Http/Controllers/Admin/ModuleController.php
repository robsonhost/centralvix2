<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\ModuleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ModuleController extends Controller
{
    public function __construct(private ModuleService $modules) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        $grouped = $this->modules->grouped($companyId);
        $categories = $this->modules->categories();
        $stats = $this->modules->stats($companyId);

        return view('admin.modules.index', compact('grouped', 'categories', 'stats'));
    }

    public function toggle(Request $request, string $module): JsonResponse
    {
        $companyId = auth()->user()->company_id;

        if (!$this->modules->find($module)) {
            return response()->json(['success' => false, 'message' => 'Módulo não encontrado.'], 404);
        }

        $def = $this->modules->find($module);
        if (!empty($def['depends_on']) && !$this->modules->isEnabled($companyId, $def['depends_on'])) {
            $parent = $this->modules->definitions()[$def['depends_on']]['name'] ?? $def['depends_on'];
            return response()->json([
                'success' => false,
                'message' => "Ative o módulo \"{$parent}\" antes de habilitar este.",
            ], 422);
        }

        $enabled = $this->modules->toggle($companyId, $module, $request->has('enabled')
            ? $request->boolean('enabled')
            : null);

        // PWA depende do branding (manifest/tema): limpa o cache ao alternar.
        if ($module === 'client_pwa') {
            app(\App\Services\BrandingService::class)->clearCache($companyId);
        }

        activity()
            ->causedBy(auth()->user())
            ->withProperties(['module' => $module, 'enabled' => $enabled])
            ->log('Módulo ' . ($enabled ? 'ativado' : 'desativado'));

        return response()->json([
            'success' => true,
            'enabled' => $enabled,
            'message' => ($this->modules->find($module)['name'] ?? $module)
                . ($enabled ? ' ativado com sucesso!' : ' desativado.'),
            'stats' => $this->modules->stats($companyId),
        ]);
    }
}
