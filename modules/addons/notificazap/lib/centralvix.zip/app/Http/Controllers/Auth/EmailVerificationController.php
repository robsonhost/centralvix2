<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\ClientEmailVerificationMail;
use App\Models\Client;
use App\Models\User;
use Illuminate\Auth\Events\Verified;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\View\View;

class EmailVerificationController extends Controller
{
    /**
     * Exibe o aviso de verificação de email
     */
    public function notice(): View
    {
        return view('auth.verify-email');
    }

    /**
     * Verifica o email usando id/hash (Laravel padrão)
     */
    public function verify(Request $request, string $id, string $hash): RedirectResponse
    {
        $user = User::findOrFail($id);

        if (!hash_equals((string) $hash, sha1($user->getEmailForVerification()))) {
            return redirect()->route('login')
                ->with('error', 'Link de verificação inválido.');
        }

        if ($user->hasVerifiedEmail()) {
            return redirect()->route('client.dashboard')
                ->with('info', 'Seu email já foi verificado anteriormente.');
        }

        if ($user->markEmailAsVerified()) {
            event(new Verified($user));
        }

        // Log da atividade
        activity()
            ->performedOn($user)
            ->causedBy($user)
            ->log('Email verificado com sucesso');

        return redirect()->route('client.dashboard')
            ->with('success', '✓ Email verificado com sucesso! Bem-vindo ao ' . config('app.name') . '!');
    }

    /**
     * Verifica o email usando o token (método customizado)
     */
    public function verifyByToken(Request $request, string $token): RedirectResponse
    {
        $client = Client::where('verification_token', $token)->first();

        if (!$client) {
            return redirect()->route('login')
                ->with('error', 'Link de verificação inválido ou expirado.');
        }

        // Verifica se já foi verificado
        if ($client->hasVerifiedEmail()) {
            return redirect()->route('client.dashboard')
                ->with('info', 'Seu email já foi verificado anteriormente.');
        }

        // Marca como verificado
        $client->markEmailAsVerified();

        // Log da atividade
        activity()
            ->performedOn($client)
            ->causedBy($client)
            ->log('Email verificado com sucesso');

        return redirect()->route('client.dashboard')
            ->with('success', '✓ Email verificado com sucesso! Bem-vindo ao ' . config('app.name') . '!');
    }

    /**
     * Reenvia o email de verificação
     */
    public function resend(Request $request): RedirectResponse
    {
        $user = $request->user();
        
        if (!$user) {
            return redirect()->route('login')
                ->with('error', 'Você precisa estar logado para reenviar a verificação.');
        }

        // Se já verificado
        if ($user->hasVerifiedEmail()) {
            return back()->with('info', 'Seu email já está verificado.');
        }

        // Busca o client associado
        $client = Client::where('user_id', $user->id)->first();
        
        if (!$client) {
            return back()->with('error', 'Perfil de cliente não encontrado.');
        }

        // Gera novo token
        $token = $client->generateVerificationToken();
        $verificationUrl = route('verification.verify.token', ['token' => $token]);

        // Envia email de verificação customizado
        try {
            Mail::to($client->email)->send(new ClientEmailVerificationMail($client, $verificationUrl));
            
            return back()->with('success', '✓ Email de verificação reenviado com sucesso! Verifique sua caixa de entrada e spam.');
        } catch (\Exception $e) {
            \Log::error('Erro ao reenviar email de verificação: ' . $e->getMessage());
            
            return back()->with('error', 'Erro ao enviar email: ' . $e->getMessage() . ' | Verifique as configurações SMTP no servidor.');
        }
    }
}
