<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Backup;
use App\Models\BackupSetting;
use App\Jobs\RunBackupJob;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;

class BackupController extends Controller
{
    /**
     * List backups
     */
    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;
        
        $query = Backup::where('company_id', $companyId)
            ->orderBy('created_at', 'desc');

        // Filters
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $backups = $query->paginate(20);
        
        // Stats
        $stats = [
            'total' => Backup::where('company_id', $companyId)->count(),
            'completed' => Backup::where('company_id', $companyId)->where('status', 'completed')->count(),
            'failed' => Backup::where('company_id', $companyId)->where('status', 'failed')->count(),
            'total_size' => Backup::where('company_id', $companyId)->where('status', 'completed')->sum('size_bytes'),
        ];

        return view('admin.backups.index', compact('backups', 'stats'));
    }

    /**
     * Settings page
     */
    public function settings(): View
    {
        $companyId = auth()->user()->company_id;
        $settings = BackupSetting::firstOrCreate(
            ['company_id' => $companyId],
            [
                'enabled' => true,
                'frequency' => 'daily',
                'schedule_time' => '03:00',
                'retention_days' => 30,
            ]
        );

        return view('admin.backups.settings', compact('settings'));
    }

    /**
     * Save settings
     */
    public function saveSettings(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'enabled' => 'boolean',
            'frequency' => 'required|in:daily,weekly,monthly',
            'schedule_time' => 'required|date_format:H:i',
            'retention_days' => 'required|integer|min:1|max:365',
            'backup_database' => 'boolean',
            'backup_files' => 'boolean',
            'backup_uploads' => 'boolean',
            'email_notifications' => 'boolean',
            'notification_email' => 'nullable|email',
        ]);

        $companyId = auth()->user()->company_id;
        $settings = BackupSetting::where('company_id', $companyId)->first();

        $settings->update($validated);

        return redirect()->route('admin.backups.settings')
            ->with('success', 'Configurações salvas com sucesso!');
    }

    /**
     * Run backup manually
     */
    public function run(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'type' => 'required|in:database,files,uploads,full',
        ]);

        $companyId = auth()->user()->company_id;
        $userId = auth()->id();

        // Dispatch job
        RunBackupJob::dispatch($companyId, $validated['type'], $userId);

        return response()->json([
            'success' => true,
            'message' => 'Backup iniciado! Você será notificado quando concluir.',
        ]);
    }

    /**
     * Download backup
     */
    public function download(Backup $backup)
    {
        if ($backup->company_id !== auth()->user()->company_id) {
            abort(403);
        }

        if ($backup->status !== 'completed') {
            return back()->with('error', 'Este backup não está completo.');
        }

        return Storage::download($backup->path, $backup->filename);
    }

    /**
     * Delete backup
     */
    public function destroy(Backup $backup): JsonResponse
    {
        if ($backup->company_id !== auth()->user()->company_id) {
            abort(403);
        }

        // Delete file
        if (Storage::exists($backup->path)) {
            Storage::delete($backup->path);
        }

        // Delete record
        $backup->delete();

        return response()->json([
            'success' => true,
            'message' => 'Backup excluído com sucesso!',
        ]);
    }
}
