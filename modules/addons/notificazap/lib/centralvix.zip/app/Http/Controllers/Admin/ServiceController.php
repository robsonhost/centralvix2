<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Services\ProvisioningService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ServiceController extends Controller
{
    public function __construct(private ProvisioningService $provisioningService) {}

    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Service::with(['client', 'product', 'server'])
            ->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('domain', 'like', "%{$search}%")
                  ->orWhereHas('client', fn($c) => $c->where('email', 'like', "%{$search}%"));
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $services = $query->latest()->paginate(20);
        
        // Buscar produtos e servidores para os filtros
        $products = \App\Models\Product::where('company_id', $companyId)
            ->orderBy('name')
            ->get();
            
        $servers = \App\Models\Server::where('company_id', $companyId)
            ->orderBy('name')
            ->get();
        
        // Estatísticas
        $stats = [
            'active' => Service::where('company_id', $companyId)->where('status', 'active')->count(),
            'pending' => Service::where('company_id', $companyId)->where('status', 'pending')->count(),
            'suspended' => Service::where('company_id', $companyId)->where('status', 'suspended')->count(),
            'active_revenue' => Service::where('company_id', $companyId)->where('status', 'active')->sum('amount'),
        ];

        return view('admin.services.index', compact('services', 'products', 'servers', 'stats'));
    }

    public function create(): View
    {
        $companyId = auth()->user()->company_id;
        
        $clients = \App\Models\Client::where('company_id', $companyId)
            ->where('status', 'active')
            ->orderBy('firstname')
            ->get();
            
        $products = \App\Models\Product::where('company_id', $companyId)
            ->where('status', 'active')
            ->orderBy('name')
            ->get();
            
        $servers = \App\Models\Server::where('company_id', $companyId)
            ->where('status', 'active')
            ->orderBy('name')
            ->get();
        
        return view('admin.services.create', compact('clients', 'products', 'servers'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'product_id' => 'required|exists:products,id',
            'server_id' => 'nullable|exists:servers,id',
            'domain' => 'nullable|string|max:255',
            'username' => 'nullable|string|max:255',
            'password' => 'nullable|string|max:255',
            'billing_cycle' => 'required|in:monthly,quarterly,semiannually,annually,biennially,triennially,lifetime',
            'amount' => 'required|numeric|min:0',
            'next_due_date' => 'required|date',
            'status' => 'required|in:pending,active,suspended,cancelled,terminated',
            'notes' => 'nullable|string',
        ]);

        $companyId = auth()->user()->company_id;
        $validated['company_id'] = $companyId;

        $product = \App\Models\Product::findOrFail($validated['product_id']);
        if (\App\Support\HostingRules::productRequiresDomain($product)) {
            $request->validate([
                'domain' => \App\Support\HostingRules::domainValidationRules($product),
            ]);
            $validated['domain'] = \App\Support\HostingRules::normalizeDomain($validated['domain'] ?? null);
        }

        $validated['module'] = $product->module;
        $validated['server_id'] = $validated['server_id']
            ?? $product->module_config['server_id']
            ?? $product->server_id
            ?? null;
        
        if ($request->filled('password')) {
            $validated['password'] = encrypt($request->password);
        }

        $service = Service::create($validated);

        return redirect()->route('admin.services.show', $service)
            ->with('success', 'Serviço criado com sucesso!');
    }

    public function show(Service $service): View
    {
        $this->authorizeCompany($service);
        $service->load(['client', 'product', 'server', 'invoiceItems.invoice', 'domains']);
        $servers = \App\Models\Server::where('company_id', $service->company_id)
            ->where('status', 'active')
            ->orderBy('name')
            ->get();

        return view('admin.services.show', compact('service', 'servers'));
    }

    public function suspend(Service $service): RedirectResponse
    {
        $this->authorizeCompany($service);

        try {
            $this->provisioningService->suspend($service);
            return back()->with('success', 'Serviço suspenso com sucesso.');
        } catch (\Exception $e) {
            return back()->with('error', 'Erro ao suspender: ' . $e->getMessage());
        }
    }

    public function unsuspend(Service $service): RedirectResponse
    {
        $this->authorizeCompany($service);

        try {
            $this->provisioningService->unsuspend($service);
            return back()->with('success', 'Serviço reativado com sucesso.');
        } catch (\Exception $e) {
            return back()->with('error', 'Erro ao reativar: ' . $e->getMessage());
        }
    }

    public function terminate(Request $request, Service $service): RedirectResponse
    {
        $this->authorizeCompany($service);

        try {
            $this->provisioningService->terminate($service);
            return back()->with('success', 'Serviço encerrado.');
        } catch (\Exception $e) {
            return back()->with('error', 'Erro ao encerrar: ' . $e->getMessage());
        }
    }

    public function provision(Service $service): RedirectResponse
    {
        $this->authorizeCompany($service);

        if ($service->status !== 'pending') {
            return back()->with('error', 'Apenas serviços pendentes podem ser provisionados manualmente.');
        }

        if (!$service->module) {
            $service->update(['status' => 'active']);
            return back()->with('success', 'Serviço ativado (sem módulo de provisionamento).');
        }

        try {
            $this->provisioningService->provision($service->fresh(['product', 'server', 'client']));
            return back()->with('success', 'Conta provisionada com sucesso! O cliente receberá os dados de acesso.');
        } catch (\Exception $e) {
            return back()->with('error', 'Falha ao provisionar: ' . $e->getMessage());
        }
    }

    public function cancel(Service $service): RedirectResponse
    {
        $this->authorizeCompany($service);
        $service->update(['status' => 'cancelled']);
        return back()->with('success', 'Serviço cancelado.');
    }

    public function update(Request $request, Service $service): RedirectResponse
    {
        $this->authorizeCompany($service);

        $validated = $request->validate([
            'domain' => 'nullable|string',
            'username' => 'nullable|string',
            'notes' => 'nullable|string',
            'next_due_date' => 'nullable|date',
            'billing_cycle' => 'nullable|in:monthly,quarterly,semiannually,annually,biennially,triennially,lifetime',
            'amount' => 'nullable|numeric|min:0',
            'server_id' => 'nullable|exists:servers,id',
            'override_auto_suspend' => 'boolean',
            'override_auto_terminate' => 'boolean',
        ]);

        if ($request->filled('password')) {
            $validated['password'] = encrypt($request->password);
        }

        $service->update($validated);
        return back()->with('success', 'Serviço atualizado.');
    }

    private function authorizeCompany(Service $service): void
    {
        if ($service->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }
}
