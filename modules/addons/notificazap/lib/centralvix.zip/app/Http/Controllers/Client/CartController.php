<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\CartItem;
use App\Models\Product;
use App\Services\BillingService;
use App\Services\CartService;
use App\Services\CouponService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CartController extends Controller
{
    public function __construct(
        private CartService $cartService,
        private BillingService $billingService,
        private CouponService $couponService,
    ) {
    }

    public function index(): View
    {
        $client = auth()->user()->resolveClient() ?? abort(404);
        $cart = $this->cartService->resolve($client)->load('items.product');

        return view('client.cart.index', compact('cart', 'client'));
    }

    public function add(Request $request): RedirectResponse
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        $data = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'billing_cycle' => ['required', 'string'],
            'domain' => ['nullable', 'string', 'max:255'],
            'quantity' => ['nullable', 'integer', 'min:1', 'max:10'],
        ]);

        $product = Product::findOrFail($data['product_id']);
        $domainRules = \App\Support\HostingRules::domainValidationRules($product);
        $request->validate(['domain' => $domainRules]);
        $domain = \App\Support\HostingRules::normalizeDomain($data['domain'] ?? null);

        $this->cartService->addItem(
            $client,
            $product,
            $data['billing_cycle'],
            $domain,
            (int) ($data['quantity'] ?? 1),
        );

        return redirect()->route('client.cart.index')->with('success', 'Produto adicionado ao carrinho.');
    }

    public function remove(CartItem $item): RedirectResponse
    {
        $client = auth()->user()->resolveClient() ?? abort(404);
        if ($item->cart?->client_id !== $client->id) {
            abort(403);
        }

        $this->cartService->removeItem($item);

        return back()->with('success', 'Item removido do carrinho.');
    }

    public function checkout(Request $request): RedirectResponse
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        $coupon = null;
        if ($request->filled('coupon_code')) {
            $coupon = $this->couponService->validate($request->coupon_code, $client);
            if (!$coupon) {
                return back()->withErrors(['coupon_code' => 'Cupom inválido.']);
            }
        }

        $orders = $this->cartService->checkout($client, $this->billingService, $coupon);
        $invoice = collect($orders)->flatMap(fn ($o) => $o->invoices)->first();

        if ($invoice) {
            return redirect()->route('client.invoices.show', $invoice)
                ->with('success', 'Pedido criado! Efetue o pagamento para ativar os serviços.');
        }

        return redirect()->route('client.orders.index')->with('success', 'Pedido criado com sucesso.');
    }
}
