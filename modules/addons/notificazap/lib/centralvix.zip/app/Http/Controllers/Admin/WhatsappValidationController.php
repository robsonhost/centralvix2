<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WhatsappValidationController extends Controller
{
    /**
     * Valida se um número de WhatsApp é válido
     */
    public function validateNumber(Request $request)
    {
        $request->validate([
            'phone' => 'required|string'
        ]);

        $phone = $this->formatPhoneNumber($request->phone);

        if (empty($phone)) {
            return response()->json([
                'valid' => false,
                'message' => 'Número inválido. Digite um número válido.',
                'formatted' => null
            ]);
        }

        // Verificar se Evolution API está habilitada
        if (!config('services.evolution.enabled', false)) {
            return response()->json([
                'valid' => true,
                'message' => 'Número formatado (validação automática desabilitada)',
                'formatted' => $phone,
                'warning' => true
            ]);
        }

        try {
            // Tentar validar via Evolution API
            $response = Http::timeout(10)
                ->withHeaders([
                    'apikey' => config('services.evolution.api_key')
                ])
                ->get(config('services.evolution.url') . '/chat/checkNumberExists/' . config('services.evolution.instance'), [
                    'number' => $phone
                ]);

            if ($response->successful()) {
                $data = $response->json();
                
                if (isset($data['exists']) && $data['exists']) {
                    return response()->json([
                        'valid' => true,
                        'message' => 'Número válido e registrado no WhatsApp!',
                        'formatted' => $phone
                    ]);
                } else {
                    return response()->json([
                        'valid' => false,
                        'message' => 'Número não encontrado no WhatsApp. Verifique se está correto.',
                        'formatted' => $phone
                    ]);
                }
            } else {
                // Erro na API, mas retorna número formatado
                return response()->json([
                    'valid' => true,
                    'message' => 'Número formatado (não foi possível verificar no WhatsApp)',
                    'formatted' => $phone,
                    'warning' => true
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Erro ao validar WhatsApp: ' . $e->getMessage());
            
            return response()->json([
                'valid' => true,
                'message' => 'Número formatado (erro ao validar)',
                'formatted' => $phone,
                'warning' => true
            ]);
        }
    }

    /**
     * Formata número de telefone para padrão internacional
     */
    private function formatPhoneNumber($phone)
    {
        // Remove tudo que não é número
        $phone = preg_replace('/[^0-9]/', '', $phone);

        // Valida se tem pelo menos 10 dígitos
        if (strlen($phone) < 10) {
            return null;
        }

        // Se começa com 0, remove
        if (substr($phone, 0, 1) === '0') {
            $phone = substr($phone, 1);
        }

        // Se não tem código do país (55), adiciona
        if (strlen($phone) <= 11 && !str_starts_with($phone, '55')) {
            $phone = '55' . $phone;
        }

        // Formata para padrão internacional: 5527999999999
        return $phone;
    }
}
