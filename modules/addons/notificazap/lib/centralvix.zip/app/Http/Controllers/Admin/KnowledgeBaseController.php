<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\KnowledgeBaseArticle;
use App\Models\KnowledgeBaseCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class KnowledgeBaseController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = KnowledgeBaseArticle::with('category', 'author')
            ->where('company_id', $companyId);

        // Filtros
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('content', 'like', "%{$search}%")
                  ->orWhere('tags', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('category')) {
            $query->where('category_id', $request->category);
        }

        $articles = $query->latest()->paginate(20);
        
        // Categorias e Estatísticas
        $categories = KnowledgeBaseCategory::where('company_id', $companyId)->withCount('articles')->get();
        
        $allArticles = KnowledgeBaseArticle::where('company_id', $companyId);
        $stats = [
            'total' => $allArticles->count(),
            'published' => $allArticles->where('status', 'published')->count(),
            'draft' => $allArticles->where('status', 'draft')->count(),
            'views' => $allArticles->sum('views'),
            'categories' => $categories->count(),
        ];

        return view('admin.kb.index', compact('articles', 'categories', 'stats'));
    }

    public function createArticle(): View
    {
        $companyId = auth()->user()->company_id;
        $categories = KnowledgeBaseCategory::where('company_id', $companyId)->get();
        return view('admin.kb.articles.create', compact('categories'));
    }

    public function storeArticle(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'title'   => 'required|string|max:255',
            'content' => 'required|string',
            'tags'    => 'nullable|string',
        ]);

        $companyId = auth()->user()->company_id;

        KnowledgeBaseArticle::create([
            'company_id'  => $companyId,
            'category_id' => $request->category_id,
            'title'       => $validated['title'],
            'slug'        => Str::slug($validated['title']),
            'content'     => $validated['content'],
            'tags'        => $request->tags,
            'status'      => $request->status ?? 'draft',
            'author_id'   => auth()->id(),
        ]);

        return redirect()->route('admin.kb.index')
            ->with('success', 'Artigo ' . ($request->status === 'published' ? 'publicado' : 'salvo como rascunho') . ' com sucesso!');
    }

    public function editArticle(KnowledgeBaseArticle $article): View
    {
        if ($article->company_id !== auth()->user()->company_id) abort(403);

        $categories = KnowledgeBaseCategory::where('company_id', auth()->user()->company_id)->get();
        return view('admin.kb.articles.edit', compact('article', 'categories'));
    }

    public function updateArticle(Request $request, KnowledgeBaseArticle $article): RedirectResponse
    {
        if ($article->company_id !== auth()->user()->company_id) abort(403);

        $validated = $request->validate([
            'title'   => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        $article->update(array_merge($validated, [
            'category_id' => $request->category_id,
            'tags'        => $request->tags,
            'status'      => $request->status ?? $article->status,
        ]));

        return redirect()->route('admin.kb.index')->with('success', 'Artigo atualizado!');
    }

    public function destroyArticle(KnowledgeBaseArticle $article): RedirectResponse
    {
        if ($article->company_id !== auth()->user()->company_id) abort(403);
        $article->delete();
        return redirect()->route('admin.kb.index')->with('success', 'Artigo excluído.');
    }
}
