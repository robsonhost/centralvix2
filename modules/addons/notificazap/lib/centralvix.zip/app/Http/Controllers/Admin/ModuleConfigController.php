<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ModuleConfigController extends Controller
{
    public function __construct(
        private ModuleService $modules,
        private ModuleSettingsService $settings,
    ) {}

    public function show(string $module): View
    {
        $def = $this->modules->find($module);
        abort_unless($def, 404);

        $schema = $this->settings->schema($module);
        abort_unless($schema, 404);

        $companyId = auth()->user()->company_id;
        $values = $this->settings->all($companyId, $module);
        $enabled = $this->modules->isEnabled($companyId, $module);

        return view('admin.modules.configure', compact('module', 'def', 'schema', 'values', 'enabled'));
    }

    public function update(Request $request, string $module): RedirectResponse
    {
        $def = $this->modules->find($module);
        abort_unless($def, 404);
        abort_unless($this->settings->schema($module), 404);

        $companyId = auth()->user()->company_id;

        $this->settings->save($companyId, $module, $request->input('settings', []));

        // O módulo do PWA reflete no branding (manifest/tema), então limpamos o cache.
        if ($module === 'client_pwa') {
            app(\App\Services\BrandingService::class)->clearCache($companyId);
        }

        activity()
            ->causedBy(auth()->user())
            ->withProperties(['module' => $module])
            ->log('Configurações do módulo atualizadas');

        return redirect()
            ->route('admin.modules.config', $module)
            ->with('success', 'Configurações de "' . ($def['name'] ?? $module) . '" salvas com sucesso!');
    }
}
