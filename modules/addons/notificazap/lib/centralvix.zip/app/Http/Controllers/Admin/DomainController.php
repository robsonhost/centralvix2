<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Domain;
use App\Models\DomainPricing;
use App\Services\AdminExportService;
use App\Services\DomainService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DomainController extends Controller
{
    public function __construct(
        private DomainService $domainService,
        private AdminExportService $exportService,
    ) {}

    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Domain::with('client')->where('company_id', $companyId);

        if ($request->filled('search')) {
            $query->where('domain', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('registrar')) {
            $query->where('registrar', $request->registrar);
        }

        if ($request->get('expiring') === '1') {
            $query->whereNotNull('expiry_date')
                  ->where('expiry_date', '>', now())
                  ->where('expiry_date', '<=', now()->addDays(30));
        }

        $sort = $request->get('sort', 'expiry_asc');
        match ($sort) {
            'expiry_desc' => $query->orderByDesc('expiry_date'),
            'name_asc' => $query->orderBy('domain'),
            'name_desc' => $query->orderByDesc('domain'),
            'created_desc' => $query->latest('created_at'),
            default => $query->orderBy('expiry_date'),
        };

        $domains = $query->paginate(20);

        $stats = [
            'total' => Domain::where('company_id', $companyId)->count(),
            'active' => Domain::where('company_id', $companyId)->where('status', 'active')->count(),
            'expiring' => Domain::where('company_id', $companyId)
                ->whereNotNull('expiry_date')
                ->where('expiry_date', '>', now())
                ->where('expiry_date', '<=', now()->addDays(30))
                ->count(),
            'expired' => Domain::where('company_id', $companyId)->where('status', 'expired')->count(),
        ];

        return view('admin.domains.index', compact('domains', 'stats'));
    }

    public function create(): View
    {
        $companyId = auth()->user()->company_id;
        $clients = Client::where('company_id', $companyId)->where('status', 'active')->orderBy('firstname')->get();
        $pricing = DomainPricing::where('company_id', $companyId)->where('active', true)->orderBy('order')->get();

        return view('admin.domains.create', compact('clients', 'pricing'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'domain' => 'required|string|max:255',
            'client_id' => 'required|exists:clients,id',
            'years' => 'required|integer|min:1|max:10',
            'auto_renew' => 'boolean',
            'privacy_protection' => 'boolean',
            'nameservers' => 'nullable|array|max:4',
            'nameservers.*' => 'nullable|string|max:255',
        ]);

        $companyId = auth()->user()->company_id;

        Client::where('company_id', $companyId)->findOrFail($validated['client_id']);

        $check = $this->domainService->checkAvailability($validated['domain'], $companyId);
        if (!$check['available']) {
            return back()->withInput()->with('error', $check['message']);
        }

        $nameservers = array_values(array_filter($validated['nameservers'] ?? []));

        $domain = $this->domainService->register([
            ...$validated,
            'nameservers' => $nameservers ?: null,
            'registrar' => $check['registrar'] ?? null,
            'auto_renew' => $request->boolean('auto_renew', true),
            'privacy_protection' => $request->boolean('privacy_protection', false),
        ], $companyId);

        return redirect()->route('admin.domains.show', $domain)
            ->with('success', "Domínio {$domain->domain} registrado com sucesso!");
    }

    public function checkAvailability(Request $request): JsonResponse
    {
        $request->validate(['domain' => 'required|string|max:255']);

        $result = $this->domainService->checkAvailability(
            $request->domain,
            auth()->user()->company_id
        );

        return response()->json($result);
    }

    public function show(Domain $domain): View
    {
        $this->authorizeCompany($domain);
        $domain->load('client');

        return view('admin.domains.show', compact('domain'));
    }

    public function renew(Domain $domain): RedirectResponse
    {
        $this->authorizeCompany($domain);

        try {
            $this->domainService->renew($domain);
            return back()->with('success', "Domínio {$domain->domain} renovado por 1 ano.");
        } catch (\Exception $e) {
            return back()->with('error', 'Erro ao renovar domínio: ' . $e->getMessage());
        }
    }

    public function updateNameservers(Request $request, Domain $domain): RedirectResponse
    {
        $this->authorizeCompany($domain);

        $validated = $request->validate([
            'nameservers' => 'required|array|min:2|max:4',
            'nameservers.*' => 'required|string|max:255',
        ]);

        $this->domainService->updateNameservers($domain, $validated['nameservers']);

        return back()->with('success', 'Nameservers atualizados com sucesso.');
    }

    public function destroy(Domain $domain): RedirectResponse
    {
        $this->authorizeCompany($domain);

        $name = $domain->domain;
        $domain->delete();

        return redirect()->route('admin.domains.index')
            ->with('success', "Domínio {$name} removido do sistema.");
    }

    public function whois(Domain $domain): JsonResponse
    {
        $this->authorizeCompany($domain);

        return response()->json([
            'domain' => $domain->domain,
            'data' => $this->domainService->getWhoisInfo($domain),
        ]);
    }

    public function export(Request $request): \Symfony\Component\HttpFoundation\StreamedResponse|\Illuminate\Http\Response
    {
        $companyId = auth()->user()->company_id;
        $format = $request->get('format', 'csv');

        $query = Domain::with('client')->where('company_id', $companyId);

        if ($request->filled('search')) {
            $query->where('domain', 'like', '%' . $request->search . '%');
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('registrar')) {
            $query->where('registrar', $request->registrar);
        }
        if ($request->get('expiring') === '1') {
            $query->whereNotNull('expiry_date')
                  ->where('expiry_date', '>', now())
                  ->where('expiry_date', '<=', now()->addDays(30));
        }

        $headings = ['Domínio', 'Cliente', 'Registrador', 'Status', 'Registro', 'Expiração', 'Auto-renovar'];
        $rows = $query->orderBy('domain')->get()->map(fn (Domain $d) => [
            $d->domain,
            $d->client?->display_name ?? '—',
            $d->registrar ?? '—',
            ucfirst($d->status ?? '—'),
            $d->registration_date?->format('d/m/Y') ?? '—',
            $d->expiry_date?->format('d/m/Y') ?? '—',
            $d->auto_renew ? 'Sim' : 'Não',
        ])->all();

        return $this->exportService->download($format, 'Dominios', $headings, $rows);
    }

    private function authorizeCompany(Domain $domain): void
    {
        if ($domain->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }
}
