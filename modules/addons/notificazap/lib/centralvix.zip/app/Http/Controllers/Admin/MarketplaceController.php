<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\AddonService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MarketplaceController extends Controller
{
    public function __construct(private AddonService $addons) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $products = Product::where('company_id', $companyId)
            ->orderByDesc('is_addon')
            ->orderBy('name')
            ->paginate(30);

        $stats = [
            'addons' => Product::where('company_id', $companyId)->where('is_addon', true)->count(),
            'featured' => Product::where('company_id', $companyId)->where('is_addon', true)->where('featured', true)->count(),
            'enabled' => $this->addons->isEnabled($companyId),
        ];

        return view('admin.marketplace.index', compact('products', 'stats'));
    }

    public function toggle(Request $request, Product $product): JsonResponse
    {
        abort_unless($product->company_id === auth()->user()->company_id, 403);

        $field = $request->input('field');
        abort_unless(in_array($field, ['is_addon', 'featured'], true), 422);

        $product->update([$field => $request->boolean('value')]);

        return response()->json([
            'success' => true,
            'value' => (bool) $product->{$field},
        ]);
    }
}
