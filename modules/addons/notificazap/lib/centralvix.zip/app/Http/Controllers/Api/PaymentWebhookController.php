<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PaymentGateway;
use App\Models\Transaction;
use App\Services\PaymentGateways\AsaasGateway;
use App\Services\PaymentGateways\C6BankGateway;
use App\Services\PaymentGateways\PagHiperGateway;
use App\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PaymentWebhookController extends Controller
{
    private const KNOWN_GATEWAYS = [
        'asaas'    => 'ASAAS',
        'paghiper' => 'PagHiper',
        'c6bank'   => 'C6 Bank PIX',
    ];

    /**
     * Verificação de status (GET no navegador)
     * GET /api/webhooks/{gateway}
     */
    public function status(Request $request, string $gateway)
    {
        $label = self::KNOWN_GATEWAYS[$gateway] ?? ucfirst($gateway);
        $endpoint = url("/api/webhooks/{$gateway}");

        $payload = [
            'status'          => 'ok',
            'gateway'         => $gateway,
            'gateway_label'   => $label,
            'endpoint'        => $endpoint,
            'allowed_methods' => ['POST'],
            'message'         => 'Webhook ativo. Configure esta URL no painel do ' . $label . ' para receber notificações via POST.',
        ];

        if ($request->expectsJson() || $request->ajax()) {
            return response()->json($payload);
        }

        $html = <<<HTML
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webhook {$label} — CentralVix</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: system-ui, -apple-system, sans-serif; background: #0f172a; color: #e2e8f0; min-height: 100vh; display: grid; place-items: center; padding: 1.5rem; }
        .card { max-width: 32rem; width: 100%; background: #1e293b; border: 1px solid #334155; border-radius: 1rem; padding: 2rem; box-shadow: 0 25px 50px -12px rgba(0,0,0,.5); }
        .badge { display: inline-flex; align-items: center; gap: .5rem; background: #14532d; color: #86efac; font-size: .75rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; padding: .35rem .75rem; border-radius: 9999px; margin-bottom: 1rem; }
        h1 { font-size: 1.5rem; font-weight: 700; margin-bottom: .5rem; }
        p { color: #94a3b8; line-height: 1.6; font-size: .9375rem; }
        .url { margin-top: 1.25rem; padding: .75rem 1rem; background: #0f172a; border: 1px solid #334155; border-radius: .5rem; font-family: ui-monospace, monospace; font-size: .8125rem; word-break: break-all; color: #7dd3fc; }
        .hint { margin-top: 1rem; font-size: .8125rem; color: #64748b; }
        .method { margin-top: 1.25rem; display: inline-block; background: #1e3a5f; color: #93c5fd; font-size: .75rem; font-weight: 700; padding: .25rem .6rem; border-radius: .35rem; }
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">✓ Endpoint ativo</div>
        <h1>Webhook {$label}</h1>
        <p>Este endpoint está funcionando corretamente. O {$label} deve enviar notificações de pagamento para a URL abaixo usando o método <strong>POST</strong>.</p>
        <div class="url">{$endpoint}</div>
        <p class="hint">Abrir esta URL no navegador apenas confirma que o endpoint existe. Pagamentos reais são processados quando o gateway envia um POST.</p>
        <span class="method">POST only</span>
    </div>
</body>
</html>
HTML;

        return response($html, 200, ['Content-Type' => 'text/html; charset=UTF-8']);
    }

    /**
     * Webhook ASAAS
     * POST /api/webhooks/asaas
     */
    public function asaas(Request $request): JsonResponse
    {
        try {
            Log::info('Webhook ASAAS recebido', [
                'headers' => $request->headers->all(),
                'body' => $request->all(),
            ]);

            $gateway = new AsaasGateway();
            $gateway->processWebhook($request->all());

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error('Erro ao processar webhook ASAAS', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json(['status' => 'error'], 500);
        }
    }

    /**
     * Webhook PagHiper
     * POST /api/webhooks/paghiper
     */
    public function paghiper(Request $request): JsonResponse
    {
        try {
            $payload = $request->all();

            Log::info('Webhook PagHiper recebido', [
                'headers' => $request->headers->all(),
                'body'    => $payload,
            ]);

            $settings = $this->resolvePagHiperSettings($payload);
            $gateway  = new PagHiperGateway($settings);
            $gateway->processWebhook($payload, app(PaymentService::class));

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error('Erro ao processar webhook PagHiper', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json(['status' => 'error'], 500);
        }
    }

    /**
     * Webhook C6 Bank PIX
     * POST /api/webhooks/c6bank
     */
    public function c6bank(Request $request): JsonResponse
    {
        try {
            Log::info('Webhook C6 Bank recebido', $request->all());

            $gateway = new C6BankGateway();
            $gateway->processWebhook($request->all());

            return response()->json(['status' => 'success']);
        } catch (\Exception $e) {
            Log::error('Erro webhook C6 Bank', ['error' => $e->getMessage()]);
            return response()->json(['status' => 'error'], 500);
        }
    }

    /**
     * Webhook genérico (legado)
     * POST /api/webhooks/{gateway}
     */
    public function handle(Request $request, string $gateway): JsonResponse
    {
        try {
            Log::info("Webhook {$gateway} recebido", [
                'headers' => $request->headers->all(),
                'body' => $request->all(),
            ]);

            $gatewayClass = match ($gateway) {
                'asaas'    => AsaasGateway::class,
                'paghiper' => PagHiperGateway::class,
                'c6bank'   => C6BankGateway::class,
                default    => null,
            };

            if (!$gatewayClass) {
                Log::warning("Gateway desconhecido: {$gateway}");
                return response()->json(['status' => 'unknown_gateway'], 404);
            }

            $payload = $request->all();

            if ($gateway === 'paghiper') {
                $settings        = $this->resolvePagHiperSettings($payload);
                $gatewayInstance = new PagHiperGateway($settings);
                $gatewayInstance->processWebhook($payload, app(PaymentService::class));
            } else {
                $gatewayInstance = new $gatewayClass();
                $gatewayInstance->processWebhook($payload);
            }

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error("Erro ao processar webhook {$gateway}", [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json(['status' => 'error'], 500);
        }
    }

    /**
     * Resolve credenciais PagHiper do banco (por empresa) a partir do webhook.
     */
    private function resolvePagHiperSettings(array $payload): array
    {
        $apiKey        = trim((string) ($payload['apiKey'] ?? $payload['api_key'] ?? ''));
        $transactionId = $payload['transaction_id'] ?? null;

        if ($apiKey) {
            $gateways = PaymentGateway::where('module', 'paghiper')
                ->where('status', 'active')
                ->get();

            foreach ($gateways as $gw) {
                $s        = is_array($gw->settings) ? $gw->settings : [];
                $gwApiKey = trim((string) ($s['api_key'] ?? $s['apiKey'] ?? ''));
                if ($gwApiKey === $apiKey) {
                    return array_merge(config('payment.paghiper', []), $s);
                }
            }
        }

        if ($transactionId) {
            $txn = Transaction::where('gateway_transaction_id', $transactionId)
                ->where('gateway', 'paghiper')
                ->latest()
                ->first();

            if ($txn) {
                $gw = PaymentGateway::where('company_id', $txn->company_id)
                    ->where('module', 'paghiper')
                    ->where('status', 'active')
                    ->first();

                if ($gw) {
                    return array_merge(
                        config('payment.paghiper', []),
                        is_array($gw->settings) ? $gw->settings : []
                    );
                }
            }
        }

        return config('payment.paghiper', []);
    }
}
