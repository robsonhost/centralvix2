<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\AdminExportService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class OrderController extends Controller
{
    public function __construct(private AdminExportService $exportService) {}
    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Order::with(['client', 'items.product'])
            ->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('uuid', 'like', "%{$search}%")
                  ->orWhere('id', 'like', "%{$search}%")
                  ->orWhereHas('client', fn($c) => $c->where('email', 'like', "%{$search}%")
                                                     ->orWhere('firstname', 'like', "%{$search}%")
                                                     ->orWhere('lastname', 'like', "%{$search}%"));
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $orders = $query->latest()->paginate(20);

        // Estatísticas
        $stats = [
            'total' => Order::where('company_id', $companyId)->count(),
            'pending' => Order::where('company_id', $companyId)->where('status', 'pending')->count(),
            'active' => Order::where('company_id', $companyId)->where('status', 'active')->count(),
            'cancelled' => Order::where('company_id', $companyId)->where('status', 'cancelled')->count(),
            'fraud' => Order::where('company_id', $companyId)->where('status', 'fraud')->count(),
            'total_value' => Order::where('company_id', $companyId)->sum('total'),
            'pending_value' => Order::where('company_id', $companyId)->where('status', 'pending')->sum('total'),
            'active_value' => Order::where('company_id', $companyId)->where('status', 'active')->sum('total'),
        ];

        return view('admin.orders.index', compact('orders', 'stats'));
    }

    public function create(): View
    {
        $companyId = auth()->user()->company_id;
        $clients = \App\Models\Client::where('company_id', $companyId)->where('status', 'active')->get();
        $products = \App\Models\Product::where('company_id', $companyId)->where('status', 'active')->get();
        return view('admin.orders.create', compact('clients', 'products'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'payment_method' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        $companyId = auth()->user()->company_id;
        $client = \App\Models\Client::where('company_id', $companyId)->findOrFail($validated['client_id']);

        // Create order
        $order = Order::create([
            'uuid' => \Illuminate\Support\Str::uuid(),
            'company_id' => $companyId,
            'client_id' => $client->id,
            'status' => 'pending',
            'payment_method' => $validated['payment_method'] ?? null,
            'notes' => $validated['notes'] ?? null,
            'subtotal' => 0,
            'discount' => 0,
            'total' => 0,
        ]);

        // Add items and calculate total
        $total = 0;
        foreach ($validated['items'] as $itemData) {
            $product = \App\Models\Product::find($itemData['product_id']);
            $quantity = $itemData['quantity'];
            $price = $product->price;
            $subtotal = $price * $quantity;
            $total += $subtotal;

            $order->items()->create([
                'product_id' => $product->id,
                'description' => $product->name,
                'quantity' => $quantity,
                'price' => $price,
                'subtotal' => $subtotal,
            ]);
        }

        $order->update([
            'subtotal' => $total,
            'total' => $total,
        ]);

        return redirect()->route('admin.orders.show', $order)
            ->with('success', 'Pedido criado com sucesso!');
    }

    public function show(Order $order): View
    {
        $this->authorizeCompany($order);
        $order->load(['client', 'items.product', 'services']);
        return view('admin.orders.show', compact('order'));
    }

    public function cancel(Order $order): RedirectResponse
    {
        $this->authorizeCompany($order);

        if ($order->status === 'cancelled') {
            return back()->with('error', 'Pedido já cancelado.');
        }

        $order->update(['status' => 'cancelled']);
        $order->services()->update(['status' => 'cancelled']);

        return back()->with('success', 'Pedido cancelado.');
    }

    public function markFraud(Order $order): RedirectResponse
    {
        $this->authorizeCompany($order);
        $order->update(['status' => 'fraud']);
        $order->services()->update(['status' => 'fraud']);
        return back()->with('success', 'Pedido marcado como fraude.');
    }

    public function export(Request $request): StreamedResponse|\Illuminate\Http\Response
    {
        $companyId = auth()->user()->company_id;
        $format = $request->get('format', 'csv');

        $query = Order::with(['client', 'items.product'])->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('uuid', 'like', "%{$search}%")
                  ->orWhere('id', 'like', "%{$search}%")
                  ->orWhereHas('client', fn ($c) => $c->where('email', 'like', "%{$search}%")
                      ->orWhere('firstname', 'like', "%{$search}%")
                      ->orWhere('lastname', 'like', "%{$search}%"));
            });
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $headings = ['ID', 'UUID', 'Cliente', 'E-mail', 'Produtos', 'Total', 'Pagamento', 'Status', 'Data'];
        $rows = $query->latest()->get()->map(fn (Order $o) => [
            $o->id,
            $o->uuid,
            $o->client?->display_name ?? '—',
            $o->client?->email ?? '—',
            $o->items->map(fn ($i) => $i->product?->name ?? $i->description ?? 'Item')->join(', '),
            'R$ ' . number_format((float) $o->total, 2, ',', '.'),
            $o->payment_method ? strtoupper($o->payment_method) : '—',
            match ($o->status) { 'pending' => 'Pendente', 'active' => 'Aceito', 'cancelled' => 'Cancelado', 'fraud' => 'Fraude', default => $o->status },
            $o->created_at?->format('d/m/Y H:i') ?? '—',
        ])->all();

        return $this->exportService->download($format, 'Pedidos', $headings, $rows);
    }

    private function authorizeCompany(Order $order): void
    {
        if ($order->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }
}
