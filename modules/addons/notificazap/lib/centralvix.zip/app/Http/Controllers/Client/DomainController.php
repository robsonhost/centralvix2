<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Domain;
use App\Services\DomainBillingService;
use App\Services\DomainService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DomainController extends Controller
{
    public function __construct(
        private DomainService $domainService,
        private DomainBillingService $domainBilling,
    ) {
    }

    private function client()
    {
        return auth()->user()->resolveClient() ?? abort(404);
    }

    private function authorizeDomain(Domain $domain): void
    {
        if (!auth()->user()->canAccessClientRecord($domain->client)) {
            abort(403);
        }
    }

    public function index(): View
    {
        $client = $this->client();
        $domains = $client->domains()->orderBy('expiry_date')->paginate(15);

        $stats = [
            'total' => $client->domains()->count(),
            'active' => $client->domains()->where('status', 'active')->count(),
            'expiring_soon' => $client->domains()
                ->where('status', 'active')
                ->whereDate('expiry_date', '<=', now()->addDays(30))
                ->whereDate('expiry_date', '>=', now())
                ->count(),
            'expired' => $client->domains()->where('status', 'expired')->count(),
        ];

        return view('client.domains.index', compact('domains', 'stats', 'client'));
    }

    public function show(Domain $domain): View
    {
        $this->authorizeDomain($domain);
        $renewalPrice = $this->domainBilling->renewalPrice($domain, 1);
        $hasPendingRenewal = $this->domainBilling->hasPendingRenewalInvoice($domain);

        return view('client.domains.show', compact('domain', 'renewalPrice', 'hasPendingRenewal'));
    }

    public function checkAvailability(Request $request): JsonResponse
    {
        $client = $this->client();

        $data = $request->validate([
            'domain' => ['required', 'string', 'max:255'],
        ]);

        $result = $this->domainService->checkAvailability($data['domain'], $client->company_id);

        return response()->json($result);
    }

    public function renew(Domain $domain): RedirectResponse
    {
        $this->authorizeDomain($domain);

        if (!in_array($domain->status, ['active', 'expired'], true)) {
            return back()->with('error', 'Este domínio não pode ser renovado no momento.');
        }

        try {
            $invoice = $this->domainBilling->createRenewalInvoice($domain, 1);

            return redirect()->route('client.invoices.show', $invoice)
                ->with('success', 'Fatura de renovação gerada. Efetue o pagamento para renovar o domínio.');
        } catch (\InvalidArgumentException $e) {
            return back()->with('error', $e->getMessage());
        } catch (\Throwable $e) {
            logger()->error('Domain renew invoice failed', ['domain_id' => $domain->id, 'error' => $e->getMessage()]);
            return back()->with('error', 'Não foi possível gerar a fatura de renovação.');
        }
    }

    public function updateNameservers(Request $request, Domain $domain): RedirectResponse
    {
        $this->authorizeDomain($domain);

        $data = $request->validate([
            'nameservers' => ['required', 'array', 'min:2', 'max:5'],
            'nameservers.*' => ['required', 'string', 'max:255'],
        ]);

        $this->domainService->updateNameservers($domain, $data['nameservers']);

        return back()->with('success', 'Nameservers atualizados com sucesso.');
    }

    public function eppCode(Domain $domain): RedirectResponse
    {
        $this->authorizeDomain($domain);

        $code = $this->domainService->getEppCode($domain);

        if (!$code) {
            return back()->with('error', 'EPP Code indisponível. Abra um ticket de suporte.');
        }

        if (!$domain->epp_code) {
            $domain->update(['epp_code' => $code]);
        }

        return back()->with('success', 'EPP Code: ' . $code);
    }

    public function toggleAutoRenew(Domain $domain): RedirectResponse
    {
        $this->authorizeDomain($domain);

        $domain->update(['auto_renew' => !$domain->auto_renew]);

        return back()->with('success', $domain->auto_renew
            ? 'Renovação automática ativada.'
            : 'Renovação automática desativada.');
    }
}
