<?php



namespace App\Http\Controllers\Admin;



use App\Http\Controllers\Controller;

use App\Models\Client;

use App\Models\Invoice;

use App\Models\Order;

use App\Models\Service;

use App\Models\Ticket;

use App\Models\Transaction;

use App\Models\WhatsappInstance;

use App\Services\CacheService;

use App\Services\WhatsApp\EvolutionGoService;

use App\Services\WhatsAppService;

use Illuminate\Http\JsonResponse;

use Illuminate\Http\Request;

use Illuminate\View\View;



class DashboardController extends Controller

{

    protected CacheService $cacheService;



    public function __construct(CacheService $cacheService)

    {

        $this->cacheService = $cacheService;

    }



    public function index(): View

    {

        $companyId = auth()->user()->company_id;



        // Cache dashboard stats for 5 minutes (Requirement 64.1)

        $stats = $this->cacheService->getDashboardStats($companyId, function () use ($companyId) {

            return [

                'total_clients' => Client::where('company_id', $companyId)->count(),

                'active_services' => Service::where('company_id', $companyId)->where('status', 'active')->count(),

                'unpaid_invoices' => Invoice::where('company_id', $companyId)->whereIn('status', ['unpaid', 'overdue'])->count(),

                'open_tickets' => Ticket::where('company_id', $companyId)->whereNotIn('status', ['closed'])->count(),

                'monthly_revenue' => Transaction::where('company_id', $companyId)

                    ->where('status', 'completed')

                    ->where('type', 'payment')

                    ->whereMonth('created_at', now()->month)

                    ->sum('amount'),

                'pending_orders' => Order::where('company_id', $companyId)->where('status', 'pending')->count(),

                'overdue_invoices' => Invoice::where('company_id', $companyId)->where('status', 'overdue')->count(),

                'suspended_services' => Service::where('company_id', $companyId)->where('status', 'suspended')->count(),

            ];

        });



        $recentClients = Client::where('company_id', $companyId)

            ->latest()

            ->take(5)

            ->get();



        $recentInvoices = Invoice::with('client')

            ->where('company_id', $companyId)

            ->latest()

            ->take(5)

            ->get();



        $recentTickets = Ticket::with(['client', 'department'])

            ->where('company_id', $companyId)

            ->whereNotIn('status', ['closed'])

            ->latest()

            ->take(5)

            ->get();



        $monthlyRevenue = Transaction::where('company_id', $companyId)

            ->where('status', 'completed')

            ->where('type', 'payment')

            ->whereYear('created_at', now()->year)

            ->selectRaw('MONTH(created_at) as month, SUM(amount) as total')

            ->groupBy('month')

            ->pluck('total', 'month')

            ->toArray();



        $revenueChart = [];

        for ($i = 1; $i <= 12; $i++) {

            $revenueChart[] = $monthlyRevenue[$i] ?? 0;

        }



        return view('admin.dashboard.index', compact(

            'stats', 'recentClients', 'recentInvoices', 'recentTickets', 'revenueChart'

        ));

    }



    /**

     * Verificar status da conexão WhatsApp (mesma lógica da página de instâncias).

     */

    public function whatsappStatus(): JsonResponse

    {

        try {

            $companyId = auth()->user()->company_id;



            $instance = WhatsappInstance::where('company_id', $companyId)

                ->where('is_active', true)

                ->orderByDesc('is_default')

                ->first();



            if ($instance) {

                $instance->syncConfigFromEnv();

                $service = new EvolutionGoService($instance);

                $apiName = $instance->getEvolutionApiName();

                $result = $service->getInstanceStatus($apiName);



                if ($result['success'] ?? false) {

                    $connected = (bool) ($result['data']['connected'] ?? false);

                    $dbStatus = $connected ? 'connected' : 'disconnected';



                    $instance->update(['status' => $dbStatus]);



                    return response()->json([

                        'connected' => $connected,

                        'state' => $result['data']['state'] ?? ($connected ? 'open' : 'close'),

                        'instance' => $instance->name,

                        'message' => $connected ? 'Conectado' : 'Desconectado',

                    ]);

                }



                return response()->json([

                    'connected' => $instance->status === 'connected',

                    'message' => $result['message'] ?? 'Erro ao verificar instância',

                    'instance' => $instance->name,

                ]);

            }



            $whatsappService = app(WhatsAppService::class);

            $status = $whatsappService->checkConnectionStatus();



            return response()->json($status);

        } catch (\Exception $e) {

            return response()->json([

                'connected' => false,

                'message' => 'Erro ao verificar status: ' . $e->getMessage(),

            ], 500);

        }

    }

}

