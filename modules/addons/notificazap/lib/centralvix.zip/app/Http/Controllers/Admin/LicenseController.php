<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\License;
use App\Models\Client;
use App\Services\EvolutionWhatsAppService;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class LicenseController extends Controller
{
    protected $whatsapp;

    public function __construct(EvolutionWhatsAppService $whatsapp)
    {
        $this->whatsapp = $whatsapp;
    }

    public function index(Request $request)
    {
        $search = $request->input('search');
        $status = $request->input('status');

        $companyId = auth()->user()->company_id;

        $licenses = License::with('client')
            ->where('company_id', $companyId)
            ->when($search, function($query, $search) {
                $query->where(function($q) use ($search) {
                    $q->where('license_key', 'like', "%{$search}%")
                      ->orWhere('client_name', 'like', "%{$search}%")
                      ->orWhere('client_email', 'like', "%{$search}%")
                      ->orWhere('domain', 'like', "%{$search}%");
                });
            })
            ->when($status, function($query, $status) {
                if ($status !== 'all') {
                    $query->where('status', $status);
                }
            })
            ->latest()
            ->paginate(20);

        $stats = [
            'total' => License::where('company_id', $companyId)->count(),
            'active' => License::where('company_id', $companyId)->where('status', 'active')->count(),
            'expired' => License::where('company_id', $companyId)->where('status', 'expired')->count(),
            'suspended' => License::where('company_id', $companyId)->where('status', 'suspended')->count(),
            'blocked' => License::where('company_id', $companyId)->where('status', 'blocked')->count(),
            'expiring_soon' => License::where('company_id', $companyId)->expiringSoon(30)->count(),
        ];

        return view('admin.licenses.index', compact('licenses', 'stats'));
    }

    public function create()
    {
        // Lista de clientes existentes
        $clients = Client::select('id', 'firstname', 'lastname', 'email', 'whatsapp')
            ->get()
            ->map(function($client) {
                return [
                    'id' => $client->id,
                    'name' => $client->firstname . ' ' . $client->lastname,
                    'email' => $client->email,
                    'whatsapp' => $client->whatsapp,
                ];
            });

        return view('admin.licenses.create', compact('clients'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'client_type' => 'required|in:existing,new',
            'client_id' => 'required_if:client_type,existing|nullable|exists:clients,id',
            'client_name' => 'required_if:client_type,new|nullable|string|max:255',
            'client_email' => 'required_if:client_type,new|nullable|email|max:255',
            'client_whatsapp' => 'nullable|string|max:20',
            'client_cpf_cnpj' => 'nullable|string|max:18',
            'product_name' => 'required|string|max:255',
            'domain' => 'nullable|string|max:255',
            'ip_address' => 'nullable|ip',
            'max_domains' => 'required|integer|min:0|max:100',
            'max_ips' => 'required|integer|min:0|max:100',
            'expires_in_months' => 'required|integer|min:1|max:120',
            'send_whatsapp' => 'boolean',
            'notes' => 'nullable|string',
        ]);

        // Se for cliente existente, pega os dados
        if ($validated['client_type'] === 'existing') {
            $client = Client::find($validated['client_id']);
            $validated['client_name'] = $client->firstname . ' ' . $client->lastname;
            $validated['client_email'] = $client->email;
            $validated['client_whatsapp'] = $client->whatsapp;
        }

        // Cria a licença
        $license = License::create([
            'company_id' => auth()->user()->company_id,
            'client_id' => $validated['client_id'] ?? null,
            'client_name' => $validated['client_name'],
            'client_email' => $validated['client_email'],
            'client_whatsapp' => $validated['client_whatsapp'],
            'client_cpf_cnpj' => $validated['client_cpf_cnpj'],
            'product_name' => $validated['product_name'],
            'domain' => $validated['domain'],
            'ip_address' => $validated['ip_address'],
            'max_domains' => $validated['max_domains'],
            'max_ips' => $validated['max_ips'],
            'status' => 'active',
            'issued_at' => now(),
            'expires_at' => now()->addMonths($validated['expires_in_months']),
            'notes' => $validated['notes'],
        ]);

        // Adiciona domínio se fornecido
        if (!empty($validated['domain'])) {
            $license->domains()->create([
                'domain' => $validated['domain'],
                'is_active' => true,
            ]);
        }

        // Adiciona IP se fornecido
        if (!empty($validated['ip_address'])) {
            $license->ips()->create([
                'ip_address' => $validated['ip_address'],
                'is_active' => true,
            ]);
        }

        // Envia WhatsApp se solicitado
        if ($request->boolean('send_whatsapp') && !empty($validated['client_whatsapp'])) {
            $this->sendLicenseWhatsApp($license);
        }

        activity()
            ->causedBy(auth()->user())
            ->performedOn($license)
            ->log('Licença criada');

        return redirect()
            ->route('admin.licenses.show', $license)
            ->with('success', '✓ Licença criada com sucesso!');
    }

    public function show(License $license)
    {
        $license->load(['validations' => function($query) {
            $query->latest()->limit(50);
        }, 'domains', 'ips']);

        $stats = [
            'total_validations' => $license->validations()->count(),
            'successful_validations' => $license->validations()->where('result', 'success')->count(),
            'failed_validations' => $license->validations()->where('result', 'failed')->count(),
            'last_validation' => $license->validations()->latest()->first(),
        ];

        return view('admin.licenses.show', compact('license', 'stats'));
    }

    public function edit(License $license)
    {
        return view('admin.licenses.edit', compact('license'));
    }

    public function update(Request $request, License $license)
    {
        $validated = $request->validate([
            'client_name' => 'required|string|max:255',
            'client_email' => 'required|email|max:255',
            'client_whatsapp' => 'nullable|string|max:20',
            'product_name' => 'required|string|max:255',
            'max_domains' => 'required|integer|min:0',
            'max_ips' => 'required|integer|min:0',
            'expires_at' => 'nullable|date',
            'notes' => 'nullable|string',
        ]);

        $license->update($validated);

        activity()
            ->causedBy(auth()->user())
            ->performedOn($license)
            ->log('Licença atualizada');

        return redirect()
            ->route('admin.licenses.show', $license)
            ->with('success', '✓ Licença atualizada com sucesso!');
    }

    public function destroy(License $license)
    {
        activity()
            ->causedBy(auth()->user())
            ->performedOn($license)
            ->log('Licença excluída');

        $license->delete();

        return redirect()
            ->route('admin.licenses.index')
            ->with('success', '✓ Licença excluída com sucesso!');
    }

    public function suspend(Request $request, License $license)
    {
        $validated = $request->validate([
            'reason' => 'required|string|max:500',
        ]);

        $license->suspend($validated['reason']);

        activity()
            ->causedBy(auth()->user())
            ->performedOn($license)
            ->log('Licença suspensa: ' . $validated['reason']);

        return back()->with('success', '✓ Licença suspensa com sucesso!');
    }

    public function block(Request $request, License $license)
    {
        $validated = $request->validate([
            'reason' => 'required|string|max:500',
        ]);

        $license->block($validated['reason']);

        activity()
            ->causedBy(auth()->user())
            ->performedOn($license)
            ->log('Licença bloqueada: ' . $validated['reason']);

        return back()->with('success', '✓ Licença bloqueada com sucesso!');
    }

    public function deactivate(License $license)
    {
        $license->deactivate();

        activity()
            ->causedBy(auth()->user())
            ->performedOn($license)
            ->log('Licença desativada');

        return back()->with('success', '✓ Licença desativada com sucesso!');
    }

    public function activate(License $license)
    {
        $license->activate();

        activity()
            ->causedBy(auth()->user())
            ->performedOn($license)
            ->log('Licença ativada');

        return back()->with('success', '✓ Licença ativada com sucesso!');
    }

    public function renew(Request $request, License $license)
    {
        $validated = $request->validate([
            'months' => 'required|integer|min:1|max:120',
        ]);

        $license->renew($validated['months']);

        activity()
            ->causedBy(auth()->user())
            ->performedOn($license)
            ->log('Licença renovada por ' . $validated['months'] . ' meses');

        return back()->with('success', '✓ Licença renovada com sucesso!');
    }

    public function sendWhatsApp(License $license)
    {
        if (empty($license->client_whatsapp)) {
            return back()->withErrors(['error' => 'Cliente não possui WhatsApp cadastrado']);
        }

        $this->sendLicenseWhatsApp($license);

        $license->update(['notification_sent_at' => now()]);

        return back()->with('success', '✓ WhatsApp enviado com sucesso!');
    }

    private function sendLicenseWhatsApp(License $license): void
    {
        $message = "🎉 *Licença Ativada - CentralVix*\n\n";
        $message .= "Olá *{$license->client_name}*!\n\n";
        $message .= "Sua licença foi gerada com sucesso:\n\n";
        $message .= "📦 *Produto:* {$license->product_name}\n";
        $message .= "🔑 *Chave:* `{$license->license_key}`\n\n";
        
        if ($license->domain) {
            $message .= "🌐 *Domínio:* {$license->domain}\n";
        }
        
        if ($license->expires_at) {
            $message .= "📅 *Validade:* {$license->expires_at->format('d/m/Y')}\n";
        }
        
        $message .= "\n📧 *Email:* {$license->client_email}\n";
        $message .= "\n✅ Sua licença já está ativa e pronta para uso!\n\n";
        $message .= "💬 Precisa de ajuda? Entre em contato conosco!";

        $this->whatsapp->sendText($license->client_whatsapp, $message);
    }
}
