<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\TwoFactorService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class TwoFactorController extends Controller
{
    public function __construct(private TwoFactorService $twoFactor) {}

    public function showForm(Request $request): View|RedirectResponse
    {
        $user = $this->challengeUser($request);
        if (!$user) {
            return redirect()->route('login');
        }

        $method = $this->twoFactor->resolveChallengeMethod($user);
        $sent = null;

        if (in_array($method, [TwoFactorService::METHOD_EMAIL, TwoFactorService::METHOD_WHATSAPP], true)) {
            if (!$request->session()->has('2fa:code_sent')) {
                $sent = $this->twoFactor->sendChallengeCode($user);
                $request->session()->put('2fa:code_sent', true);
            }
        }

        return view('auth.2fa', [
            'method'      => $method,
            'sentTo'      => $this->twoFactor->challengeSentTo($user),
            'canRemember' => $this->twoFactor->rememberDays($user->company_id) > 0,
            'sendResult'  => $sent,
        ]);
    }

    public function verify(Request $request): RedirectResponse
    {
        $request->validate(['code' => 'required|string|min:6|max:6']);

        $user = $this->challengeUser($request);
        if (!$user) {
            return redirect()->route('login');
        }

        if (!$this->twoFactor->verifyChallenge($user, $request->code)) {
            return back()->withErrors(['code' => 'Código inválido ou expirado. Tente novamente.']);
        }

        $request->session()->forget(['2fa:user_id', '2fa:code_sent']);
        Auth::login($user);
        $request->session()->regenerate();

        if ($request->boolean('remember_device')) {
            $this->twoFactor->rememberDevice($user);
        }

        if ($this->twoFactor->mustSetup($user)) {
            return redirect()->route('two-factor.setup');
        }

        if ($user->isAdmin()) {
            return redirect()->intended(route('admin.dashboard'));
        }

        return redirect()->intended(route('client.dashboard'));
    }

    public function resend(Request $request): RedirectResponse
    {
        $user = $this->challengeUser($request);
        if (!$user) {
            return redirect()->route('login');
        }

        $result = $this->twoFactor->sendChallengeCode($user);

        return back()->with(
            ($result['success'] ?? false) ? 'success' : 'error',
            $result['message'] ?? 'Não foi possível reenviar o código.'
        );
    }

    protected function challengeUser(Request $request): ?User
    {
        $userId = $request->session()->get('2fa:user_id');

        return $userId ? User::find($userId) : null;
    }
}
