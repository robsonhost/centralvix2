<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\InvoiceNfe;
use App\Models\NfeSetting;
use App\Services\Nfe\NfseGovBrService;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;

class NfseController extends Controller
{
    protected $nfseService;

    public function __construct(NfseGovBrService $nfseService)
    {
        $this->nfseService = $nfseService;
    }

    /**
     * Listagem de NFS-e
     */
    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;
        
        $query = InvoiceNfe::where('company_id', $companyId)
            ->with(['invoice', 'client'])
            ->orderBy('created_at', 'desc');

        // Filtros
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('nfe_number', 'like', "%{$search}%")
                  ->orWhere('nfe_key', 'like', "%{$search}%")
                  ->orWhereHas('client', function($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  });
            });
        }

        $nfses = $query->paginate(20);
        
        // Estatísticas
        $stats = [
            'total' => InvoiceNfe::where('company_id', $companyId)->count(),
            'issued' => InvoiceNfe::where('company_id', $companyId)->where('status', 'issued')->count(),
            'cancelled' => InvoiceNfe::where('company_id', $companyId)->where('status', 'cancelled')->count(),
            'pending' => InvoiceNfe::where('company_id', $companyId)->where('status', 'pending')->count(),
        ];

        return view('admin.nfse.index', compact('nfses', 'stats'));
    }

    /**
     * Página de configurações
     */
    public function settings(): View
    {
        $companyId = auth()->user()->company_id;
        $settings = NfeSetting::firstOrCreate(
            ['company_id' => $companyId],
            [
                'provider' => 'nfse_govbr',
                'environment' => 'homologacao',
                'enabled' => false,
            ]
        );

        return view('admin.nfse.settings', compact('settings'));
    }

    /**
     * Salvar configurações
     */
    public function saveSettings(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'enabled' => 'boolean',
            'environment' => 'required|in:homologacao,producao',
            'certificate' => 'nullable|file|mimes:pfx,p12',
            'certificate_password' => 'required_with:certificate',
            'serie_nfe' => 'required|string',
            'natureza_operacao' => 'required|string',
            'regime_tributario' => 'required|in:1,2,3',
            'auto_issue' => 'boolean',
            'send_email' => 'boolean',
        ]);

        $companyId = auth()->user()->company_id;
        $settings = NfeSetting::where('company_id', $companyId)->first();

        // Upload do certificado
        if ($request->hasFile('certificate')) {
            $path = $request->file('certificate')->store('certificates', 'local');
            $validated['certificate_path'] = storage_path('app/' . $path);
        }

        $settings->update($validated);

        return redirect()->route('admin.nfse.settings')
            ->with('success', 'Configurações salvas com sucesso!');
    }

    /**
     * Emitir NFS-e para uma fatura
     */
    public function emit(Invoice $invoice): JsonResponse
    {
        try {
            // Verificar se já existe NFS-e para esta fatura
            $existing = InvoiceNfe::where('invoice_id', $invoice->id)->first();
            if ($existing && $existing->status === 'issued') {
                return response()->json([
                    'success' => false,
                    'message' => 'Esta fatura já possui uma NFS-e emitida.',
                ], 400);
            }

            // Emitir NFS-e
            $result = $this->nfseService->emitirNfse($invoice);

            if ($result['success']) {
                return response()->json([
                    'success' => true,
                    'message' => 'NFS-e emitida com sucesso!',
                    'nfse' => $result['nfse'],
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => $result['message'],
                'errors' => $result['errors'] ?? [],
            ], 400);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao emitir NFS-e: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Visualizar detalhes da NFS-e
     */
    public function show(InvoiceNfe $nfse): View
    {
        $nfse->load(['invoice', 'client', 'company']);
        return view('admin.nfse.show', compact('nfse'));
    }

    /**
     * Cancelar NFS-e
     */
    public function cancel(Request $request, InvoiceNfe $nfse): JsonResponse
    {
        $validated = $request->validate([
            'motivo' => 'required|string|min:15|max:255',
        ]);

        if (!$nfse->canCancel()) {
            return response()->json([
                'success' => false,
                'message' => 'Esta NFS-e não pode ser cancelada.',
            ], 400);
        }

        $result = $this->nfseService->cancelarNfse($nfse, $validated['motivo']);

        if ($result['success']) {
            return response()->json([
                'success' => true,
                'message' => 'NFS-e cancelada com sucesso!',
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => $result['message'],
        ], 400);
    }

    /**
     * Download do PDF
     */
    public function downloadPdf(InvoiceNfe $nfse)
    {
        if ($nfse->pdf_url) {
            return redirect($nfse->pdf_url);
        }

        $url = $this->nfseService->downloadPdf($nfse->nfe_number);
        
        if ($url) {
            $nfse->update(['pdf_url' => $url]);
            return redirect($url);
        }

        return back()->with('error', 'PDF não disponível.');
    }

    /**
     * Download do XML
     */
    public function downloadXml(InvoiceNfe $nfse)
    {
        if ($nfse->xml_url) {
            return redirect($nfse->xml_url);
        }

        $url = $this->nfseService->downloadXml($nfse->nfe_number);
        
        if ($url) {
            $nfse->update(['xml_url' => $url]);
            return redirect($url);
        }

        return back()->with('error', 'XML não disponível.');
    }

    /**
     * Validar certificado digital
     */
    public function validateCertificate(Request $request): JsonResponse
    {
        $request->validate([
            'certificate' => 'required|file|mimes:pfx,p12',
            'password' => 'required|string',
        ]);

        $path = $request->file('certificate')->store('temp');
        $fullPath = storage_path('app/' . $path);

        $result = $this->nfseService->validateCertificate($fullPath, $request->password);

        // Limpar arquivo temporário
        unlink($fullPath);

        return response()->json($result);
    }
}
