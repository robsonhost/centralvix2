<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductGroup;
use App\Models\Server;
use App\Services\CacheService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ServerController extends Controller
{
    protected CacheService $cacheService;

    public function __construct(CacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $query = Server::where('company_id', $companyId);

        // Filters
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('hostname', 'like', '%' . $request->search . '%')
                  ->orWhere('ip_address', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $servers = $query->paginate(20);

        // Statistics
        $stats = [
            'total' => Server::where('company_id', $companyId)->count(),
            'online' => Server::where('company_id', $companyId)->where('status', 'active')->count(),
            'offline' => Server::where('company_id', $companyId)->where('status', 'inactive')->count(),
            'maintenance' => Server::where('company_id', $companyId)->where('status', 'maintenance')->count(),
            'total_accounts' => Server::where('company_id', $companyId)->sum('assigned_accounts'),
        ];

        return view('admin.servers.index', compact('servers', 'stats'));
    }

    public function create(): View
    {
        return view('admin.servers.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateServer($request);

        $companyId = auth()->user()->company_id;

        $secure    = $request->boolean('secure', true);
        $verifySsl = $request->boolean('verify_ssl', false);

        $server = Server::create(array_merge($validated, [
            'company_id' => $companyId,
            'ip_address' => $request->input('ip_address', $validated['hostname']),
            'type'       => $this->resolveServerType($validated['module'] ?? null),
            'secure'     => $secure,
            'api_token'  => $request->filled('api_token') ? encrypt($request->api_token) : null,
            'settings'   => ['secure' => $secure, 'verify_ssl' => $verifySsl],
        ]));

        return redirect()->route('admin.servers.edit', $server)->with('success', 'Servidor criado!');
    }

    public function edit(Server $server): View
    {
        $this->authorizeCompany($server);
        return view('admin.servers.edit', compact('server'));
    }

    public function update(Request $request, Server $server): RedirectResponse
    {
        $this->authorizeCompany($server);

        $validated = $this->validateServer($request);
        $secure    = $request->boolean('secure', true);
        $verifySsl = $request->boolean('verify_ssl', false);

        $data = array_merge($validated, [
            'ip_address' => $request->input('ip_address', $validated['hostname']),
            'type'       => $this->resolveServerType($validated['module'] ?? null, $server->type),
            'secure'     => $secure,
            'settings'   => array_merge((array) ($server->settings ?? []), [
                'secure' => $secure,
                'verify_ssl' => $verifySsl,
            ]),
        ]);

        // Only update api_token if user typed a new value
        if ($request->filled('api_token')) {
            $data['api_token'] = encrypt($request->api_token);
        }

        $server->update($data);

        return back()->with('success', 'Servidor atualizado!');
    }

    public function show(Server $server): View
    {
        $this->authorizeCompany($server);

        $connection = null;
        $stats = ['accounts_count' => 0, 'packages_count' => 0, 'load' => []];
        $accounts = [];
        $packages = [];
        $listErrors = [];
        $error = null;

        if ($this->isWhmServer($server)) {
            try {
                $module = new \Modules\Hosting\CpanelModule($server);
                $connection = $module->testConnection();

                if ($connection['success'] ?? false) {
                    $accounts = $module->listAccounts();
                    if ($accounts === [] && $module->getLastError()) {
                        $listErrors['accounts'] = $module->getLastError();
                    }

                    $packages = $this->cacheService->getWhmPackages(
                        $server->company_id,
                        $server->id,
                        fn () => $module->listPackages()
                    );
                    if ($packages === [] && $module->getLastError()) {
                        $listErrors['packages'] = $module->getLastError();
                    }

                    $stats['accounts_count'] = count($accounts);
                    $stats['packages_count'] = count($packages);
                    $stats['load'] = $module->getServerLoad();

                    $server->update(['assigned_accounts' => $stats['accounts_count']]);
                } else {
                    $error = $connection['message'] ?? 'Falha na conexão WHM.';
                }
            } catch (\Throwable $e) {
                $error = $e->getMessage();
                logger()->error('Server show failed', ['server_id' => $server->id, 'error' => $e->getMessage()]);
            }
        } else {
            $error = 'Servidor não identificado como cPanel/WHM. Edite o servidor e selecione o módulo "cPanel / WHM".';
        }

        return view('admin.servers.show', compact('server', 'stats', 'connection', 'error', 'accounts', 'packages', 'listErrors'));
    }

    public function destroy(Server $server): RedirectResponse
    {
        $this->authorizeCompany($server);
        $server->delete();
        return redirect()->route('admin.servers.index')->with('success', 'Servidor removido.');
    }

    /**
     * Test server connection
     */
    public function test(Request $request, Server $server)
    {
        $this->authorizeCompany($server);

        try {
            if (!$this->isWhmServer($server)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Teste de conexão disponível apenas para servidores cPanel/WHM.',
                ]);
            }

            $originalServer = $server;
            $testToken = $request->input('api_token');
            $hasSavedToken = (bool) $server->getDecryptedApiToken();

            if (!$hasSavedToken && empty($testToken)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Token/API Key não configurado. Cole o token WHM e salve, ou preencha o campo antes de testar.',
                    'details' => [
                        'hint' => 'WHM → Desenvolvimento → Gerenciar tokens de API',
                        'hostname' => $server->hostname,
                        'port' => $server->port ?? 2087,
                    ],
                ]);
            }

            if ($testToken || $request->has('verify_ssl') || $request->has('secure')) {
                $server = clone $server;
                $settings = (array) ($server->settings ?? []);
                if ($testToken) {
                    $server->api_token = encrypt($testToken);
                }
                if ($request->has('verify_ssl')) {
                    $settings['verify_ssl'] = $request->boolean('verify_ssl');
                }
                if ($request->has('secure')) {
                    $server->secure = $request->boolean('secure');
                    $settings['secure'] = $server->secure;
                }
                $server->settings = $settings;
            }

            $module = new \Modules\Hosting\CpanelModule($server);
            $result = $module->testConnection();

            if ($result['success'] ?? false) {
                $originalServer->update(['status' => 'active']);
            }

            return response()->json($result);

        } catch (\Throwable $e) {
            logger()->error('Server test failed', [
                'server_id' => $server->id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'details' => ['trace' => config('app.debug') ? $e->getFile() . ':' . $e->getLine() : null],
            ], 500);
        }
    }

    /**
     * Test all servers
     */
    public function testAll(Request $request)
    {
        $companyId = auth()->user()->company_id;
        $servers = Server::where('company_id', $companyId)->get();
        
        $online = 0;
        $offline = 0;
        
        foreach ($servers as $server) {
            try {
                if ($this->isWhmServer($server) && $server->getDecryptedApiToken()) {
                    $module = new \Modules\Hosting\CpanelModule($server);
                    $result = $module->testConnection();
                    if ($result['success'] ?? false) {
                        $online++;
                        $server->update(['status' => 'active']);
                    } else {
                        $offline++;
                        $server->update(['status' => 'inactive']);
                    }
                } else {
                    $offline++;
                }
            } catch (\Throwable $e) {
                $offline++;
                $server->update(['status' => 'inactive']);
            }
        }
        
        return response()->json([
            'success' => true,
            'online' => $online,
            'offline' => $offline
        ]);
    }

    /**
     * List accounts on server
     */
    public function accounts(Server $server): JsonResponse
    {
        $this->authorizeCompany($server);

        try {
            if (!$this->isWhmServer($server)) {
                return response()->json(['success' => false, 'message' => 'Servidor não é cPanel/WHM.'], 422);
            }

            $module = new \Modules\Hosting\CpanelModule($server);
            $test = $module->testConnection();
            if (!($test['success'] ?? false)) {
                return response()->json([
                    'success' => false,
                    'message' => $test['message'] ?? 'Falha na conexão WHM.',
                    'details' => $test['details'] ?? null,
                ], 422);
            }

            $accounts = $module->listAccounts();

            return response()->json([
                'success' => true,
                'accounts' => $accounts,
                'total' => count($accounts),
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function packages(Server $server): JsonResponse
    {
        $this->authorizeCompany($server);

        try {
            if (!$this->isWhmServer($server)) {
                return response()->json(['success' => false, 'message' => 'Servidor não é cPanel/WHM.'], 422);
            }

            $companyId = auth()->user()->company_id;
            $module = new \Modules\Hosting\CpanelModule($server);
            $test = $module->testConnection();
            if (!($test['success'] ?? false)) {
                return response()->json([
                    'success' => false,
                    'message' => $test['message'] ?? 'Falha na conexão WHM.',
                    'details' => $test['details'] ?? null,
                ], 422);
            }

            $packages = $this->cacheService->getWhmPackages(
                $companyId,
                $server->id,
                fn () => $module->listPackages()
            );

            return response()->json([
                'success' => true,
                'packages' => $packages,
                'total' => count($packages),
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function storePackage(Request $request, Server $server): JsonResponse
    {
        $this->authorizeCompany($server);

        if (!$this->isWhmServer($server)) {
            return response()->json(['success' => false, 'message' => 'Apenas servidores cPanel/WHM.'], 422);
        }

        $data = $request->validate([
            'name' => 'required|string|max:64',
            'quota' => 'nullable|integer|min:0',
            'bwlimit' => 'nullable|integer|min:0',
            'maxftp' => 'nullable|integer|min:0',
            'maxsql' => 'nullable|integer|min:0',
            'maxpop' => 'nullable|integer|min:0',
        ]);

        $module = new \Modules\Hosting\CpanelModule($server);
        $result = $module->createPackage($data);

        if ($result['success'] ?? false) {
            $this->cacheService->forgetWhmPackages(auth()->user()->company_id, $server->id);
        }

        return response()->json($result, ($result['success'] ?? false) ? 200 : 422);
    }

    public function createHostingProduct(Request $request, Server $server, string $packageName): JsonResponse
    {
        $this->authorizeCompany($server);

        $data = $request->validate([
            'name' => 'nullable|string|max:255',
            'price_monthly' => 'nullable|numeric|min:0',
            'group_id' => 'nullable|exists:product_groups,id',
        ]);

        $companyId = auth()->user()->company_id;
        $productName = $data['name'] ?? ('Hospedagem ' . $packageName);

        $product = Product::create([
            'company_id' => $companyId,
            'group_id' => $data['group_id'] ?? null,
            'name' => $productName,
            'type' => 'hosting',
            'module' => 'CpanelModule',
            'module_config' => [
                'server_id' => $server->id,
                'plan' => $packageName,
            ],
            'price_monthly' => $data['price_monthly'] ?? 0,
            'status' => 'active',
            'stock_unlimited' => true,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Plano de hospedagem criado e vinculado ao pacote WHM.',
            'redirect' => route('admin.products.edit', $product),
            'product_id' => $product->id,
        ]);
    }

    private function validateServer(Request $request): array
    {
        return $request->validate([
            'name'         => 'required|string|max:255',
            'hostname'     => 'required|string|max:255',
            'ip_address'   => 'nullable|string|max:255',
            'module'       => 'nullable|string|max:100',
            'port'         => 'nullable|integer',
            'username'     => 'nullable|string',
            'status'       => 'required|in:active,inactive,maintenance',
            'max_accounts' => 'nullable|integer|min:0',
        ]);
    }

    private function resolveServerType(?string $module, ?string $fallback = 'cpanel'): string
    {
        return match ($module) {
            'CpanelModule' => 'cpanel',
            'PleskModule' => 'plesk',
            'DirectAdminModule' => 'directadmin',
            'VirtualizorModule' => 'virtualizor',
            'ProxmoxModule' => 'proxmox',
            'ShoutcastModule', 'CentovaCastModule' => 'streaming',
            default => $fallback ?? 'custom',
        };
    }

    private function authorizeCompany(Server $server): void
    {
        if ($server->company_id !== auth()->user()->company_id) abort(403);
    }

    private function isWhmServer(Server $server): bool
    {
        if (in_array($server->type, ['cpanel', 'whm'], true)) {
            return true;
        }

        if ($server->module === 'CpanelModule') {
            return true;
        }

        $port = (int) ($server->port ?? 0);

        return in_array($port, [2086, 2087], true) && (bool) $server->getDecryptedApiToken();
    }
}
