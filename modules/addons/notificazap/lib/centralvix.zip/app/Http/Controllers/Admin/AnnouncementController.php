<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Announcement;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AnnouncementController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $announcements = Announcement::forCompany($companyId)
            ->orderByDesc('is_active')
            ->orderByDesc('created_at')
            ->paginate(15);

        $stats = [
            'total'    => Announcement::forCompany($companyId)->count(),
            'active'   => Announcement::forCompany($companyId)->where('is_active', true)->count(),
            'current'  => Announcement::forCompany($companyId)->published()->count(),
        ];

        return view('admin.announcements.index', compact('announcements', 'stats'));
    }

    public function create(): View
    {
        return view('admin.announcements.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validateData($request);
        $data['company_id'] = auth()->user()->company_id;
        $data['created_by'] = auth()->id();

        Announcement::create($data);

        return redirect()
            ->route('admin.announcements.index')
            ->with('success', 'Aviso criado com sucesso!');
    }

    public function edit(Announcement $announcement): View
    {
        $this->authorizeCompany($announcement);

        return view('admin.announcements.edit', compact('announcement'));
    }

    public function update(Request $request, Announcement $announcement): RedirectResponse
    {
        $this->authorizeCompany($announcement);

        $announcement->update($this->validateData($request));

        return redirect()
            ->route('admin.announcements.index')
            ->with('success', 'Aviso atualizado com sucesso!');
    }

    public function destroy(Announcement $announcement): RedirectResponse
    {
        $this->authorizeCompany($announcement);

        $announcement->delete();

        return redirect()
            ->route('admin.announcements.index')
            ->with('success', 'Aviso removido.');
    }

    public function toggle(Announcement $announcement): JsonResponse
    {
        $this->authorizeCompany($announcement);

        $announcement->update(['is_active' => !$announcement->is_active]);

        return response()->json([
            'success' => true,
            'is_active' => $announcement->is_active,
            'message' => $announcement->is_active ? 'Aviso ativado.' : 'Aviso desativado.',
        ]);
    }

    private function validateData(Request $request): array
    {
        return $request->validate([
            'title'       => ['required', 'string', 'max:150'],
            'message'     => ['required', 'string', 'max:2000'],
            'type'        => ['required', 'in:info,success,warning,danger'],
            'audience'    => ['required', 'in:all,active,overdue'],
            'is_active'   => ['nullable', 'boolean'],
            'dismissible' => ['nullable', 'boolean'],
            'starts_at'   => ['nullable', 'date'],
            'ends_at'     => ['nullable', 'date', 'after_or_equal:starts_at'],
        ], [], [
            'title' => 'título',
            'message' => 'mensagem',
            'ends_at' => 'data final',
        ]) + [
            'is_active'   => $request->boolean('is_active'),
            'dismissible' => $request->boolean('dismissible'),
        ];
    }

    private function authorizeCompany(Announcement $announcement): void
    {
        abort_unless($announcement->company_id === auth()->user()->company_id, 403);
    }
}
