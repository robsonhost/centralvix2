<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WebhookDelivery;
use App\Models\WebhookEndpoint;
use App\Services\WebhookDispatcher;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class WebhookController extends Controller
{
    /**
     * Eventos disponíveis para assinatura.
     */
    public const AVAILABLE_EVENTS = [
        'invoice.created'  => 'Fatura criada',
        'invoice.paid'     => 'Fatura paga',
        'invoice.*'        => 'Todos os eventos de fatura',
        'payment.received' => 'Pagamento recebido',
        'ticket.created'   => 'Ticket criado',
        'client.created'   => 'Cliente criado',
    ];

    public function __construct(private WebhookDispatcher $dispatcher) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $endpoints = WebhookEndpoint::forCompany($companyId)->latest()->get();
        $deliveries = WebhookDelivery::where('company_id', $companyId)
            ->with('endpoint')
            ->latest()
            ->limit(20)
            ->get();

        return view('admin.webhooks.index', compact('endpoints', 'deliveries'));
    }

    public function create(): View
    {
        $events = self::AVAILABLE_EVENTS;

        return view('admin.webhooks.create', compact('events'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name'      => ['required', 'string', 'max:150'],
            'url'       => ['required', 'url', 'max:500'],
            'secret'    => ['nullable', 'string', 'max:100'],
            'events'    => ['nullable', 'array'],
            'events.*'  => ['string', 'max:60'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        WebhookEndpoint::create([
            'company_id' => auth()->user()->company_id,
            'name'       => $data['name'],
            'url'        => $data['url'],
            'secret'     => $data['secret'] ?: Str::random(40),
            'events'     => $data['events'] ?? [],
            'is_active'  => $request->boolean('is_active'),
        ]);

        return redirect()->route('admin.webhooks.index')->with('success', 'Webhook criado com sucesso!');
    }

    public function destroy(WebhookEndpoint $webhook): RedirectResponse
    {
        $this->authorizeCompany($webhook);
        $webhook->delete();

        return redirect()->route('admin.webhooks.index')->with('success', 'Webhook removido.');
    }

    public function toggle(WebhookEndpoint $webhook): JsonResponse
    {
        $this->authorizeCompany($webhook);
        $webhook->update(['is_active' => !$webhook->is_active]);

        return response()->json([
            'success' => true,
            'is_active' => $webhook->is_active,
            'message' => $webhook->is_active ? 'Webhook ativado.' : 'Webhook desativado.',
        ]);
    }

    public function test(WebhookEndpoint $webhook): JsonResponse
    {
        $this->authorizeCompany($webhook);

        $result = $this->dispatcher->test($webhook);

        return response()->json($result, $result['success'] ? 200 : 422);
    }

    private function authorizeCompany(WebhookEndpoint $webhook): void
    {
        abort_unless($webhook->company_id === auth()->user()->company_id, 403);
    }
}
