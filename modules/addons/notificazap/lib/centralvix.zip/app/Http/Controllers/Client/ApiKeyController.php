<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\ApiKey;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ApiKeyController extends Controller
{
    public function __construct(
        protected ModuleService $modules,
        protected ModuleSettingsService $settings,
    ) {}

    public function index(Request $request): View
    {
        $client = $this->resolveClient();

        $apiKeys = ApiKey::where('company_id', $client->company_id)
            ->where('client_id', $client->id)
            ->latest()
            ->get();

        $cfg = $this->settings->all($client->company_id, 'api_access');

        return view('client.api-keys.index', [
            'apiKeys'    => $apiKeys,
            'cfg'        => $cfg,
            'maxKeys'    => (int) ($cfg['max_keys_per_client'] ?? 3),
            'allowWrite' => (bool) ($cfg['allow_write'] ?? false),
            'expiryDays' => (int) ($cfg['key_expiry_days'] ?? 365),
            'plainKey'   => session('api_key_plain'),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $client = $this->resolveClient();
        $cfg = $this->settings->all($client->company_id, 'api_access');

        if (!($cfg['enabled'] ?? true)) {
            return back()->with('error', 'A geração de chaves está desativada pelo administrador.');
        }

        $existing = ApiKey::where('company_id', $client->company_id)
            ->where('client_id', $client->id)
            ->where('status', 'active')
            ->count();

        $max = (int) ($cfg['max_keys_per_client'] ?? 3);
        if ($existing >= $max) {
            return back()->with('error', "Você já atingiu o limite de {$max} chave(s) ativa(s). Revogue uma chave antes de criar outra.");
        }

        $data = $request->validate([
            'name'        => ['required', 'string', 'max:80'],
            'permissions' => ['nullable', 'array'],
            'permissions.*' => ['string', 'in:read,write'],
        ]);

        $allowWrite = (bool) ($cfg['allow_write'] ?? false);
        $perms = collect($data['permissions'] ?? ['read'])
            ->filter(fn ($p) => $allowWrite || $p === 'read')
            ->values()
            ->all();
        if (empty($perms)) {
            $perms = ['read'];
        }

        $expiryDays = (int) ($cfg['key_expiry_days'] ?? 365);

        $plain = 'cv_' . Str::random(48);

        $apiKey = ApiKey::create([
            'company_id' => $client->company_id,
            'client_id'  => $client->id,
            'name'       => $data['name'],
            'key'        => hash('sha256', $plain),
            'permissions'=> $perms,
            'status'     => 'active',
            'expires_at' => $expiryDays > 0 ? now()->addDays($expiryDays) : null,
        ]);

        return redirect()->route('client.api-keys.index')
            ->with('api_key_plain', $plain)
            ->with('api_key_id', $apiKey->id)
            ->with('success', 'Chave de API criada com sucesso. Copie agora — ela não será mostrada novamente.');
    }

    public function destroy(ApiKey $apiKey): RedirectResponse
    {
        $client = $this->resolveClient();

        abort_unless(
            $apiKey->company_id === $client->company_id && $apiKey->client_id === $client->id,
            403
        );

        $apiKey->update(['status' => 'revoked']);

        return back()->with('success', "Chave \"{$apiKey->name}\" revogada.");
    }

    /**
     * Resolve cliente autenticado e garante que o módulo está ativo.
     */
    protected function resolveClient()
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        abort_unless(
            $this->modules->isEnabled($client->company_id, 'api_access'),
            404,
            'Acesso à API desativado pelo administrador.'
        );

        return $client;
    }
}
