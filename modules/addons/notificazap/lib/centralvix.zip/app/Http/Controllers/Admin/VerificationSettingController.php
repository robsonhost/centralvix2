<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\VerificationSetting;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class VerificationSettingController extends Controller
{
    /**
     * Show verification settings page
     */
    public function index(): View
    {
        $companyId = session('company_id', 1);
        
        $settings = VerificationSetting::firstOrCreate(
            ['company_id' => $companyId],
            [
                'email_verification_enabled' => true,
                'whatsapp_verification_enabled' => false,
                'allow_user_choice' => true,
                'default_method' => 'email',
                'code_length' => 6,
                'code_expiry_minutes' => 1440,
                'resend_cooldown_enabled' => true,
                'resend_cooldown_minutes' => 2,
            ]
        );

        return view('admin.settings.verification', compact('settings'));
    }

    /**
     * Update verification settings
     */
    public function update(Request $request): RedirectResponse
    {
        $companyId = session('company_id', 1);

        $validated = $request->validate([
            'email_verification_enabled' => 'boolean',
            'whatsapp_verification_enabled' => 'boolean',
            'allow_user_choice' => 'boolean',
            'default_method' => 'required|in:email,whatsapp',
            'code_length' => 'required|integer|min:4|max:8',
            'code_expiry_minutes' => 'required|integer|min:5|max:10080',
            'resend_cooldown_enabled' => 'boolean',
            'resend_cooldown_minutes' => 'required|integer|min:1|max:60',
        ]);

        // Garantir que pelo menos um método esteja ativo
        if (!$request->has('email_verification_enabled') && !$request->has('whatsapp_verification_enabled')) {
            return back()->with('error', 'Pelo menos um método de verificação deve estar ativo!');
        }

        // Atualizar ou criar configurações
        VerificationSetting::updateOrCreate(
            ['company_id' => $companyId],
            array_merge($validated, [
                'email_verification_enabled' => $request->has('email_verification_enabled'),
                'whatsapp_verification_enabled' => $request->has('whatsapp_verification_enabled'),
                'allow_user_choice' => $request->has('allow_user_choice'),
                'resend_cooldown_enabled' => $request->has('resend_cooldown_enabled'),
            ])
        );

        return back()->with('success', 'Configurações de verificação atualizadas com sucesso!');
    }
}
