<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Services\AddonService;
use Illuminate\View\View;

class MarketplaceController extends Controller
{
    public function __construct(private AddonService $addons) {}

    public function index(): View
    {
        $client = auth()->user()->client ?? abort(404);

        abort_unless($this->addons->showInClientArea($client->company_id), 404);

        $addons = $this->addons->all($client->company_id);

        return view('client.marketplace.index', compact('addons'));
    }
}
