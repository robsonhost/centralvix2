<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use App\Models\Product;
use App\Models\ProductGroup;
use App\Services\BillingService;
use App\Services\CouponService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class OrderController extends Controller
{
    public function __construct(
        private BillingService $billingService,
        private CouponService $couponService
    ) {}

    public function index(): View
    {
        $client = auth()->user()->client ?? abort(404);
        $orders = $client->orders()->with(['items.product', 'services'])->latest()->paginate(15);
        return view('client.orders.index', compact('orders'));
    }

    public function create(Request $request): View
    {
        $client = auth()->user()->client ?? abort(404);

        $groups = ProductGroup::where('company_id', $client->company_id)
            ->where('status', 'active')
            ->with(['activeProducts.features'])
            ->get();

        $selectedProduct = $request->filled('product')
            ? Product::where('uuid', $request->product)->first()
            : null;

        return view('client.orders.create-NOVO', compact('groups', 'selectedProduct', 'client'));
    }

    public function store(Request $request): RedirectResponse
    {
        $client = auth()->user()->client ?? abort(404);

        $validated = $request->validate([
            'product_id' => 'required|exists:products,id',
            'billing_cycle' => 'required|in:monthly,quarterly,semiannually,annually,biennially,triennially,lifetime',
            'domain' => 'nullable|string|max:255',
            'coupon_code' => 'nullable|string',
        ]);

        $product = Product::findOrFail($validated['product_id']);

        $domainRules = \App\Support\HostingRules::domainValidationRules($product);
        $request->validate(['domain' => $domainRules]);
        $domain = \App\Support\HostingRules::normalizeDomain($validated['domain'] ?? null);

        if (!$product->isAvailable()) {
            return back()->with('error', 'Produto indisponível.');
        }

        $coupon = null;
        if ($request->filled('coupon_code')) {
            $coupon = $this->couponService->validate($request->coupon_code, $client, $product);
            if (!$coupon) {
                return back()->withErrors(['coupon_code' => 'Cupom inválido ou expirado.']);
            }
        }

        $order = $this->billingService->createOrder($client, $product, $validated['billing_cycle'], $domain, $coupon);

        // Redireciona para a fatura mais recente do pedido
        $invoice = $order->invoices()->latest()->first();
        
        if ($invoice) {
            return redirect()->route('client.invoices.show', $invoice)
                ->with('success', 'Pedido criado com sucesso! Efetue o pagamento para ativar o serviço.');
        }
        
        // Se não houver invoice, redireciona para a lista de pedidos
        return redirect()->route('client.orders.index')
            ->with('success', 'Pedido criado com sucesso!');
    }

    public function validateCoupon(Request $request): JsonResponse
    {
        $client = auth()->user()->resolveClient() ?? abort(404);

        $data = $request->validate([
            'code' => ['required', 'string', 'max:50'],
            'product_id' => ['nullable', 'exists:products,id'],
            'billing_cycle' => ['nullable', 'string'],
        ]);

        $product = isset($data['product_id']) ? Product::find($data['product_id']) : null;
        $coupon = $this->couponService->validate($data['code'], $client, $product);

        if (!$coupon) {
            return response()->json(['valid' => false, 'message' => 'Cupom inválido ou expirado.']);
        }

        $base = $product
            ? (float) $product->getPriceForCycle($data['billing_cycle'] ?? 'monthly')
            : 0;
        $discount = $coupon->calculateDiscount($base);

        return response()->json([
            'valid' => true,
            'code' => $coupon->code,
            'discount' => $discount,
            'type' => $coupon->type,
            'message' => 'Cupom válido: -R$ ' . number_format($discount, 2, ',', '.'),
        ]);
    }
}
