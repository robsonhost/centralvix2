<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\CreditRecharge;
use App\Models\PaymentGateway;
use App\Models\RechargeOption;
use App\Services\PaymentService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class RechargeController extends Controller
{
    public function __construct(private PaymentService $paymentService) {}

    private function ensureModule(): void
    {
        $client = auth()->user()->resolveClient();
        abort_unless(
            $client && app(\App\Services\ModuleService::class)->isEnabled($client->company_id, 'consultas'),
            404
        );
    }

    /**
     * Página de recarga
     */
    public function index(): View
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $options = RechargeOption::forCompany($client->company_id)
            ->active()
            ->orderBy('order')
            ->orderBy('amount')
            ->get();

        $gateways = PaymentGateway::where('company_id', $client->company_id)
            ->where('status', 'active')
            ->orderBy('order')
            ->get();

        return view('client.recharge.index', [
            'client' => $client,
            'options' => $options,
            'gateways' => $gateways,
            'balance' => (float) $client->credit_balance,
        ]);
    }

    /**
     * Processa a recarga
     */
    public function store(Request $request): RedirectResponse
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $validated = $request->validate([
            'amount' => 'required|numeric|min:1',
            'gateway_id' => 'required|exists:payment_gateways,id',
        ]);

        $option = RechargeOption::forCompany($client->company_id)
            ->where('amount', $validated['amount'])
            ->active()
            ->first();

        if (!$option) {
            return back()->with('error', 'Valor de recarga inválido.');
        }

        $gateway = PaymentGateway::where('id', $validated['gateway_id'])
            ->where('company_id', $client->company_id)
            ->where('status', 'active')
            ->first();

        if (!$gateway) {
            return back()->with('error', 'Método de pagamento inválido.');
        }

        $recharge = CreditRecharge::create([
            'company_id' => $client->company_id,
            'client_id' => $client->id,
            'amount' => $option->amount + $option->bonus,
            'balance_before' => $client->credit_balance,
            'status' => 'pending',
            'payment_method' => $gateway->module,
            'gateway' => $gateway->module,
            'ip_address' => $request->ip(),
        ]);

        try {
            $result = $this->createPayment($recharge, $gateway, $option);

            if (isset($result['redirect_url'])) {
                return redirect()->away($result['redirect_url']);
            }

            return redirect()->route('client.consultas.recharge.show', $recharge)
                ->with('info', 'Recarga criada! Realize o pagamento para adicionar os créditos.');

        } catch (\Throwable $e) {
            $recharge->update(['status' => 'failed']);

            return back()->with('error', 'Erro ao criar recarga: ' . $e->getMessage());
        }
    }

    /**
     * Exibe detalhes da recarga (PIX, boleto, etc)
     */
    public function show(CreditRecharge $recharge): View
    {
        $this->ensureModule();
        if (!auth()->user()->canAccessClientRecord($recharge->client)) {
            abort(403);
        }

        return view('client.recharge.show', [
            'recharge' => $recharge,
        ]);
    }

    /**
     * Histórico de recargas
     */
    public function history(): View
    {
        $this->ensureModule();
        $client = auth()->user()->resolveClient() ?? abort(404);

        $recharges = CreditRecharge::where('client_id', $client->id)
            ->latest()
            ->paginate(20);

        return view('client.recharge.history', [
            'client' => $client,
            'recharges' => $recharges,
        ]);
    }

    /**
     * Verifica status da recarga (polling)
     */
    public function status(CreditRecharge $recharge): \Illuminate\Http\JsonResponse
    {
        if (!auth()->user()->canAccessClientRecord($recharge->client)) {
            abort(403);
        }

        return response()->json([
            'status' => $recharge->status,
            'label' => $recharge->status_label,
            'paid' => $recharge->isPaid(),
            'balance' => $recharge->isPaid() ? (float) $recharge->client->credit_balance : null,
        ]);
    }

    /**
     * Cria pagamento no gateway
     */
    protected function createPayment(CreditRecharge $recharge, PaymentGateway $gateway, RechargeOption $option): array
    {
        $module = strtolower($gateway->module);

        $description = 'Recarga de créditos - R$ ' . number_format($option->amount, 2, ',', '.');
        if ($option->bonus > 0) {
            $description .= ' + R$ ' . number_format($option->bonus, 2, ',', '.') . ' bônus';
        }

        $data = [
            'amount' => (float) $option->amount,
            'description' => $description,
            'external_reference' => 'RECHARGE-' . $recharge->uuid,
            'payer' => [
                'name' => $recharge->client->full_name,
                'email' => $recharge->client->email,
                'document' => $recharge->client->cpf ?? $recharge->client->cnpj,
            ],
        ];

        if (in_array($module, ['pix', 'mercadopago', 'mercado_pago', 'asaas'])) {
            $result = $this->createPixPayment($gateway, $data, $recharge);
        } elseif (in_array($module, ['boleto', 'paghiper'])) {
            $result = $this->createBoletoPayment($gateway, $data, $recharge);
        } else {
            $result = ['success' => false, 'message' => 'Gateway não suportado para recarga'];
        }

        if (isset($result['gateway_id'])) {
            $recharge->update([
                'gateway_id' => $result['gateway_id'],
                'gateway_data' => $result['gateway_data'] ?? null,
            ]);
        }

        return $result;
    }

    protected function createPixPayment(PaymentGateway $gateway, array $data, CreditRecharge $recharge): array
    {
        $recharge->update([
            'gateway_data' => [
                'type' => 'pix',
                'qr_code' => 'PLACEHOLDER_PIX_CODE',
                'qr_code_base64' => null,
            ],
        ]);

        return [
            'success' => true,
            'gateway_data' => $recharge->gateway_data,
        ];
    }

    protected function createBoletoPayment(PaymentGateway $gateway, array $data, CreditRecharge $recharge): array
    {
        $recharge->update([
            'gateway_data' => [
                'type' => 'boleto',
                'barcode' => '12345678901234567890123456789012345678901234567890',
                'pdf_url' => null,
            ],
        ]);

        return [
            'success' => true,
            'gateway_data' => $recharge->gateway_data,
        ];
    }
}
