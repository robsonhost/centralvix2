<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Jobs\UpdateExchangeRates;
use App\Models\Setting;
use App\Services\CurrencyService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\View\View;

class CurrencyController extends Controller
{
    public function __construct(private CurrencyService $currency) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $base = $this->currency->baseCurrency($companyId);
        $enabled = $this->currency->enabledCurrencies($companyId);

        $rows = [];
        foreach ($enabled as $code) {
            $rows[] = [
                'code' => $code,
                'symbol' => $this->currency->symbol($code),
                'is_base' => $code === $base,
                'rate' => $code === $base ? 1.0 : $this->currency->storedRate($companyId, $code),
            ];
        }

        return view('admin.currencies.index', [
            'base' => $base,
            'rows' => $rows,
            'enabled' => $this->currency->isEnabled($companyId),
            'updatedAt' => Setting::get($companyId, 'currency_rates', 'updated_at'),
            'markup' => (float) ($this->currency->config($companyId)['exchange_markup_percent'] ?? 0),
        ]);
    }

    public function updateRates(Request $request): RedirectResponse
    {
        $companyId = auth()->user()->company_id;
        $base = $this->currency->baseCurrency($companyId);

        $data = $request->validate([
            'rates' => 'array',
            'rates.*' => 'nullable|numeric|min:0',
        ]);

        foreach (($data['rates'] ?? []) as $code => $rate) {
            $code = strtoupper($code);
            if ($code === $base || !in_array($code, CurrencyService::SUPPORTED, true)) {
                continue;
            }
            if ($rate !== null && $rate !== '') {
                $this->currency->setRate($companyId, $code, (float) $rate);
            }
        }

        Setting::set($companyId, 'currency_rates', 'updated_at', now()->toIso8601String(), 'string');

        return back()->with('success', 'Taxas de câmbio atualizadas manualmente.');
    }

    public function refresh(): RedirectResponse
    {
        $companyId = auth()->user()->company_id;

        if (!$this->currency->isEnabled($companyId)) {
            return back()->with('error', 'Ative o módulo "Multi-moeda" primeiro.');
        }

        $base = $this->currency->baseCurrency($companyId);
        $targets = array_diff($this->currency->enabledCurrencies($companyId), [$base]);
        $updated = 0;

        foreach ($targets as $target) {
            try {
                $pair = strtoupper($target) . '-' . strtoupper($base);
                $response = Http::timeout(15)->get("https://economia.awesomeapi.com.br/last/{$pair}");
                $bid = $response->successful() ? $response->json(strtoupper($target) . strtoupper($base) . '.bid') : null;
                if (is_numeric($bid)) {
                    $this->currency->setRate($companyId, $target, (float) $bid);
                    $updated++;
                }
            } catch (\Throwable $e) {
                // Ignora falha individual de cotação.
            }
        }

        Setting::set($companyId, 'currency_rates', 'updated_at', now()->toIso8601String(), 'string');

        return back()->with($updated > 0 ? 'success' : 'error',
            $updated > 0 ? "Cotações atualizadas ({$updated})." : 'Não foi possível obter cotações no momento.');
    }
}
