<?php

namespace App\Http\Controllers;

use App\Models\SatisfactionSurvey;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SurveyController extends Controller
{
    public function show(string $token): View
    {
        $survey = SatisfactionSurvey::where('token', $token)->firstOrFail();
        $company = $survey->company;

        return view('survey.show', [
            'survey' => $survey,
            'company' => $company,
            'answered' => $survey->status === 'answered',
        ]);
    }

    public function submit(Request $request, string $token)
    {
        $survey = SatisfactionSurvey::where('token', $token)->firstOrFail();

        if ($survey->status === 'answered') {
            return redirect()->route('survey.show', $token);
        }

        $max = $survey->isNps() ? 10 : 5;
        $min = $survey->isNps() ? 0 : 1;

        $data = $request->validate([
            'score' => "required|integer|min:{$min}|max:{$max}",
            'comment' => 'nullable|string|max:1000',
        ]);

        $survey->update([
            'score' => $data['score'],
            'comment' => $data['comment'] ?? null,
            'status' => 'answered',
            'answered_at' => now(),
        ]);

        return redirect()->route('survey.show', $token)->with('thanks', true);
    }
}
