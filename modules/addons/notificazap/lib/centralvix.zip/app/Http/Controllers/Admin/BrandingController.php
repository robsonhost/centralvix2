<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\BrandingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class BrandingController extends Controller
{
    public function __construct(private BrandingService $branding) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        $branding = $this->branding->get($companyId);

        return view('admin.settings.branding', compact('branding'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'company_name' => 'required|string|max:100',
            'primary_color' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'secondary_color' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'accent_color' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'sidebar_start' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'sidebar_end' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'login_gradient_start' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'login_gradient_end' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
        ]);

        $this->branding->saveBranding(auth()->user()->company_id, $validated);

        return back()->with('success', 'Personalização salva! Cores aplicadas em todo o sistema.');
    }

    public function upload(Request $request): RedirectResponse
    {
        $request->validate([
            'type' => 'required|in:logo_login,logo_admin,logo_client,favicon,pwa_icon,login_bg,login_bg_remove,login_banner,login_banner_remove',
            'file' => 'required_unless:type,login_bg_remove,login_banner_remove|file|mimes:jpg,jpeg,png,webp,svg,ico|max:8192',
        ]);

        // Remoção da imagem de fundo
        if ($request->type === 'login_bg_remove') {
            $companyId = auth()->user()->company_id;
            \App\Models\Setting::where('company_id', $companyId)
                ->where('group', 'branding')
                ->where('key', 'login_bg')
                ->delete();
            \Illuminate\Support\Facades\Cache::forget("branding_{$companyId}");
            return back()->with('success', 'Imagem de fundo removida.');
        }

        // Remoção do banner de login
        if ($request->type === 'login_banner_remove') {
            $companyId = auth()->user()->company_id;
            \App\Models\Setting::where('company_id', $companyId)
                ->where('group', 'branding')
                ->where('key', 'login_banner')
                ->delete();
            \Illuminate\Support\Facades\Cache::forget("branding_{$companyId}");
            return back()->with('success', 'Banner de login removido.');
        }

        $this->branding->uploadAsset(
            auth()->user()->company_id,
            $request->type,
            $request->file('file')
        );

        return back()->with('success', 'Imagem enviada com sucesso!');
    }

    public function pwa(): View
    {
        $companyId = auth()->user()->company_id;
        $branding = $this->branding->get($companyId);

        return view('admin.settings.pwa', compact('branding'));
    }

    public function updatePwa(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'enabled' => 'nullable|boolean',
            'name' => 'required|string|max:80',
            'short_name' => 'required|string|max:20',
            'theme_color' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'background_color' => 'required|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'display' => 'required|in:standalone,fullscreen,minimal-ui,browser',
        ]);

        $validated['enabled'] = $request->boolean('enabled');

        $this->branding->savePwa(auth()->user()->company_id, $validated);

        return back()->with('success', 'Configurações PWA salvas!');
    }
}
