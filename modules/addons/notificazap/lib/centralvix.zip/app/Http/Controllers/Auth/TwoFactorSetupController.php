<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Services\TwoFactorService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class TwoFactorSetupController extends Controller
{
    public function __construct(private TwoFactorService $twoFactor) {}

    public function show(Request $request): View|RedirectResponse
    {
        $user = $request->user();
        abort_unless($this->twoFactor->moduleEnabled($user->company_id), 404);

        $allowed = $this->twoFactor->allowedMethods($user->company_id);
        $pendingSecret = $request->session()->get('2fa_setup_secret');
        $pendingQr = $pendingSecret ? $this->twoFactor->appQrUrl($user, $pendingSecret) : null;

        return view('auth.two-factor-setup', [
            'user'          => $user,
            'enabled'       => $user->isTwoFactorEnabled(),
            'currentMethod' => $user->two_factor_method,
            'allowed'       => $allowed,
            'required'      => $this->twoFactor->isRequiredFor($user),
            'mustSetup'     => $this->twoFactor->mustSetup($user),
            'graceMessage'  => $this->twoFactor->graceMessage($user),
            'pendingSecret' => $pendingSecret,
            'pendingQr'     => $pendingQr,
        ]);
    }

    public function beginApp(Request $request): RedirectResponse
    {
        $user = $request->user();
        abort_unless($this->twoFactor->moduleEnabled($user->company_id), 404);
        abort_unless(in_array(TwoFactorService::METHOD_APP, $this->twoFactor->allowedMethods($user->company_id), true), 422);

        $secret = $this->twoFactor->generateAppSecret();
        $request->session()->put('2fa_setup_secret', $secret);

        return redirect()->route('two-factor.setup')->with('info', 'Escaneie o QR Code e confirme com um código do aplicativo.');
    }

    public function confirmApp(Request $request): RedirectResponse
    {
        $user = $request->user();
        $request->validate(['code' => 'required|string|size:6']);

        $secret = $request->session()->get('2fa_setup_secret');
        if (!$secret || !$this->twoFactor->verifyAppCode($secret, $request->code)) {
            return back()->withErrors(['code' => 'Código inválido. Verifique o aplicativo e tente novamente.']);
        }

        $this->twoFactor->activate($user, TwoFactorService::METHOD_APP, $secret);
        $request->session()->forget('2fa_setup_secret');

        return $this->afterEnable($user, 'Verificação por aplicativo ativada com sucesso!');
    }

    public function sendEmail(Request $request): RedirectResponse
    {
        return $this->sendSetup(TwoFactorService::METHOD_EMAIL);
    }

    public function sendWhatsapp(Request $request): RedirectResponse
    {
        return $this->sendSetup(TwoFactorService::METHOD_WHATSAPP);
    }

    public function confirmEmail(Request $request): RedirectResponse
    {
        return $this->confirmSetup($request, TwoFactorService::METHOD_EMAIL);
    }

    public function confirmWhatsapp(Request $request): RedirectResponse
    {
        return $this->confirmSetup($request, TwoFactorService::METHOD_WHATSAPP);
    }

    public function disable(Request $request): RedirectResponse
    {
        $user = $request->user();

        if ($this->twoFactor->mustSetup($user)) {
            return back()->with('error', 'A verificação em duas etapas é obrigatória para sua conta.');
        }

        $request->validate(['password' => 'required|string']);

        if (!Hash::check($request->password, $user->password)) {
            return back()->withErrors(['password' => 'Senha incorreta.']);
        }

        $this->twoFactor->deactivate($user);
        $request->session()->forget('2fa_setup_secret');

        return back()->with('success', 'Verificação em duas etapas desativada.');
    }

    protected function sendSetup(string $method): RedirectResponse
    {
        $user = auth()->user();
        abort_unless($this->twoFactor->moduleEnabled($user->company_id), 404);

        $result = $this->twoFactor->sendSetupCode($user, $method);

        return back()->with(
            ($result['success'] ?? false) ? 'success' : 'error',
            $result['message'] ?? 'Erro ao enviar código.'
        );
    }

    protected function confirmSetup(Request $request, string $method): RedirectResponse
    {
        $user = $request->user();
        $request->validate(['code' => 'required|string|size:6']);

        if (!$this->twoFactor->verifySetupCode($user, $method, $request->code)) {
            return back()->withErrors(['code' => 'Código inválido ou expirado.']);
        }

        $this->twoFactor->activate($user, $method);

        return $this->afterEnable($user, 'Verificação em duas etapas ativada com sucesso!');
    }

    protected function afterEnable($user, string $message): RedirectResponse
    {
        if ($user->isAdmin()) {
            return redirect()->route('admin.dashboard')->with('success', $message);
        }

        return redirect()->route('client.dashboard')->with('success', $message);
    }
}
