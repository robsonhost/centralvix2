<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\LoginAttempt;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SecurityController extends Controller
{
    /**
     * Show security dashboard
     */
    public function index(): View
    {
        $blockedIps = LoginAttempt::whereNotNull('blocked_until')
            ->where('blocked_until', '>', now())
            ->orderBy('blocked_until', 'desc')
            ->get()
            ->unique('ip_address');

        $recentAttempts = LoginAttempt::orderBy('attempted_at', 'desc')
            ->paginate(50);

        $stats = [
            'blockedCount' => $blockedIps->count(),
            'failedAttempts' => LoginAttempt::where('successful', false)
                ->where('attempted_at', '>', now()->subDay())
                ->count(),
            'successfulLogins' => LoginAttempt::where('successful', true)
                ->where('attempted_at', '>', now()->subDay())
                ->count(),
            'totalAttempts' => LoginAttempt::where('attempted_at', '>', now()->subDay())
                ->count(),
        ];

        return view('admin.security.index', [
            'blockedIps' => $blockedIps,
            'recentAttempts' => $recentAttempts,
            'blockedCount' => $stats['blockedCount'],
            'failedAttempts' => $stats['failedAttempts'],
            'successfulLogins' => $stats['successfulLogins'],
            'totalAttempts' => $stats['totalAttempts'],
        ]);
    }

    /**
     * Unblock an IP address
     */
    public function unblockIp(Request $request): JsonResponse
    {
        $ip = $request->input('ip');
        LoginAttempt::unblockIp($ip);

        return response()->json([
            'success' => true,
            'message' => 'IP desbloqueado com sucesso'
        ]);
    }

    /**
     * Block an IP address manually
     */
    public function blockIp(Request $request): JsonResponse
    {
        $ip = $request->input('ip');
        LoginAttempt::blockIp($ip, 60); // Block for 60 minutes

        return response()->json([
            'success' => true,
            'message' => 'IP bloqueado com sucesso'
        ]);
    }

    /**
     * Unblock all IPs
     */
    public function unblockAll(): JsonResponse
    {
        $count = LoginAttempt::whereNotNull('blocked_until')
            ->where('blocked_until', '>', now())
            ->count();

        LoginAttempt::whereNotNull('blocked_until')
            ->update(['blocked_until' => null]);

        return response()->json([
            'success' => true,
            'count' => $count,
            'message' => "{$count} IP(s) desbloqueados"
        ]);
    }
}
