<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BannedIp;
use App\Models\IpAccessLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class BannedIpController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        $bannedIps = BannedIp::with('bannedBy')
            ->where('company_id', $companyId)
            ->latest('banned_at')
            ->paginate(20);

        $stats = [
            'total_banned' => BannedIp::where('company_id', $companyId)->where('active', true)->count(),
            'permanent' => BannedIp::where('company_id', $companyId)->where('active', true)->whereNull('expires_at')->count(),
            'temporary' => BannedIp::where('company_id', $companyId)->where('active', true)->whereNotNull('expires_at')->count(),
            'blocked_today' => IpAccessLog::where('company_id', $companyId)->where('result', 'blocked')->whereDate('created_at', today())->count(),
        ];

        return view('admin.settings.banned-ips.index', compact('bannedIps', 'stats'));
    }

    public function create(): View
    {
        return view('admin.settings.banned-ips.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'ip_address' => 'required|string|max:255',
            'reason' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
            'expires_at' => 'nullable|date|after:now',
            'active' => 'boolean',
        ]);

        $validated['company_id'] = auth()->user()->company_id;
        $validated['banned_at'] = now();
        $validated['banned_by'] = auth()->id();

        BannedIp::create($validated);

        return redirect()->route('admin.settings.banned-ips.index')
            ->with('success', 'IP banido com sucesso!');
    }

    public function edit(BannedIp $bannedIp): View
    {
        return view('admin.settings.banned-ips.edit', compact('bannedIp'));
    }

    public function update(Request $request, BannedIp $bannedIp): RedirectResponse
    {
        $validated = $request->validate([
            'ip_address' => 'required|string|max:255',
            'reason' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
            'expires_at' => 'nullable|date',
            'active' => 'boolean',
        ]);

        $bannedIp->update($validated);

        return redirect()->route('admin.settings.banned-ips.index')
            ->with('success', 'IP atualizado com sucesso!');
    }

    public function destroy(BannedIp $bannedIp): RedirectResponse
    {
        $bannedIp->delete();

        return redirect()->route('admin.settings.banned-ips.index')
            ->with('success', 'Banimento removido com sucesso!');
    }

    public function logs(): View
    {
        $companyId = auth()->user()->company_id;
        
        $logs = IpAccessLog::with('client')
            ->where('company_id', $companyId)
            ->latest()
            ->paginate(50);

        return view('admin.settings.banned-ips.logs', compact('logs'));
    }
}
