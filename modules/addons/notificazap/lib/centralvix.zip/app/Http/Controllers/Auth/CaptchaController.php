<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Response;

class CaptchaController extends Controller
{
    /**
     * Gera a imagem CAPTCHA e armazena o código na sessão.
     */
    public function image(): Response
    {
        $code = $this->generateCode();
        session(['captcha_code' => strtoupper($code)]);

        $width  = 160;
        $height = 50;
        $img    = imagecreatetruecolor($width, $height);

        $bg = imagecolorallocate($img, 235, 243, 255);
        imagefill($img, 0, 0, $bg);

        for ($i = 0; $i < 6; $i++) {
            $lc = imagecolorallocate($img, rand(150, 210), rand(150, 210), rand(180, 230));
            imageline($img, rand(0, $width), rand(0, $height), rand(0, $width), rand(0, $height), $lc);
        }

        for ($i = 0; $i < 60; $i++) {
            $dc = imagecolorallocate($img, rand(160, 220), rand(160, 220), rand(190, 235));
            imagesetpixel($img, rand(0, $width), rand(0, $height), $dc);
        }

        $textColors = [
            imagecolorallocate($img, 30, 80, 160),
            imagecolorallocate($img, 20, 100, 180),
            imagecolorallocate($img, 40, 60, 150),
        ];

        $x = 12;
        foreach (str_split($code) as $char) {
            $color = $textColors[array_rand($textColors)];
            $y     = rand(10, 22);
            imagestring($img, 5, $x, $y, $char, $color);
            $x += rand(26, 30);
        }

        $border = imagecolorallocate($img, 200, 218, 245);
        imagerectangle($img, 0, 0, $width - 1, $height - 1, $border);

        ob_start();
        imagepng($img);
        imagedestroy($img);
        $imageData = ob_get_clean();

        return response($imageData, 200, [
            'Content-Type'  => 'image/png',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma'        => 'no-cache',
            'Expires'       => '0',
        ]);
    }

    /**
     * Gera novo código e retorna JSON para refresh via AJAX.
     * O código é retornado em texto para exibição client-side (igual ao projeto React de referência).
     */
    public function refresh(): \Illuminate\Http\JsonResponse
    {
        $code = $this->generateCode();
        session(['captcha_code' => strtoupper($code)]);

        return response()->json(['code' => $code]);
    }

    private function generateCode(): string
    {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $code  = '';
        for ($i = 0; $i < 5; $i++) {
            $code .= $chars[random_int(0, strlen($chars) - 1)];
        }
        return $code;
    }
}
