<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Monitor;
use App\Services\ModuleSettingsService;
use App\Services\MonitorService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MonitorController extends Controller
{
    public function __construct(
        private MonitorService $monitors,
        private ModuleSettingsService $settings,
    ) {}

    public function index(): View
    {
        $companyId = auth()->user()->company_id;

        $uptime = Monitor::forCompany($companyId)->where('type', 'uptime')->orderBy('name')->get();
        $ssl = Monitor::forCompany($companyId)->where('type', 'ssl')->orderBy('name')->get();

        $stats = [
            'total' => $uptime->count() + $ssl->count(),
            'up'    => $uptime->where('status', 'up')->count() + $ssl->where('status', 'up')->count(),
            'down'  => $uptime->where('status', 'down')->count() + $ssl->where('status', 'down')->count(),
        ];

        return view('admin.monitors.index', compact('uptime', 'ssl', 'stats'));
    }

    public function create(): View
    {
        return view('admin.monitors.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name'         => ['required', 'string', 'max:150'],
            'type'         => ['required', 'in:uptime,ssl'],
            'target'       => ['required', 'string', 'max:255'],
            'notify_email' => ['nullable', 'email', 'max:150'],
            'notify_phone' => ['nullable', 'string', 'max:30'],
            'is_active'    => ['nullable', 'boolean'],
        ]);

        $data['company_id'] = auth()->user()->company_id;
        $data['is_active'] = $request->boolean('is_active');

        Monitor::create($data);

        return redirect()->route('admin.monitors.index')->with('success', 'Monitor criado com sucesso!');
    }

    public function destroy(Monitor $monitor): RedirectResponse
    {
        $this->authorizeCompany($monitor);
        $monitor->delete();

        return redirect()->route('admin.monitors.index')->with('success', 'Monitor removido.');
    }

    public function toggle(Monitor $monitor): JsonResponse
    {
        $this->authorizeCompany($monitor);
        $monitor->update(['is_active' => !$monitor->is_active]);

        return response()->json([
            'success' => true,
            'is_active' => $monitor->is_active,
            'message' => $monitor->is_active ? 'Monitor ativado.' : 'Monitor desativado.',
        ]);
    }

    public function check(Monitor $monitor): RedirectResponse
    {
        $this->authorizeCompany($monitor);

        $module = $monitor->type === 'ssl' ? 'ssl_monitor' : 'uptime_monitor';
        $cfg = $this->settings->all($monitor->company_id, $module);

        if ($monitor->type === 'ssl') {
            $this->monitors->runSsl($monitor, $cfg);
        } else {
            $this->monitors->runUptime($monitor, $cfg);
        }

        return back()->with('success', "Verificação executada: {$monitor->fresh()->status_label}.");
    }

    private function authorizeCompany(Monitor $monitor): void
    {
        abort_unless($monitor->company_id === auth()->user()->company_id, 403);
    }
}
