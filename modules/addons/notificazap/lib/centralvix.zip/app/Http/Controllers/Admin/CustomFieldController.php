<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CustomField;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CustomFieldController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;
        
        $query = CustomField::where('company_id', $companyId);

        if ($request->filled('applies_to')) {
            $query->where('applies_to', $request->applies_to);
        }

        $fields = $query->orderBy('order')
            ->orderBy('name')
            ->paginate(20);

        return view('admin.settings.custom-fields.index', compact('fields'));
    }

    public function create(): View
    {
        return view('admin.settings.custom-fields.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'field_type' => 'required|in:text,textarea,select,checkbox,radio,date',
            'applies_to' => 'required|in:client,product,service,invoice',
            'options' => 'nullable|array',
            'validation' => 'nullable|string',
            'description' => 'nullable|string',
            'required' => 'boolean',
            'show_on_order' => 'boolean',
            'show_on_invoice' => 'boolean',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $validated['company_id'] = auth()->user()->company_id;

        CustomField::create($validated);

        return redirect()->route('admin.settings.custom-fields.index')
            ->with('success', 'Campo personalizado criado com sucesso!');
    }

    public function edit(CustomField $customField): View
    {
        return view('admin.settings.custom-fields.edit', compact('customField'));
    }

    public function update(Request $request, CustomField $customField): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'field_type' => 'required|in:text,textarea,select,checkbox,radio,date',
            'applies_to' => 'required|in:client,product,service,invoice',
            'options' => 'nullable|array',
            'validation' => 'nullable|string',
            'description' => 'nullable|string',
            'required' => 'boolean',
            'show_on_order' => 'boolean',
            'show_on_invoice' => 'boolean',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $customField->update($validated);

        return redirect()->route('admin.settings.custom-fields.index')
            ->with('success', 'Campo personalizado atualizado com sucesso!');
    }

    public function destroy(CustomField $customField): RedirectResponse
    {
        $customField->delete();

        return redirect()->route('admin.settings.custom-fields.index')
            ->with('success', 'Campo personalizado removido com sucesso!');
    }
}
