<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DomainPricing;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DomainPricingController extends Controller
{
    public function index(): View
    {
        $companyId = auth()->user()->company_id;
        
        $pricing = DomainPricing::where('company_id', $companyId)
            ->orderBy('order')
            ->orderBy('tld')
            ->paginate(20);

        return view('admin.settings.domain-pricing.index', compact('pricing'));
    }

    public function create(): View
    {
        return view('admin.settings.domain-pricing.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'tld' => 'required|string|max:50|unique:domain_pricing,tld,NULL,id,company_id,' . auth()->user()->company_id,
            'register_price' => 'required|numeric|min:0',
            'renew_price' => 'required|numeric|min:0',
            'transfer_price' => 'required|numeric|min:0',
            'min_years' => 'required|integer|min:1',
            'max_years' => 'required|integer|min:1',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $validated['company_id'] = auth()->user()->company_id;

        DomainPricing::create($validated);

        return redirect()->route('admin.settings.domain-pricing.index')
            ->with('success', 'TLD adicionado com sucesso!');
    }

    public function edit(DomainPricing $domainPricing): View
    {
        return view('admin.settings.domain-pricing.edit', compact('domainPricing'));
    }

    public function update(Request $request, DomainPricing $domainPricing): RedirectResponse
    {
        $validated = $request->validate([
            'tld' => 'required|string|max:50|unique:domain_pricing,tld,' . $domainPricing->id . ',id,company_id,' . auth()->user()->company_id,
            'register_price' => 'required|numeric|min:0',
            'renew_price' => 'required|numeric|min:0',
            'transfer_price' => 'required|numeric|min:0',
            'min_years' => 'required|integer|min:1',
            'max_years' => 'required|integer|min:1',
            'active' => 'boolean',
            'order' => 'integer',
        ]);

        $domainPricing->update($validated);

        return redirect()->route('admin.settings.domain-pricing.index')
            ->with('success', 'TLD atualizado com sucesso!');
    }

    public function destroy(DomainPricing $domainPricing): RedirectResponse
    {
        $domainPricing->delete();

        return redirect()->route('admin.settings.domain-pricing.index')
            ->with('success', 'TLD removido com sucesso!');
    }
}
