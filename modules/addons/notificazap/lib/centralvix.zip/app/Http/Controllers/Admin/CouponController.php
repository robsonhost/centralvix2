<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CouponController extends Controller
{
    public function index(): View
    {
        $coupons = Coupon::where('company_id', auth()->user()->company_id)->latest()->paginate(20);
        return view('admin.coupons.index', compact('coupons'));
    }

    public function create(): View
    {
        return view('admin.coupons.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'code' => 'required|string|unique:coupons,code|max:50',
            'name' => 'required|string|max:255',
            'type' => 'required|in:percentage,fixed',
            'value' => 'required|numeric|min:0',
            'max_uses' => 'nullable|integer|min:0',
            'applies_to' => 'required|in:all,products,categories',
            'clients_only' => 'boolean',
            'new_clients_only' => 'boolean',
            'valid_from' => 'nullable|date',
            'valid_until' => 'nullable|date|after:valid_from',
            'status' => 'required|in:active,inactive',
        ]);

        Coupon::create(array_merge($validated, [
            'company_id' => auth()->user()->company_id,
            'clients_only' => $request->boolean('clients_only'),
            'new_clients_only' => $request->boolean('new_clients_only'),
        ]));

        return redirect()->route('admin.coupons.index')
            ->with('success', 'Cupom criado com sucesso!');
    }

    public function edit(Coupon $coupon): View
    {
        $this->authorizeCompany($coupon);
        return view('admin.coupons.edit', compact('coupon'));
    }

    public function update(Request $request, Coupon $coupon): RedirectResponse
    {
        $this->authorizeCompany($coupon);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'type' => 'required|in:percentage,fixed',
            'value' => 'required|numeric|min:0',
            'max_uses' => 'nullable|integer|min:0',
            'applies_to' => 'required|in:all,products,categories',
            'clients_only' => 'boolean',
            'new_clients_only' => 'boolean',
            'valid_from' => 'nullable|date',
            'valid_until' => 'nullable|date',
            'status' => 'required|in:active,inactive,expired',
        ]);

        $coupon->update($validated);
        return redirect()->route('admin.coupons.index')
            ->with('success', 'Cupom atualizado.');
    }

    public function destroy(Coupon $coupon): RedirectResponse
    {
        $this->authorizeCompany($coupon);
        $coupon->delete();
        return redirect()->route('admin.coupons.index')
            ->with('success', 'Cupom removido.');
    }

    private function authorizeCompany(Coupon $coupon): void
    {
        if ($coupon->company_id !== auth()->user()->company_id) {
            abort(403);
        }
    }
}
