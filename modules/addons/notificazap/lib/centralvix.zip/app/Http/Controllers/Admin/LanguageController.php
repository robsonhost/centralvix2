<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class LanguageController extends Controller
{
    /**
     * Switch language
     */
    public function switch(Request $request)
    {
        $validated = $request->validate([
            'language' => 'required|string|in:pt,en,es',
        ]);

        $language = $validated['language'];

        // Save to session
        Session::put('locale', $language);

        // Update user preference if authenticated
        if (auth()->check()) {
            auth()->user()->update([
                'preferred_language' => $language,
            ]);
        }

        // Set for current request
        App::setLocale($language);

        return response()->json([
            'success' => true,
            'message' => 'Idioma alterado com sucesso!',
            'language' => $language,
        ]);
    }

    /**
     * Get available languages
     */
    public function available()
    {
        $languages = Language::active()->get();

        return response()->json([
            'languages' => $languages,
            'current' => App::getLocale(),
        ]);
    }
}
