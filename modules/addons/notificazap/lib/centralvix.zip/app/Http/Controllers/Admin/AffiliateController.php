<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Affiliate;
use App\Models\AffiliateReferral;
use App\Models\Client;
use App\Models\Commission;
use App\Models\Referral;
use App\Services\AdminExportService;
use App\Services\AffiliateService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class AffiliateController extends Controller
{
    public function __construct(
        private AffiliateService $affiliateService,
        private AdminExportService $exportService,
    ) {}

    public function index(Request $request): View
    {
        $companyId = auth()->user()->company_id;

        $this->syncAffiliates($companyId);

        $query = Affiliate::with('client')->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('code', 'like', '%' . $search . '%')
                  ->orWhereHas('client', function ($c) use ($search) {
                      $c->where('firstname', 'like', '%' . $search . '%')
                        ->orWhere('lastname', 'like', '%' . $search . '%')
                        ->orWhere('email', 'like', '%' . $search . '%');
                  });
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $affiliates = $query->latest()->paginate(20);

        $stats = [
            'total' => Affiliate::where('company_id', $companyId)->count(),
            'active' => Affiliate::where('company_id', $companyId)->where('status', 'active')->count(),
            'total_clicks' => Affiliate::where('company_id', $companyId)->sum('clicks'),
            'total_conversions' => Affiliate::where('company_id', $companyId)->sum('conversions'),
            'total_balance' => Affiliate::where('company_id', $companyId)->sum('balance'),
            'total_earned' => Affiliate::where('company_id', $companyId)->sum('total_earned'),
            'pending_commissions' => AffiliateReferral::whereHas('affiliate', fn ($q) => $q->where('company_id', $companyId))
                ->where('status', 'pending')->count(),
        ];

        $chartData = $this->getChartData($companyId);

        return view('admin.affiliates.index', compact('affiliates', 'stats', 'chartData'));
    }

    public function show(Affiliate $affiliate): View
    {
        if ($affiliate->company_id !== auth()->user()->company_id) abort(403);
        $affiliate->load(['client', 'referrals.client', 'referrals.invoice']);
        return view('admin.affiliates.show', compact('affiliate'));
    }

    public function approve(Request $request, AffiliateReferral $referral): RedirectResponse|JsonResponse
    {
        if ($referral->affiliate->company_id !== auth()->user()->company_id) abort(403);

        if ($referral->status !== 'pending') {
            if ($request->wantsJson()) {
                return response()->json(['success' => false, 'message' => 'Esta comissão já foi processada.'], 422);
            }
            return back()->with('error', 'Esta comissão já foi processada.');
        }

        $this->affiliateService->approveCommission($referral);
        $referral->refresh();
        $referral->load('affiliate');

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Comissão aprovada!',
                'referral' => $this->referralPayload($referral),
                'affiliate' => $this->affiliatePayload($referral->affiliate),
            ]);
        }

        return back()->with('success', 'Comissão aprovada!');
    }

    public function pay(Request $request, AffiliateReferral $referral): RedirectResponse|JsonResponse
    {
        if ($referral->affiliate->company_id !== auth()->user()->company_id) abort(403);

        if ($referral->status !== 'approved') {
            if ($request->wantsJson()) {
                return response()->json(['success' => false, 'message' => 'Comissão precisa estar aprovada antes do pagamento.'], 422);
            }
            return back()->with('error', 'Comissão precisa estar aprovada antes do pagamento.');
        }

        $referral->update(['status' => 'paid']);

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Comissão marcada como paga!',
                'referral' => $this->referralPayload($referral->fresh()),
            ]);
        }

        return back()->with('success', 'Comissão marcada como paga!');
    }

    public function toggleStatus(Request $request, Affiliate $affiliate): JsonResponse
    {
        if ($affiliate->company_id !== auth()->user()->company_id) abort(403);

        $newStatus = $affiliate->status === 'active' ? 'inactive' : 'active';
        $affiliate->update(['status' => $newStatus]);

        return response()->json([
            'success' => true,
            'message' => $newStatus === 'active' ? 'Afiliado ativado!' : 'Afiliado desativado.',
            'affiliate' => $this->affiliatePayload($affiliate->fresh()),
        ]);
    }

    public function payout(Request $request, Affiliate $affiliate): JsonResponse
    {
        if ($affiliate->company_id !== auth()->user()->company_id) abort(403);

        $request->validate([
            'amount' => 'nullable|numeric|min:0.01',
            'payment_method' => 'nullable|string|max:50',
        ]);

        $amount = $request->filled('amount') ? (float) $request->amount : (float) $affiliate->balance;

        if ($amount <= 0 || $affiliate->balance < $amount) {
            return response()->json(['success' => false, 'message' => 'Saldo insuficiente para pagamento.'], 422);
        }

        try {
            $this->affiliateService->payout($affiliate, $amount);
        } catch (\InvalidArgumentException $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
        }

        return response()->json([
            'success' => true,
            'message' => 'Pagamento de R$ ' . number_format($amount, 2, ',', '.') . ' registrado!',
            'affiliate' => $this->affiliatePayload($affiliate->fresh()),
        ]);
    }

    public function export(Request $request): \Symfony\Component\HttpFoundation\StreamedResponse|\Illuminate\Http\Response
    {
        $companyId = auth()->user()->company_id;
        $format = $request->get('format', 'csv');

        $query = Affiliate::with('client')->where('company_id', $companyId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('code', 'like', '%' . $search . '%')
                  ->orWhereHas('client', function ($c) use ($search) {
                      $c->where('firstname', 'like', '%' . $search . '%')
                        ->orWhere('lastname', 'like', '%' . $search . '%')
                        ->orWhere('email', 'like', '%' . $search . '%');
                  });
            });
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $headings = ['Código', 'Afiliado', 'E-mail', 'Status', 'Comissão', 'Saldo', 'Total Ganho', 'Cliques', 'Conversões', 'Taxa Conv.'];
        $rows = $query->latest()->get()->map(fn (Affiliate $a) => [
            $a->code,
            $a->client?->display_name ?? '—',
            $a->client?->email ?? '—',
            ucfirst($a->status),
            $a->commission_type === 'percentage' ? $a->commission_value . '%' : 'R$ ' . number_format((float) $a->commission_value, 2, ',', '.'),
            'R$ ' . number_format((float) $a->balance, 2, ',', '.'),
            'R$ ' . number_format((float) $a->total_earned, 2, ',', '.'),
            $a->clicks,
            $a->conversions,
            $a->conversion_rate . '%',
        ])->all();

        return $this->exportService->download($format, 'Afiliados', $headings, $rows);
    }

    private function getChartData(int $companyId): array
    {
        $months = collect();
        for ($i = 11; $i >= 0; $i--) {
            $months->push(now()->subMonths($i)->format('Y-m'));
        }

        $monthly = AffiliateReferral::whereHas('affiliate', fn ($q) => $q->where('company_id', $companyId))
            ->whereIn('status', ['approved', 'paid'])
            ->where('created_at', '>=', now()->subMonths(12))
            ->select(
                DB::raw("DATE_FORMAT(created_at, '%Y-%m') as month"),
                DB::raw('SUM(commission) as total')
            )
            ->groupBy('month')
            ->pluck('total', 'month');

        $monthlyData = $months->map(fn ($m) => (float) ($monthly[$m] ?? 0))->values();
        $monthLabels = $months->map(fn ($m) => \Carbon\Carbon::createFromFormat('Y-m', $m)->translatedFormat('M/y'))->values();

        $topAffiliates = Affiliate::with('client')
            ->where('company_id', $companyId)
            ->orderByDesc('total_earned')
            ->limit(5)
            ->get();

        return [
            'monthly_labels' => $monthLabels,
            'monthly_data' => $monthlyData,
            'top_labels' => $topAffiliates->map(fn ($a) => $a->client?->display_name ?? $a->code)->values(),
            'top_data' => $topAffiliates->pluck('total_earned')->map(fn ($v) => (float) $v)->values(),
        ];
    }

    private function affiliatePayload(Affiliate $affiliate): array
    {
        return [
            'id' => $affiliate->id,
            'status' => $affiliate->status,
            'balance' => number_format($affiliate->balance, 2, ',', '.'),
            'balance_raw' => (float) $affiliate->balance,
            'total_earned' => number_format($affiliate->total_earned, 2, ',', '.'),
            'clicks' => $affiliate->clicks,
            'conversions' => $affiliate->conversions,
            'conversion_rate' => $affiliate->conversion_rate,
        ];
    }

    private function referralPayload(AffiliateReferral $referral): array
    {
        return [
            'id' => $referral->id,
            'status' => $referral->status,
            'status_label' => ucfirst($referral->status),
            'commission' => number_format($referral->commission, 2, ',', '.'),
        ];
    }

    private function syncAffiliates(int $companyId): void
    {
        $referrerIds = Referral::whereHas('referrer', fn ($q) => $q->where('company_id', $companyId))
            ->pluck('referrer_id');

        $commissionIds = Commission::whereHas('client', fn ($q) => $q->where('company_id', $companyId))
            ->pluck('client_id');

        $clientIds = $referrerIds->merge($commissionIds)->unique()->filter();

        foreach ($clientIds as $clientId) {
            Affiliate::firstOrCreate(
                ['client_id' => $clientId, 'company_id' => $companyId],
                [
                    'status' => 'active',
                    'commission_type' => 'percentage',
                    'commission_value' => 10,
                    'url' => config('app.url') . '/register?ref=',
                ]
            );
        }
    }
}
