<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ConsultaSettingsController extends Controller
{
    public function index(): View
    {
        $companyId = (int) auth()->user()->company_id;
        $settings = $this->settings($companyId);

        return view('admin.consultas.settings', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $companyId = (int) auth()->user()->company_id;

        $validated = $request->validate([
            'price_people_cpf' => ['required', 'numeric', 'min:0'],
            'price_people_email' => ['required', 'numeric', 'min:0'],
            'price_people_phone' => ['required', 'numeric', 'min:0'],
            'price_people_mother_name' => ['required', 'numeric', 'min:0'],
            'price_people_cep' => ['required', 'numeric', 'min:0'],
            'price_company_email' => ['required', 'numeric', 'min:0'],
            'price_company_cep' => ['required', 'numeric', 'min:0'],
            'price_company_corporate_name' => ['required', 'numeric', 'min:0'],
            'price_company_phone' => ['required', 'numeric', 'min:0'],
            'price_company_cnpj' => ['required', 'numeric', 'min:0'],
            'price_score_serasa' => ['required', 'numeric', 'min:0'],
            'price_score_serasa_premium' => ['required', 'numeric', 'min:0'],
            'price_score_acerta_essencial' => ['required', 'numeric', 'min:0'],
            'price_score_scr_banco_central' => ['required', 'numeric', 'min:0'],
            'price_score_sera_ofc' => ['required', 'numeric', 'min:0'],
            'recharge_amounts' => ['required', 'string', 'min:2'],
        ]);

        foreach ($validated as $key => $value) {
            Setting::set($companyId, 'module_consultas', $key, $value, 'string');
        }

        return back()->with('success', 'Configurações de consultas atualizadas com sucesso.');
    }

    private function settings(int $companyId): array
    {
        $get = fn (string $key, string $default): string => (string) Setting::get($companyId, 'module_consultas', $key, $default);

        return [
            'price_people_cpf' => $get('price_people_cpf', '0.05'),
            'price_people_email' => $get('price_people_email', '0.05'),
            'price_people_phone' => $get('price_people_phone', '0.10'),
            'price_people_mother_name' => $get('price_people_mother_name', '0.05'),
            'price_people_cep' => $get('price_people_cep', '0.05'),
            'price_company_email' => $get('price_company_email', '0.05'),
            'price_company_cep' => $get('price_company_cep', '0.05'),
            'price_company_corporate_name' => $get('price_company_corporate_name', '0.05'),
            'price_company_phone' => $get('price_company_phone', '0.10'),
            'price_company_cnpj' => $get('price_company_cnpj', '0.05'),
            'price_score_serasa' => $get('price_score_serasa', '5.00'),
            'price_score_serasa_premium' => $get('price_score_serasa_premium', '9.00'),
            'price_score_acerta_essencial' => $get('price_score_acerta_essencial', '2.50'),
            'price_score_scr_banco_central' => $get('price_score_scr_banco_central', '15.00'),
            'price_score_sera_ofc' => $get('price_score_sera_ofc', '9.00'),
            'recharge_amounts' => $get('recharge_amounts', '50,100,150,200,250,300,500,700,1000,3000'),
        ];
    }
}

