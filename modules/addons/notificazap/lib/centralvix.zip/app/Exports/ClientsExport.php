<?php

namespace App\Exports;

use App\Models\Client;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ClientsExport implements FromCollection, WithHeadings, WithMapping, WithStyles, ShouldAutoSize
{
    protected $query;

    public function __construct($query)
    {
        $this->query = $query;
    }

    public function collection()
    {
        return $this->query->get();
    }

    public function headings(): array
    {
        return [
            'ID',
            'Código',
            'Tipo',
            'Nome',
            'Sobrenome',
            'Nome Completo',
            'Email',
            'Telefone',
            'Celular',
            'WhatsApp',
            'CPF',
            'CNPJ',
            'Empresa',
            'Data Nascimento',
            'Endereço',
            'Número',
            'Complemento',
            'Bairro',
            'Cidade',
            'Estado',
            'CEP',
            'País',
            'Status',
            'Saldo Crédito',
            'Grupo',
            'Data Criação',
            'Email Verificado',
        ];
    }

    public function map($client): array
    {
        return [
            $client->id,
            $client->client_code,
            $client->type,
            $client->firstname,
            $client->lastname,
            $client->full_name,
            $client->email,
            $client->phone,
            $client->mobile,
            $client->whatsapp,
            $client->cpf,
            $client->cnpj,
            $client->company_name,
            $client->date_of_birth ? $client->date_of_birth->format('d/m/Y') : '',
            $client->address,
            $client->address_number,
            $client->address_complement,
            $client->neighborhood,
            $client->city,
            $client->state,
            $client->zip,
            $client->country,
            $this->getStatusLabel($client->status),
            'R$ ' . number_format($client->credit_balance, 2, ',', '.'),
            $client->group ? $client->group->name : '',
            $client->created_at->format('d/m/Y H:i'),
            $client->email_verified_at ? 'Sim' : 'Não',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }

    private function getStatusLabel($status): string
    {
        $labels = [
            'active' => 'Ativo',
            'inactive' => 'Inativo',
            'suspended' => 'Suspenso',
            'closed' => 'Fechado',
            'banned' => 'Banido',
        ];

        return $labels[$status] ?? $status;
    }
}
