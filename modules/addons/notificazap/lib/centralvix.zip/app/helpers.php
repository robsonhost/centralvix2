<?php

use App\Services\ModuleService;
use App\Services\ModuleSettingsService;

if (!function_exists('module_enabled')) {
    /**
     * Verifica se um módulo/add-on está ativo para a empresa.
     */
    function module_enabled(string $slug, ?int $companyId = null): bool
    {
        $companyId ??= auth()->user()?->company_id;

        if (!$companyId) {
            return false;
        }

        return app(ModuleService::class)->isEnabled($companyId, $slug);
    }
}

if (!function_exists('consultas_available')) {
    /**
     * Consultas disponível no painel do cliente quando o módulo está ativo
     * ou quando existem tipos de consulta configurados no admin.
     */
    function consultas_available(?int $companyId = null): bool
    {
        $companyId ??= auth()->user()?->company_id;

        if (class_exists(\App\Models\ConsultaType::class) && \App\Models\ConsultaType::active()->exists()) {
            return true;
        }

        if (!$companyId) {
            return false;
        }

        return app(ModuleService::class)->isEnabled($companyId, 'consultas');
    }
}

if (!function_exists('module_config')) {
    /**
     * Retorna configuração de um módulo (group module_{slug}).
     */
    function module_config(string $slug, ?string $key = null, mixed $default = null): mixed
    {
        $companyId = auth()->user()?->company_id;
        if (!$companyId) {
            return $default;
        }

        $service = app(ModuleSettingsService::class);
        $all = $service->all($companyId, $slug);

        return $key === null ? $all : ($all[$key] ?? $default);
    }
}

if (!function_exists('branding')) {
    /**
     * Configurações de personalização/PWA da empresa.
     */
    function branding(?int $companyId = null): array
    {
        return app(\App\Services\BrandingService::class)->get($companyId);
    }
}
