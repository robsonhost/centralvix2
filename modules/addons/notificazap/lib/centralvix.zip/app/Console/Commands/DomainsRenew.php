<?php

namespace App\Console\Commands;

use App\Jobs\ProcessDomainRenewals;
use Illuminate\Console\Command;

class DomainsRenew extends Command
{
    protected $signature = 'domains:renew';
    protected $description = 'Process automatic domain renewals';

    public function handle(): int
    {
        $this->info('Processing domain renewals...');
        ProcessDomainRenewals::dispatch();
        $this->info('Domain renewal job dispatched.');
        return Command::SUCCESS;
    }
}
