<?php

namespace App\Console\Commands;

use App\Jobs\GenerateRecurringInvoices;
use App\Jobs\SendInvoiceReminders;
use App\Jobs\SuspendOverdueServices;
use App\Jobs\ReactivateServices;
use Illuminate\Console\Command;

class BillingRun extends Command
{
    protected $signature = 'billing:run {--dry-run : Simulate without making changes}';
    protected $description = 'Run all billing tasks: generate invoices, send reminders, suspend overdue services';

    public function handle(): int
    {
        $this->info('Starting CentralVix billing run...');

        if ($this->option('dry-run')) {
            $this->warn('DRY RUN mode - no changes will be made.');
        }

        $this->task('Generating recurring invoices', function () {
            GenerateRecurringInvoices::dispatch();
        });

        $this->task('Sending invoice reminders', function () {
            SendInvoiceReminders::dispatch();
        });

        $this->task('Suspending overdue services', function () {
            SuspendOverdueServices::dispatch();
        });

        $this->task('Reactivating paid services', function () {
            ReactivateServices::dispatch();
        });

        $this->info('Billing run completed successfully.');
        return Command::SUCCESS;
    }
}
