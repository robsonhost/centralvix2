<?php

namespace App\Console\Commands;

use App\Models\Client;
use App\Models\ClientScore;
use Illuminate\Console\Command;

class CalculateClientScores extends Command
{
    protected $signature   = 'clients:scores {--company= : Company ID}';
    protected $description = 'Calculate and update client scores';

    public function handle(): void
    {
        $query = Client::query();

        if ($this->option('company')) {
            $query->where('company_id', $this->option('company'));
        }

        $clients = $query->get();
        $this->info("📊 Calculating scores for {$clients->count()} clients...");

        $bar = $this->output->createProgressBar($clients->count());
        $bar->start();

        foreach ($clients as $client) {
            try {
                ClientScore::calculate($client);
            } catch (\Exception $e) {
                $this->newLine();
                $this->error("Failed for client #{$client->id}: " . $e->getMessage());
            }
            $bar->advance();
        }

        $bar->finish();
        $this->newLine();
        $this->info('✅ Scores updated!');
    }
}
