<?php

namespace App\Console\Commands;

use App\Jobs\CleanOldLogs;
use Illuminate\Console\Command;

class CleanLogsCommand extends Command
{
    protected $signature   = 'logs:clean {--days=90 : Number of days to keep}';
    protected $description = 'Clean old logs, notification history and expired tokens';

    public function handle(): void
    {
        $days = (int) $this->option('days');

        $this->info("🧹 Cleaning logs older than {$days} days...");

        CleanOldLogs::dispatch($days);

        $this->info('✅ Job dispatched to queue.');
    }
}
