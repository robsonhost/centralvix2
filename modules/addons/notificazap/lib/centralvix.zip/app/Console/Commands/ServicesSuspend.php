<?php

namespace App\Console\Commands;

use App\Services\BillingService;
use Illuminate\Console\Command;

class ServicesSuspend extends Command
{
    protected $signature = 'services:suspend';
    protected $description = 'Suspend services with overdue invoices';

    public function handle(BillingService $billingService): int
    {
        $this->info('Checking for overdue services to suspend...');
        $count = $billingService->suspendOverdueServices();
        $this->info("Suspended {$count} service(s).");
        return Command::SUCCESS;
    }
}
