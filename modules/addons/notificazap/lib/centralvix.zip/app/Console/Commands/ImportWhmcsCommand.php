<?php

namespace App\Console\Commands;

use App\Services\Import\WhmcsImportService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class ImportWhmcsCommand extends Command
{
    protected $signature = 'whmcs:import
                            {--company=1 : ID da company/tenant no CentralVix}
                            {--only= : Entidades separadas por vírgula (servers,clients,products,...)}
                            {--dry-run : Simula sem gravar}
                            {--fresh : Limpa mapas de importação desta company antes}';

    protected $description = 'Importa clientes, produtos, planos, servidores, serviços, faturas e demais dados do WHMCS';

    public function handle(): int
    {
        $companyId = (int) $this->option('company');
        $dryRun = (bool) $this->option('dry-run');
        $only = $this->option('only')
            ? array_map('trim', explode(',', $this->option('only')))
            : [];

        if ($this->option('fresh') && !$dryRun) {
            $deleted = DB::table('whmcs_import_maps')->where('company_id', $companyId)->delete();
            $this->warn("Mapas WHMCS removidos: {$deleted}");
        }

        $this->info('Iniciando importação WHMCS → CentralVix');
        $this->line('Company ID: ' . $companyId);
        if ($dryRun) {
            $this->warn('Modo dry-run — nenhum dado será gravado.');
        }

        try {
            $importer = new WhmcsImportService(fn (string $msg) => $this->line('  ' . $msg));
            $stats = $importer->run($companyId, $only, $dryRun);
        } catch (\Throwable $e) {
            $this->error('Falha: ' . $e->getMessage());
            $this->line('');
            $this->line('Certifique-se de:');
            $this->line('  1. WHMCS_DB_DATABASE no .env = banco que você tem acesso (em cPanel: mesmo DB_DATABASE)');
            $this->line('  2. Importar o SQL: php artisan whmcs:load-sql');
            $this->line('  3. Rodar: php artisan config:clear && php artisan migrate');

            return self::FAILURE;
        }

        $this->newLine();
        $this->info('Importação concluída:');
        $rows = [];
        foreach ($stats as $entity => $count) {
            $rows[] = [$entity, $count];
        }
        $this->table(['Entidade', 'Registros'], $rows);

        return self::SUCCESS;
    }
}
