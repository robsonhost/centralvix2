<?php

namespace App\Console\Commands;

use App\Models\Company;
use App\Models\Product;
use App\Models\Server;
use App\Services\DefaultNotificationTemplatesService;
use Illuminate\Console\Command;
use Modules\Hosting\CpanelModule;

class InstallNotificationTemplatesCommand extends Command
{
    protected $signature = 'notifications:install-templates
                            {--company= : ID da empresa (opcional; padrão: todas)}';

    protected $description = 'Instala templates de e-mail e WhatsApp para serviço ativado/reativado';

    public function handle(DefaultNotificationTemplatesService $templates): int
    {
        $companyId = $this->option('company');

        if ($companyId) {
            if (!Company::find($companyId)) {
                $this->error("Empresa #{$companyId} não encontrada.");
                return self::FAILURE;
            }
            $result = $templates->installForCompany((int) $companyId);
            $this->info("Empresa #{$companyId}: {$result['email']} e-mail(s), {$result['whatsapp']} WhatsApp.");
            return self::SUCCESS;
        }

        $totals = $templates->installForAllCompanies();
        $this->info("Templates instalados em {$totals['companies']} empresa(s).");
        $this->line("  E-mail: {$totals['email']} | WhatsApp: {$totals['whatsapp']}");

        return self::SUCCESS;
    }
}
