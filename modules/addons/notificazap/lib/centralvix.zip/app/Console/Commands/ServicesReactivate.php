<?php

namespace App\Console\Commands;

use App\Jobs\ReactivateServices;
use Illuminate\Console\Command;

class ServicesReactivate extends Command
{
    protected $signature = 'services:reactivate';
    protected $description = 'Reactivate suspended services where invoices have been paid';

    public function handle(): int
    {
        $this->info('Reactivating eligible suspended services...');
        ReactivateServices::dispatch();
        $this->info('Reactivation job dispatched.');
        return Command::SUCCESS;
    }
}
