<?php

namespace App\Console\Commands;

use App\Jobs\SuspendOverdueServices;
use App\Jobs\UnsuspendPaidServices;
use Illuminate\Console\Command;

class AutomateSuspensions extends Command
{
    /**
     * The name and signature of the console command.
     */
    protected $signature = 'centralvix:automate-suspensions';

    /**
     * The console command description.
     */
    protected $description = 'Automatically suspend overdue services and unsuspend paid services';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Starting automatic suspension/unsuspension process...');

        // Dispatch suspend job
        $this->info('Dispatching suspend overdue services job...');
        SuspendOverdueServices::dispatch();

        // Dispatch unsuspend job
        $this->info('Dispatching unsuspend paid services job...');
        UnsuspendPaidServices::dispatch();

        $this->info('Jobs dispatched successfully!');
        $this->info('Services will be processed in the background.');

        return Command::SUCCESS;
    }
}
