<?php

namespace App\Console\Commands;

use App\Services\BillingService;
use App\Services\InvoiceService;
use Illuminate\Console\Command;

class InvoicesGenerate extends Command
{
    protected $signature = 'invoices:generate';
    protected $description = 'Generate recurring invoices for services due soon';

    public function handle(BillingService $billingService, InvoiceService $invoiceService): int
    {
        $this->info('Generating recurring invoices...');
        $count = $billingService->generateRecurringInvoices();
        $overdue = $invoiceService->markOverdueInvoices();
        $this->info("Generated: {$count} invoices. Marked overdue: {$overdue}.");
        return Command::SUCCESS;
    }
}
