<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Process;

class LoadWhmcsSqlCommand extends Command
{
    protected $signature = 'whmcs:load-sql
                            {file? : Caminho do .sql (padrão: database/centralrobsonhos_whmcs.sql)}
                            {--database= : Nome do banco (padrão: WHMCS_DB_DATABASE)}
                            {--create-db : Tenta CREATE DATABASE (requer privilégio; raramente funciona em cPanel)}';

    protected $description = 'Importa o dump SQL do WHMCS para o banco configurado em WHMCS_DB_*';

    public function handle(): int
    {
        $file = $this->argument('file') ?: config('whmcs_import.default_sql_path');
        $database = $this->option('database') ?: config('database.connections.whmcs.database');
        $mainDatabase = config('database.connections.mysql.database');

        if (!is_file($file)) {
            $this->error("Arquivo não encontrado: {$file}");
            $this->line('Coloque o dump em database/centralrobsonhos_whmcs.sql ou informe o caminho.');

            return self::FAILURE;
        }

        $host = config('database.connections.whmcs.host');
        $port = config('database.connections.whmcs.port', 3306);
        $user = config('database.connections.whmcs.username');
        $pass = config('database.connections.whmcs.password');

        $this->info("Banco destino: {$database}");
        $this->info("Arquivo: {$file}");

        if ($database === $mainDatabase) {
            $this->line('Modo cPanel: importando no banco principal (tabelas WHMCS tbl* convivem com as do CentralVix).');
        }

        if ($database !== $mainDatabase) {
            $this->warn('Em hospedagem compartilhada, use WHMCS_DB_DATABASE=' . $mainDatabase . ' no .env');
        }

        $this->warn('Isso pode demorar alguns minutos (arquivo grande)…');

        if ($this->option('create-db')) {
            try {
                DB::statement("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $this->info("Banco `{$database}` verificado/criado.");
            } catch (\Throwable $e) {
                $this->warn('Não foi possível criar o banco (normal em cPanel): ' . $e->getMessage());
            }
        }

        if (!$this->databaseExists($database, $host, $port, $user, $pass)) {
            $this->error("Banco `{$database}` inacessível para o usuário `{$user}`.");
            $this->newLine();
            $this->line('Em cPanel, crie o banco no painel ou use o banco principal no .env:');
            $this->line('  WHMCS_DB_DATABASE=' . $mainDatabase);
            $this->line('  WHMCS_DB_USERNAME=' . config('database.connections.mysql.username'));
            $this->line('  WHMCS_DB_PASSWORD=<mesma senha do DB_PASSWORD>');

            return self::FAILURE;
        }

        $preparedFile = $this->prepareSqlFile($file, $database);

        $passArg = $pass !== '' && $pass !== null ? '-p' . escapeshellarg($pass) : '';
        $importFile = escapeshellarg($preparedFile);

        if (PHP_OS_FAMILY === 'Windows') {
            $cmd = sprintf(
                'mysql -h %s -P %s -u %s %s %s -e "source %s"',
                escapeshellarg($host),
                escapeshellarg((string) $port),
                escapeshellarg($user),
                $passArg,
                escapeshellarg($database),
                str_replace('\\', '/', $preparedFile)
            );
        } else {
            $cmd = sprintf(
                'mysql -h %s -P %s -u %s %s %s < %s',
                escapeshellarg($host),
                escapeshellarg((string) $port),
                escapeshellarg($user),
                $passArg,
                escapeshellarg($database),
                $importFile
            );
        }

        $this->line('Executando importação MySQL…');

        $result = Process::timeout(3600)->run($cmd);

        if (is_file($preparedFile) && $preparedFile !== $file) {
            @unlink($preparedFile);
        }

        if (!$result->successful()) {
            $this->error('Falha ao importar SQL.');
            $this->line($result->errorOutput());
            $this->newLine();
            $this->line('Alternativas:');
            $this->line('  • phpMyAdmin → banco ' . $database . ' → Importar → escolher o .sql');
            $this->line("  • mysql -u {$user} -p {$database} < {$file}");

            return self::FAILURE;
        }

        $this->info('SQL importado com sucesso!');
        $this->line('Próximo passo: php artisan config:clear && php artisan whmcs:import --company=1');

        return self::SUCCESS;
    }

    private function databaseExists(string $database, string $host, int|string $port, string $user, ?string $pass): bool
    {
        try {
            config(['database.connections.whmcs_check' => array_merge(
                config('database.connections.whmcs'),
                ['database' => $database]
            )]);
            DB::connection('whmcs_check')->getPdo();

            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Remove CREATE DATABASE / USE de dumps exportados de outro host
     * para permitir importação no banco principal do cPanel.
     */
    private function prepareSqlFile(string $file, string $targetDatabase): string
    {
        $handle = fopen($file, 'rb');
        if (!$handle) {
            return $file;
        }

        $tmp = tempnam(sys_get_temp_dir(), 'whmcs_import_');
        $out = fopen($tmp, 'wb');
        $changed = false;

        while (($line = fgets($handle)) !== false) {
            $trimmed = ltrim($line);

            if (preg_match('/^CREATE\s+DATABASE\b/i', $trimmed)) {
                $changed = true;
                continue;
            }

            if (preg_match('/^USE\s+[`\'"]?[\w-]+[`\'"]?\s*;/i', $trimmed)) {
                $changed = true;
                fwrite($out, 'USE `' . $targetDatabase . "`;\n");
                continue;
            }

            fwrite($out, $line);
        }

        fclose($handle);
        fclose($out);

        return $changed ? $tmp : $file;
    }
}
