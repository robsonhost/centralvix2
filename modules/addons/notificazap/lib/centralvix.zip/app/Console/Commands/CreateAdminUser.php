<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class CreateAdminUser extends Command
{
    /**
     * The name and signature of the console command.
     */
    protected $signature = 'admin:create 
                            {--email= : Email do administrador}
                            {--password= : Senha do administrador}
                            {--name= : Nome do administrador}';

    /**
     * The console command description.
     */
    protected $description = 'Criar um novo usuário administrador';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('🔐 Criando Usuário Administrador');
        $this->line('');

        // Obter dados
        $name = $this->option('name') ?: $this->ask('Nome', 'Administrador');
        $email = $this->option('email') ?: $this->ask('Email', 'admin@centralvix.com');
        $password = $this->option('password') ?: $this->secret('Senha (mínimo 8 caracteres)');

        // Validar
        $validator = Validator::make([
            'name' => $name,
            'email' => $email,
            'password' => $password,
        ], [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8',
        ]);

        if ($validator->fails()) {
            $this->error('❌ Erro de validação:');
            foreach ($validator->errors()->all() as $error) {
                $this->line('   • ' . $error);
            }
            return self::FAILURE;
        }

        // Criar usuário
        try {
            $user = User::create([
                'name' => $name,
                'email' => $email,
                'password' => Hash::make($password),
                'role' => 'admin',
                'is_active' => true,
                'email_verified_at' => now(),
            ]);

            $this->line('');
            $this->info('✓ Usuário administrador criado com sucesso!');
            $this->line('');
            $this->line('╔════════════════════════════════════════╗');
            $this->line('║  CREDENCIAIS DO ADMINISTRADOR         ║');
            $this->line('╠════════════════════════════════════════╣');
            $this->line('║  Nome:  ' . str_pad($name, 32) . ' ║');
            $this->line('║  Email: ' . str_pad($email, 32) . ' ║');
            $this->line('║  Senha: ' . str_pad(str_repeat('*', strlen($password)), 32) . ' ║');
            $this->line('╚════════════════════════════════════════╝');
            $this->line('');
            $this->line('🌐 Acesse: ' . config('app.url') . '/admin');
            $this->line('');

            return self::SUCCESS;
        } catch (\Exception $e) {
            $this->error('❌ Erro ao criar usuário: ' . $e->getMessage());
            return self::FAILURE;
        }
    }
}
