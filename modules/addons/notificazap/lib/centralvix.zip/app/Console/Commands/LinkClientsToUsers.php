<?php

namespace App\Console\Commands;

use App\Models\Client;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class LinkClientsToUsers extends Command
{
    protected $signature = 'clients:link-users {--force : Forçar criação mesmo se já vinculado}';
    protected $description = 'Vincula todos os clientes sem usuário a contas de usuário';

    public function handle()
    {
        $this->info('🔗 Vinculando clientes a usuários...');
        
        // Buscar clientes sem user_id ou com force
        $query = Client::query();
        
        if (!$this->option('force')) {
            $query->whereNull('user_id');
        }
        
        $clients = $query->get();
        
        if ($clients->isEmpty()) {
            $this->info('✅ Todos os clientes já possuem usuário vinculado!');
            return 0;
        }
        
        $this->info("📊 Encontrados {$clients->count()} clientes sem usuário");
        
        $bar = $this->output->createProgressBar($clients->count());
        $bar->start();
        
        $created = 0;
        $errors = 0;
        
        foreach ($clients as $client) {
            try {
                // Verificar se já existe um usuário com este email
                $existingUser = User::where('email', $client->email)->first();
                
                if ($existingUser) {
                    // Vincular ao usuário existente
                    $client->user_id = $existingUser->id;
                    $client->save();
                    $this->newLine();
                    $this->info("✓ Cliente {$client->email} vinculado ao usuário existente");
                } else {
                    // Criar novo usuário
                    $user = User::create([
                        'uuid' => Str::uuid(),
                        'company_id' => $client->company_id ?? 1,
                        'name' => trim($client->firstname . ' ' . $client->lastname),
                        'email' => $client->email,
                        'email_verified_at' => now(),
                        'password' => Hash::make(Str::random(16)),
                        'phone' => $client->phone ?? $client->mobile ?? $client->whatsapp,
                        'whatsapp' => $client->whatsapp ?? $client->phone ?? $client->mobile,
                        'cpf_cnpj' => $client->cpf ?? $client->cnpj,
                        'status' => $client->status ?? 'active',
                    ]);
                    
                    // Vincular ao cliente
                    $client->user_id = $user->id;
                    $client->save();
                    
                    $created++;
                }
                
            } catch (\Exception $e) {
                $errors++;
                $this->newLine();
                $this->error("✗ Erro ao processar {$client->email}: " . $e->getMessage());
            }
            
            $bar->advance();
        }
        
        $bar->finish();
        $this->newLine(2);
        
        $this->info("✅ Processo concluído!");
        $this->info("   Usuários criados: {$created}");
        $this->info("   Erros: {$errors}");
        
        return 0;
    }
}
