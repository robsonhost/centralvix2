<?php

namespace App\Console\Commands;

use App\Models\EmailTemplate;
use App\Models\Product;
use App\Models\Server;
use App\Models\WhatsappTemplate;
use Illuminate\Console\Command;
use Modules\Hosting\CpanelModule;

class HostingFlowCheckCommand extends Command
{
    protected $signature = 'hosting:check-flow
                            {--server= : ID numérico do servidor WHM}
                            {--product= : ID numérico do produto de hospedagem}
                            {--company=1 : ID da empresa}
                            {--list : Lista servidores e produtos disponíveis}';

    protected $description = 'Verifica pré-requisitos do fluxo WHMCS (WHM, produto, templates, fila)';

    public function handle(): int
    {
        $companyId = (int) $this->option('company');
        $ok = true;

        $this->info('=== Checklist fluxo hospedagem (estilo WHMCS) ===');
        $this->newLine();

        if ($this->option('list') || !$this->option('server') || !$this->option('product')) {
            $this->printAvailableResources($companyId);
            $this->newLine();
        }

        $serverId = $this->parseNumericId($this->option('server'));
        $productId = $this->parseNumericId($this->option('product'));

        if ($this->option('server') && $serverId === null) {
            $this->error('✗ --server deve ser um ID numérico (ex: --server=1). Não use texto como ID_DO_SERVIDOR.');
            $ok = false;
        }

        if ($this->option('product') && $productId === null) {
            $this->error('✗ --product deve ser um ID numérico (ex: --product=5). Não use texto como ID_DO_PRODUTO.');
            $ok = false;
        }

        if ($serverId) {
            $server = Server::where('company_id', $companyId)->find($serverId);
            if (!$server) {
                $this->error("✗ Servidor #{$serverId} não encontrado na empresa #{$companyId}.");
                $ok = false;
            } else {
                $module = new CpanelModule($server);
                $test = $module->testConnection();
                if ($test['success'] ?? false) {
                    $this->line("✓ WHM conectado: {$server->hostname} (v{$test['version']})");
                    $packages = $module->listPackages();
                    $accounts = $module->listAccounts();
                    $this->line('  Pacotes: ' . count($packages) . ' | Contas: ' . count($accounts));
                } else {
                    $this->error('✗ WHM falhou: ' . ($test['message'] ?? 'erro desconhecido'));
                    if (!empty($test['details'])) {
                        $this->line('  ' . json_encode($test['details'], JSON_UNESCAPED_UNICODE));
                    }
                    $ok = false;
                }
            }
        } elseif (!$this->option('server')) {
            $this->warn('○ Informe --server=ID (veja tabela acima)');
            $ok = false;
        }

        if ($productId) {
            $product = Product::where('company_id', $companyId)->find($productId);
            if (!$product) {
                $this->error("✗ Produto #{$productId} não encontrado na empresa #{$companyId}.");
                $ok = false;
            } else {
                $cfg = (array) ($product->module_config ?? []);
                $serverOk = !empty($cfg['server_id']);
                $planOk = !empty($cfg['plan']);
                $moduleOk = $product->module === 'CpanelModule';

                $this->line(($serverOk ? '✓' : '✗') . ' Produto server_id: ' . ($cfg['server_id'] ?? 'NÃO CONFIGURADO'));
                $this->line(($planOk ? '✓' : '✗') . ' Produto plan WHM: ' . ($cfg['plan'] ?? 'NÃO CONFIGURADO'));
                $this->line(($moduleOk ? '✓' : '✗') . ' Módulo: ' . ($product->module ?? '—') . ' | Tipo: ' . $product->type);

                if (!$serverOk || !$planOk || !$moduleOk) {
                    $ok = false;
                }
            }
        } elseif (!$this->option('product')) {
            $this->warn('○ Informe --product=ID (veja tabela acima)');
            $ok = false;
        }

        $emailTpl = EmailTemplate::where('company_id', $companyId)->where('slug', 'service_activated')->where('status', 'active')->exists();
        $waTpl = WhatsappTemplate::where('company_id', $companyId)->where('slug', 'service_activated')->where('is_active', true)->exists();

        $this->newLine();
        $this->line(($emailTpl ? '✓' : '✗') . ' Template e-mail service_activated');
        $this->line(($waTpl ? '✓' : '○') . ' Template WhatsApp service_activated');
        if (!$emailTpl) {
            $this->warn('  Rode: php artisan notifications:install-templates --company=' . $companyId);
            $ok = false;
        }

        $queueDriver = config('queue.default');
        $this->line('  Queue driver: ' . $queueDriver);
        if ($queueDriver !== 'sync') {
            $this->warn('  Certifique-se de rodar: php artisan queue:work');
        }

        $this->line('  CPANEL_VERIFY_SSL: ' . (env('CPANEL_VERIFY_SSL', false) ? 'true' : 'false'));

        $this->newLine();
        if ($serverId && $productId) {
            $this->line('Comando pronto para copiar:');
            $this->info("php artisan hosting:check-flow --company={$companyId} --server={$serverId} --product={$productId}");
            $this->newLine();
        }

        if ($ok) {
            $this->info('✅ Pronto para teste ponta a ponta!');
            $this->line('Fluxo: pedido → pagamento → provisionamento → e-mail/WhatsApp → login cPanel na área cliente.');
        } else {
            $this->error('⚠ Corrija os itens acima antes do teste E2E.');
        }

        return $ok ? self::SUCCESS : self::FAILURE;
    }

    private function printAvailableResources(int $companyId): void
    {
        $servers = Server::where('company_id', $companyId)->orderBy('id')->get(['id', 'name', 'hostname', 'module', 'status']);

        $this->comment('Servidores disponíveis (use --server=ID):');
        if ($servers->isEmpty()) {
            $this->warn('  Nenhum servidor cadastrado.');
        } else {
            $this->table(
                ['ID', 'Nome', 'Hostname', 'Módulo', 'Status'],
                $servers->map(fn ($s) => [$s->id, $s->name, $s->hostname, $s->module ?? '—', $s->status])->all()
            );
        }

        $products = Product::where('company_id', $companyId)
            ->whereIn('type', ['hosting', 'reseller', 'streaming_audio', 'streaming_video'])
            ->orderBy('id')
            ->get(['id', 'name', 'type', 'module', 'module_config', 'status']);

        $this->comment('Produtos de hospedagem/streaming (use --product=ID):');
        if ($products->isEmpty()) {
            $this->warn('  Nenhum produto hosting/reseller cadastrado.');
        } else {
            $this->table(
                ['ID', 'Nome', 'Tipo', 'Módulo', 'server_id', 'plan WHM', 'Status'],
                $products->map(function ($p) {
                    $cfg = (array) ($p->module_config ?? []);

                    return [
                        $p->id,
                        $p->name,
                        $p->type,
                        $p->module ?? '—',
                        $cfg['server_id'] ?? '—',
                        $cfg['plan'] ?? '—',
                        $p->status,
                    ];
                })->all()
            );
        }
    }

    private function parseNumericId(mixed $value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_numeric($value)) {
            return (int) $value;
        }

        return null;
    }
}
