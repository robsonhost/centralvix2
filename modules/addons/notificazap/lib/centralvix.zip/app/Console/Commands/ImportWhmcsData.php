<?php

namespace App\Console\Commands;

use App\Models\Client;
use App\Models\ClientGroup;
use App\Models\Product;
use App\Models\Server;
use App\Models\Service;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class ImportWhmcsData extends Command
{
    protected $signature = 'whmcs:import 
                            {--clients : Importar apenas clientes}
                            {--products : Importar apenas produtos}
                            {--servers : Importar apenas servidores}
                            {--services : Importar apenas serviços}
                            {--all : Importar tudo}';

    protected $description = 'Importa dados do banco WHMCS para o CentralVix';

    private $whmcsDb;
    private $companyId;
    private $stats = [
        'clients' => ['imported' => 0, 'skipped' => 0, 'errors' => 0],
        'products' => ['imported' => 0, 'skipped' => 0, 'errors' => 0],
        'servers' => ['imported' => 0, 'skipped' => 0, 'errors' => 0],
        'services' => ['imported' => 0, 'skipped' => 0, 'errors' => 0],
    ];

    public function handle()
    {
        $this->info('🚀 Iniciando importação do WHMCS...');
        
        // Conectar ao banco WHMCS
        $this->connectWhmcsDatabase();
        
        // Obter company_id do usuário logado (ou padrão)
        $this->companyId = 1; // Ajustar conforme necessário
        
        $importAll = $this->option('all');
        
        try {
            if ($importAll || $this->option('clients')) {
                $this->importClients();
            }
            
            if ($importAll || $this->option('products')) {
                $this->importProducts();
            }
            
            if ($importAll || $this->option('servers')) {
                $this->importServers();
            }
            
            if ($importAll || $this->option('services')) {
                $this->importServices();
            }
            
            $this->displayStats();
            $this->info('✅ Importação concluída!');
            
        } catch (\Exception $e) {
            $this->error('❌ Erro na importação: ' . $e->getMessage());
            $this->error($e->getTraceAsString());
            return 1;
        }
        
        return 0;
    }

    private function connectWhmcsDatabase()
    {
        $this->info('📡 Conectando ao banco WHMCS...');
        
        $this->whmcsDb = DB::connection('mysql')->setDatabaseName(
            config('database.connections.mysql.whmcs_database', env('WHMCS_DB_DATABASE'))
        );
        
        config([
            'database.connections.whmcs' => [
                'driver' => 'mysql',
                'host' => env('WHMCS_DB_HOST', '127.0.0.1'),
                'port' => env('WHMCS_DB_PORT', 3306),
                'database' => env('WHMCS_DB_DATABASE'),
                'username' => env('WHMCS_DB_USERNAME'),
                'password' => env('WHMCS_DB_PASSWORD'),
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'prefix' => 'tbl',
                'strict' => false,
            ]
        ]);
        
        $this->whmcsDb = DB::connection('whmcs');
        $this->info('✓ Conectado ao banco WHMCS');
    }

    private function importClients()
    {
        $this->info('👥 Importando clientes...');
        $bar = $this->output->createProgressBar();
        
        try {
            $whmcsClients = $this->whmcsDb->table('clients')->get();
            $bar->start($whmcsClients->count());
            
            foreach ($whmcsClients as $whmcsClient) {
                $bar->advance();
                
                try {
                    // Verificar se cliente já existe pelo email
                    $existingClient = Client::where('email', $whmcsClient->email)->first();
                    
                    if ($existingClient) {
                        $this->stats['clients']['skipped']++;
                        continue;
                    }
                    
                    // Mapear status do WHMCS para CentralVix
                    $status = $this->mapClientStatus($whmcsClient->status);
                    
                    // Montar endereço completo (address1 + address2)
                    $fullAddress = trim(($whmcsClient->address1 ?? '') . ' ' . ($whmcsClient->address2 ?? ''));
                    
                    // Criar User primeiro (para login)
                    $user = \App\Models\User::create([
                        'uuid' => Str::uuid(),
                        'company_id' => $this->companyId,
                        'name' => trim($whmcsClient->firstname . ' ' . $whmcsClient->lastname),
                        'email' => $whmcsClient->email,
                        'email_verified_at' => now(),
                        'password' => Hash::make(Str::random(16)), // Senha aleatória
                        'phone' => $whmcsClient->phonenumber ?? null,
                        'whatsapp' => $whmcsClient->phonenumber ?? null,
                        'cpf_cnpj' => $whmcsClient->tax_id ?? null,
                        'status' => $status,
                    ]);
                    
                    // Criar cliente vinculado ao user
                    $client = Client::create([
                        'uuid' => Str::uuid(),
                        'company_id' => $this->companyId,
                        'user_id' => $user->id, // VINCULAR AO USER
                        'client_code' => 'CLI-' . str_pad($whmcsClient->id, 5, '0', STR_PAD_LEFT),
                        'type' => !empty($whmcsClient->companyname) ? 'company' : 'individual',
                        'firstname' => $whmcsClient->firstname,
                        'lastname' => $whmcsClient->lastname,
                        'email' => $whmcsClient->email,
                        'email_verified_at' => now(),
                        'phone' => $whmcsClient->phonenumber ?? null,
                        'mobile' => $whmcsClient->phonenumber ?? null,
                        'whatsapp' => $whmcsClient->phonenumber ?? null,
                        'cpf' => $this->extractCpf($whmcsClient->tax_id ?? ''),
                        'cnpj' => $this->extractCnpj($whmcsClient->tax_id ?? ''),
                        'company_name' => $whmcsClient->companyname ?? null,
                        'date_of_birth' => null,
                        'address' => !empty($fullAddress) ? $fullAddress : null,
                        'address_number' => null,
                        'address_complement' => null,
                        'neighborhood' => null,
                        'city' => $whmcsClient->city ?? null,
                        'state' => $whmcsClient->state ?? null,
                        'country' => $whmcsClient->country ?? 'BR',
                        'zip' => $whmcsClient->postcode ?? null,
                        'notes' => $whmcsClient->notes ?? null,
                        'status' => $status,
                        'credit_balance' => $whmcsClient->credit ?? 0,
                        'currency' => $whmcsClient->currency ?? 'BRL',
                        'language' => $this->mapLanguage($whmcsClient->language ?? 'portuguese-br'),
                    ]);
                    
                    $this->stats['clients']['imported']++;
                    
                } catch (\Exception $e) {
                    $this->stats['clients']['errors']++;
                    $this->warn("Erro ao importar cliente {$whmcsClient->email}: " . $e->getMessage());
                }
            }
            
            $bar->finish();
            $this->newLine();
            
        } catch (\Exception $e) {
            $this->error('Erro ao importar clientes: ' . $e->getMessage());
        }
    }

    private function importProducts()
    {
        $this->info('📦 Importando produtos/planos...');
        $bar = $this->output->createProgressBar();
        
        try {
            $whmcsProducts = $this->whmcsDb->table('products')->get();
            $bar->start($whmcsProducts->count());
            
            foreach ($whmcsProducts as $whmcsProduct) {
                $bar->advance();
                
                try {
                    // Verificar se produto já existe
                    $existingProduct = Product::where('name', $whmcsProduct->name)->first();
                    
                    if ($existingProduct) {
                        $this->stats['products']['skipped']++;
                        continue;
                    }
                    
                    // Mapear tipo de produto
                    $type = $this->mapProductType($whmcsProduct->type);
                    
                    Product::create([
                        'uuid' => Str::uuid(),
                        'company_id' => $this->companyId,
                        'name' => $whmcsProduct->name,
                        'slug' => Str::slug($whmcsProduct->name),
                        'description' => $whmcsProduct->description ?? '',
                        'type' => $type,
                        'category' => $this->mapProductGroup($whmcsProduct->gid ?? 0),
                        'price_monthly' => $whmcsProduct->pricing ?? 0,
                        'price_quarterly' => 0,
                        'price_semiannually' => 0,
                        'price_annually' => 0,
                        'setup_fee' => $whmcsProduct->setupfee ?? 0,
                        'billing_cycle' => 'monthly',
                        'payment_type' => $whmcsProduct->paytype ?? 'recurring',
                        'status' => $whmcsProduct->hidden == 0 ? 'active' : 'inactive',
                        'stock_control' => $whmcsProduct->stockcontrol == 1,
                        'stock_quantity' => $whmcsProduct->qty ?? null,
                        'order' => $whmcsProduct->order ?? 0,
                        'welcome_email' => $whmcsProduct->welcomeemail ?? null,
                        'module' => $whmcsProduct->servertype ?? null,
                    ]);
                    
                    $this->stats['products']['imported']++;
                    
                } catch (\Exception $e) {
                    $this->stats['products']['errors']++;
                    $this->warn("Erro ao importar produto {$whmcsProduct->name}: " . $e->getMessage());
                }
            }
            
            $bar->finish();
            $this->newLine();
            
        } catch (\Exception $e) {
            $this->error('Erro ao importar produtos: ' . $e->getMessage());
        }
    }

    private function importServers()
    {
        $this->info('🖥️  Importando servidores...');
        $bar = $this->output->createProgressBar();
        
        try {
            $whmcsServers = $this->whmcsDb->table('servers')->get();
            $bar->start($whmcsServers->count());
            
            foreach ($whmcsServers as $whmcsServer) {
                $bar->advance();
                
                try {
                    // Verificar se servidor já existe
                    $existingServer = Server::where('hostname', $whmcsServer->hostname)->first();
                    
                    if ($existingServer) {
                        $this->stats['servers']['skipped']++;
                        continue;
                    }
                    
                    Server::create([
                        'uuid' => Str::uuid(),
                        'company_id' => $this->companyId,
                        'name' => $whmcsServer->name,
                        'hostname' => $whmcsServer->hostname,
                        'ip_address' => $whmcsServer->ipaddress ?? null,
                        'type' => $whmcsServer->type ?? 'cpanel',
                        'username' => $whmcsServer->username ?? null,
                        'password' => $whmcsServer->password ?? null,
                        'access_hash' => $whmcsServer->accesshash ?? null,
                        'port' => $whmcsServer->port ?? 2087,
                        'secure' => $whmcsServer->secure == 'on',
                        'status' => $whmcsServer->disabled == 0 ? 'active' : 'inactive',
                        'max_accounts' => $whmcsServer->maxaccounts ?? 0,
                        'name_servers' => json_encode([
                            $whmcsServer->nameserver1 ?? null,
                            $whmcsServer->nameserver2 ?? null,
                            $whmcsServer->nameserver3 ?? null,
                            $whmcsServer->nameserver4 ?? null,
                        ]),
                        'monthly_cost' => $whmcsServer->monthlycost ?? 0,
                    ]);
                    
                    $this->stats['servers']['imported']++;
                    
                } catch (\Exception $e) {
                    $this->stats['servers']['errors']++;
                    $this->warn("Erro ao importar servidor {$whmcsServer->name}: " . $e->getMessage());
                }
            }
            
            $bar->finish();
            $this->newLine();
            
        } catch (\Exception $e) {
            $this->error('Erro ao importar servidores: ' . $e->getMessage());
        }
    }

    private function importServices()
    {
        $this->info('⚙️  Importando serviços/hospedagens...');
        $bar = $this->output->createProgressBar();
        
        try {
            $whmcsHosting = $this->whmcsDb->table('hosting')->get();
            $bar->start($whmcsHosting->count());
            
            foreach ($whmcsHosting as $whmcsService) {
                $bar->advance();
                
                try {
                    // Buscar cliente correspondente
                    $whmcsClient = $this->whmcsDb->table('clients')
                        ->where('id', $whmcsService->userid)
                        ->first();
                    
                    if (!$whmcsClient) {
                        $this->stats['services']['skipped']++;
                        continue;
                    }
                    
                    $client = Client::where('email', $whmcsClient->email)->first();
                    
                    if (!$client) {
                        $this->stats['services']['skipped']++;
                        continue;
                    }
                    
                    // Buscar produto correspondente
                    $whmcsProduct = $this->whmcsDb->table('products')
                        ->where('id', $whmcsService->packageid)
                        ->first();
                    
                    $product = null;
                    if ($whmcsProduct) {
                        $product = Product::where('name', $whmcsProduct->name)->first();
                    }
                    
                    // Criar serviço
                    Service::create([
                        'uuid' => Str::uuid(),
                        'company_id' => $this->companyId,
                        'client_id' => $client->id,
                        'product_id' => $product->id ?? null,
                        'server_id' => $whmcsService->server ?? null,
                        'domain' => $whmcsService->domain ?? null,
                        'username' => $whmcsService->username ?? null,
                        'password' => $whmcsService->password ?? null,
                        'status' => $this->mapServiceStatus($whmcsService->domainstatus),
                        'billing_cycle' => $this->mapBillingCycle($whmcsService->billingcycle),
                        'amount' => $whmcsService->amount ?? 0,
                        'registration_date' => $whmcsService->regdate ?? now(),
                        'next_due_date' => $whmcsService->nextduedate ?? null,
                        'termination_date' => $whmcsService->termination_date ?? null,
                        'suspended_reason' => $whmcsService->suspendreason ?? null,
                        'notes' => $whmcsService->notes ?? null,
                    ]);
                    
                    $this->stats['services']['imported']++;
                    
                } catch (\Exception $e) {
                    $this->stats['services']['errors']++;
                    $this->warn("Erro ao importar serviço: " . $e->getMessage());
                }
            }
            
            $bar->finish();
            $this->newLine();
            
        } catch (\Exception $e) {
            $this->error('Erro ao importar serviços: ' . $e->getMessage());
        }
    }

    private function displayStats()
    {
        $this->newLine();
        $this->info('📊 Estatísticas da Importação:');
        $this->table(
            ['Tipo', 'Importados', 'Ignorados', 'Erros'],
            [
                ['Clientes', $this->stats['clients']['imported'], $this->stats['clients']['skipped'], $this->stats['clients']['errors']],
                ['Produtos', $this->stats['products']['imported'], $this->stats['products']['skipped'], $this->stats['products']['errors']],
                ['Servidores', $this->stats['servers']['imported'], $this->stats['servers']['skipped'], $this->stats['servers']['errors']],
                ['Serviços', $this->stats['services']['imported'], $this->stats['services']['skipped'], $this->stats['services']['errors']],
            ]
        );
    }

    // Helper methods
    
    private function mapClientStatus($status): string
    {
        $statusMap = [
            'Active' => 'active',
            'Inactive' => 'inactive',
            'Closed' => 'closed',
        ];
        
        return $statusMap[$status] ?? 'inactive';
    }

    private function mapLanguage($language): string
    {
        if (str_contains(strtolower($language), 'portuguese') || str_contains(strtolower($language), 'brasil')) {
            return 'pt_BR';
        }
        return 'en';
    }

    private function extractCpf($taxId): ?string
    {
        if (strlen($taxId) == 11 || strlen($taxId) == 14) {
            if (strlen($taxId) == 11) {
                return $taxId;
            }
        }
        return null;
    }

    private function extractCnpj($taxId): ?string
    {
        if (strlen($taxId) == 14 || strlen($taxId) == 18) {
            return $taxId;
        }
        return null;
    }

    private function mapProductType($type): string
    {
        $typeMap = [
            'hostingaccount' => 'hosting',
            'reselleraccount' => 'reseller',
            'server' => 'vps',
            'other' => 'other',
        ];
        
        return $typeMap[$type] ?? 'hosting';
    }

    private function mapProductGroup($gid): string
    {
        // Buscar grupo de produto no WHMCS se necessário
        return 'hosting';
    }

    private function mapServiceStatus($status): string
    {
        $statusMap = [
            'Active' => 'active',
            'Pending' => 'pending',
            'Suspended' => 'suspended',
            'Terminated' => 'terminated',
            'Cancelled' => 'cancelled',
            'Fraud' => 'fraud',
        ];
        
        return $statusMap[$status] ?? 'pending';
    }

    private function mapBillingCycle($cycle): string
    {
        $cycleMap = [
            'Monthly' => 'monthly',
            'Quarterly' => 'quarterly',
            'Semi-Annually' => 'semiannually',
            'Annually' => 'annually',
            'Biennially' => 'biennially',
            'Triennially' => 'triennially',
            'One Time' => 'onetime',
            'Free Account' => 'free',
        ];
        
        return $cycleMap[$cycle] ?? 'monthly';
    }
}
