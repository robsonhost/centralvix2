<?php

namespace App\Modules\Provisioning;

use App\Models\Service;
use App\Services\Provisioning\OvhCloudService;
use Illuminate\Support\Facades\Log;

class OvhModule
{
    private OvhCloudService $ovh;

    public function __construct()
    {
        $this->ovh = new OvhCloudService();
    }

    /**
     * Criar/Provisionar VPS
     */
    public function createService(Service $service): array
    {
        try {
            Log::info('OVH: Iniciando provisionamento de VPS', [
                'service_id' => $service->id,
            ]);

            // Para VPS OVH, o serviço já existe (não criamos sob demanda)
            // Apenas configuramos e reinstalamos com as configurações do cliente
            
            $serviceName = $service->server_data['ovh_service_name'] ?? null;
            
            if (!$serviceName) {
                return [
                    'success' => false,
                    'message' => 'Service Name do OVH não configurado',
                ];
            }

            // Obter detalhes do VPS
            $vpsInfo = $this->ovh->getVps($serviceName);
            
            if (!$vpsInfo['success']) {
                return $vpsInfo;
            }

            // Obter template padrão ou especificado
            $templateId = $service->config_options['template_id'] ?? 'debian11_64';
            
            // Reinstalar com o template escolhido
            $reinstall = $this->ovh->reinstallVps($serviceName, [
                'template_id' => $templateId,
                'language' => 'pt',
                'ssh_key' => $service->client->ssh_key ?? null,
            ]);

            if ($reinstall['success']) {
                // Atualizar dados do serviço
                $service->update([
                    'status' => 'active',
                    'server_data' => array_merge($service->server_data ?? [], [
                        'ovh_service_name' => $serviceName,
                        'template_id' => $templateId,
                        'provisioned_at' => now()->toISOString(),
                        'task_id' => $reinstall['task_id'] ?? null,
                    ]),
                ]);

                Log::info('OVH: VPS provisionado com sucesso', [
                    'service_id' => $service->id,
                    'service_name' => $serviceName,
                ]);

                return [
                    'success' => true,
                    'message' => 'VPS provisionado com sucesso',
                    'data' => $vpsInfo['vps'],
                ];
            }

            return $reinstall;

        } catch (\Exception $e) {
            Log::error('OVH: Erro ao provisionar VPS', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao provisionar VPS: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Suspender VPS
     */
    public function suspendService(Service $service): array
    {
        // OVH não tem suspensão via API para VPS
        // Seria necessário usar firewall ou outras medidas
        Log::info('OVH: Suspensão de VPS não suportada via API', [
            'service_id' => $service->id,
        ]);

        return [
            'success' => true,
            'message' => 'VPS marcado como suspenso (suspensão manual necessária)',
        ];
    }

    /**
     * Reativar VPS
     */
    public function unsuspendService(Service $service): array
    {
        Log::info('OVH: Reativação de VPS', [
            'service_id' => $service->id,
        ]);

        return [
            'success' => true,
            'message' => 'VPS reativado',
        ];
    }

    /**
     * Terminar/Cancelar VPS
     */
    public function terminateService(Service $service): array
    {
        Log::info('OVH: Terminação de VPS', [
            'service_id' => $service->id,
        ]);

        // Cancelamento deve ser feito manualmente no painel OVH
        return [
            'success' => true,
            'message' => 'VPS marcado para terminação (cancelamento manual necessário no painel OVH)',
        ];
    }

    /**
     * Obter informações do VPS
     */
    public function getServiceInfo(Service $service): array
    {
        $serviceName = $service->server_data['ovh_service_name'] ?? null;
        
        if (!$serviceName) {
            return [
                'success' => false,
                'message' => 'Service Name não configurado',
            ];
        }

        $vpsInfo = $this->ovh->getVps($serviceName);
        
        if ($vpsInfo['success']) {
            // Obter IPs
            $ips = $this->ovh->getIps($serviceName);
            
            // Obter monitoramento
            $monitoring = $this->ovh->getMonitoring($serviceName);

            return [
                'success' => true,
                'data' => [
                    'vps' => $vpsInfo['vps'],
                    'ips' => $ips['ips'] ?? [],
                    'monitoring' => $monitoring['monitoring'] ?? [],
                ],
            ];
        }

        return $vpsInfo;
    }

    /**
     * Reiniciar VPS
     */
    public function rebootService(Service $service): array
    {
        $serviceName = $service->server_data['ovh_service_name'] ?? null;
        
        if (!$serviceName) {
            return [
                'success' => false,
                'message' => 'Service Name não configurado',
            ];
        }

        return $this->ovh->rebootVps($serviceName);
    }

    /**
     * Reinstalar VPS
     */
    public function reinstallService(Service $service, array $options = []): array
    {
        $serviceName = $service->server_data['ovh_service_name'] ?? null;
        
        if (!$serviceName) {
            return [
                'success' => false,
                'message' => 'Service Name não configurado',
            ];
        }

        $templateId = $options['template_id'] ?? $service->config_options['template_id'] ?? 'debian11_64';

        return $this->ovh->reinstallVps($serviceName, [
            'template_id' => $templateId,
            'language' => 'pt',
            'ssh_key' => $service->client->ssh_key ?? null,
        ]);
    }

    /**
     * Criar backup/snapshot
     */
    public function createBackup(Service $service, string $description = ''): array
    {
        $serviceName = $service->server_data['ovh_service_name'] ?? null;
        
        if (!$serviceName) {
            return [
                'success' => false,
                'message' => 'Service Name não configurado',
            ];
        }

        return $this->ovh->createSnapshot($serviceName, $description);
    }

    /**
     * Restaurar backup/snapshot
     */
    public function restoreBackup(Service $service, string $snapshotId): array
    {
        $serviceName = $service->server_data['ovh_service_name'] ?? null;
        
        if (!$serviceName) {
            return [
                'success' => false,
                'message' => 'Service Name não configurado',
            ];
        }

        return $this->ovh->restoreSnapshot($serviceName, $snapshotId);
    }

    /**
     * Listar templates disponíveis
     */
    public function getAvailableTemplates(Service $service): array
    {
        $serviceName = $service->server_data['ovh_service_name'] ?? null;
        
        if (!$serviceName) {
            return [
                'success' => false,
                'message' => 'Service Name não configurado',
            ];
        }

        return $this->ovh->getTemplates($serviceName);
    }

    /**
     * Testar conexão
     */
    public function testConnection(): array
    {
        return $this->ovh->testConnection();
    }
}
