<?php

namespace App\Modules\Provisioning;

use App\Models\Service;
use App\Services\Provisioning\VirtualizorService;
use Illuminate\Support\Facades\Log;

class VirtualizorModule
{
    private VirtualizorService $virtualizor;

    public function __construct()
    {
        $this->virtualizor = new VirtualizorService();
    }

    /**
     * Criar VPS
     */
    public function createService(Service $service): array
    {
        try {
            Log::info('Virtualizor: Iniciando provisionamento', [
                'service_id' => $service->id,
            ]);

            $result = $this->virtualizor->createVps([
                'hostname' => $service->domain ?? 'vps' . $service->id . '.centralvix.com',
                'plan_id' => $service->config_options['plan_id'] ?? 1,
                'os_id' => $service->config_options['os_id'] ?? 1,
                'root_password' => $this->generatePassword(),
                'email' => $service->client->email,
                'user_id' => $service->client->id,
            ]);

            if ($result['success']) {
                $service->update([
                    'status' => 'active',
                    'server_data' => [
                        'vps_id' => $result['vps_id'],
                        'vps_name' => $result['vps_name'],
                        'ip_address' => $result['ip_address'],
                        'root_password' => $result['root_password'],
                        'provisioned_at' => now()->toISOString(),
                    ],
                ]);

                Log::info('Virtualizor: VPS provisionado', [
                    'service_id' => $service->id,
                    'vps_id' => $result['vps_id'],
                ]);

                return [
                    'success' => true,
                    'message' => 'VPS criado com sucesso',
                    'data' => $result,
                ];
            }

            return $result;

        } catch (\Exception $e) {
            Log::error('Virtualizor: Erro ao provisionar', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Suspender VPS
     */
    public function suspendService(Service $service): array
    {
        $vpsId = $service->server_data['vps_id'] ?? null;
        
        if (!$vpsId) {
            return ['success' => false, 'message' => 'VPS ID não encontrado'];
        }

        return $this->virtualizor->suspendVps($vpsId);
    }

    /**
     * Reativar VPS
     */
    public function unsuspendService(Service $service): array
    {
        $vpsId = $service->server_data['vps_id'] ?? null;
        
        if (!$vpsId) {
            return ['success' => false, 'message' => 'VPS ID não encontrado'];
        }

        return $this->virtualizor->unsuspendVps($vpsId);
    }

    /**
     * Terminar VPS
     */
    public function terminateService(Service $service): array
    {
        $vpsId = $service->server_data['vps_id'] ?? null;
        
        if (!$vpsId) {
            return ['success' => false, 'message' => 'VPS ID não encontrado'];
        }

        return $this->virtualizor->deleteVps($vpsId);
    }

    /**
     * Obter informações do VPS
     */
    public function getServiceInfo(Service $service): array
    {
        $vpsId = $service->server_data['vps_id'] ?? null;
        
        if (!$vpsId) {
            return ['success' => false, 'message' => 'VPS ID não encontrado'];
        }

        $info = $this->virtualizor->getVps($vpsId);
        $stats = $this->virtualizor->getStats($vpsId);

        return [
            'success' => true,
            'data' => [
                'vps' => $info['vps'] ?? [],
                'stats' => $stats['stats'] ?? [],
            ],
        ];
    }

    /**
     * Reiniciar VPS
     */
    public function rebootService(Service $service): array
    {
        $vpsId = $service->server_data['vps_id'] ?? null;
        
        if (!$vpsId) {
            return ['success' => false, 'message' => 'VPS ID não encontrado'];
        }

        return $this->virtualizor->rebootVps($vpsId);
    }

    /**
     * Reinstalar VPS
     */
    public function reinstallService(Service $service, array $options = []): array
    {
        $vpsId = $service->server_data['vps_id'] ?? null;
        
        if (!$vpsId) {
            return ['success' => false, 'message' => 'VPS ID não encontrado'];
        }

        return $this->virtualizor->reinstallVps($vpsId, [
            'os_id' => $options['os_id'] ?? 1,
        ]);
    }

    /**
     * Alterar senha
     */
    public function changePassword(Service $service, string $newPassword): array
    {
        $vpsId = $service->server_data['vps_id'] ?? null;
        
        if (!$vpsId) {
            return ['success' => false, 'message' => 'VPS ID não encontrado'];
        }

        return $this->virtualizor->changePassword($vpsId, $newPassword);
    }

    /**
     * Listar OS disponíveis
     */
    public function getAvailableOs(): array
    {
        return $this->virtualizor->listOs();
    }

    /**
     * Listar planos
     */
    public function getAvailablePlans(): array
    {
        return $this->virtualizor->listPlans();
    }

    /**
     * Testar conexão
     */
    public function testConnection(): array
    {
        return $this->virtualizor->testConnection();
    }

    /**
     * Gerar senha
     */
    private function generatePassword(int $length = 16): string
    {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
        return substr(str_shuffle(str_repeat($chars, ceil($length / strlen($chars)))), 0, $length);
    }
}
