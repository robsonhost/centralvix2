<?php

namespace App\Modules\Provisioning;

use App\Models\Service;
use App\Services\Provisioning\ProxmoxService;
use Illuminate\Support\Facades\Log;

class ProxmoxModule
{
    private ProxmoxService $proxmox;

    public function __construct()
    {
        $this->proxmox = new ProxmoxService();
    }

    /**
     * Criar VPS (KVM ou LXC)
     */
    public function createService(Service $service): array
    {
        try {
            Log::info('Proxmox: Iniciando provisionamento', [
                'service_id' => $service->id,
            ]);

            $type = $service->config_options['type'] ?? 'lxc'; // lxc or kvm

            if ($type === 'lxc') {
                $result = $this->proxmox->createContainer([
                    'hostname' => $service->domain ?? 'ct' . $service->id,
                    'template' => $service->config_options['template'] ?? 'local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst',
                    'memory' => $service->config_options['memory'] ?? 1024,
                    'cores' => $service->config_options['cores'] ?? 1,
                    'disk_size' => $service->config_options['disk'] ?? 8,
                    'storage' => $service->config_options['storage'] ?? 'local-lvm',
                ]);
            } else {
                $result = $this->proxmox->createVm([
                    'hostname' => $service->domain ?? 'vm' . $service->id,
                    'iso' => $service->config_options['iso'] ?? 'none',
                    'memory' => $service->config_options['memory'] ?? 2048,
                    'cores' => $service->config_options['cores'] ?? 2,
                    'disk_size' => $service->config_options['disk'] ?? 20,
                    'storage' => $service->config_options['storage'] ?? 'local-lvm',
                    'ostype' => $service->config_options['ostype'] ?? 'l26',
                ]);
            }

            if ($result['success']) {
                $service->update([
                    'status' => 'active',
                    'server_data' => [
                        'vmid' => $result['vmid'],
                        'type' => $type,
                        'password' => $result['password'] ?? null,
                        'task_id' => $result['task_id'] ?? null,
                        'provisioned_at' => now()->toISOString(),
                    ],
                ]);

                Log::info('Proxmox: VM/Container provisionado', [
                    'service_id' => $service->id,
                    'vmid' => $result['vmid'],
                ]);

                return [
                    'success' => true,
                    'message' => 'VM/Container criado com sucesso',
                    'data' => $result,
                ];
            }

            return $result;

        } catch (\Exception $e) {
            Log::error('Proxmox: Erro ao provisionar', [
                'service_id' => $service->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Suspender VM/Container
     */
    public function suspendService(Service $service): array
    {
        $vmid = $service->server_data['vmid'] ?? null;
        $type = $service->server_data['type'] ?? 'lxc';
        
        if (!$vmid) {
            return ['success' => false, 'message' => 'VMID não encontrado'];
        }

        return $this->proxmox->stopVm($vmid, $type);
    }

    /**
     * Reativar VM/Container
     */
    public function unsuspendService(Service $service): array
    {
        $vmid = $service->server_data['vmid'] ?? null;
        $type = $service->server_data['type'] ?? 'lxc';
        
        if (!$vmid) {
            return ['success' => false, 'message' => 'VMID não encontrado'];
        }

        return $this->proxmox->startVm($vmid, $type);
    }

    /**
     * Terminar VM/Container
     */
    public function terminateService(Service $service): array
    {
        $vmid = $service->server_data['vmid'] ?? null;
        $type = $service->server_data['type'] ?? 'lxc';
        
        if (!$vmid) {
            return ['success' => false, 'message' => 'VMID não encontrado'];
        }

        return $this->proxmox->deleteVm($vmid, $type);
    }

    /**
     * Obter informações
     */
    public function getServiceInfo(Service $service): array
    {
        $vmid = $service->server_data['vmid'] ?? null;
        $type = $service->server_data['type'] ?? 'lxc';
        
        if (!$vmid) {
            return ['success' => false, 'message' => 'VMID não encontrado'];
        }

        $info = $this->proxmox->getVm($vmid, $type);
        $stats = $this->proxmox->getStats($vmid, $type);

        return [
            'success' => true,
            'data' => [
                'vm' => $info['vm'] ?? [],
                'stats' => $stats['stats'] ?? [],
            ],
        ];
    }

    /**
     * Reiniciar
     */
    public function rebootService(Service $service): array
    {
        $vmid = $service->server_data['vmid'] ?? null;
        $type = $service->server_data['type'] ?? 'lxc';
        
        if (!$vmid) {
            return ['success' => false, 'message' => 'VMID não encontrado'];
        }

        return $this->proxmox->rebootVm($vmid, $type);
    }

    /**
     * Criar backup
     */
    public function createBackup(Service $service, string $description = ''): array
    {
        $vmid = $service->server_data['vmid'] ?? null;
        $type = $service->server_data['type'] ?? 'lxc';
        
        if (!$vmid) {
            return ['success' => false, 'message' => 'VMID não encontrado'];
        }

        $snapName = 'backup-' . now()->format('YmdHis');
        return $this->proxmox->createSnapshot($vmid, $snapName, $type);
    }

    /**
     * Restaurar backup
     */
    public function restoreBackup(Service $service, string $snapName): array
    {
        $vmid = $service->server_data['vmid'] ?? null;
        $type = $service->server_data['type'] ?? 'lxc';
        
        if (!$vmid) {
            return ['success' => false, 'message' => 'VMID não encontrado'];
        }

        return $this->proxmox->restoreSnapshot($vmid, $snapName, $type);
    }

    /**
     * Listar templates
     */
    public function getAvailableTemplates(): array
    {
        return $this->proxmox->listTemplates();
    }

    /**
     * Testar conexão
     */
    public function testConnection(): array
    {
        return $this->proxmox->testConnection();
    }
}
