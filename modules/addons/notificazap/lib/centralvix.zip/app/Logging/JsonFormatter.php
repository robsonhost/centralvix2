<?php

namespace App\Logging;

use Illuminate\Log\Logger;
use Monolog\Formatter\JsonFormatter as MonologJsonFormatter;
use Monolog\LogRecord;

/**
 * JSON Formatter for Structured Logging
 * 
 * Requirements: 65.1, 65.2
 * 
 * Formats log entries as structured JSON with context including:
 * - user_id: Current authenticated user
 * - company_id: Current tenant/company
 * - ip: Client IP address
 * - url: Request URL
 * - action: Action being performed
 * - timestamp: ISO 8601 timestamp
 * - level: Log level
 * - message: Log message
 * - context: Additional context data
 */
class JsonFormatter
{
    /**
     * Customize the given logger instance.
     *
     * @param  \Illuminate\Log\Logger  $logger
     * @return void
     */
    public function __invoke(Logger $logger): void
    {
        foreach ($logger->getHandlers() as $handler) {
            $handler->setFormatter(new MonologJsonFormatter(
                dateFormat: 'Y-m-d H:i:s.u'
            ));
        }
        
        // Add processor to enrich logs with request context
        $logger->pushProcessor(function (LogRecord $record) {
            $extra = $record->extra;
            
            // Add request context if available
            if (app()->bound('request')) {
                $request = request();
                
                $extra['ip'] = $request->ip();
                $extra['url'] = $request->fullUrl();
                $extra['method'] = $request->method();
                $extra['user_agent'] = $request->userAgent();
                
                // Add authenticated user context
                if ($request->user()) {
                    $extra['user_id'] = $request->user()->id;
                    $extra['user_email'] = $request->user()->email;
                }
                
                // Add company/tenant context if multi-tenant is enabled
                if (config('app.multi_tenant', false) && $request->attributes->has('company_id')) {
                    $extra['company_id'] = $request->attributes->get('company_id');
                }
                
                // Add route information
                if ($route = $request->route()) {
                    $extra['route'] = $route->getName() ?? $route->uri();
                    $extra['action'] = $route->getActionName();
                }
            }
            
            // Add memory usage
            $extra['memory_usage'] = memory_get_usage(true);
            
            // Add execution time if available
            if (defined('LARAVEL_START')) {
                $extra['execution_time_ms'] = round((microtime(true) - LARAVEL_START) * 1000, 2);
            }
            
            return $record->with(extra: $extra);
        });
    }
}
