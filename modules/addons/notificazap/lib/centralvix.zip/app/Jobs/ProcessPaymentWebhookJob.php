<?php

namespace App\Jobs;

use App\Services\PaymentService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessPaymentWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 3;
    public int $backoff = 30;

    public function __construct(
        public readonly string $gateway,
        public readonly array  $payload,
        public readonly array  $headers = []
    ) {
        $this->onQueue('default');
    }

    public function handle(PaymentService $paymentService): void
    {
        try {
            $paymentService->processWebhookPayment($this->gateway, $this->payload);
        } catch (\Exception $e) {
            Log::error("Payment webhook [{$this->gateway}] failed: " . $e->getMessage());
            throw $e;
        }
    }
}
