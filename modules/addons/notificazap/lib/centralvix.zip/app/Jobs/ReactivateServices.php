<?php

namespace App\Jobs;

use App\Models\Invoice;
use App\Models\Service;
use App\Services\NotificationService;
use App\Services\ProvisioningService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ReactivateServices implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(ProvisioningService $provisioningService, NotificationService $notificationService): void
    {
        // Find suspended services where all invoices are now paid
        $services = Service::where('status', 'suspended')
            ->where('override_auto_suspend', false)
            ->get();

        foreach ($services as $service) {
            $unpaidInvoices = Invoice::where('client_id', $service->client_id)
                ->whereHas('items', fn($q) => $q->where('service_id', $service->id))
                ->whereIn('status', ['unpaid', 'overdue'])
                ->exists();

            if (!$unpaidInvoices) {
                try {
                    $provisioningService->unsuspend($service);
                } catch (\Exception $e) {
                    logger()->error("Failed to reactivate service #{$service->id}: " . $e->getMessage());
                }
            }
        }
    }
}
