<?php

namespace App\Jobs;

use App\Models\Company;
use App\Models\Invoice;
use App\Models\NotificationLog;
use App\Models\Setting;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use App\Services\NotificationService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class SendInvoiceReminders implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 2;

    /**
     * Coluna de vencimento detectada em runtime (date_due x due_date).
     */
    private ?string $dueColumn = null;

    public function handle(
        NotificationService $notificationService,
        ModuleService $modules,
        ModuleSettingsService $moduleSettings,
    ): void {
        Log::info('🔔 Régua de cobrança: iniciando...');

        $this->dueColumn = Schema::hasColumn('invoices', 'date_due') ? 'date_due' : 'due_date';

        Company::where('status', 'active')->get()->each(function (Company $company) use ($modules, $moduleSettings, $notificationService) {
            try {
                $this->processCompany($company, $modules, $moduleSettings, $notificationService);
            } catch (\Throwable $e) {
                Log::error("❌ Régua de cobrança falhou para empresa {$company->id}: " . $e->getMessage());
            }
        });
    }

    private function processCompany(
        Company $company,
        ModuleService $modules,
        ModuleSettingsService $moduleSettings,
        NotificationService $notificationService,
    ): void {
        $today = now()->startOfDay();

        // Quando o módulo "Régua de Cobrança" está ativo, usamos seus parâmetros.
        // Caso contrário, mantemos o comportamento legado (configurações de billing).
        $dunningEnabled = $modules->isEnabled($company->id, 'dunning');

        if ($dunningEnabled) {
            $cfg = $moduleSettings->all($company->id, 'dunning');
            $channels = array_filter([
                'whatsapp' => (bool) ($cfg['channel_whatsapp'] ?? true),
                'email'    => (bool) ($cfg['channel_email'] ?? true),
            ]);
        } else {
            $legacy = Setting::where('company_id', $company->id)
                ->where('group', 'billing')
                ->pluck('value', 'key');

            if (!($legacy['send_reminder_email'] ?? true)) {
                return;
            }

            $cfg = [
                'reminder_before_days'    => (int) ($legacy['reminder_days_before_1'] ?? 7),
                'reminder_on_due'         => (bool) ($legacy['send_on_due_date'] ?? true),
                'reminder_after_days'     => 1,
                'reminder_interval_days'  => 3,
                'max_reminders'           => 4,
                'stop_when_paid'          => true,
            ];
            $channels = ['whatsapp' => true, 'email' => true];
        }

        $sent = 0;

        // ---- Lembretes ANTES do vencimento (marcos 10/7/3/1 ou config) ----
        foreach ($this->resolveBeforeMilestones($cfg) as $beforeDays) {
            $sent += $this->remindOnDate($company, $today->copy()->addDays($beforeDays), $beforeDays, $channels);
        }

        if ((bool) ($cfg['reminder_on_due'] ?? true)) {
            $sent += $this->remindOnDate($company, $today->copy(), 0, $channels);
        }

        // ---- Lembretes APÓS o vencimento (cobrança) ----
        $afterStart = max(1, (int) ($cfg['reminder_after_days'] ?? 1));
        $interval   = max(1, (int) ($cfg['reminder_interval_days'] ?? 3));
        $maxRem     = max(1, (int) ($cfg['max_reminders'] ?? 4));

        $overdue = Invoice::with(['client', 'company'])
            ->where('company_id', $company->id)
            ->whereIn('status', ['unpaid', 'pending', 'overdue'])
            ->whereDate($this->dueColumn, '<', $today)
            ->get();

        foreach ($overdue as $invoice) {
            $daysOver = $today->diffInDays(Carbon::parse($invoice->{$this->dueColumn})->startOfDay());

            if ($daysOver < $afterStart) {
                continue;
            }
            if ((($daysOver - $afterStart) % $interval) !== 0) {
                continue;
            }

            $alreadySent = NotificationLog::where('context_type', 'invoice')
                ->where('context_id', $invoice->id)
                ->where('event', 'invoice_overdue')
                ->count();

            if ($alreadySent >= $maxRem) {
                continue;
            }

            // Evita duplicar no mesmo dia.
            $sentToday = NotificationLog::where('context_type', 'invoice')
                ->where('context_id', $invoice->id)
                ->where('event', 'invoice_overdue')
                ->whereDate('sent_at', $today)
                ->exists();

            if ($sentToday) {
                continue;
            }

            try {
                $this->dispatchReminder($invoice, -$daysOver, $channels, 'invoice_overdue');
                $sent++;
            } catch (\Throwable $e) {
                Log::error("❌ Cobrança fatura #{$invoice->id}: " . $e->getMessage());
            }
        }

        Log::info("✅ Régua de cobrança empresa {$company->id}: {$sent} envios.");
    }

    /**
     * Lembretes para faturas que vencem exatamente numa data.
     */
    private function remindOnDate(Company $company, Carbon $date, int $daysUntilDue, array $channels): int
    {
        $invoices = Invoice::with(['client', 'company'])
            ->where('company_id', $company->id)
            ->whereIn('status', ['unpaid', 'pending'])
            ->whereDate($this->dueColumn, $date)
            ->get();

        $count = 0;
        foreach ($invoices as $invoice) {
            $template = $this->resolveTemplate($daysUntilDue, 'invoice_reminder');

            $alreadySent = NotificationLog::where('context_type', 'invoice')
                ->where('context_id', $invoice->id)
                ->where('event', 'invoice_reminder')
                ->where('template_slug', $template)
                ->exists();

            if ($alreadySent) {
                continue;
            }

            try {
                $this->dispatchReminder($invoice, $daysUntilDue, $channels, 'invoice_reminder');
                $count++;
            } catch (\Throwable $e) {
                Log::error("❌ Lembrete fatura #{$invoice->id}: " . $e->getMessage());
            }
        }

        return $count;
    }

    /**
     * Marcos de lembrete antes do vencimento (padrão WHMCS-like: 10, 7, 3, 1).
     */
    private function resolveBeforeMilestones(array $cfg): array
    {
        $raw = $cfg['reminder_before_milestones'] ?? null;

        if (is_string($raw) && trim($raw) !== '') {
            $milestones = array_map('intval', array_filter(array_map('trim', explode(',', $raw))));
        } elseif (is_array($raw) && $raw !== []) {
            $milestones = array_map('intval', $raw);
        } else {
            $single = (int) ($cfg['reminder_before_days'] ?? 0);
            $milestones = $single > 0 ? [$single] : [10, 7, 3, 1];
        }

        $milestones = array_values(array_unique(array_filter($milestones, fn (int $d) => $d > 0)));
        rsort($milestones);

        return $milestones;
    }

    /**
     * Envia o lembrete pelos canais habilitados e registra no log.
     * $days: positivo/zero = dias até vencer; negativo = dias em atraso.
     */
    private function dispatchReminder(Invoice $invoice, int $days, array $channels, string $event): void
    {
        $client = $invoice->client;
        if (!$client) {
            return;
        }

        $template = $this->resolveTemplate($days, $event);

        $data = [
            'client_name'    => $client->firstname ?? $client->display_name ?? 'Cliente',
            'invoice_number' => $invoice->invoice_number,
            'invoice_total'  => 'R$ ' . number_format((float) $invoice->total, 2, ',', '.'),
            'due_date'       => optional($invoice->{$this->dueColumn})->format('d/m/Y')
                ?? Carbon::parse($invoice->{$this->dueColumn})->format('d/m/Y'),
            'days_text'      => $this->daysText($days),
            'invoice_id'     => $invoice->id,
        ];

        // E-mail
        if (!empty($channels['email']) && $client->email) {
            try {
                $mailDays = $days >= 0 ? $days : 0;
                \Mail::to($client->email)->send(new \App\Mail\InvoiceReminderMail($invoice, $mailDays));
            } catch (\Throwable $e) {
                Log::error("📧 Falha e-mail fatura #{$invoice->id}: " . $e->getMessage());
            }
        }

        // WhatsApp (com auto login nos templates)
        if (!empty($channels['whatsapp'])) {
            try {
                $waData = array_merge(
                    $data,
                    app(NotificationService::class)->invoiceUrlsForWhatsApp($invoice)
                );
                app(\App\Services\WhatsApp\WhatsappNotificationService::class)->notifyClient(
                    $client,
                    $template,
                    $waData,
                    'invoice',
                    (int) $invoice->id,
                );
            } catch (\Throwable $e) {
                Log::error("💬 Falha WhatsApp fatura #{$invoice->id}: " . $e->getMessage());
            }
        }

        NotificationLog::create([
            'company_id'    => $invoice->company_id,
            'client_id'     => $client->id,
            'event'         => $event,
            'type'          => $event,
            'channel'       => implode('_', array_keys(array_filter($channels))) ?: 'system',
            'channels'      => array_keys(array_filter($channels)),
            'recipient'     => $client->email,
            'template_slug' => $template,
            'status'        => 'sent',
            'context_type'  => 'invoice',
            'context_id'    => $invoice->id,
            'sent_at'       => now(),
        ]);
    }

    private function resolveTemplate(int $days, string $event): string
    {
        if ($event === 'invoice_overdue') {
            return 'invoice_overdue';
        }

        return match ($days) {
            0 => 'invoice_reminder_today',
            1 => 'invoice_reminder_1day',
            3 => 'invoice_reminder_3days',
            7 => 'invoice_reminder_7days',
            10 => 'invoice_reminder_10days',
            default => 'invoice_reminder_generic',
        };
    }

    private function daysText(int $days): string
    {
        if ($days < 0) {
            $d = abs($days);
            return $d === 1 ? 'há 1 dia' : "há {$d} dias";
        }

        return match ($days) {
            0 => 'hoje',
            1 => 'amanhã',
            default => "em {$days} dias",
        };
    }

    private function formatPhone(?string $phone): ?string
    {
        if (!$phone) {
            return null;
        }

        $phone = preg_replace('/\D/', '', $phone);

        if (strlen($phone) === 11 && !str_starts_with($phone, '55')) {
            $phone = '55' . $phone;
        }

        return $phone ?: null;
    }
}
