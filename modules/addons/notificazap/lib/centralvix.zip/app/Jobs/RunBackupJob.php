<?php

namespace App\Jobs;

use App\Models\Company;
use App\Services\BackupService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class RunBackupJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 3600; // 1 hour

    protected $companyId;
    protected $type;
    protected $userId;

    /**
     * Create a new job instance.
     */
    public function __construct(int $companyId, string $type = 'full', ?int $userId = null)
    {
        $this->companyId = $companyId;
        $this->type = $type;
        $this->userId = $userId;
    }

    /**
     * Execute the job.
     */
    public function handle(BackupService $backupService): void
    {
        try {
            Log::info("Starting backup for company {$this->companyId}, type: {$this->type}");

            $backup = $backupService->runBackup($this->companyId, $this->type, $this->userId);

            Log::info("Backup completed successfully: {$backup->filename}");

        } catch (\Exception $e) {
            Log::error("Backup failed for company {$this->companyId}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Handle a job failure.
     */
    public function failed(\Throwable $exception): void
    {
        Log::error("Backup job failed: " . $exception->getMessage());
    }
}
