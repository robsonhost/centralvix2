<?php

namespace App\Jobs;

use App\Services\BillingService;
use App\Services\InvoiceService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class GenerateRecurringInvoices implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $timeout = 300;

    public function handle(BillingService $billingService, InvoiceService $invoiceService): void
    {
        $count = $billingService->generateRecurringInvoices();
        $invoiceService->markOverdueInvoices();
        logger()->info("Generated {$count} recurring invoices.");
    }
}
