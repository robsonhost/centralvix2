<?php

namespace App\Jobs;

use App\Models\Company;
use App\Models\Invoice;
use App\Services\LateFeeService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class ApplyLateFees implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 2;

    public function handle(LateFeeService $service): void
    {
        Log::info('💰 Multa e juros: iniciando aplicação...');

        $dueColumn = Schema::hasColumn('invoices', 'date_due') ? 'date_due' : 'due_date';

        Company::where('status', 'active')->get()->each(function (Company $company) use ($service, $dueColumn) {
            if (!$service->isEnabled($company->id)) {
                return;
            }

            $cfg = $service->config($company->id);

            // Quando a aplicação automática está desligada, o admin aplica manualmente.
            if (!($cfg['apply_automatically'] ?? true)) {
                return;
            }

            $changed = 0;

            Invoice::where('company_id', $company->id)
                ->whereIn('status', ['unpaid', 'pending', 'overdue'])
                ->whereDate($dueColumn, '<', now()->startOfDay())
                ->chunkById(200, function ($invoices) use ($service, $cfg, &$changed) {
                    foreach ($invoices as $invoice) {
                        try {
                            if ($service->apply($invoice, $cfg)) {
                                $changed++;
                            }
                        } catch (\Throwable $e) {
                            Log::error("❌ Multa/juros fatura #{$invoice->id}: " . $e->getMessage());
                        }
                    }
                });

            if ($changed > 0) {
                Log::info("✅ Multa e juros empresa {$company->id}: {$changed} faturas atualizadas.");
            }
        });
    }
}
