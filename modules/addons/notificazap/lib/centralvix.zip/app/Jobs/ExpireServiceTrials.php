<?php

namespace App\Jobs;

use App\Models\Company;
use App\Models\Service;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

/**
 * Expira / suspende serviços em trial vencido e dispara notificação prévia.
 * Roda diariamente — respeita config do módulo `service_trial` por empresa.
 */
class ExpireServiceTrials implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 2;

    public function handle(ModuleService $modules, ModuleSettingsService $settings): void
    {
        if (!Schema::hasTable('services') || !Schema::hasColumn('services', 'is_trial')) {
            Log::info('⏳ Service trial: schema ainda não migrado, pulando.');
            return;
        }

        Log::info('⏳ Service trial: iniciando varredura...');

        Company::where('status', 'active')->get()->each(function (Company $company) use ($modules, $settings) {
            if (!$modules->isEnabled($company->id, 'service_trial')) {
                return;
            }

            $cfg = $settings->all($company->id, 'service_trial');
            $autoSuspend = (bool) ($cfg['auto_suspend'] ?? true);
            $notifyDays  = (int)  ($cfg['notify_before_end_days'] ?? 2);

            // 1) Suspender trials já vencidos
            if ($autoSuspend) {
                $expired = Service::where('company_id', $company->id)
                    ->where('is_trial', true)
                    ->whereNull('trial_converted_at')
                    ->whereNotNull('trial_ends_at')
                    ->where('trial_ends_at', '<', now())
                    ->whereIn('status', ['active', 'pending'])
                    ->get();

                foreach ($expired as $service) {
                    try {
                        $service->update(['status' => 'suspended']);
                        Log::info("⛔ Trial expirado — serviço #{$service->id} suspenso.");
                    } catch (\Throwable $e) {
                        Log::error("❌ Trial #{$service->id}: " . $e->getMessage());
                    }
                }
            }

            // 2) Notificar X dias antes
            if ($notifyDays > 0) {
                $threshold = now()->copy()->addDays($notifyDays);

                Service::where('company_id', $company->id)
                    ->where('is_trial', true)
                    ->whereNull('trial_converted_at')
                    ->whereNull('trial_notified_at')
                    ->whereNotNull('trial_ends_at')
                    ->whereBetween('trial_ends_at', [now(), $threshold])
                    ->whereIn('status', ['active', 'pending'])
                    ->chunkById(100, function ($services) {
                        foreach ($services as $service) {
                            try {
                                // Marca como notificado (gancho para envio real fica para
                                // canais de notificação — e-mail/WhatsApp já existentes).
                                $service->update(['trial_notified_at' => now()]);
                                Log::info("🔔 Trial #{$service->id} notificação registrada.");
                            } catch (\Throwable $e) {
                                Log::error("❌ Notificação trial #{$service->id}: " . $e->getMessage());
                            }
                        }
                    });
            }
        });

        Log::info('✅ Service trial: varredura concluída.');
    }
}
