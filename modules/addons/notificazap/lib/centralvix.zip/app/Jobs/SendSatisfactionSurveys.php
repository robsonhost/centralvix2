<?php

namespace App\Jobs;

use App\Models\Company;
use App\Models\SatisfactionSurvey;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use App\Services\SatisfactionSurveyService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendSatisfactionSurveys implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 300;
    public int $tries = 1;

    public function handle(SatisfactionSurveyService $service, ModuleService $modules, ModuleSettingsService $settings): void
    {
        Company::where('status', 'active')->get()->each(function (Company $company) use ($service, $modules, $settings) {
            if (!$modules->isEnabled($company->id, 'satisfaction_survey')) {
                return;
            }

            $cfg = $settings->all($company->id, 'satisfaction_survey');
            $delayHours = (int) ($cfg['delay_hours'] ?? 1);
            $cutoff = now()->subHours(max(0, $delayHours));

            SatisfactionSurvey::forCompany($company->id)
                ->whereNull('sent_at')
                ->where('status', 'pending')
                ->where('created_at', '<=', $cutoff)
                ->limit(200)
                ->get()
                ->each(function (SatisfactionSurvey $survey) use ($service) {
                    try {
                        $service->send($survey);
                    } catch (\Throwable $e) {
                        Log::error("Envio pesquisa #{$survey->id}: " . $e->getMessage());
                    }
                });
        });
    }
}
