<?php

namespace App\Jobs;

use App\Models\Company;
use App\Models\Monitor;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use App\Services\MonitorService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class CheckUptimeMonitors implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 1;

    public function handle(MonitorService $service, ModuleService $modules, ModuleSettingsService $settings): void
    {
        Company::where('status', 'active')->get()->each(function (Company $company) use ($service, $modules, $settings) {
            if (!$modules->isEnabled($company->id, 'uptime_monitor')) {
                return;
            }

            $cfg = $settings->all($company->id, 'uptime_monitor');

            Monitor::forCompany($company->id)->active()->where('type', 'uptime')
                ->get()
                ->each(function (Monitor $monitor) use ($service, $cfg) {
                    try {
                        $service->runUptime($monitor, $cfg);
                    } catch (\Throwable $e) {
                        Log::error("Uptime monitor #{$monitor->id} falhou: " . $e->getMessage());
                    }
                });
        });
    }
}
