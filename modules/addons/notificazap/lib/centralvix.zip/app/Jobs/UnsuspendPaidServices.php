<?php

namespace App\Jobs;

use App\Models\Client;
use App\Models\Service;
use App\Services\ProvisioningService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class UnsuspendPaidServices implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 3;

    /**
     * Execute the job - Unsuspend services for clients who paid their invoices
     */
    public function handle(): void
    {
        Log::info('Starting automatic unsuspension of paid services');

        // Find all suspended clients
        $suspendedClients = Client::where('status', 'suspended')
            ->with('services')
            ->get();

        foreach ($suspendedClients as $client) {
            $this->checkAndUnsuspendClient($client);
        }

        Log::info('Finished automatic unsuspension', [
            'clients_processed' => $suspendedClients->count()
        ]);
    }

    /**
     * Check if client has paid and unsuspend if needed
     */
    private function checkAndUnsuspendClient(Client $client): void
    {
        // Check if client still has unpaid/overdue invoices
        $unpaidInvoices = $client->invoices()
            ->whereIn('status', ['unpaid', 'overdue'])
            ->count();

        // If no unpaid invoices, unsuspend
        if ($unpaidInvoices === 0) {
            // Update client status
            $client->update([
                'status' => 'active',
                'notes' => trim(($client->notes ?? '') . "\n[" . now()->format('Y-m-d H:i:s') . "] Cliente reativado automaticamente após pagamento")
            ]);

            Log::info('Client unsuspended', [
                'client_id' => $client->id,
                'client_name' => $client->display_name
            ]);

            // Unsuspend all services
            $suspendedServices = $client->services()
                ->where('status', 'suspended')
                ->get();

            foreach ($suspendedServices as $service) {
                $this->unsuspendService($service);
            }

            // Send reactivation notification
            $this->sendReactivationNotification($client);
        }
    }

    /**
     * Unsuspend a specific service
     */
    private function unsuspendService(Service $service): void
    {
        try {
            // Update service status
            $service->update([
                'status' => 'active',
                'notes' => trim(($service->notes ?? '') . "\n[" . now()->format('Y-m-d H:i:s') . "] Serviço reativado automaticamente após pagamento")
            ]);

            // Unsuspend on server (cPanel/WHM)
            if ($service->server && $service->server->isActive()) {
                $provisioningService = app(ProvisioningService::class);
                $provisioningService->unsuspend($service);

                Log::info('Service unsuspended on server', [
                    'service_id' => $service->id,
                    'domain' => $service->domain,
                    'server' => $service->server->name
                ]);
            }

        } catch (\Exception $e) {
            Log::error('Failed to unsuspend service', [
                'service_id' => $service->id,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Send reactivation notification to client
     */
    private function sendReactivationNotification(Client $client): void
    {
        try {
            Log::info('Reactivation notification sent', [
                'client_id' => $client->id,
                'email' => $client->email
            ]);

            // TODO: Send email using your mail system
            // Mail::to($client->email)->send(new ServiceReactivatedMail($client));

        } catch (\Exception $e) {
            Log::error('Failed to send reactivation notification', [
                'client_id' => $client->id,
                'error' => $e->getMessage()
            ]);
        }
    }
}
