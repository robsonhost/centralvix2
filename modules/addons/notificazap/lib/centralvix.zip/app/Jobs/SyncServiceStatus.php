<?php

namespace App\Jobs;

use App\Models\Service;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SyncServiceStatus implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 1;
    public int $timeout = 300;

    public function __construct()
    {
        $this->onQueue('default');
    }

    public function handle(): void
    {
        $services = Service::where('status', 'active')
            ->whereNotNull('module')
            ->with('server')
            ->get();

        foreach ($services as $service) {
            try {
                $moduleClass = "Modules\\Hosting\\{$service->module}";

                if (!class_exists($moduleClass)) {
                    continue;
                }

                if (!$service->server) {
                    continue;
                }

                $module = new $moduleClass($service->server);

                if (!method_exists($module, 'getStatus')) {
                    continue;
                }

                $status = $module->getStatus($service);

                if ($status && $status !== $service->status) {
                    $service->update(['status' => $status]);
                    Log::info("SyncServiceStatus: service #{$service->id} updated to '{$status}'.");
                }
            } catch (\Exception $e) {
                Log::error("SyncServiceStatus failed for service #{$service->id}: " . $e->getMessage());
            }
        }
    }
}
