<?php

namespace App\Jobs;

use App\Models\Client;
use App\Services\NotificationService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendNotificationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $backoff = 60;

    public function __construct(
        public int $clientId,
        public string $templateSlug,
        public array $data = []
    ) {}

    public function handle(NotificationService $notificationService): void
    {
        $client = Client::find($this->clientId);
        if (!$client) return;

        $notificationService->sendEmail($client, $this->templateSlug, $this->data);
    }
}
