<?php

namespace App\Jobs;

use App\Services\Nfe\NfseGovBrService;
use App\Models\Invoice;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class IssueNfseJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 300; // 5 minutes

    protected $invoiceId;

    /**
     * Create a new job instance.
     */
    public function __construct(int $invoiceId)
    {
        $this->invoiceId = $invoiceId;
    }

    /**
     * Execute the job.
     */
    public function handle(NfseGovBrService $nfseService): void
    {
        try {
            $invoice = Invoice::findOrFail($this->invoiceId);

            Log::info("Starting NFS-e emission for invoice {$this->invoiceId}");

            $result = $nfseService->emitirNfse($invoice);

            if ($result['success']) {
                Log::info("NFS-e emitted successfully for invoice {$this->invoiceId}: " . $result['nfse']->nfe_number);
            } else {
                Log::error("Failed to emit NFS-e for invoice {$this->invoiceId}: " . ($result['message'] ?? 'Unknown error'));
            }

        } catch (\Exception $e) {
            Log::error("NFS-e emission job failed for invoice {$this->invoiceId}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Handle a job failure.
     */
    public function failed(\Throwable $exception): void
    {
        Log::error("NFS-e emission job failed: " . $exception->getMessage());
    }
}
