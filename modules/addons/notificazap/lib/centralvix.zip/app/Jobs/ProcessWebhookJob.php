<?php

namespace App\Jobs;

use App\Models\Webhook;
use App\Models\WebhookLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;

class ProcessWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $backoff = 60;

    public function __construct(
        public int $webhookId,
        public string $event,
        public array $payload = []
    ) {}

    public function handle(): void
    {
        $webhook = Webhook::find($this->webhookId);
        if (!$webhook || $webhook->status !== 'active') return;

        $log = WebhookLog::create([
            'webhook_id' => $webhook->id,
            'event' => $this->event,
            'payload' => $this->payload,
            'status' => 'pending',
            'created_at' => now(),
        ]);

        try {
            $signature = hash_hmac('sha256', json_encode($this->payload), $webhook->secret ?? '');

            $response = Http::timeout(30)
                ->withHeaders([
                    'Content-Type' => 'application/json',
                    'X-CentralVix-Event' => $this->event,
                    'X-CentralVix-Signature' => $signature,
                ])
                ->post($webhook->url, $this->payload);

            $log->update([
                'response_code' => $response->status(),
                'response_body' => substr($response->body(), 0, 1000),
                'status' => $response->successful() ? 'success' : 'failed',
            ]);

            $webhook->update(['last_sent_at' => now()]);
        } catch (\Exception $e) {
            $log->update([
                'response_body' => $e->getMessage(),
                'status' => 'failed',
            ]);

            throw $e;
        }
    }
}
