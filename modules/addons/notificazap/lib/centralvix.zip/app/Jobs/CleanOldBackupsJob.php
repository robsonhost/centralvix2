<?php

namespace App\Jobs;

use App\Models\Backup;
use App\Models\BackupSetting;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class CleanOldBackupsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 600; // 10 minutes

    protected $companyId;

    /**
     * Create a new job instance.
     */
    public function __construct(?int $companyId = null)
    {
        $this->companyId = $companyId;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        try {
            if ($this->companyId) {
                $this->cleanCompanyBackups($this->companyId);
            } else {
                $this->cleanAllCompaniesBackups();
            }

        } catch (\Exception $e) {
            Log::error("Clean old backups job failed: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Clean backups for a specific company
     */
    protected function cleanCompanyBackups(int $companyId): void
    {
        $settings = BackupSetting::where('company_id', $companyId)->first();

        if (!$settings) {
            Log::warning("No backup settings found for company {$companyId}");
            return;
        }

        $retentionDays = $settings->retention_days ?? 30;
        $cutoffDate = now()->subDays($retentionDays);

        Log::info("Cleaning backups older than {$cutoffDate} for company {$companyId}");

        $oldBackups = Backup::where('company_id', $companyId)
            ->where('created_at', '<', $cutoffDate)
            ->where('status', 'completed')
            ->get();

        $deletedCount = 0;
        $deletedSize = 0;

        foreach ($oldBackups as $backup) {
            try {
                // Delete file from storage
                if ($backup->path && Storage::exists($backup->path)) {
                    $deletedSize += $backup->size_bytes;
                    Storage::delete($backup->path);
                    Log::info("Deleted backup file: {$backup->path}");
                }

                // Delete database record
                $backup->delete();
                $deletedCount++;

            } catch (\Exception $e) {
                Log::error("Failed to delete backup {$backup->id}: " . $e->getMessage());
            }
        }

        Log::info("Cleaned {$deletedCount} old backups for company {$companyId}, freed " . $this->formatBytes($deletedSize));

        // Send notification if configured
        if ($settings->email_notifications && $deletedCount > 0) {
            $this->sendCleanupNotification($settings, $deletedCount, $deletedSize);
        }
    }

    /**
     * Clean backups for all companies
     */
    protected function cleanAllCompaniesBackups(): void
    {
        $companies = BackupSetting::where('enabled', true)
            ->pluck('company_id')
            ->unique();

        foreach ($companies as $companyId) {
            $this->cleanCompanyBackups($companyId);
        }

        Log::info("Completed cleaning old backups for all companies");
    }

    /**
     * Send cleanup notification
     */
    protected function sendCleanupNotification(BackupSetting $settings, int $count, int $size): void
    {
        if (!$settings->notification_email) {
            return;
        }

        // TODO: Send email notification
        // Mail::to($settings->notification_email)->send(new BackupCleanedMail($count, $size));
        
        Log::info("Backup cleanup notification sent to {$settings->notification_email}");
    }

    /**
     * Format bytes to human readable
     */
    protected function formatBytes(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, 2) . ' ' . $units[$i];
    }

    /**
     * Handle a job failure.
     */
    public function failed(\Throwable $exception): void
    {
        Log::error("Clean old backups job failed: " . $exception->getMessage());
    }
}
