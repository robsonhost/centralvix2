<?php

namespace App\Jobs;

use App\Events\ServiceSuspended;
use App\Models\Client;
use App\Models\Invoice;
use App\Models\Service;
use App\Services\ProvisioningService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

class SuspendOverdueServices implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 3;

    /**
     * Execute the job - Suspend services for clients with overdue invoices
     */
    public function handle(): void
    {
        Log::info('Starting automatic suspension of overdue services');

        $gracePeriodDays = config('centralvix.suspension_grace_period', 7);
        $cutoffDate = Carbon::now()->subDays($gracePeriodDays);
        $dueColumn = Schema::hasColumn('invoices', 'date_due') ? 'date_due' : 'due_date';

        // Find all overdue invoices past grace period
        $overdueInvoices = Invoice::where('status', 'overdue')
            ->where($dueColumn, '<=', $cutoffDate)
            ->with(['client', 'client.services'])
            ->get();

        $clientsToSuspend = $overdueInvoices->pluck('client')->unique('id')->filter();

        foreach ($clientsToSuspend as $client) {
            $this->suspendClient($client);
        }

        Log::info('Finished automatic suspension', [
            'clients_processed' => $clientsToSuspend->count()
        ]);
    }

    /**
     * Suspend all active services for a client
     */
    private function suspendClient(Client $client): void
    {
        // Check if client has unpaid invoices
        $unpaidInvoices = $client->invoices()
            ->whereIn('status', ['unpaid', 'overdue'])
            ->count();

        if ($unpaidInvoices === 0) {
            return; // Client is paid up, don't suspend
        }

        // Update client status
        if ($client->status !== 'suspended') {
            $client->update([
                'status' => 'suspended',
                'notes' => trim(($client->notes ?? '') . "\n[" . now()->format('Y-m-d H:i:s') . "] Cliente suspenso automaticamente por inadimplência")
            ]);

            Log::info('Client suspended', [
                'client_id' => $client->id,
                'client_name' => $client->display_name,
                'unpaid_invoices' => $unpaidInvoices
            ]);
        }

        // Suspend all active services
        $activeServices = $client->services()
            ->where('status', 'active')
            ->get();

        foreach ($activeServices as $service) {
            $this->suspendService($service);
        }

        // Send suspension notification
        $this->sendSuspensionNotification($client, $unpaidInvoices);
    }

    /**
     * Suspend a specific service
     */
    private function suspendService(Service $service): void
    {
        try {
            // Update service status
            $service->update([
                'status' => 'suspended',
                'notes' => trim(($service->notes ?? '') . "\n[" . now()->format('Y-m-d H:i:s') . "] Serviço suspenso automaticamente por inadimplência")
            ]);

            // Suspend on server (cPanel/WHM)
            if ($service->server && $service->server->isActive()) {
                $provisioningService = app(ProvisioningService::class);
                $provisioningService->suspend($service);

                Log::info('Service suspended on server', [
                    'service_id' => $service->id,
                    'domain' => $service->domain,
                    'server' => $service->server->name
                ]);
            }

            ServiceSuspended::dispatch($service, 'automatic_overdue', true);

        } catch (\Exception $e) {
            Log::error('Failed to suspend service', [
                'service_id' => $service->id,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Send suspension notification to client
     */
    private function sendSuspensionNotification(Client $client, int $unpaidCount): void
    {
        try {
            // You can implement email notification here
            Log::info('Suspension notification sent', [
                'client_id' => $client->id,
                'email' => $client->email,
                'unpaid_invoices' => $unpaidCount
            ]);

            // TODO: Send email using your mail system
            // Mail::to($client->email)->send(new ServiceSuspendedMail($client, $unpaidCount));

        } catch (\Exception $e) {
            Log::error('Failed to send suspension notification', [
                'client_id' => $client->id,
                'error' => $e->getMessage()
            ]);
        }
    }
}
