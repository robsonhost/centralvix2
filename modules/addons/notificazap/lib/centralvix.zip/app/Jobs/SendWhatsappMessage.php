<?php

namespace App\Jobs;

use App\Models\WhatsappMessage;
use App\Services\WhatsApp\EvolutionGoService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendWhatsappMessage implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries  = 3;
    public int $backoff = 30; // seconds between retries

    public function __construct(
        public readonly int $messageId
    ) {
        $this->onQueue('whatsapp');
    }

    public function handle(): void
    {
        $message = WhatsappMessage::with('instance')->find($this->messageId);

        if (!$message || in_array($message->status, ['sent', 'delivered'])) {
            return;
        }

        if (!$message->instance || !$message->instance->isConnected()) {
            $message->update(['status' => 'failed', 'error_message' => 'Instance not connected']);
            return;
        }

        $evolution = new EvolutionGoService($message->instance);

        try {
            $result = match ($message->type) {
                'image', 'document', 'audio', 'video' => $evolution->sendMedia(
                    $message->instance->instance_key,
                    $message->to_number,
                    $message->type,
                    $message->media_url ?? '',
                    $message->media_caption ?? ''
                ),
                'buttons' => $evolution->sendButtons(
                    $message->instance->instance_key,
                    $message->to_number,
                    $message->content,
                    config('app.name'),
                    json_decode($message->content, true)['buttons'] ?? []
                ),
                default => $evolution->sendText(
                    $message->instance->instance_key,
                    $message->to_number,
                    $message->content
                ),
            };

            $msgId = $result['key']['id'] ?? null;

            $message->update([
                'status'       => $msgId ? 'sent' : 'failed',
                'message_id'   => $msgId,
                'sent_at'      => $msgId ? now() : null,
                'raw_response' => $result,
                'retry_count'  => $message->retry_count + 1,
                'error_message' => $msgId ? null : ($result['error'] ?? 'Unknown error'),
            ]);
        } catch (\Exception $e) {
            Log::error("SendWhatsappMessage failed #{$this->messageId}: " . $e->getMessage());

            $message->increment('retry_count');
            $message->update(['status' => 'failed', 'error_message' => $e->getMessage()]);

            if ($message->retry_count < $this->tries) {
                $this->release($this->backoff);
            }
        }
    }

    public function failed(\Throwable $e): void
    {
        WhatsappMessage::find($this->messageId)?->update([
            'status'        => 'failed',
            'error_message' => $e->getMessage(),
        ]);
    }
}
