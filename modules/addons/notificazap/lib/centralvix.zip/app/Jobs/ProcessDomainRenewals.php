<?php

namespace App\Jobs;

use App\Models\Domain;
use App\Services\DomainBillingService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessDomainRenewals implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(DomainBillingService $domainBilling): void
    {
        $renewalWindowDays = 30;

        $domains = Domain::query()
            ->where('status', 'active')
            ->where('auto_renew', true)
            ->whereDate('expiry_date', '<=', now()->addDays($renewalWindowDays))
            ->whereDate('expiry_date', '>=', now()->subDays(7))
            ->with('client')
            ->get();

        $generated = 0;

        foreach ($domains as $domain) {
            try {
                if ($domainBilling->hasPendingRenewalInvoice($domain)) {
                    continue;
                }

                $invoice = $domainBilling->createRenewalInvoice($domain, 1);
                $generated++;

                Log::info('Fatura de renovação de domínio gerada', [
                    'domain' => $domain->domain,
                    'invoice_id' => $invoice->id,
                ]);
            } catch (\Throwable $e) {
                Log::error('Falha ao gerar fatura de renovação', [
                    'domain' => $domain->domain,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        Log::info('ProcessDomainRenewals concluído', ['invoices_generated' => $generated]);
    }
}
