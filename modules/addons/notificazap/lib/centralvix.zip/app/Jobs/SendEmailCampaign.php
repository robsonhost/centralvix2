<?php

namespace App\Jobs;

use App\Models\EmailCampaign;
use App\Services\EmailCampaignService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendEmailCampaign implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 1;

    public function __construct(public int $campaignId) {}

    public function handle(EmailCampaignService $service): void
    {
        $campaign = EmailCampaign::find($this->campaignId);
        if (!$campaign || in_array($campaign->status, ['sent', 'cancelled'], true)) {
            return;
        }

        $service->processBatch($campaign);
    }
}
