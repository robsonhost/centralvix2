<?php

namespace App\Jobs;

use App\Models\Invoice;
use App\Models\Service;
use App\Models\Setting;
use App\Services\ProvisioningService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class TerminateOverdueServices implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 3;

    public function handle(ProvisioningService $provisioningService): void
    {
        Log::info('Starting automatic termination of overdue suspended services');

        $dueColumn = Schema::hasColumn('invoices', 'date_due') ? 'date_due' : 'due_date';
        $terminated = 0;

        $services = Service::query()
            ->where('status', 'suspended')
            ->where('override_auto_terminate', false)
            ->with(['client', 'server'])
            ->get();

        foreach ($services as $service) {
            $days = $this->resolveTerminateDays($service->company_id);

            if ($days <= 0) {
                continue;
            }

            if (!$this->clientHasOverdueInvoices($service, $dueColumn)) {
                continue;
            }

            $suspendedAt = $this->resolveSuspendedAt($service);
            if ($suspendedAt->diffInDays(now()) < $days) {
                continue;
            }

            try {
                $provisioningService->terminate($service);
                $terminated++;

                Log::info('Service terminated automatically', [
                    'service_id' => $service->id,
                    'client_id' => $service->client_id,
                    'days_suspended' => $suspendedAt->diffInDays(now()),
                ]);
            } catch (\Throwable $e) {
                Log::error('Failed to terminate service', [
                    'service_id' => $service->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        Log::info('Finished automatic termination', ['services_terminated' => $terminated]);
    }

    private function resolveTerminateDays(int $companyId): int
    {
        $fromDb = Setting::where('company_id', $companyId)
            ->where('group', 'billing')
            ->where('key', 'auto_terminate_days')
            ->value('value');

        if ($fromDb !== null && $fromDb !== '') {
            return max(0, (int) $fromDb);
        }

        return max(0, (int) config('centralvix.auto_terminate_days', 30));
    }

    private function clientHasOverdueInvoices(Service $service, string $dueColumn): bool
    {
        return Invoice::where('client_id', $service->client_id)
            ->whereIn('status', ['unpaid', 'overdue'])
            ->whereDate($dueColumn, '<', now()->startOfDay())
            ->exists();
    }

    private function resolveSuspendedAt(Service $service): Carbon
    {
        $fromModule = $service->module_data['suspended_at'] ?? null;

        if ($fromModule) {
            return Carbon::parse($fromModule);
        }

        return Carbon::parse($service->updated_at);
    }
}
