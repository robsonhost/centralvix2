<?php

namespace App\Jobs;

use App\Models\Company;
use App\Models\Setting;
use App\Services\CurrencyService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class UpdateExchangeRates implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 120;
    public int $tries = 1;

    public function handle(CurrencyService $currency): void
    {
        Company::where('status', 'active')->get()->each(function (Company $company) use ($currency) {
            $companyId = (int) $company->id;

            if (!$currency->isEnabled($companyId)) {
                return;
            }

            $cfg = $currency->config($companyId);
            if (!($cfg['auto_exchange'] ?? true)) {
                return;
            }

            $interval = (int) ($cfg['update_interval_hours'] ?? 24);
            $lastUpdate = Setting::get($companyId, 'currency_rates', 'updated_at');
            if ($lastUpdate && now()->diffInHours(\Illuminate\Support\Carbon::parse($lastUpdate)) < max(1, $interval)) {
                return;
            }

            $base = $currency->baseCurrency($companyId);
            $targets = array_diff($currency->enabledCurrencies($companyId), [$base]);

            foreach ($targets as $target) {
                $rate = $this->fetchRate($target, $base);
                if ($rate !== null) {
                    $currency->setRate($companyId, $target, $rate);
                }
            }

            Setting::set($companyId, 'currency_rates', 'updated_at', now()->toIso8601String(), 'string');
        });
    }

    /**
     * Busca quantas unidades da moeda BASE valem 1 unidade da moeda alvo.
     * Ex.: target USD, base BRL => par USD-BRL (ex.: 5.20).
     */
    private function fetchRate(string $target, string $base): ?float
    {
        try {
            $pair = strtoupper($target) . '-' . strtoupper($base);
            $response = Http::timeout(15)->get("https://economia.awesomeapi.com.br/last/{$pair}");

            if (!$response->successful()) {
                return null;
            }

            $key = strtoupper($target) . strtoupper($base);
            $bid = $response->json("{$key}.bid");

            return is_numeric($bid) ? (float) $bid : null;
        } catch (\Throwable $e) {
            Log::warning("Câmbio {$target}->{$base}: " . $e->getMessage());
            return null;
        }
    }
}
