<?php

namespace App\Jobs;

use App\Services\License\CentralVixLicenseService;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;

class VerifyCentralVixLicenses
{
    use Queueable;

    public function handle(CentralVixLicenseService $licenseService): void
    {
        try {
            $licenseService->verifyAllCompanies();
        } catch (\Throwable $e) {
            Log::error('VerifyCentralVixLicenses failed', ['error' => $e->getMessage()]);
        }
    }
}
