<?php

namespace App\Jobs;

use App\Models\Cart;
use App\Services\ModuleService;
use App\Services\ModuleSettingsService;
use App\Services\NotificationService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessAbandonedCarts implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(
        ModuleService $modules,
        ModuleSettingsService $moduleSettings,
        NotificationService $notifications,
    ): void {
        $sent = 0;

        Cart::query()
            ->where('status', 'active')
            ->whereHas('items')
            ->whereHas('client')
            ->with(['client', 'items.product'])
            ->chunkById(50, function ($carts) use ($modules, $moduleSettings, $notifications, &$sent) {
                foreach ($carts as $cart) {
                    if (!$modules->isEnabled($cart->company_id, 'abandoned_cart')) {
                        continue;
                    }

                    $cfg = $moduleSettings->all($cart->company_id, 'abandoned_cart');
                    $delayHours = max(1, (int) ($cfg['delay_hours'] ?? 2));
                    $maxAttempts = max(1, (int) ($cfg['max_attempts'] ?? 3));

                    if ($cart->reminder_count >= $maxAttempts) {
                        continue;
                    }

                    $inactiveSince = $cart->last_activity_at ?? $cart->updated_at;
                    if ($inactiveSince->diffInHours(now()) < $delayHours) {
                        continue;
                    }

                    if ($cart->abandoned_notified_at && $cart->abandoned_notified_at->isToday()) {
                        continue;
                    }

                    $client = $cart->client;
                    if (!$client?->email) {
                        continue;
                    }

                    try {
                        $productNames = $cart->items->map(fn ($i) => $i->product?->name)->filter()->implode(', ');
                        $notifications->sendEmail($client, 'abandoned_cart', [
                            'client_name' => $client->firstname ?? $client->display_name,
                            'products' => $productNames ?: 'seu pedido',
                            'cart_url' => route('client.orders.create'),
                            'discount' => $cfg['discount_percent'] ?? 0,
                        ]);

                        $cart->update([
                            'abandoned_notified_at' => now(),
                            'reminder_count' => $cart->reminder_count + 1,
                        ]);

                        $sent++;
                    } catch (\Throwable $e) {
                        Log::error('Abandoned cart notification failed', [
                            'cart_id' => $cart->id,
                            'error' => $e->getMessage(),
                        ]);
                    }
                }
            });

        Log::info('ProcessAbandonedCarts finished', ['notifications_sent' => $sent]);
    }
}
