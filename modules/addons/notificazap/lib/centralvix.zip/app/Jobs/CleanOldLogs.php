<?php

namespace App\Jobs;

use App\Models\ActivityLog;
use App\Models\NotificationLog;
use App\Models\WhatsappMessage;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CleanOldLogs implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        private readonly int $keepDays = 90
    ) {
        $this->onQueue('default');
    }

    public function handle(): void
    {
        $cutoff = now()->subDays($this->keepDays);

        // Clean notification logs
        $nlCount = NotificationLog::where('created_at', '<', $cutoff)->delete();
        Log::info("CleanOldLogs: removed {$nlCount} notification logs older than {$this->keepDays} days.");

        // Clean delivered/read WhatsApp messages (keep failed for review)
        $waCount = WhatsappMessage::where('created_at', '<', $cutoff)
            ->whereIn('status', ['delivered', 'read', 'sent'])
            ->delete();
        Log::info("CleanOldLogs: removed {$waCount} WhatsApp messages.");

        // Clean email logs
        $elCount = \App\Models\EmailLog::where('created_at', '<', $cutoff)
            ->where('status', 'sent')
            ->delete();
        Log::info("CleanOldLogs: removed {$elCount} email logs.");

        // Clean expired auto-login tokens
        $altCount = \App\Models\AutoLoginToken::where('expires_at', '<', $cutoff)->delete();
        Log::info("CleanOldLogs: removed {$altCount} expired auto-login tokens.");

        // Clean AI interactions older than 180 days
        $aiCount = \App\Models\AiInteraction::where('created_at', '<', now()->subDays(180))->delete();
        Log::info("CleanOldLogs: removed {$aiCount} AI interactions.");
    }
}
