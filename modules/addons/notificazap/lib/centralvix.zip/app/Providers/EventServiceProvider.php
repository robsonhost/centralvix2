<?php

namespace App\Providers;

use Illuminate\Auth\Events\Login;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event to listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],

        // Domain Events - New Event-Driven Architecture (Requirement 63.1)
        \App\Events\ServiceProvisioned::class => [
            \App\Listeners\LogServiceProvisioned::class,
            \App\Listeners\SendServiceProvisionedNotification::class,
        ],

        \App\Events\ServiceSuspended::class => [
            \App\Listeners\LogServiceSuspension::class,
            \App\Listeners\SendServiceSuspendedNotification::class,
        ],

        \App\Events\ServiceReactivated::class => [
            \App\Listeners\LogServiceReactivation::class,
            \App\Listeners\SendServiceReactivatedNotification::class,
        ],

        \App\Events\InvoicePaid::class => [
            \App\Listeners\ProvisionServicesOnInvoicePaid::class,
            \App\Listeners\LogInvoicePaid::class,
            \App\Listeners\SendInvoicePaidNotification::class,
            \App\Listeners\CheckServiceReactivationEligibility::class,
            \App\Listeners\TriggerWebhookForInvoicePaid::class,
            \App\Listeners\ProcessAffiliateCommission::class,
            \App\Listeners\ProcessDomainRenewalOnPayment::class,
        ],

        \App\Events\InvoiceGenerated::class => [
            \App\Listeners\LogInvoiceGenerated::class,
            \App\Listeners\SendInvoiceGeneratedNotification::class,
            \App\Listeners\TriggerWebhookForInvoiceGenerated::class,
        ],

        // Legacy Client Events (to be migrated)
        'App\Events\ClientRegistered' => [
            'App\Listeners\SendWelcomeEmail',
            'App\Listeners\CreateDefaultClientSettings',
        ],

        // Legacy Invoice Events (to be migrated)
        'App\Events\InvoiceOverdue' => [
            'App\Listeners\SuspendServices',
            'App\Listeners\SendOverdueNotification',
        ],

        // Legacy Service Events (to be migrated)
        'App\Events\ServiceCreated' => [
            'App\Listeners\ProvisionService',
            'App\Listeners\SendServiceCreatedEmail',
        ],

        'App\Events\ServiceTerminated' => [
            'App\Listeners\TerminateServiceOnServer',
            'App\Listeners\SendServiceTerminatedEmail',
        ],

        // Legacy Ticket Events
        'App\Events\TicketCreated' => [
            'App\Listeners\NotifyAdminsNewTicket',
            'App\Listeners\SendTicketCreatedEmail',
        ],

        'App\Events\TicketReplied' => [
            'App\Listeners\NotifyTicketReply',
        ],

        // Legacy Payment Events
        'App\Events\PaymentReceived' => [
            'App\Listeners\ProcessPayment',
            'App\Listeners\SendPaymentConfirmation',
        ],

        // Legacy Security Events
        'App\Events\LoginAttemptFailed' => [
            'App\Listeners\IncrementFailedLogins',
        ],

        'App\Events\IpBlocked' => [
            'App\Listeners\SendIpBlockedAlert',
        ],
    ];

    /**
     * Register any events for your application.
     */
    public function boot(): void
    {
        // Registra o último acesso do usuário ao efetuar login.
        // Guarda o acesso ANTERIOR na sessão para exibir no painel
        // ("último acesso") sem precisar de coluna adicional.
        Event::listen(Login::class, function (Login $event) {
            $user = $event->user;

            if (!$user instanceof \App\Models\User) {
                return;
            }

            try {
                if ($user->last_login_at) {
                    session(['previous_login_at' => $user->last_login_at->toISOString()]);
                    session(['previous_login_ip' => $user->last_login_ip]);
                }

                $user->forceFill([
                    'last_login_at' => now(),
                    'last_login_ip' => request()->ip(),
                ])->saveQuietly();
            } catch (\Throwable $e) {
                // Não deve bloquear o login por falha no registro de acesso.
            }
        });
    }

    /**
     * Determine if events and listeners should be automatically discovered.
     */
    public function shouldDiscoverEvents(): bool
    {
        return false;
    }
}
