<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        // Define custom gates
        Gate::define('manage-users', function ($user) {
            return $user->hasPermissionTo('manage_users');
        });

        Gate::define('manage-clients', function ($user) {
            return $user->hasPermissionTo('manage_clients');
        });

        Gate::define('manage-services', function ($user) {
            return $user->hasPermissionTo('manage_services');
        });

        Gate::define('manage-invoices', function ($user) {
            return $user->hasPermissionTo('manage_invoices');
        });

        Gate::define('manage-tickets', function ($user) {
            return $user->hasPermissionTo('manage_tickets');
        });

        Gate::define('manage-settings', function ($user) {
            return $user->hasPermissionTo('manage_settings');
        });

        Gate::define('view-reports', function ($user) {
            return $user->hasPermissionTo('view_reports');
        });

        Gate::define('manage-products', function ($user) {
            return $user->hasPermissionTo('manage_products');
        });

        Gate::define('manage-domains', function ($user) {
            return $user->hasPermissionTo('manage_domains');
        });

        Gate::define('manage-servers', function ($user) {
            return $user->hasPermissionTo('manage_servers');
        });

        Gate::define('super-admin', function ($user) {
            return $user->hasRole('Super Admin');
        });
    }
}
