<?php

namespace App\Providers;

use App\Services\Logging\SentryService;
use Illuminate\Support\ServiceProvider;

/**
 * SentryServiceProvider
 * 
 * Requirement 65.3: Configure Sentry for error tracking and monitoring
 * 
 * This service provider binds the SentryService to the container
 * and initializes Sentry integration for the application.
 */
class SentryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        // Bind SentryService as singleton
        $this->app->singleton(SentryService::class, function ($app) {
            return new SentryService();
        });

        // Alias for easier access
        $this->app->alias(SentryService::class, 'sentry.service');
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        if (!$this->isSentryAvailable() || empty(config('sentry.dsn'))) {
            return;
        }

        $this->configureSentryIntegration();
    }

    protected function isSentryAvailable(): bool
    {
        return class_exists(\Sentry\SentrySdk::class);
    }

    /**
     * Configure Sentry integration with Laravel
     */
    protected function configureSentryIntegration(): void
    {
        // Set release version if available
        if ($release = config('sentry.release')) {
            \Sentry\configureScope(function (\Sentry\State\Scope $scope) use ($release): void {
                $scope->setTag('release', $release);
            });
        }

        // Set environment
        if ($environment = config('sentry.environment')) {
            \Sentry\configureScope(function (\Sentry\State\Scope $scope) use ($environment): void {
                $scope->setTag('environment', $environment);
            });
        }

        // Add application context
        \Sentry\configureScope(function (\Sentry\State\Scope $scope): void {
            $scope->setContext('app', [
                'name' => config('app.name'),
                'url' => config('app.url'),
                'locale' => config('app.locale'),
                'timezone' => config('app.timezone'),
            ]);
        });
    }
}

