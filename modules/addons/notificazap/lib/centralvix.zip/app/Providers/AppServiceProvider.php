<?php

namespace App\Providers;

use App\Models\Client;
use App\Models\Invoice;
use App\Models\Product;
use App\Models\Server;
use App\Models\Service;
use App\Models\Setting;
use App\Observers\ClientObserver;
use App\Observers\InvoiceObserver;
use App\Observers\InvoiceRechargeObserver;
use App\Observers\ProductObserver;
use App\Observers\ServerObserver;
use App\Observers\ServiceObserver;
use App\Observers\SettingObserver;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Laravel\Horizon\Horizon;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        if (file_exists(app_path('helpers.php'))) {
            require_once app_path('helpers.php');
        }

        // Register SentryService as singleton (Requirement 65.3)
        $this->app->singleton(\App\Services\Logging\SentryService::class);

        // Backup requires php-zip (ZipArchive); skip on servers without the extension
        if (class_exists(\ZipArchive::class)) {
            $this->app->register(\Spatie\Backup\BackupServiceProvider::class);
        }

        // Sentry SDK optional — only register when vendor package is installed
        if (class_exists(\Sentry\Laravel\ServiceProvider::class)) {
            $this->app->register(\Sentry\Laravel\ServiceProvider::class);
            $this->app->register(\Sentry\Laravel\Tracing\ServiceProvider::class);
        }
    }

    public function boot(): void
    {
        Paginator::useBootstrapFive();
        
        // Register observers for automatic cache invalidation (Requirement 64.3)
        Product::observe(ProductObserver::class);
        Setting::observe(SettingObserver::class);
        Client::observe(ClientObserver::class);
        Invoice::observe(InvoiceObserver::class);
        Invoice::observe(InvoiceRechargeObserver::class);
        Service::observe(ServiceObserver::class);
        Server::observe(ServerObserver::class);

        // Configure Horizon authorization
        Horizon::auth(function ($request) {
            return auth()->check() && auth()->user()->isAdmin();
        });

        // Share company settings + branding with all views
        View::composer(['admin.*', 'admin.**', 'client.*', 'client.**', 'auth.*', 'layouts.*'], function ($view) {
            $companyId = auth()->user()?->company_id;

            if ($companyId) {
                $view->with('_companySettings', cache()->remember(
                    "company_settings_{$companyId}",
                    300,
                    fn () => Setting::where('company_id', $companyId)
                        ->get()
                        ->keyBy(fn ($s) => "{$s->group}.{$s->key}")
                ));
            }

            $view->with('branding', app(\App\Services\BrandingService::class)->get($companyId));
        });

        // Sidebar + navbar do cliente: cliente resolvido e flags de módulos.
        View::composer('client.layouts.app', function ($view) {
            $unpaidCount = 0;
            $client = null;
            $consultasEnabled = false;
            $apiAccessEnabled = false;
            $clientWalletEnabled = false;

            try {
                $user = auth()->user();
                if ($user) {
                    $client = $user->resolveClient();
                    $companyId = (int) ($client?->company_id ?? $user->company_id ?? 0);

                    if ($client) {
                        $unpaidCount = (int) $client->invoices()
                            ->whereIn('status', ['unpaid', 'overdue', 'pending'])
                            ->count();
                    }

                    if ($companyId > 0) {
                        $modules = app(\App\Services\ModuleService::class);
                        $consultasEnabled = consultas_available($companyId);
                        $apiAccessEnabled = $modules->isEnabled($companyId, 'api_access');
                        $clientWalletEnabled = $modules->isEnabled($companyId, 'client_wallet');
                    }
                }
            } catch (\Throwable $e) {
                // mantém defaults seguros
            }

            $view->with([
                'unpaidCount' => $unpaidCount,
                'client' => $client,
                'consultasEnabled' => $consultasEnabled,
                'apiAccessEnabled' => $apiAccessEnabled,
                'clientWalletEnabled' => $clientWalletEnabled,
                'clientBalance' => (float) ($client?->credit_balance ?? 0),
            ]);
        });
    }
}
