<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class LoginAttempt extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'ip_address',
        'email',
        'successful',
        'user_agent',
        'details',
        'attempted_at',
        'blocked_until',
    ];

    protected $casts = [
        'successful' => 'boolean',
        'attempted_at' => 'datetime',
        'blocked_until' => 'datetime',
    ];

    /**
     * Check if IP is blocked
     */
    public static function isBlocked(string $ip): bool
    {
        $attempt = static::where('ip_address', $ip)
            ->whereNotNull('blocked_until')
            ->where('blocked_until', '>', now())
            ->first();

        return $attempt !== null;
    }

    /**
     * Get blocked until time for IP
     */
    public static function getBlockedUntil(string $ip): ?Carbon
    {
        $attempt = static::where('ip_address', $ip)
            ->whereNotNull('blocked_until')
            ->where('blocked_until', '>', now())
            ->first();

        return $attempt?->blocked_until;
    }

    /**
     * Record login attempt
     */
    public static function record(string $ip, ?string $email, bool $successful): void
    {
        static::create([
            'ip_address' => $ip,
            'email' => $email,
            'successful' => $successful,
            'user_agent' => request()->userAgent(),
            'attempted_at' => now(),
        ]);

        // Check for multiple failed attempts
        if (!$successful) {
            $failedAttempts = static::where('ip_address', $ip)
                ->where('successful', false)
                ->where('attempted_at', '>', now()->subMinutes(15))
                ->count();

            if ($failedAttempts >= 3) {
                static::blockIp($ip);
            }
        }
    }

    /**
     * Block IP for 30 minutes
     */
    public static function blockIp(string $ip, int $minutes = 30): void
    {
        static::create([
            'ip_address' => $ip,
            'successful' => false,
            'blocked_until' => now()->addMinutes($minutes),
            'user_agent' => request()->userAgent(),
            'details' => 'IP bloqueado por múltiplas tentativas falhadas',
            'attempted_at' => now(),
        ]);
    }

    /**
     * Unblock IP
     */
    public static function unblockIp(string $ip): void
    {
        static::where('ip_address', $ip)
            ->whereNotNull('blocked_until')
            ->update(['blocked_until' => null]);
    }

    /**
     * Get failed attempts for IP in last 15 minutes
     */
    public static function getRecentFailedAttempts(string $ip): int
    {
        return static::where('ip_address', $ip)
            ->where('successful', false)
            ->where('attempted_at', '>', now()->subMinutes(15))
            ->count();
    }
}
