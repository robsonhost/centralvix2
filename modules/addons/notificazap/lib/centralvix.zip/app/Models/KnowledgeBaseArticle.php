<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class KnowledgeBaseArticle extends Model
{
    protected $table = 'knowledge_base_articles';
    
    protected $fillable = [
        'company_id',
        'category_id',
        'author_id',
        'title',
        'slug',
        'content',
        'summary',
        'tags',
        'views',
        'helpful_count',
        'not_helpful_count',
        'published',
        'featured',
        'order',
        'seo_title',
        'seo_description',
        'seo_keywords',
    ];

    protected $casts = [
        'views' => 'integer',
        'helpful_count' => 'integer',
        'not_helpful_count' => 'integer',
        'published' => 'boolean',
        'featured' => 'boolean',
        'order' => 'integer',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(KnowledgeBaseCategory::class, 'category_id');
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'author_id');
    }

    public function scopePublished($query)
    {
        return $query->where('status', 'published');
    }

    public function scopeFeatured($query)
    {
        return $query->where('featured', true);
    }

    public function incrementViews()
    {
        $this->increment('views');
    }

    public function markAsHelpful()
    {
        $this->increment('helpful_count');
    }

    public function markAsNotHelpful()
    {
        $this->increment('not_helpful_count');
    }
}
