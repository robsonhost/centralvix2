<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'department_id',
        'assigned_to',
        'subject',
        'status',
        'priority',
        'service_id',
        'closed_at',
        'last_reply_at',
    ];

    protected $casts = [
        'closed_at' => 'datetime',
        'last_reply_at' => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
        });

        static::updated(function (self $ticket) {
            if ($ticket->wasChanged('status') && $ticket->status === 'closed') {
                try {
                    app(\App\Services\SatisfactionSurveyService::class)->onTicketClosed($ticket);
                } catch (\Throwable $e) {
                    // Nunca interromper o fechamento de ticket por causa da pesquisa.
                }
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function department(): BelongsTo
    {
        return $this->belongsTo(TicketDepartment::class, 'department_id');
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(Service::class);
    }

    public function replies(): HasMany
    {
        return $this->hasMany(TicketReply::class)->orderBy('created_at');
    }

    public function attachments(): HasMany
    {
        return $this->hasMany(TicketAttachment::class);
    }

    public function getLastReplyAttribute(): ?TicketReply
    {
        return $this->replies()->latest()->first();
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'open' => 'Aberto',
            'answered' => 'Respondido',
            'client_reply' => 'Aguardando',
            'closed' => 'Fechado',
            'on_hold' => 'Em espera',
            default => ucfirst($this->status),
        };
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'open' => 'success',
            'answered' => 'info',
            'client_reply' => 'warning',
            'closed' => 'secondary',
            'on_hold' => 'dark',
            default => 'secondary',
        };
    }

    public function getPriorityBadgeAttribute(): string
    {
        return match ($this->priority) {
            'low' => 'secondary',
            'medium' => 'info',
            'high' => 'warning',
            'urgent' => 'danger',
            default => 'secondary',
        };
    }

    public function close(): void
    {
        $this->update(['status' => 'closed', 'closed_at' => now()]);
    }
}
