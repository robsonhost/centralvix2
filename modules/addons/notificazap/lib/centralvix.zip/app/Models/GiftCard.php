<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class GiftCard extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'code',
        'initial_value',
        'balance',
        'status',
        'expires_at',
        'redeemed_by',
        'redeemed_at',
        'created_by',
        'notes',
    ];

    protected $casts = [
        'initial_value' => 'decimal:2',
        'balance' => 'decimal:2',
        'expires_at' => 'date',
        'redeemed_at' => 'datetime',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function redeemer(): BelongsTo
    {
        return $this->belongsTo(Client::class, 'redeemed_by');
    }

    public function scopeForCompany(Builder $query, int $companyId): Builder
    {
        return $query->where('company_id', $companyId);
    }

    public function isExpired(): bool
    {
        return $this->expires_at && $this->expires_at->isPast();
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'active' => 'success',
            'redeemed' => 'primary',
            'expired' => 'warning',
            'cancelled' => 'secondary',
            default => 'secondary',
        };
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'active' => 'Ativo',
            'redeemed' => 'Resgatado',
            'expired' => 'Expirado',
            'cancelled' => 'Cancelado',
            default => ucfirst($this->status),
        };
    }
}
