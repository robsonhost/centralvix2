<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ConsultaType extends Model
{
    use HasFactory;

    protected $fillable = [
        'slug',
        'name',
        'description',
        'category',
        'icon',
        'accent',
        'api_provider',
        'api_endpoint',
        'api_config',
        'cost_price',
        'sale_price',
        'active',
        'sort_order',
    ];

    protected $casts = [
        'api_config' => 'array',
        'cost_price' => 'decimal:4',
        'sale_price' => 'decimal:4',
        'active'     => 'boolean',
        'sort_order' => 'integer',
    ];

    public function logs(): HasMany
    {
        return $this->hasMany(ConsultaLog::class);
    }

    public function getMarginAttribute(): float
    {
        return round((float) $this->sale_price - (float) $this->cost_price, 4);
    }

    public function getCategoryLabelAttribute(): string
    {
        return match ($this->category) {
            'pessoas'  => 'Pessoas',
            'empresas' => 'Empresas',
            'score'    => 'Score e Crédito',
            default    => 'Outras',
        };
    }

    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

    public function scopeCategory($query, string $category)
    {
        return $query->where('category', $category);
    }
}
