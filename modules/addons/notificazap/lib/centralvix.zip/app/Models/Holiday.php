<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Holiday extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'date',
        'type',
        'state_code',
        'city_name',
        'recurring',
        'recurring_rule',
        'adjusts_due_date',
        'adjustment_days',
        'is_active',
        'notes',
    ];

    protected $casts = [
        'date' => 'date',
        'recurring' => 'boolean',
        'adjusts_due_date' => 'boolean',
        'is_active' => 'boolean',
        'adjustment_days' => 'integer',
    ];

    // Relationships
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeForDate($query, $date)
    {
        return $query->whereDate('date', $date);
    }

    public function scopeNational($query)
    {
        return $query->where('type', 'national');
    }

    public function scopeForState($query, string $stateCode)
    {
        return $query->where('state_code', $stateCode);
    }

    public function scopeForCity($query, string $cityName)
    {
        return $query->where('city_name', $cityName);
    }
}
