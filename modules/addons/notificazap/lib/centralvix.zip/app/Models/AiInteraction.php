<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AiInteraction extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id', 'client_id', 'provider', 'model', 'context_type',
        'context_id', 'prompt', 'response', 'tokens_used', 'cost_usd', 'status', 'error',
    ];

    protected $casts = [
        'tokens_used' => 'integer',
        'cost_usd'    => 'decimal:6',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }
}
