<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Referral extends Model
{
    protected $fillable = [
        'uuid',
        'referrer_id',
        'referred_id',
        'ip_address',
        'user_agent',
        'converted_at',
        'metadata',
    ];

    protected $casts = [
        'converted_at' => 'datetime',
        'metadata' => 'array',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($referral) {
            if (empty($referral->uuid)) {
                $referral->uuid = (string) Str::uuid();
            }
        });
    }

    // Relationships
    public function referrer(): BelongsTo
    {
        return $this->belongsTo(Client::class, 'referrer_id');
    }

    public function referred(): BelongsTo
    {
        return $this->belongsTo(Client::class, 'referred_id');
    }

    public function services(): HasMany
    {
        return $this->hasMany(Service::class, 'referral_id');
    }

    public function commissions(): HasMany
    {
        return $this->hasMany(Commission::class);
    }

    // Helpers
    public function isConverted(): bool
    {
        return !is_null($this->converted_at);
    }

    public function markAsConverted(): void
    {
        $this->update(['converted_at' => now()]);
    }
}
