<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrderStatus extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'slug',
        'color',
        'description',
        'is_default',
        'send_email',
        'email_template',
        'active',
        'order',
    ];

    protected $casts = [
        'is_default' => 'boolean',
        'send_email' => 'boolean',
        'active' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }
}
