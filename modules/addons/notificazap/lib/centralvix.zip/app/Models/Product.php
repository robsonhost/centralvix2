<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'group_id',
        'name',
        'slug',
        'description',
        'short_description',
        'type',
        'module',
        'module_config',
        'price_monthly',
        'price_quarterly',
        'price_semiannually',
        'price_annually',
        'price_biennially',
        'price_triennially',
        'price_lifetime',
        'setup_fee',
        'stock',
        'stock_unlimited',
        'tax_class',
        'status',
        'order',
        'featured',
        'is_addon',
    ];

    protected $casts = [
        'module_config' => 'array',
        'price_monthly' => 'decimal:2',
        'price_quarterly' => 'decimal:2',
        'price_semiannually' => 'decimal:2',
        'price_annually' => 'decimal:2',
        'price_biennially' => 'decimal:2',
        'price_triennially' => 'decimal:2',
        'price_lifetime' => 'decimal:2',
        'setup_fee' => 'decimal:2',
        'stock_unlimited' => 'boolean',
        'featured' => 'boolean',
        'is_addon' => 'boolean',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
            if (empty($model->slug)) {
                $model->slug = Str::slug($model->name);
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function group(): BelongsTo
    {
        return $this->belongsTo(ProductGroup::class, 'group_id');
    }

    public function features(): HasMany
    {
        return $this->hasMany(ProductFeature::class)->orderBy('order');
    }

    public function services(): HasMany
    {
        return $this->hasMany(Service::class);
    }

    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function getPriceForCycle(string $cycle): float
    {
        return match ($cycle) {
            'monthly' => (float) $this->price_monthly,
            'quarterly' => (float) $this->price_quarterly,
            'semiannually' => (float) $this->price_semiannually,
            'annually' => (float) $this->price_annually,
            'biennially' => (float) $this->price_biennially,
            'triennially' => (float) $this->price_triennially,
            'lifetime' => (float) $this->price_lifetime,
            default => (float) $this->price_monthly,
        };
    }

    public function isAvailable(): bool
    {
        if ($this->status !== 'active') {
            return false;
        }
        if (!$this->stock_unlimited && $this->stock <= 0) {
            return false;
        }
        return true;
    }

    public function getTypeLabel(): string
    {
        return match ($this->type) {
            'hosting' => 'Hospedagem',
            'reseller' => 'Reseller',
            'vps' => 'VPS',
            'dedicated' => 'Dedicado',
            'domain' => 'Domínio',
            'ssl' => 'SSL',
            'email' => 'E-mail',
            'saas' => 'SaaS',
            'license' => 'Licença',
            'streaming_audio' => 'Streaming Áudio',
            'streaming_video' => 'Streaming Vídeo',
            'custom' => 'Personalizado',
            default => ucfirst($this->type),
        };
    }
}
