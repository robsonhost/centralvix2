<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Webhook extends Model
{
    protected $fillable = [
        'company_id',
        'url',
        'events',
        'secret',
        'status',
        'last_sent_at',
    ];

    protected $hidden = ['secret'];

    protected $casts = [
        'events' => 'array',
        'last_sent_at' => 'datetime',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function logs(): HasMany
    {
        return $this->hasMany(WebhookLog::class);
    }

    public function shouldReceive(string $event): bool
    {
        return in_array('*', $this->events) || in_array($event, $this->events);
    }
}
