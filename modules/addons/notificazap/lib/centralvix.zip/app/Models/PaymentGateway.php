<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PaymentGateway extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'module',
        'display_name',
        'settings',
        'status',
        'order',
        'test_mode',
    ];

    protected $casts = [
        'settings' => 'encrypted:array',
        'test_mode' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isTestMode(): bool
    {
        return (bool) $this->test_mode;
    }

    public function getSetting(string $key, mixed $default = null): mixed
    {
        return $this->settings[$key] ?? $default;
    }

    /** @return array<string, array{label: string, description: string, icon: string}> */
    public function checkoutMethods(): array
    {
        $module = strtolower((string) $this->module);
        $name   = $this->display_name ?: $this->name ?: strtoupper($module);

        $pagHiperMethods = ['pix' => ['label' => 'PIX via PagHiper', 'description' => 'QR Code · confirmação em segundos', 'icon' => 'qrcode']];
        if (!$this->getSetting('disable_boleto', false)) {
            $pagHiperMethods['boleto'] = ['label' => 'Boleto via PagHiper', 'description' => 'PDF + linha digitável · 1–3 dias úteis', 'icon' => 'barcode'];
        }

        return match ($module) {
            'paghiper' => $pagHiperMethods,
            'credit', 'saldo', 'credit_balance' => [
                'credit' => ['label' => 'Saldo em Conta', 'description' => 'Debita do crédito disponível', 'icon' => 'wallet'],
            ],
            'pix', 'c6bank', 'c6_bank' => [
                'pix' => ['label' => $name, 'description' => 'Pagamento instantâneo via PIX', 'icon' => 'qrcode'],
            ],
            'boleto' => [
                'boleto' => ['label' => $name, 'description' => 'Boleto bancário', 'icon' => 'barcode'],
            ],
            'asaas' => [
                'pix'    => ['label' => $name . ' — PIX', 'description' => 'PIX instantâneo', 'icon' => 'qrcode'],
                'boleto' => ['label' => $name . ' — Boleto', 'description' => 'Boleto bancário', 'icon' => 'barcode'],
            ],
            default => [
                'default' => ['label' => $name, 'description' => 'Pagamento seguro', 'icon' => 'credit-card'],
            ],
        };
    }
}
