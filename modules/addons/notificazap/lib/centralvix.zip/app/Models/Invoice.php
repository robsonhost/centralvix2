<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Invoice extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'order_id',
        'invoice_number',
        'status',
        'subtotal',
        'discount',
        'tax',
        'late_fee',
        'interest',
        'late_fee_updated_at',
        'total',
        'amount_paid',
        'currency',
        'exchange_rate',
        'date_created',
        'date_due',
        'date_paid',
        'payment_method',
        'payment_gateway',
        'transaction_id',
        'notes',
        'admin_notes',
        'pdf_path',
    ];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'discount' => 'decimal:2',
        'tax' => 'decimal:2',
        'late_fee' => 'decimal:2',
        'interest' => 'decimal:2',
        'total' => 'decimal:2',
        'amount_paid' => 'decimal:2',
        'exchange_rate' => 'decimal:6',
        'date_created' => 'date',
        'date_due' => 'date',
        'date_paid' => 'datetime',
        'late_fee_updated_at' => 'datetime',
    ];

    /**
     * Valor da fatura antes de quaisquer encargos de atraso (multa + juros).
     */
    public function getBaseAmountAttribute(): float
    {
        return round((float) $this->total - (float) ($this->late_fee ?? 0) - (float) ($this->interest ?? 0), 2);
    }

    /**
     * Soma de multa + juros atualmente aplicados.
     */
    public function getLateChargesAttribute(): float
    {
        return round((float) ($this->late_fee ?? 0) + (float) ($this->interest ?? 0), 2);
    }

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
            if (empty($model->invoice_number)) {
                $model->invoice_number = 'INV' . date('Y') . str_pad(rand(1, 999999), 6, '0', STR_PAD_LEFT);
            }
            if (empty($model->date_created)) {
                $model->date_created = now()->toDateString();
            }
        });

        static::created(function (self $invoice) {
            $invoice->fireWebhook('invoice.created');
        });
    }

    /**
     * Dados expostos nos webhooks.
     */
    public function toWebhookArray(): array
    {
        return [
            'id'             => $this->id,
            'uuid'           => $this->uuid,
            'invoice_number' => $this->invoice_number,
            'client_id'      => $this->client_id,
            'status'         => $this->status,
            'subtotal'       => (float) $this->subtotal,
            'discount'       => (float) $this->discount,
            'tax'            => (float) $this->tax,
            'late_fee'       => (float) ($this->late_fee ?? 0),
            'interest'       => (float) ($this->interest ?? 0),
            'total'          => (float) $this->total,
            'date_due'       => optional($this->date_due)->toDateString(),
            'date_paid'      => optional($this->date_paid)->toIso8601String(),
        ];
    }

    public function fireWebhook(string $event): void
    {
        try {
            if (!$this->company_id) {
                return;
            }
            app(\App\Services\WebhookDispatcher::class)->event($this->company_id, $event, $this->toWebhookArray());
        } catch (\Throwable $e) {
            // Nunca interromper o fluxo de faturas por causa de webhook.
        }
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(InvoiceItem::class);
    }

    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class);
    }

    public function isPaid(): bool
    {
        return $this->status === 'paid';
    }

    public function isPartiallyPaid(): bool
    {
        return $this->status === 'partial'
            || ((float) ($this->amount_paid ?? 0) > 0 && !$this->isPaid());
    }

    public function getBalanceDueAttribute(): float
    {
        return max(0, round((float) $this->total - (float) ($this->amount_paid ?? 0), 2));
    }

    public function isUnpaid(): bool
    {
        return $this->status === 'unpaid';
    }

    public function isOverdue(): bool
    {
        return $this->status === 'overdue'
            || ($this->status === 'unpaid' && $this->date_due && $this->date_due->isPast());
    }

    public function markAsPaid(string $gateway = null, string $transactionId = null): void
    {
        $this->update([
            'status' => 'paid',
            'amount_paid' => $this->total,
            'date_paid' => now(),
            'payment_gateway' => $gateway,
            'transaction_id' => $transactionId,
        ]);

        $this->fireWebhook('invoice.paid');
    }

    public function applyPartialPayment(float $amount, string $gateway = null, ?string $transactionId = null): void
    {
        $paid = round((float) ($this->amount_paid ?? 0) + $amount, 2);
        $total = round((float) $this->total, 2);

        if ($paid >= $total) {
            $this->markAsPaid($gateway, $transactionId);
            return;
        }

        $this->update([
            'status' => 'partial',
            'amount_paid' => $paid,
            'payment_gateway' => $gateway ?? $this->payment_gateway,
            'transaction_id' => $transactionId ?? $this->transaction_id,
        ]);
    }

    public function getCurrencyCodeAttribute(): string
    {
        return $this->currency ?: 'BRL';
    }

    public function formatMoney(float $value): string
    {
        return app(\App\Services\CurrencyService::class)->format($value, $this->currency_code);
    }

    public function getFormattedTotalAttribute(): string
    {
        return $this->formatMoney((float) $this->total);
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'draft' => 'Rascunho',
            'unpaid' => 'Não pago',
            'paid' => 'Pago',
            'partial' => 'Parcialmente pago',
            'overdue' => 'Vencido',
            'cancelled' => 'Cancelado',
            'refunded' => 'Reembolsado',
            default => ucfirst($this->status),
        };
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'draft' => 'secondary',
            'unpaid' => 'warning',
            'paid' => 'success',
            'overdue' => 'danger',
            'cancelled' => 'secondary',
            'refunded' => 'info',
            default => 'secondary',
        };
    }
}
