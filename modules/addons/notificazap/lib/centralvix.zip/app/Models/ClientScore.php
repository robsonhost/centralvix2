<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ClientScore extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id', 'client_id',
        'total_score', 'tier',
        'payment_score', 'tenure_score', 'purchase_score',
        'ticket_score', 'fraud_score',
        'last_calculated_at',
    ];

    protected $casts = [
        'total_score'        => 'integer',
        'payment_score'      => 'integer',
        'tenure_score'       => 'integer',
        'purchase_score'     => 'integer',
        'ticket_score'       => 'integer',
        'fraud_score'        => 'integer',
        'last_calculated_at' => 'datetime',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function getTierLabelAttribute(): string
    {
        return match ($this->tier) {
            'bronze'   => '🥉 Bronze',
            'silver'   => '🥈 Prata',
            'gold'     => '🥇 Ouro',
            'platinum' => '💎 Platina',
            default    => ucfirst($this->tier ?? 'bronze'),
        };
    }

    public function getTierColorAttribute(): string
    {
        return match ($this->tier) {
            'bronze'   => '#cd7f32',
            'silver'   => '#c0c0c0',
            'gold'     => '#ffd700',
            'platinum' => '#e5e4e2',
            default    => '#6c757d',
        };
    }

    public static function calculate(Client $client): self
    {
        // Pagamentos em dia
        $paidOnTime    = $client->invoices()->where('status', 'paid')->count();
        $paymentScore  = min($paidOnTime * 10, 400);

        // Tempo de uso (em meses)
        $months        = max(1, (int) $client->created_at->diffInMonths(now()));
        $tenureScore   = min($months * 5, 200);

        // Compras (serviços contratados)
        $services       = $client->services()->count();
        $purchaseScore  = min($services * 20, 200);

        // Tickets (penalidades por excesso de tickets abertos)
        $openTickets   = $client->tickets()->where('status', 'open')->count();
        $ticketScore   = max(-50, $openTickets * -5);

        // Fraud score (de fraud_flags se existir)
        $fraudScore    = 0;

        $totalScore = $paymentScore + $tenureScore + $purchaseScore + $ticketScore + $fraudScore;

        $tier = match (true) {
            $totalScore >= 700 => 'platinum',
            $totalScore >= 500 => 'gold',
            $totalScore >= 300 => 'silver',
            default            => 'bronze',
        };

        return self::updateOrCreate(
            ['client_id' => $client->id, 'company_id' => $client->company_id],
            [
                'total_score'        => $totalScore,
                'tier'               => $tier,
                'payment_score'      => $paymentScore,
                'tenure_score'       => $tenureScore,
                'purchase_score'     => $purchaseScore,
                'ticket_score'       => $ticketScore,
                'fraud_score'        => $fraudScore,
                'last_calculated_at' => now(),
            ]
        );
    }
}
