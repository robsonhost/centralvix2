<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class ConsultaLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'consulta_type_id',
        'parameter',
        'parameter_label',
        'cost_price',
        'sale_price',
        'status',
        'result',
        'request_payload',
        'error_message',
        'ip_address',
        'user_agent',
    ];

    protected $casts = [
        'result'          => 'array',
        'request_payload' => 'array',
        'cost_price'      => 'decimal:4',
        'sale_price'      => 'decimal:4',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = (string) Str::uuid();
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(ConsultaType::class, 'consulta_type_id');
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'Pendente',
            'success' => 'Concluída',
            'failed'  => 'Erro',
            'no_data' => 'Sem dados',
            default   => 'Desconhecido',
        };
    }

    public function getStatusColorAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'secondary',
            'success' => 'success',
            'failed'  => 'danger',
            'no_data' => 'warning',
            default   => 'secondary',
        };
    }
}
