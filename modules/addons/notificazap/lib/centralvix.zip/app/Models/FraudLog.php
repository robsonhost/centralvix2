<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FraudLog extends Model
{
    protected $fillable = [
        'company_id',
        'fraud_rule_id',
        'client_id',
        'order_id',
        'action_taken',
        'ip_address',
        'country',
        'details',
    ];

    protected $casts = [
        'details' => 'array',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function fraudRule(): BelongsTo
    {
        return $this->belongsTo(FraudRule::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }
}
