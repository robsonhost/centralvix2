<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CompanyLicense extends Model
{
    protected $fillable = [
        'company_id',
        'license_key',
        'remote_license_id',
        'license_type',
        'registered_to',
        'registered_domain',
        'max_clients',
        'valid_domain',
        'valid_ip',
        'valid_directory',
        'branding_removal',
        'remote_status',
        'is_compliant',
        'compliance_message',
        'issued_at',
        'expires_at',
        'last_verified_at',
        'active',
    ];

    protected $casts = [
        'branding_removal' => 'boolean',
        'is_compliant' => 'boolean',
        'active' => 'boolean',
        'issued_at' => 'datetime',
        'expires_at' => 'datetime',
        'last_verified_at' => 'datetime',
        'max_clients' => 'integer',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function isExpired(): bool
    {
        return $this->expires_at !== null && $this->expires_at->isPast();
    }

    public function daysUntilExpiry(): ?int
    {
        if (!$this->expires_at) {
            return null;
        }

        return (int) now()->diffInDays($this->expires_at, false);
    }

    public function isBlocked(): bool
    {
        if (!$this->active) {
            return true;
        }

        if ($this->isExpired()) {
            return true;
        }

        // Período trial local (sem chave do licenciador) — admin liberado até expirar
        if ($this->remote_status === 'trial' && str_starts_with((string) $this->license_key, 'TRIAL-')) {
            return false;
        }

        if (in_array($this->remote_status, ['suspended', 'cancelled', 'expired', 'blocked'], true)) {
            return true;
        }

        return !$this->is_compliant;
    }
}
