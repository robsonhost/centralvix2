<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ClientGroup extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'description',
        'color',
        'discount_percentage',
        'active',
        'order',
    ];

    protected $casts = [
        'discount_percentage' => 'decimal:2',
        'active' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function clients(): HasMany
    {
        return $this->hasMany(Client::class, 'group_id');
    }
}
