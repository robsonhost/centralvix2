<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NfeSetting extends Model
{
    protected $fillable = [
        'company_id',
        'enabled',
        'provider',
        'environment',
        'api_token',
        'certificate_path',
        'certificate_password',
        'auto_issue',
        'serie_nfe',
        'next_number',
        'natureza_operacao',
        'regime_tributario',
        'taxes_config',
        'send_email',
    ];

    protected $casts = [
        'enabled' => 'boolean',
        'auto_issue' => 'boolean',
        'taxes_config' => 'array',
        'send_email' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function getNextNumber(): string
    {
        $number = $this->next_number;
        $this->increment('next_number');
        return str_pad($number, 9, '0', STR_PAD_LEFT);
    }

    public function isProduction(): bool
    {
        return $this->environment === 'producao';
    }
}
