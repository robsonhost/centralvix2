<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BackupSetting extends Model
{
    protected $fillable = [
        'company_id',
        'enabled',
        'frequency',
        'schedule_time',
        'retention_days',
        'backup_database',
        'backup_files',
        'backup_uploads',
        'storage_location',
        'storage_config',
        'email_notifications',
        'notification_email',
    ];

    protected $casts = [
        'enabled' => 'boolean',
        'backup_database' => 'boolean',
        'backup_files' => 'boolean',
        'backup_uploads' => 'boolean',
        'email_notifications' => 'boolean',
        'storage_config' => 'array',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }
}
