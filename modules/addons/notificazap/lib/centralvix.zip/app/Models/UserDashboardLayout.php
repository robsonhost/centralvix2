<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserDashboardLayout extends Model
{
    protected $fillable = [
        'user_id',
        'layout',
        'widget_settings',
    ];

    protected $casts = [
        'layout' => 'array',
        'widget_settings' => 'array',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
