<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class EmailCampaign extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'name',
        'subject',
        'body',
        'audience',
        'client_ids',
        'status',
        'scheduled_at',
        'total_recipients',
        'sent_count',
        'failed_count',
        'opened_count',
        'started_at',
        'completed_at',
        'created_by',
    ];

    protected $casts = [
        'client_ids' => 'array',
        'scheduled_at' => 'datetime',
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function recipients(): HasMany
    {
        return $this->hasMany(EmailCampaignRecipient::class, 'campaign_id');
    }

    public function scopeForCompany(Builder $query, int $companyId): Builder
    {
        return $query->where('company_id', $companyId);
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'draft' => 'secondary',
            'scheduled' => 'info',
            'sending' => 'warning',
            'sent' => 'success',
            'cancelled' => 'dark',
            default => 'secondary',
        };
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'draft' => 'Rascunho',
            'scheduled' => 'Agendada',
            'sending' => 'Enviando',
            'sent' => 'Enviada',
            'cancelled' => 'Cancelada',
            default => ucfirst($this->status),
        };
    }

    public function getOpenRateAttribute(): float
    {
        return $this->sent_count > 0
            ? round(($this->opened_count / $this->sent_count) * 100, 1)
            : 0.0;
    }

    public function isEditable(): bool
    {
        return in_array($this->status, ['draft', 'scheduled'], true);
    }
}
