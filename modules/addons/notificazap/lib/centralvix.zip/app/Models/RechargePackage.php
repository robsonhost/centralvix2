<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RechargePackage extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'name',
        'amount',
        'bonus',
        'highlight',
        'active',
        'sort_order',
    ];

    protected $casts = [
        'amount'    => 'decimal:2',
        'bonus'     => 'decimal:2',
        'highlight' => 'boolean',
        'active'    => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function getTotalCreditAttribute(): float
    {
        return round((float) $this->amount + (float) $this->bonus, 2);
    }

    public function getDisplayNameAttribute(): string
    {
        if ($this->name) {
            return $this->name;
        }
        return 'R$ ' . number_format((float) $this->amount, 2, ',', '.');
    }

    public function scopeActive($query)
    {
        return $query->where('active', true);
    }
}
