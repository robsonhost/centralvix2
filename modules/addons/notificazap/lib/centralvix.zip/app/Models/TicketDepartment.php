<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TicketDepartment extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'company_id',
        'name',
        'description',
        'email',
        'auto_assign',
        'hidden',
        'required_login',
        'order',
        'status',
    ];

    protected $casts = [
        'auto_assign' => 'boolean',
        'hidden' => 'boolean',
        'required_login' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class, 'department_id');
    }

    public function openTickets(): HasMany
    {
        return $this->hasMany(Ticket::class, 'department_id')->whereNotIn('status', ['closed']);
    }
}
