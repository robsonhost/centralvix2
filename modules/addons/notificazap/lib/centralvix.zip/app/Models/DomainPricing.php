<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DomainPricing extends Model
{
    protected $table = 'domain_pricing';

    protected $fillable = [
        'company_id',
        'tld',
        'register_price',
        'renew_price',
        'transfer_price',
        'min_years',
        'max_years',
        'active',
        'order',
    ];

    protected $casts = [
        'register_price' => 'decimal:2',
        'renew_price' => 'decimal:2',
        'transfer_price' => 'decimal:2',
        'active' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }
}
