<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Coupon extends Model
{
    protected $fillable = [
        'company_id',
        'code',
        'name',
        'type',
        'value',
        'max_uses',
        'uses',
        'applies_to',
        'product_ids',
        'category_ids',
        'billing_cycles',
        'clients_only',
        'new_clients_only',
        'valid_from',
        'valid_until',
        'status',
    ];

    protected $casts = [
        'value' => 'decimal:2',
        'product_ids' => 'array',
        'category_ids' => 'array',
        'billing_cycles' => 'array',
        'clients_only' => 'boolean',
        'new_clients_only' => 'boolean',
        'valid_from' => 'datetime',
        'valid_until' => 'datetime',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function isValid(): bool
    {
        if ($this->status !== 'active') return false;
        if ($this->max_uses > 0 && $this->uses >= $this->max_uses) return false;
        if ($this->valid_from && now()->lt($this->valid_from)) return false;
        if ($this->valid_until && now()->gt($this->valid_until)) return false;
        return true;
    }

    public function calculateDiscount(float $amount): float
    {
        if ($this->type === 'percentage') {
            return round($amount * ($this->value / 100), 2);
        }
        return min($this->value, $amount);
    }
}
