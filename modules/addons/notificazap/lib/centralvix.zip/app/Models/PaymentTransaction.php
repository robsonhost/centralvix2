<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PaymentTransaction extends Model
{
    protected $fillable = [
        'company_id',
        'invoice_id',
        'gateway',
        'transaction_id',
        'amount',
        'status',
        'payment_method',
        'data',
        'paid_at',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'data' => 'array',
        'paid_at' => 'datetime',
    ];

    /**
     * Relação com Company
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * Relação com Invoice
     */
    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    /**
     * Verificar se transação foi paga
     */
    public function isPaid(): bool
    {
        return $this->status === 'paid';
    }

    /**
     * Verificar se transação está pendente
     */
    public function isPending(): bool
    {
        return $this->status === 'pending';
    }

    /**
     * Marcar como paga
     */
    public function markAsPaid(): void
    {
        $this->update([
            'status' => 'paid',
            'paid_at' => now(),
        ]);
    }

    /**
     * Obter nome do gateway formatado
     */
    public function getGatewayNameAttribute(): string
    {
        return match($this->gateway) {
            'asaas' => 'ASAAS',
            'paghiper' => 'PagHiper',
            'c6bank' => 'C6 Bank PIX',
            'mercadopago' => 'Mercado Pago',
            'pagseguro' => 'PagSeguro',
            'stripe' => 'Stripe',
            'paypal' => 'PayPal',
            default => ucfirst($this->gateway),
        };
    }

    /**
     * Obter nome do método de pagamento formatado
     */
    public function getPaymentMethodNameAttribute(): string
    {
        return match($this->payment_method) {
            'pix' => 'PIX',
            'boleto' => 'Boleto',
            'credit_card' => 'Cartão de Crédito',
            'debit_card' => 'Cartão de Débito',
            default => ucfirst(str_replace('_', ' ', $this->payment_method ?? '')),
        };
    }

    /**
     * Obter badge de status
     */
    public function getStatusBadgeAttribute(): string
    {
        return match($this->status) {
            'paid' => '<span class="badge bg-success">Pago</span>',
            'pending' => '<span class="badge bg-warning">Pendente</span>',
            'failed' => '<span class="badge bg-danger">Falhou</span>',
            'refunded' => '<span class="badge bg-info">Estornado</span>',
            'cancelled' => '<span class="badge bg-secondary">Cancelado</span>',
            default => '<span class="badge bg-secondary">' . ucfirst($this->status) . '</span>',
        };
    }
}
