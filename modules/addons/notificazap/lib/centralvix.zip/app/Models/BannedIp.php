<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BannedIp extends Model
{
    protected $fillable = [
        'company_id',
        'ip_address',
        'reason',
        'notes',
        'banned_at',
        'expires_at',
        'banned_by',
        'active',
    ];

    protected $casts = [
        'banned_at' => 'datetime',
        'expires_at' => 'datetime',
        'active' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function bannedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'banned_by');
    }

    public function isExpired(): bool
    {
        if (!$this->expires_at) {
            return false; // Permanent ban
        }
        return $this->expires_at->isPast();
    }
}
