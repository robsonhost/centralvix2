<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Announcement extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'title',
        'message',
        'type',
        'audience',
        'is_active',
        'dismissible',
        'starts_at',
        'ends_at',
        'created_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'dismissible' => 'boolean',
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * Avisos publicáveis: ativos e dentro da janela de datas.
     */
    public function scopePublished(Builder $query): Builder
    {
        $now = now();

        return $query->where('is_active', true)
            ->where(function ($q) use ($now) {
                $q->whereNull('starts_at')->orWhere('starts_at', '<=', $now);
            })
            ->where(function ($q) use ($now) {
                $q->whereNull('ends_at')->orWhere('ends_at', '>=', $now);
            });
    }

    public function scopeForCompany(Builder $query, int $companyId): Builder
    {
        return $query->where('company_id', $companyId);
    }

    public function getIsCurrentAttribute(): bool
    {
        $now = now();
        if (!$this->is_active) {
            return false;
        }
        if ($this->starts_at && $this->starts_at->isAfter($now)) {
            return false;
        }
        if ($this->ends_at && $this->ends_at->isBefore($now)) {
            return false;
        }

        return true;
    }

    public function getTypeLabelAttribute(): string
    {
        return match ($this->type) {
            'success' => 'Sucesso',
            'warning' => 'Atenção',
            'danger' => 'Importante',
            default => 'Informação',
        };
    }

    public function getAudienceLabelAttribute(): string
    {
        return match ($this->audience) {
            'active' => 'Clientes ativos',
            'overdue' => 'Clientes inadimplentes',
            default => 'Todos os clientes',
        };
    }
}
