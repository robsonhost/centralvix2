<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class EmailTemplate extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'slug',
        'subject',
        'body_html',
        'body_text',
        'variables',
        'status',
    ];

    protected $casts = [
        'variables' => 'array',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function logs(): HasMany
    {
        return $this->hasMany(EmailLog::class, 'template_id');
    }

    public function render(array $data = []): array
    {
        $subject = $this->subject ?? '';
        $bodyHtml = $this->body_html ?? '';
        $bodyText = $this->body_text ?? '';

        foreach ($data as $key => $value) {
            $value = (string) $value;
            foreach (['{' . $key . '}', '{{' . $key . '}}'] as $placeholder) {
                $subject = str_replace($placeholder, $value, $subject);
                $bodyHtml = str_replace($placeholder, $value, $bodyHtml);
                if ($bodyText) {
                    $bodyText = str_replace($placeholder, $value, $bodyText);
                }
            }
        }

        return compact('subject', 'bodyHtml', 'bodyText');
    }
}
