<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class License extends Model
{
    protected $table = 'client_licenses';

    protected $fillable = [
        'uuid',
        'license_key',
        'company_id',
        'client_id',
        'client_name',
        'client_email',
        'client_whatsapp',
        'client_cpf_cnpj',
        'product_name',
        'domain',
        'ip_address',
        'max_domains',
        'max_ips',
        'status',
        'issued_at',
        'expires_at',
        'last_check_at',
        'suspended_at',
        'suspended_reason',
        'check_count',
        'validation_failures',
        'last_validation_ip',
        'notification_sent_at',
        'welcome_sent',
        'notes',
        'metadata',
    ];

    protected $casts = [
        'issued_at' => 'datetime',
        'expires_at' => 'datetime',
        'last_check_at' => 'datetime',
        'suspended_at' => 'datetime',
        'notification_sent_at' => 'datetime',
        'welcome_sent' => 'boolean',
        'metadata' => 'array',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($license) {
            if (empty($license->uuid)) {
                $license->uuid = (string) Str::uuid();
            }
            if (empty($license->license_key)) {
                $license->license_key = self::generateLicenseKey();
            }
            if (empty($license->issued_at)) {
                $license->issued_at = now();
            }
        });
    }

    // Relationships
    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function validations(): HasMany
    {
        return $this->hasMany(LicenseValidation::class);
    }

    public function domains(): HasMany
    {
        return $this->hasMany(LicenseDomain::class);
    }

    public function ips(): HasMany
    {
        return $this->hasMany(LicenseIp::class);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeExpired($query)
    {
        return $query->where('expires_at', '<', now());
    }

    public function scopeExpiringSoon($query, int $days = 30)
    {
        return $query->where('expires_at', '<=', now()->addDays($days))
                    ->where('expires_at', '>', now());
    }

    // Helpers
    public static function generateLicenseKey(): string
    {
        return sprintf(
            'CVIX-%s-%s-%s-%s',
            strtoupper(Str::random(4)),
            strtoupper(Str::random(4)),
            strtoupper(Str::random(4)),
            strtoupper(Str::random(4))
        );
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isExpired(): bool
    {
        if (!$this->expires_at) {
            return false;
        }
        return $this->expires_at->isPast();
    }

    public function daysUntilExpiry(): ?int
    {
        if (!$this->expires_at) {
            return null;
        }
        return now()->diffInDays($this->expires_at, false);
    }

    public function validate(string $domain, string $ip): array
    {
        $this->increment('check_count');
        $this->update(['last_check_at' => now(), 'last_validation_ip' => $ip]);

        // Verifica status
        if ($this->status === 'blocked') {
            $this->logValidation($domain, $ip, 'failed', 'Licença bloqueada: ' . ($this->suspended_reason ?? ''));
            return [
                'valid' => false,
                'message' => 'Licença bloqueada',
            ];
        }

        if ($this->status !== 'active') {
            $this->logValidation($domain, $ip, 'failed', 'Licença não está ativa: ' . $this->status);
            return [
                'valid' => false,
                'message' => 'Licença ' . $this->status,
            ];
        }

        // Verifica expiração
        if ($this->isExpired()) {
            $this->update(['status' => 'expired']);
            $this->logValidation($domain, $ip, 'failed', 'Licença expirada');
            return [
                'valid' => false,
                'message' => 'Licença expirada em ' . $this->expires_at->format('d/m/Y'),
            ];
        }

        // Verifica domínio
        if ($this->max_domains > 0) {
            $domainExists = $this->domains()->where('domain', $domain)->where('is_active', true)->exists();
            if (!$domainExists) {
                $this->increment('validation_failures');
                $this->logValidation($domain, $ip, 'failed', 'Domínio não autorizado');
                return [
                    'valid' => false,
                    'message' => 'Domínio não autorizado para esta licença',
                ];
            }
        }

        // Verifica IP
        if ($this->max_ips > 0) {
            $ipExists = $this->ips()->where('ip_address', $ip)->where('is_active', true)->exists();
            if (!$ipExists) {
                $this->increment('validation_failures');
                $this->logValidation($domain, $ip, 'failed', 'IP não autorizado');
                return [
                    'valid' => false,
                    'message' => 'IP não autorizado para esta licença',
                ];
            }
        }

        // Validação bem-sucedida
        $this->logValidation($domain, $ip, 'success', null);
        
        return [
            'valid' => true,
            'message' => 'Licença válida',
            'expires_at' => $this->expires_at?->toDateTimeString(),
            'days_remaining' => $this->daysUntilExpiry(),
        ];
    }

    private function logValidation(string $domain, string $ip, string $result, ?string $error): void
    {
        $this->validations()->create([
            'domain' => $domain,
            'ip_address' => $ip,
            'result' => $result,
            'error_message' => $error,
            'user_agent' => request()->userAgent(),
            'validation_data' => request()->all(),
        ]);
    }

    public function suspend(string $reason): void
    {
        $this->update([
            'status' => 'suspended',
            'suspended_at' => now(),
            'suspended_reason' => $reason,
        ]);
    }

    public function block(string $reason): void
    {
        $this->update([
            'status' => 'blocked',
            'suspended_at' => now(),
            'suspended_reason' => $reason,
        ]);
    }

    public function deactivate(): void
    {
        $this->update([
            'status' => 'cancelled',
            'suspended_at' => now(),
            'suspended_reason' => 'Licença desativada pelo administrador',
        ]);
    }

    public function activate(): void
    {
        $this->update([
            'status' => 'active',
            'suspended_at' => null,
            'suspended_reason' => null,
        ]);
    }

    public function renew(int $months = 12): void
    {
        $expiresAt = $this->expires_at && $this->expires_at->isFuture() 
            ? $this->expires_at->addMonths($months)
            : now()->addMonths($months);

        $this->update([
            'expires_at' => $expiresAt,
            'status' => 'active',
        ]);
    }
}
