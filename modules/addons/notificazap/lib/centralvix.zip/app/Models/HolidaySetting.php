<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class HolidaySetting extends Model
{
    protected $fillable = [
        'company_id',
        'enabled',
        'adjust_weekends',
        'adjust_national_holidays',
        'adjust_state_holidays',
        'adjust_municipal_holidays',
        'default_adjustment_days',
        'skip_weekdays',
        'state_code',
        'city_name',
    ];

    protected $casts = [
        'enabled' => 'boolean',
        'adjust_weekends' => 'boolean',
        'adjust_national_holidays' => 'boolean',
        'adjust_state_holidays' => 'boolean',
        'adjust_municipal_holidays' => 'boolean',
        'default_adjustment_days' => 'integer',
        'skip_weekdays' => 'array',
    ];

    // Relationships
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }
}
