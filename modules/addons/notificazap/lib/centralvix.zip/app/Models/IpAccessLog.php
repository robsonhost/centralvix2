<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class IpAccessLog extends Model
{
    protected $fillable = [
        'company_id',
        'ip_address',
        'user_agent',
        'action',
        'result',
        'client_id',
        'details',
    ];

    protected $casts = [
        'details' => 'array',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }
}
