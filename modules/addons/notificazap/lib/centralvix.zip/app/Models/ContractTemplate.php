<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class ContractTemplate extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid', 'company_id', 'name', 'slug', 'content',
        'variables', 'type', 'product_id_bind', 'is_active',
        'require_signature',
    ];

    protected $casts = [
        'variables'          => 'array',
        'is_active'          => 'boolean',
        'require_signature'  => 'boolean',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(function ($m) {
            $m->uuid ??= Str::uuid();
            $m->slug ??= Str::slug($m->name);
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function contracts(): HasMany
    {
        return $this->hasMany(Contract::class, 'template_id');
    }

    /**
     * Render template with client/service data.
     */
    public function render(array $data = []): string
    {
        $content = $this->content;

        foreach ($data as $key => $value) {
            $content = str_replace(
                ['{{' . $key . '}}', '{{ ' . $key . ' }}'],
                $value ?? '',
                $content
            );
        }

        return $content;
    }
}
