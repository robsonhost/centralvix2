<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DashboardWidget extends Model
{
    protected $fillable = [
        'key',
        'name',
        'description',
        'component',
        'icon',
        'default_width',
        'default_height',
        'min_width',
        'min_height',
        'default_settings',
        'is_active',
    ];

    protected $casts = [
        'default_settings' => 'array',
        'is_active' => 'boolean',
    ];

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
