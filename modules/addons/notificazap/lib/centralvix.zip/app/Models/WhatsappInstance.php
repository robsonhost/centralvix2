<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class WhatsappInstance extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid', 'company_id', 'name', 'instance_key', 'provider',
        'api_url', 'api_key', 'phone_number', 'profile_name',
        'profile_picture', 'status', 'qr_code', 'connected_at',
        'settings', 'is_default', 'is_active',
    ];

    protected $casts = [
        'settings'     => 'array',
        'connected_at' => 'datetime',
        'is_default'   => 'boolean',
        'is_active'    => 'boolean',
    ];

    protected $hidden = ['api_key'];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn ($m) => $m->uuid ??= Str::uuid());

        static::saving(function (WhatsappInstance $instance) {
            if ($instance->api_url) {
                $instance->api_url = static::normalizeApiUrl($instance->api_url);
            }
        });
    }

    public static function normalizeApiUrl(string $url): string
    {
        $url = rtrim(trim($url), '/');
        $url = (string) preg_replace('#(\.com\.br)\.br(?=/|$)#', '$1', $url);

        $legacyToEnv = (string) config('whatsapp.evolution_go.url', '');
        $legacyHosts = [
            'evolution.centralvix.com.br',
            'evolution.centralvix.com',
            'evolution.centralvix.com.br.br',
        ];

        foreach ($legacyHosts as $host) {
            if (str_contains(strtolower($url), $host) && $legacyToEnv !== '') {
                return static::normalizeApiUrl($legacyToEnv);
            }
        }

        return str_replace(
            ['https://evolution.centralvix.com.br.br', 'http://evolution.centralvix.com.br.br'],
            ['https://evolution.centralvix.com.br', 'http://evolution.centralvix.com.br'],
            $url
        );
    }

    /**
     * URL efetiva da API — Evolution Go sempre usa o .env quando configurado.
     */
    public function getEffectiveApiUrl(): string
    {
        $envUrl = trim((string) config('whatsapp.evolution_go.url', ''));

        if ($this->provider === 'evolution_go' && $envUrl !== '') {
            return static::normalizeApiUrl($envUrl);
        }

        $stored = trim((string) ($this->api_url ?? ''));

        return static::normalizeApiUrl($stored !== '' ? $stored : $envUrl);
    }

    public function getEffectiveApiKey(): ?string
    {
        $fromInstance = $this->getDecryptedApiKey();
        if ($fromInstance) {
            return $fromInstance;
        }

        $envKey = trim((string) config('whatsapp.evolution_go.api_key', ''));

        return $envKey !== '' ? $envKey : null;
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function messages(): HasMany
    {
        return $this->hasMany(WhatsappMessage::class, 'instance_id');
    }

    public function chats(): HasMany
    {
        return $this->hasMany(WhatsappChat::class, 'instance_id');
    }

    public function isConnected(): bool
    {
        return $this->status === 'connected';
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'connected'    => 'Conectado',
            'connecting'   => 'Conectando',
            'disconnected' => 'Desconectado',
            'error'        => 'Erro',
            default        => ucfirst($this->status),
        };
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'connected'    => 'success',
            'connecting'   => 'warning',
            'disconnected' => 'secondary',
            'error'        => 'danger',
            default        => 'secondary',
        };
    }

    public function getDecryptedApiKey(): ?string
    {
        if (!$this->api_key) return null;
        try {
            return decrypt($this->api_key);
        } catch (\Exception) {
            return $this->api_key;
        }
    }

    /**
     * Nome usado nos endpoints /instance/{name}/... da Evolution API.
     */
    public function getEvolutionApiName(): string
    {
        $key = (string) $this->instance_key;

        if ($key !== '' && !$this->looksLikeUuid($key)) {
            return $key;
        }

        $fromSettings = $this->settings['evolution_instance_name'] ?? null;
        if (is_string($fromSettings) && $fromSettings !== '') {
            return $fromSettings;
        }

        return (string) (config('whatsapp.evolution_go.instance') ?: 'centralvix');
    }

    /**
     * Token/ID interno da instância no painel Evolution Go (opcional).
     */
    public function getEvolutionToken(): ?string
    {
        if ($this->looksLikeUuid((string) $this->instance_key)) {
            return (string) $this->instance_key;
        }

        $token = $this->settings['evolution_token'] ?? null;

        if (is_string($token) && $token !== '') {
            return $token;
        }

        $envToken = trim((string) config('whatsapp.evolution_go.instance_token', ''));

        return $envToken !== '' ? $envToken : null;
    }

    public function looksLikeUuid(string $value): bool
    {
        return (bool) preg_match(
            '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i',
            trim($value)
        );
    }

    public function syncConfigFromEnv(): void
    {
        $updates = [];
        $envUrl = trim((string) config('whatsapp.evolution_go.url', ''));
        $envKey = trim((string) config('whatsapp.evolution_go.api_key', ''));

        if ($envUrl && $this->provider === 'evolution_go') {
            $normalized = static::normalizeApiUrl($envUrl);
            if ($this->api_url !== $normalized) {
                $updates['api_url'] = $normalized;
            }
        } elseif ($envUrl) {
            $normalized = static::normalizeApiUrl($envUrl);
            if (!$this->api_url || static::normalizeApiUrl((string) $this->api_url) !== $normalized) {
                $updates['api_url'] = $normalized;
            }
        }

        if ($envKey && !$this->getDecryptedApiKey()) {
            $updates['api_key'] = encrypt($envKey);
        }

        if ($this->looksLikeUuid((string) $this->instance_key)) {
            $settings = $this->settings ?? [];
            $settings['evolution_token'] = $this->instance_key;
            $settings['evolution_instance_name'] = config('whatsapp.evolution_go.instance', 'centralvix');
            $updates['instance_key'] = config('whatsapp.evolution_go.instance', 'centralvix');
            $updates['settings'] = $settings;
        }

        if ($updates !== []) {
            $this->update($updates);
            $this->refresh();
        }
    }
}
