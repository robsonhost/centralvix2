<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LicenseIp extends Model
{
    protected $table = 'client_license_ips';

    public $timestamps = false;

    protected $fillable = [
        'license_id',
        'ip_address',
        'is_active',
        'added_at',
        'last_used_at',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'added_at' => 'datetime',
        'last_used_at' => 'datetime',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($ip) {
            if (empty($ip->added_at)) {
                $ip->added_at = now();
            }
        });
    }

    public function license(): BelongsTo
    {
        return $this->belongsTo(License::class);
    }
}
