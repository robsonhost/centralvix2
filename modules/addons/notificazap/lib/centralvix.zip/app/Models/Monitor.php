<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Monitor extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'name',
        'type',
        'target',
        'is_active',
        'status',
        'last_response_time',
        'last_checked_at',
        'last_status_change_at',
        'ssl_expires_at',
        'ssl_issuer',
        'consecutive_failures',
        'last_error',
        'notify_email',
        'notify_phone',
        'last_alert_at',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'last_checked_at' => 'datetime',
        'last_status_change_at' => 'datetime',
        'last_alert_at' => 'datetime',
        'ssl_expires_at' => 'date',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function checks(): HasMany
    {
        return $this->hasMany(MonitorCheck::class);
    }

    public function scopeForCompany(Builder $query, int $companyId): Builder
    {
        return $query->where('company_id', $companyId);
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'up' => 'success',
            'down' => 'danger',
            'warning' => 'warning',
            default => 'secondary',
        };
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'up' => 'No ar',
            'down' => 'Fora do ar',
            'warning' => 'Atenção',
            default => 'Não verificado',
        };
    }

    public function getSslDaysLeftAttribute(): ?int
    {
        if (!$this->ssl_expires_at) {
            return null;
        }

        return (int) now()->startOfDay()->diffInDays($this->ssl_expires_at, false);
    }
}
