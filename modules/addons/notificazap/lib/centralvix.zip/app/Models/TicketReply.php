<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TicketReply extends Model
{
    protected $fillable = [
        'ticket_id',
        'user_id',
        'client_id',
        'message',
        'type',
    ];

    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function attachments(): HasMany
    {
        return $this->hasMany(TicketAttachment::class, 'reply_id');
    }

    public function isFromAdmin(): bool
    {
        return !is_null($this->user_id) && is_null($this->client_id);
    }

    public function isNote(): bool
    {
        return $this->type === 'note';
    }

    public function getAuthorAttribute(): string
    {
        if ($this->user) {
            return $this->user->name;
        }
        if ($this->client) {
            return $this->client->full_name;
        }
        return 'Sistema';
    }
}
