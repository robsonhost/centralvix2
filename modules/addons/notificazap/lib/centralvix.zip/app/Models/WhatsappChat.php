<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class WhatsappChat extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id', 'instance_id', 'client_id', 'phone_number',
        'contact_name', 'profile_picture', 'last_message', 'last_message_at',
        'unread_count', 'status', 'assigned_to', 'ai_enabled', 'metadata',
    ];

    protected $casts = [
        'last_message_at' => 'datetime',
        'ai_enabled'      => 'boolean',
        'metadata'        => 'array',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function instance(): BelongsTo
    {
        return $this->belongsTo(WhatsappInstance::class, 'instance_id');
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(WhatsappMessage::class, 'to_number', 'phone_number')
            ->where('company_id', $this->company_id)
            ->orderBy('created_at');
    }

    public function getDisplayNameAttribute(): string
    {
        return $this->contact_name ?? $this->client?->display_name ?? $this->phone_number;
    }
}
