<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class ClientQuery extends Model
{
    protected $table = 'queries';

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'query_type_id',
        'search_term',
        'amount',
        'balance_before',
        'balance_after',
        'status',
        'result',
        'raw_response',
        'error_message',
        'ip_address',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'balance_before' => 'decimal:2',
        'balance_after' => 'decimal:2',
        'result' => 'array',
        'raw_response' => 'array',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function queryType(): BelongsTo
    {
        return $this->belongsTo(QueryType::class);
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'Processando',
            'completed' => 'Concluída',
            'failed' => 'Falhou',
            'refunded' => 'Estornada',
            default => ucfirst($this->status),
        };
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'warning',
            'completed' => 'success',
            'failed' => 'danger',
            'refunded' => 'info',
            default => 'secondary',
        };
    }

    public function getMaskedSearchTermAttribute(): string
    {
        $term = $this->search_term;
        $len = strlen($term);
        
        if ($len <= 4) {
            return $term;
        }

        $visible = (int) ceil($len * 0.3);
        return substr($term, 0, $visible) . str_repeat('*', $len - $visible);
    }
}
