<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class Contract extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid', 'number', 'company_id', 'client_id', 'template_id',
        'service_id', 'order_id', 'title', 'content', 'status',
        'signature_methods', 'signature_token', 'signer_ip',
        'signer_geolocation', 'signer_device', 'signed_at', 'sent_at',
        'viewed_at', 'expires_at', 'pdf_path', 'metadata',
    ];

    protected $casts = [
        'signature_methods' => 'array',
        'metadata'          => 'array',
        'signed_at'         => 'datetime',
        'sent_at'           => 'datetime',
        'viewed_at'         => 'datetime',
        'expires_at'        => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            $model->uuid ??= Str::uuid();
            $model->signature_token ??= Str::random(64);

            if (!$model->number) {
                $count = static::where('company_id', $model->company_id)->count() + 1;
                $model->number = 'CONT-' . date('Y') . '-' . str_pad($count, 5, '0', STR_PAD_LEFT);
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function template(): BelongsTo
    {
        return $this->belongsTo(ContractTemplate::class, 'template_id');
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(Service::class);
    }

    public function isSigned(): bool
    {
        return $this->status === 'signed';
    }

    public function isExpired(): bool
    {
        return $this->expires_at && $this->expires_at->isPast() && !$this->isSigned();
    }

    public function publicUrl(): string
    {
        return url('/contract/' . $this->signature_token);
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'draft'     => 'Rascunho',
            'sent'      => 'Enviado',
            'viewed'    => 'Visualizado',
            'signed'    => 'Assinado',
            'expired'   => 'Expirado',
            'cancelled' => 'Cancelado',
            default     => ucfirst($this->status),
        };
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'draft'     => 'secondary',
            'sent'      => 'info',
            'viewed'    => 'primary',
            'signed'    => 'success',
            'expired'   => 'danger',
            'cancelled' => 'dark',
            default     => 'secondary',
        };
    }
}
