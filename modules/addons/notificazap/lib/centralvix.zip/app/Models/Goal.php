<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Goal extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id', 'user_id', 'affiliate_id',
        'name', 'description', 'type', 'target_value',
        'current_value', 'period', 'starts_at', 'ends_at',
        'reward_value', 'reward_type', 'status',
    ];

    protected $casts = [
        'target_value'  => 'decimal:2',
        'current_value' => 'decimal:2',
        'reward_value'  => 'decimal:2',
        'starts_at'     => 'date',
        'ends_at'       => 'date',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function affiliate(): BelongsTo
    {
        return $this->belongsTo(Affiliate::class);
    }

    public function getProgressPercentageAttribute(): float
    {
        if ((float) $this->target_value <= 0) return 0;
        return min(100, round(($this->current_value / $this->target_value) * 100, 1));
    }

    public function isAchieved(): bool
    {
        return $this->current_value >= $this->target_value;
    }
}
