<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ClientSecurityAnswer extends Model
{
    protected $fillable = [
        'client_id',
        'security_question_id',
        'answer_hash',
    ];

    protected $hidden = [
        'answer_hash',
    ];

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function securityQuestion(): BelongsTo
    {
        return $this->belongsTo(SecurityQuestion::class);
    }
}
