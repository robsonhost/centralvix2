<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class QueryType extends Model
{
    protected $fillable = [
        'company_id',
        'slug',
        'name',
        'description',
        'category',
        'icon',
        'cost_price',
        'sell_price',
        'api_provider',
        'api_config',
        'active',
        'order',
    ];

    protected $casts = [
        'cost_price' => 'decimal:2',
        'sell_price' => 'decimal:2',
        'api_config' => 'array',
        'active' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function queries(): HasMany
    {
        return $this->hasMany(ClientQuery::class, 'query_type_id');
    }

    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

    public function scopeCategory($query, string $category)
    {
        return $query->where('category', $category);
    }

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id', $companyId);
    }

    public function getFormattedPriceAttribute(): string
    {
        return 'R$ ' . number_format($this->sell_price, 2, ',', '.');
    }

    public function getCategoryLabelAttribute(): string
    {
        return match ($this->category) {
            'pessoas' => 'Pessoas',
            'empresas' => 'Empresas',
            'score' => 'Score e Crédito',
            default => ucfirst($this->category),
        };
    }
}
