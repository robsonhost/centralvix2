<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class Transaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'invoice_id',
        'gateway',
        'gateway_transaction_id',
        'type',
        'amount',
        'fee',
        'currency',
        'status',
        'description',
        'gateway_response',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'fee' => 'decimal:2',
        'gateway_response' => 'array',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    public function getNetAmountAttribute(): float
    {
        return (float) $this->amount - (float) $this->fee;
    }

    /** ID legível para exibição (compatível com views antigas). */
    public function getTransactionIdAttribute(): string
    {
        return (string) ($this->uuid ?? $this->id);
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'completed' => 'Pago',
            'pending'   => 'Pendente',
            'failed'    => 'Falhou',
            'refunded'  => 'Estornado',
            default     => ucfirst((string) $this->status),
        };
    }

    public function isPaid(): bool
    {
        return $this->status === 'completed';
    }

    /** Atalho para dados de pagamento armazenados em gateway_response. */
    public function paymentData(string $key, mixed $default = null): mixed
    {
        return ($this->gateway_response ?? [])[$key] ?? $default;
    }
}
