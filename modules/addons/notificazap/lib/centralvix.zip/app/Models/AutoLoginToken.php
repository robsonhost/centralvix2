<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class AutoLoginToken extends Model
{
    use HasFactory;

    protected $fillable = [
        'token', 'short_code', 'client_id', 'company_id', 'redirect_to',
        'context_type', 'context_id', 'ip_address', 'user_agent', 'ttl_minutes',
        'single_use', 'used', 'used_at', 'click_count', 'last_clicked_at',
        'sent_via', 'created_by', 'expires_at',
    ];

    protected $casts = [
        'expires_at'       => 'datetime',
        'used_at'          => 'datetime',
        'last_clicked_at'  => 'datetime',
        'single_use'       => 'boolean',
        'used'             => 'boolean',
        'click_count'      => 'integer',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(function ($m) {
            $m->token ??= Str::random(64);
            if (empty($m->short_code)) {
                do {
                    $m->short_code = Str::lower(Str::random(8));
                } while (static::where('short_code', $m->short_code)->exists());
            }
        });
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function logs(): HasMany
    {
        return $this->hasMany(AutoLoginLog::class);
    }

    public function isValid(): bool
    {
        if ($this->used && $this->single_use) {
            return false;
        }

        return $this->expires_at?->isFuture() ?? false;
    }

    public function publicUrl(bool $preferShort = true): string
    {
        if ($preferShort && $this->short_code) {
            return url('/l/' . $this->short_code);
        }

        return url('/autologin/' . $this->token);
    }

    public static function generate(
        Client $client,
        ?string $redirectTo = null,
        ?string $contextType = null,
        ?int $contextId = null,
        int $ttl = 60,
        ?string $sentVia = 'manual',
        ?int $createdBy = null,
    ): self {
        return static::create([
            'token'        => Str::random(64),
            'client_id'    => $client->id,
            'company_id'   => $client->company_id,
            'redirect_to'  => $redirectTo,
            'context_type' => $contextType,
            'context_id'   => $contextId,
            'ttl_minutes'  => $ttl,
            'single_use'   => true,
            'expires_at'   => now()->addMinutes($ttl),
            'sent_via'     => $sentVia,
            'created_by'   => $createdBy,
        ]);
    }
}
