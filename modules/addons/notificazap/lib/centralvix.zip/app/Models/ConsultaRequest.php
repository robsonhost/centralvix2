<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ConsultaRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'client_id',
        'group',
        'method',
        'query_value',
        'amount',
        'status',
        'result_message',
        'result_payload',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'result_payload' => 'array',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }
}

