<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Support\Str;

class NotificationLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'type',
        'event',
        'channel',
        'channels',
        'context_type',
        'context_id',
        'recipient',
        'template_slug',
        'rendered_content',
        'status',
        'error',
        'external_id',
        'sent_at',
        'delivered_at',
        'read_at',
    ];

    protected $casts = [
        'channels'     => 'array',
        'sent_at'      => 'datetime',
        'delivered_at' => 'datetime',
        'read_at'      => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->uuid ??= Str::uuid());
    }

    /**
     * Get the company that owns the notification log.
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * Get the client that received the notification.
     */
    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    /**
     * Get the parent contextable model (service, invoice, ticket, etc.).
     */
    public function context(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Get HTML icons for all channels used in this notification.
     * 
     * @return string
     */
    public function getChannelIconsAttribute(): string
    {
        if (empty($this->channels)) {
            return '<i class="fas fa-bell"></i>';
        }

        $icons = array_map(function ($channel) {
            return match ($channel) {
                'email'     => '<i class="fas fa-envelope text-primary" title="Email"></i>',
                'whatsapp'  => '<i class="fab fa-whatsapp text-success" title="WhatsApp"></i>',
                'sms'       => '<i class="fas fa-sms text-warning" title="SMS"></i>',
                'web_push'  => '<i class="fas fa-bell text-info" title="Web Push"></i>',
                'webhook'   => '<i class="fas fa-code text-secondary" title="Webhook"></i>',
                default     => '<i class="fas fa-bell" title="' . ucfirst($channel) . '"></i>',
            };
        }, $this->channels);

        return implode(' ', $icons);
    }

    /**
     * Get the appropriate badge class for the notification status.
     * 
     * @return string
     */
    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'pending'   => 'secondary',
            'sent'      => 'info',
            'delivered' => 'primary',
            'read'      => 'success',
            'failed'    => 'danger',
            default     => 'secondary',
        };
    }

    /**
     * Get the human-readable status label.
     * 
     * @return string
     */
    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending'   => 'Pendente',
            'sent'      => 'Enviado',
            'delivered' => 'Entregue',
            'read'      => 'Lido',
            'failed'    => 'Falhou',
            default     => ucfirst($this->status),
        };
    }

    /**
     * Scope a query to only include notifications of a specific type.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $type
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfType($query, string $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Scope a query to only include notifications sent in the last N hours.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  int  $hours
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeSentInLastHours($query, int $hours = 24)
    {
        return $query->where('created_at', '>', now()->subHours($hours));
    }

    /**
     * Scope a query to only include notifications for a specific context.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $contextType
     * @param  int  $contextId
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeForContext($query, string $contextType, int $contextId)
    {
        return $query->where('context_type', $contextType)
                     ->where('context_id', $contextId);
    }

    /**
     * Check if notification was sent via a specific channel.
     *
     * @param  string  $channel
     * @return bool
     */
    public function hasSentVia(string $channel): bool
    {
        return in_array($channel, $this->channels ?? []);
    }
}
