<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class RechargeOrder extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'recharge_package_id',
        'invoice_id',
        'amount',
        'bonus',
        'total_credit',
        'status',
        'gateway',
        'transaction_id',
        'paid_at',
    ];

    protected $casts = [
        'amount'       => 'decimal:2',
        'bonus'        => 'decimal:2',
        'total_credit' => 'decimal:2',
        'paid_at'      => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = (string) Str::uuid();
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function package(): BelongsTo
    {
        return $this->belongsTo(RechargePackage::class, 'recharge_package_id');
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending'   => 'Aguardando pagamento',
            'paid'      => 'Pago',
            'cancelled' => 'Cancelado',
            'failed'    => 'Falhou',
            'refunded'  => 'Estornado',
            default     => 'Desconhecido',
        };
    }

    public function getStatusColorAttribute(): string
    {
        return match ($this->status) {
            'pending'   => 'warning',
            'paid'      => 'success',
            'cancelled' => 'secondary',
            'failed'    => 'danger',
            'refunded'  => 'info',
            default     => 'secondary',
        };
    }

    public function isPaid(): bool
    {
        return $this->status === 'paid';
    }
}
