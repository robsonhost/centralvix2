<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CustomField extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'field_type',
        'applies_to',
        'options',
        'validation',
        'description',
        'required',
        'show_on_order',
        'show_on_invoice',
        'active',
        'order',
    ];

    protected $casts = [
        'options' => 'array',
        'required' => 'boolean',
        'show_on_order' => 'boolean',
        'show_on_invoice' => 'boolean',
        'active' => 'boolean',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function values(): HasMany
    {
        return $this->hasMany(CustomFieldValue::class);
    }
}
