<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WalletTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'client_id',
        'type',
        'amount',
        'balance_after',
        'source',
        'description',
        'reference_type',
        'reference_id',
        'created_by',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'balance_after' => 'decimal:2',
    ];

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function isCredit(): bool
    {
        return $this->type === 'credit';
    }

    public function getSourceLabelAttribute(): string
    {
        return match ($this->source) {
            'topup'           => 'Recarga',
            'invoice_payment' => 'Pagamento de fatura',
            'bonus'           => 'Bônus',
            'refund'          => 'Reembolso',
            'adjustment'      => 'Ajuste',
            default           => 'Manual',
        };
    }
}
