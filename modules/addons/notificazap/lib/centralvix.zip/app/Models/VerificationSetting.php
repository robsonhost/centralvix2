<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VerificationSetting extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'email_verification_enabled',
        'whatsapp_verification_enabled',
        'allow_user_choice',
        'default_method',
        'code_length',
        'code_expiry_minutes',
        'resend_cooldown_enabled',
        'resend_cooldown_minutes',
    ];

    protected $casts = [
        'email_verification_enabled' => 'boolean',
        'whatsapp_verification_enabled' => 'boolean',
        'allow_user_choice' => 'boolean',
        'resend_cooldown_enabled' => 'boolean',
    ];

    /**
     * Get available verification methods
     */
    public function getAvailableMethods(): array
    {
        $methods = [];

        if ($this->email_verification_enabled) {
            $methods[] = 'email';
        }

        if ($this->whatsapp_verification_enabled) {
            $methods[] = 'whatsapp';
        }

        return $methods;
    }

    /**
     * Check if method is enabled
     */
    public function isMethodEnabled(string $method): bool
    {
        return match($method) {
            'email' => $this->email_verification_enabled,
            'whatsapp' => $this->whatsapp_verification_enabled,
            default => false,
        };
    }
}
