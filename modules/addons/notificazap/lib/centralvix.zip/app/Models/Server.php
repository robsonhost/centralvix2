<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Server extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'name',
        'hostname',
        'ip_address',
        'ip_secondary',
        'type',
        'module',
        'username',
        'password',
        'port',
        'secure',
        'api_token',
        'status',
        'max_accounts',
        'assigned_accounts',
        'disk_total',
        'disk_used',
        'bandwidth_total',
        'bandwidth_used',
        'notes',
        'settings',
    ];

    protected $hidden = ['password', 'api_token'];

    protected $casts = [
        'secure' => 'boolean',
        'max_accounts' => 'integer',
        'assigned_accounts' => 'integer',
        'disk_total' => 'integer',
        'disk_used' => 'integer',
        'bandwidth_total' => 'integer',
        'bandwidth_used' => 'integer',
        'settings' => 'array',
    ];

    public function getDecryptedApiToken(): ?string
    {
        if (!$this->api_token) return null;
        try {
            return decrypt($this->api_token);
        } catch (\Exception) {
            return $this->api_token;
        }
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function services(): HasMany
    {
        return $this->hasMany(Service::class);
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function getUsagePercentageAttribute(): float
    {
        if ($this->max_accounts === 0) {
            return 0;
        }
        return round(($this->assigned_accounts / $this->max_accounts) * 100, 1);
    }

    public function getDiskUsagePercentageAttribute(): float
    {
        if ($this->disk_total === 0) {
            return 0;
        }
        return round(($this->disk_used / $this->disk_total) * 100, 1);
    }

    public function getTypeLabelAttribute(): string
    {
        return match ($this->type) {
            'cpanel' => 'cPanel/WHM',
            'plesk' => 'Plesk',
            'directadmin' => 'DirectAdmin',
            'virtualizor' => 'Virtualizor',
            'proxmox' => 'Proxmox',
            'solusvm' => 'SolusVM',
            'custom' => 'Personalizado',
            default => ucfirst($this->type),
        };
    }
}
