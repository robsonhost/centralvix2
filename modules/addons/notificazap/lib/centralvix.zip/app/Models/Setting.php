<?php

namespace App\Models;

use App\Services\CacheService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Setting extends Model
{
    protected $fillable = [
        'company_id',
        'group',
        'key',
        'value',
        'type',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function getTypedValueAttribute(): mixed
    {
        return match ($this->type) {
            'boolean' => filter_var($this->value, FILTER_VALIDATE_BOOLEAN),
            'integer' => (int) $this->value,
            'json' => json_decode($this->value, true),
            default => $this->value,
        };
    }

    /**
     * Get setting value with cache (24h TTL - Requirement 64.1)
     */
    public static function get(int $companyId, string $group, string $key, mixed $default = null): mixed
    {
        $cacheService = app(CacheService::class);
        
        return $cacheService->getSetting($companyId, $group, $key, function () use ($companyId, $group, $key, $default) {
            $setting = static::where('company_id', $companyId)
                ->where('group', $group)
                ->where('key', $key)
                ->first();

            return $setting ? $setting->typed_value : $default;
        });
    }

    public static function set(int $companyId, string $group, string $key, mixed $value, string $type = 'string'): self
    {
        if (is_array($value)) {
            $value = json_encode($value);
            $type = 'json';
        } elseif (is_bool($value)) {
            $value = $value ? '1' : '0';
            $type = 'boolean';
        }

        return static::updateOrCreate(
            ['company_id' => $companyId, 'group' => $group, 'key' => $key],
            ['value' => $value, 'type' => $type]
        );
    }
}
