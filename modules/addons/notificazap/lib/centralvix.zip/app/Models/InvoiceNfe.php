<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InvoiceNfe extends Model
{
    protected $table = 'invoices_nfe';

    protected $fillable = [
        'company_id',
        'invoice_id',
        'client_id',
        'nfe_number',
        'nfe_series',
        'nfe_key',
        'protocol',
        'status',
        'status_message',
        'amount',
        'pdf_url',
        'xml_url',
        'nfe_data',
        'issued_at',
        'cancelled_at',
        'cancellation_reason',
    ];

    protected $casts = [
        'nfe_data' => 'array',
        'amount' => 'decimal:2',
        'issued_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function isIssued(): bool
    {
        return $this->status === 'issued';
    }

    public function isCancelled(): bool
    {
        return $this->status === 'cancelled';
    }

    public function canCancel(): bool
    {
        return $this->isIssued() && !$this->cancelled_at;
    }
}
