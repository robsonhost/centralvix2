<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class Client extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, LogsActivity;

    protected $fillable = [
        'uuid',
        'company_id',
        'user_id',
        'client_code',
        'type',
        'firstname',
        'lastname',
        'email',
        'email_verified_at',
        'verification_token',
        'verification_code',
        'verification_code_expires_at',
        'verification_attempts',
        'email_secondary',
        'phone',
        'mobile',
        'whatsapp',
        'cpf',
        'cnpj',
        'company_name',
        'trading_name',
        'date_of_birth',
        'address',
        'address_number',
        'address_complement',
        'neighborhood',
        'city',
        'state',
        'country',
        'zip',
        'notes',
        'internal_notes',
        'status',
        'credit_balance',
        'currency',
        'language',
        'group_id',
        'affiliate_id',
        'profile_completed_at',
        'profile_completion_percentage',
        'cpf_cnpj',
        'marketing_opt_out',
    ];

    protected $hidden = [
        'remember_token',
    ];

    protected $casts = [
        'date_of_birth' => 'date',
        'credit_balance' => 'decimal:2',
        'email_verified_at' => 'datetime',
        'verification_code_expires_at' => 'datetime',
        'profile_completed_at' => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
            if (empty($model->client_code)) {
                $model->client_code = 'CLI' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
            }
        });
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['firstname', 'lastname', 'email', 'status', 'credit_balance'])
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs();
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function group(): BelongsTo
    {
        return $this->belongsTo(ClientGroup::class, 'group_id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function services(): HasMany
    {
        return $this->hasMany(Service::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class);
    }

    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class);
    }

    public function domains(): HasMany
    {
        return $this->hasMany(Domain::class);
    }

    public function sslCertificates(): HasMany
    {
        return $this->hasMany(SslCertificate::class);
    }

    public function contacts(): HasMany
    {
        return $this->hasMany(ClientContact::class);
    }

    public function referrals(): HasMany
    {
        return $this->hasMany(Referral::class, 'referrer_id');
    }

    public function referredBy(): BelongsTo
    {
        return $this->belongsTo(Referral::class, 'id', 'referred_id');
    }

    public function commissions(): HasMany
    {
        return $this->hasMany(Commission::class);
    }

    public function affiliate(): HasMany
    {
        return $this->hasMany(Affiliate::class);
    }

    public function contracts(): HasMany
    {
        return $this->hasMany(Contract::class);
    }

    public function score(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(ClientScore::class);
    }

    public function getFullNameAttribute(): string
    {
        return trim("{$this->firstname} {$this->lastname}");
    }

    public function getDisplayNameAttribute(): string
    {
        if ($this->type === 'company' && $this->company_name) {
            return $this->company_name;
        }
        return $this->full_name;
    }

    public function getAvatarUrlAttribute(): string
    {
        return 'https://ui-avatars.com/api/?name=' . urlencode($this->full_name) . '&color=7F9CF5&background=EBF4FF';
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isSuspended(): bool
    {
        return $this->status === 'suspended';
    }

    public function addCredit(float $amount): void
    {
        $this->increment('credit_balance', $amount);
    }

    public function deductCredit(float $amount): bool
    {
        if ($this->credit_balance >= $amount) {
            $this->decrement('credit_balance', $amount);
            return true;
        }
        return false;
    }

    public function getUnpaidInvoicesCount(): int
    {
        return $this->invoices()->whereIn('status', ['unpaid', 'overdue'])->count();
    }

    public function getUnpaidInvoicesTotal(): float
    {
        return (float) $this->invoices()->whereIn('status', ['unpaid', 'overdue'])->sum('total');
    }

    /**
     * Marca o email como verificado
     */
    public function markEmailAsVerified(): bool
    {
        return $this->forceFill([
            'email_verified_at' => now(),
            'verification_token' => null,
            'verification_code' => null,
            'verification_code_expires_at' => null,
            'verification_attempts' => 0,
        ])->save();
    }

    /**
     * Verifica se o email já foi verificado
     */
    public function hasVerifiedEmail(): bool
    {
        return !is_null($this->email_verified_at);
    }

    /**
     * Gera um novo token de verificação
     */
    public function generateVerificationToken(): string
    {
        $token = Str::random(64);
        $this->verification_token = $token;
        $this->save();
        return $token;
    }

    /**
     * Gera código de verificação numérico
     */
    public function generateVerificationCode(int $length = 6, int $expiryMinutes = 30): string
    {
        $min = pow(10, $length - 1);
        $max = pow(10, $length) - 1;
        $code = (string) rand($min, $max);

        $this->verification_code = $code;
        $this->verification_code_expires_at = now()->addMinutes($expiryMinutes);
        $this->verification_attempts = 0;
        $this->save();

        return $code;
    }

    /**
     * Valida código de verificação
     */
    public function validateVerificationCode(string $code): bool
    {
        // Verifica se já expirou
        if (!$this->verification_code_expires_at || $this->verification_code_expires_at->isPast()) {
            return false;
        }

        // Incrementa tentativas
        $this->increment('verification_attempts');

        // Verifica se código está correto
        if ($this->verification_code === $code) {
            $this->markEmailAsVerified();
            return true;
        }

        return false;
    }

    /**
     * Verifica se código expirou
     */
    public function isVerificationCodeExpired(): bool
    {
        return !$this->verification_code_expires_at || $this->verification_code_expires_at->isPast();
    }

    /**
     * Verifica se excedeu tentativas
     */
    public function hasExceededVerificationAttempts(int $max = 5): bool
    {
        return $this->verification_attempts >= $max;
    }
}
