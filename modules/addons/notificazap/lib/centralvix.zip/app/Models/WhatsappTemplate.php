<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class WhatsappTemplate extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid', 'company_id', 'slug', 'name', 'category',
        'content', 'variables', 'type', 'buttons', 'list',
        'is_active', 'is_default', 'footer',
    ];

    protected $casts = [
        'variables' => 'array',
        'buttons'   => 'array',
        'list'      => 'array',
        'is_active' => 'boolean',
        'is_default' => 'boolean',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->uuid ??= Str::uuid());
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * Render template replacing {{variable}} with actual values.
     */
    public function render(array $data = []): string
    {
        $content = $this->content;

        foreach ($data as $key => $value) {
            $content = str_replace(
                ['{{' . $key . '}}', '{{ ' . $key . ' }}'],
                $value ?? '',
                $content
            );
        }

        return $content;
    }

    public function getCategoryLabelAttribute(): string
    {
        return match ($this->category) {
            'financeiro'  => 'Financeiro',
            'clientes'    => 'Clientes',
            'servicos'    => 'Serviços',
            'hospedagem'  => 'Hospedagem',
            'vps'         => 'VPS',
            'dominios'    => 'Domínios',
            'ssl'         => 'SSL',
            'tickets'     => 'Tickets',
            'contratos'   => 'Contratos',
            'seguranca'   => 'Segurança',
            default       => ucfirst($this->category),
        };
    }
}
