<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Affiliate extends Model
{
    protected $fillable = [
        'company_id',
        'client_id',
        'code',
        'url',
        'status',
        'commission_type',
        'commission_value',
        'recurring_commission',
        'balance',
        'total_earned',
        'clicks',
        'conversions',
    ];

    protected $casts = [
        'commission_value' => 'decimal:2',
        'recurring_commission' => 'boolean',
        'balance' => 'decimal:2',
        'total_earned' => 'decimal:2',
        'clicks' => 'integer',
        'conversions' => 'integer',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->code)) {
                $model->code = strtoupper(Str::random(8));
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function referrals(): HasMany
    {
        return $this->hasMany(AffiliateReferral::class);
    }

    public function getConversionRateAttribute(): float
    {
        if ($this->clicks === 0) return 0;
        return round(($this->conversions / $this->clicks) * 100, 2);
    }
}
