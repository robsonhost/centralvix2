<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class Domain extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'service_id',
        'domain',
        'tld',
        'registrar',
        'registrar_data',
        'status',
        'registration_date',
        'expiry_date',
        'next_due_date',
        'auto_renew',
        'privacy_protection',
        'epp_code',
        'nameservers',
        'dns_records',
    ];

    protected $casts = [
        'registrar_data' => 'array',
        'nameservers' => 'array',
        'dns_records' => 'array',
        'registration_date' => 'date',
        'expiry_date' => 'date',
        'next_due_date' => 'date',
        'auto_renew' => 'boolean',
        'privacy_protection' => 'boolean',
    ];

    protected $hidden = ['epp_code'];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
            if (empty($model->tld)) {
                $parts = explode('.', $model->domain, 2);
                $model->tld = isset($parts[1]) ? '.' . $parts[1] : '';
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(Service::class);
    }

    public function isExpired(): bool
    {
        return $this->expiry_date && $this->expiry_date->isPast();
    }

    public function getDaysUntilExpiryAttribute(): int
    {
        if (!$this->expiry_date) {
            return 0;
        }
        return max(0, now()->diffInDays($this->expiry_date, false));
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'active' => 'success',
            'expired' => 'danger',
            'suspended' => 'warning',
            'pending' => 'info',
            'cancelled' => 'secondary',
            'transferred' => 'primary',
            default => 'secondary',
        };
    }

    public function getRegisteredAtAttribute(): ?\Carbon\Carbon
    {
        return $this->registration_date;
    }
}
