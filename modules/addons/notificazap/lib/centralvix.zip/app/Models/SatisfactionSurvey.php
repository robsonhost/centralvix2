<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SatisfactionSurvey extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'client_id',
        'ticket_id',
        'type',
        'token',
        'status',
        'score',
        'comment',
        'channel',
        'sent_at',
        'answered_at',
    ];

    protected $casts = [
        'sent_at' => 'datetime',
        'answered_at' => 'datetime',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    }

    public function scopeForCompany(Builder $query, int $companyId): Builder
    {
        return $query->where('company_id', $companyId);
    }

    public function scopeAnswered(Builder $query): Builder
    {
        return $query->where('status', 'answered');
    }

    public function isNps(): bool
    {
        return $this->type === 'nps';
    }

    /**
     * Classificação NPS do score (0-10) ou CSAT (1-5).
     */
    public function getCategoryAttribute(): ?string
    {
        if ($this->score === null) {
            return null;
        }

        if ($this->isNps()) {
            return match (true) {
                $this->score >= 9 => 'promoter',
                $this->score >= 7 => 'passive',
                default => 'detractor',
            };
        }

        return $this->score >= 4 ? 'satisfied' : ($this->score == 3 ? 'neutral' : 'unsatisfied');
    }
}
