<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LicenseValidation extends Model
{
    protected $table = 'client_license_validations';

    const UPDATED_AT = null;

    protected $fillable = [
        'license_id',
        'domain',
        'ip_address',
        'user_agent',
        'validation_data',
        'result',
        'error_message',
        'validated_at',
    ];

    protected $casts = [
        'validation_data' => 'array',
        'validated_at' => 'datetime',
    ];

    public function license(): BelongsTo
    {
        return $this->belongsTo(License::class);
    }

    public function isSuccess(): bool
    {
        return $this->result === 'success';
    }

    public function isFailed(): bool
    {
        return $this->result === 'failed';
    }
}
