<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Spatie\Permission\Traits\HasRoles;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, Notifiable, HasRoles, LogsActivity;

    protected $fillable = [
        'uuid',
        'company_id',
        'name',
        'email',
        'email_verified_at',
        'password',
        'phone',
        'whatsapp',
        'cpf_cnpj',
        'company_name',
        'birth_date',
        'address',
        'address_number',
        'address_complement',
        'neighborhood',
        'city',
        'state',
        'country',
        'zip',
        'notes',
        'status',
        'two_factor_secret',
        'two_factor_recovery_codes',
        'two_factor_confirmed_at',
        'two_factor_method',
        'two_factor_grace_ends_at',
        'last_login_at',
        'last_login_ip',
        'profile_completed_at',
        'profile_completion_percentage',
    ];

    protected $hidden = [
        'password',
        'remember_token',
        'two_factor_secret',
        'two_factor_recovery_codes',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'two_factor_confirmed_at' => 'datetime',
        'two_factor_grace_ends_at' => 'datetime',
        'last_login_at' => 'datetime',
        'birth_date' => 'date',
        'password' => 'hashed',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
        });
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'email', 'status'])
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs();
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function isAdmin(): bool
    {
        return $this->hasRole(['super-admin', 'admin', 'financial', 'support', 'commercial']);
    }

    public function isSuperAdmin(): bool
    {
        return $this->hasRole('super-admin');
    }

    public function updateLastLogin(string $ip): void
    {
        $this->update([
            'last_login_at' => now(),
            'last_login_ip' => $ip,
        ]);
    }

    public function client(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(\App\Models\Client::class);
    }

    /**
     * Resolve o registro de Cliente deste usuário de forma robusta:
     * primeiro pelo vínculo direto (user_id) e, se não existir, pelo
     * e-mail dentro da mesma empresa. Evita 404/403 quando os cadastros
     * (User x Client) ficaram desalinhados.
     */
    public function resolveClient(): ?\App\Models\Client
    {
        if ($this->relationLoaded('client') && $this->client) {
            return $this->client;
        }

        $client = $this->client()->first();
        if ($client) {
            return $client;
        }

        if (!$this->email) {
            return null;
        }

        return \App\Models\Client::where('company_id', $this->company_id)
            ->whereRaw('LOWER(email) = ?', [mb_strtolower($this->email)])
            ->first();
    }

    /**
     * Verifica se o usuário pode acessar/operar sobre um registro de Cliente.
     * Cobre: dono direto (user_id), mesmo e-mail+empresa e administradores
     * (ou sessão de impersonação) agindo sobre clientes da própria empresa.
     */
    public function canAccessClientRecord(?\App\Models\Client $client): bool
    {
        if (!$client) {
            return false;
        }

        $sameCompany = (int) $client->company_id === (int) $this->company_id;

        if (($this->isAdmin() || session()->has('impersonate_from')) && $sameCompany) {
            return true;
        }

        if ($client->user_id && (int) $client->user_id === (int) $this->id) {
            return true;
        }

        return $sameCompany
            && $this->email
            && strcasecmp((string) $client->email, (string) $this->email) === 0;
    }

    public function getFullNameAttribute(): string
    {
        return $this->name;
    }

    public function isTwoFactorEnabled(): bool
    {
        return !is_null($this->two_factor_confirmed_at);
    }

    /** Alias usado por middlewares legados. */
    public function hasEnabledTwoFactor(): bool
    {
        return $this->isTwoFactorEnabled();
    }

    public function getAvatarUrlAttribute(): string
    {
        return 'https://ui-avatars.com/api/?name=' . urlencode($this->name) . '&color=7F9CF5&background=EBF4FF';
    }

    /**
     * Calculate profile completion percentage
     */
    public function calculateProfileCompletion(): int
    {
        $fields = [
            'name' => 10,
            'email' => 10,
            'phone' => 10,
            'whatsapp' => 10,
            'cpf_cnpj' => 15,
            'birth_date' => 10,
            'address' => 10,
            'city' => 10,
            'state' => 5,
            'zip' => 10,
            'email_verified_at' => 10,
        ];

        $completed = 0;
        foreach ($fields as $field => $weight) {
            if (!empty($this->$field)) {
                $completed += $weight;
            }
        }

        return min($completed, 100);
    }

    /**
     * Update profile completion
     */
    public function updateProfileCompletion(): void
    {
        $percentage = $this->calculateProfileCompletion();
        $this->profile_completion_percentage = $percentage;
        
        if ($percentage === 100 && is_null($this->profile_completed_at)) {
            $this->profile_completed_at = now();
        } elseif ($percentage < 100) {
            $this->profile_completed_at = null;
        }
        
        $this->saveQuietly();
    }

    /**
     * Get missing profile fields
     */
    public function getMissingProfileFields(): array
    {
        $fields = [
            'phone' => 'Telefone',
            'whatsapp' => 'WhatsApp',
            'cpf_cnpj' => 'CPF/CNPJ',
            'birth_date' => 'Data de Nascimento',
            'address' => 'Endereço',
            'city' => 'Cidade',
            'state' => 'Estado',
            'zip' => 'CEP',
        ];

        $missing = [];
        foreach ($fields as $field => $label) {
            if (empty($this->$field)) {
                $missing[$field] = $label;
            }
        }

        if (is_null($this->email_verified_at)) {
            $missing['email_verified_at'] = 'Verificação de E-mail';
        }

        return $missing;
    }

    /**
     * Check if profile is complete
     */
    public function isProfileComplete(): bool
    {
        return $this->profile_completion_percentage >= 100;
    }
}
