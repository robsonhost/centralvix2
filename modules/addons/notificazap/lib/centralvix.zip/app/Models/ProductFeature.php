<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductFeature extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'product_id',
        'name',
        'value',
        'icon',
        'order',
        'highlighted',
    ];

    protected $casts = [
        'highlighted' => 'boolean',
    ];

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
