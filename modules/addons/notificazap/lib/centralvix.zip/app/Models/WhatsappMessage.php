<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class WhatsappMessage extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid', 'company_id', 'instance_id', 'client_id',
        'to_number', 'template_slug', 'type', 'content',
        'media_url', 'media_caption', 'message_id', 'status',
        'error_message', 'retry_count', 'context_type', 'context_id',
        'sent_by', 'sent_at', 'delivered_at', 'read_at', 'raw_response',
    ];

    protected $casts = [
        'sent_at'      => 'datetime',
        'delivered_at' => 'datetime',
        'read_at'      => 'datetime',
        'raw_response' => 'array',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->uuid ??= Str::uuid());
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function instance(): BelongsTo
    {
        return $this->belongsTo(WhatsappInstance::class, 'instance_id');
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending'   => 'Pendente',
            'queued'    => 'Na fila',
            'sent'      => 'Enviado',
            'delivered' => 'Entregue',
            'read'      => 'Lido',
            'failed'    => 'Falhou',
            'deleted'   => 'Deletado',
            default     => ucfirst($this->status),
        };
    }

    public function getStatusIconAttribute(): string
    {
        return match ($this->status) {
            'pending'   => '🕐',
            'queued'    => '📤',
            'sent'      => '✓',
            'delivered' => '✓✓',
            'read'      => '✓✓',
            'failed'    => '✗',
            default     => '',
        };
    }
}
