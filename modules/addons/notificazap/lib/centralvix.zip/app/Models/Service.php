<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Service extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'company_id',
        'client_id',
        'product_id',
        'order_id',
        'name',
        'status',
        'domain',
        'username',
        'password',
        'server_id',
        'module',
        'module_data',
        'billing_cycle',
        'amount',
        'setup_fee',
        'first_payment_date',
        'next_due_date',
        'billing_date',
        'notes',
        'override_auto_suspend',
        'override_auto_terminate',
        'is_trial',
        'trial_started_at',
        'trial_ends_at',
        'trial_notified_at',
        'trial_converted_at',
    ];

    protected $casts = [
        'module_data' => 'array',
        'amount' => 'decimal:2',
        'setup_fee' => 'decimal:2',
        'first_payment_date' => 'date',
        'next_due_date' => 'date',
        'billing_date' => 'date',
        'override_auto_suspend' => 'boolean',
        'override_auto_terminate' => 'boolean',
        'is_trial' => 'boolean',
        'trial_started_at' => 'datetime',
        'trial_ends_at' => 'datetime',
        'trial_notified_at' => 'datetime',
        'trial_converted_at' => 'datetime',
    ];

    protected $hidden = ['password'];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function server(): BelongsTo
    {
        return $this->belongsTo(Server::class);
    }

    public function invoiceItems(): HasMany
    {
        return $this->hasMany(InvoiceItem::class);
    }

    public function invoices(): \Illuminate\Database\Eloquent\Relations\HasManyThrough
    {
        return $this->hasManyThrough(
            Invoice::class,
            InvoiceItem::class,
            'service_id',
            'id',
            'id',
            'invoice_id'
        );
    }

    public function getDecryptedPassword(): ?string
    {
        if (!$this->password) {
            return null;
        }

        try {
            return decrypt($this->password);
        } catch (\Exception) {
            return is_string($this->password) ? $this->password : null;
        }
    }

    public function isReseller(): bool
    {
        return $this->product?->type === 'reseller';
    }

    public function isStreaming(): bool
    {
        return in_array($this->product?->type, ['streaming_audio', 'streaming_video'], true);
    }

    public function domains(): HasMany
    {
        return $this->hasMany(Domain::class);
    }

    public function sslCertificates(): HasMany
    {
        return $this->hasMany(SslCertificate::class);
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isPending(): bool
    {
        return $this->status === 'pending';
    }

    public function isSuspended(): bool
    {
        return $this->status === 'suspended';
    }

    /**
     * Serviço de hospedagem com gestão via painel cliente (cPanel, etc.).
     */
    public function isHostingManageable(): bool
    {
        if (!in_array($this->product?->type, ['hosting', 'reseller'], true)) {
            return false;
        }

        if (!$this->server_id || !$this->username) {
            return false;
        }

        return in_array($this->status, ['active', 'suspended'], true);
    }

    public function canMutateHosting(): bool
    {
        return $this->isHostingManageable() && $this->isActive();
    }

    public function isOverdue(): bool
    {
        return $this->next_due_date && $this->next_due_date->isPast();
    }

    public function isTrial(): bool
    {
        return (bool) $this->is_trial && empty($this->trial_converted_at);
    }

    public function isTrialExpired(): bool
    {
        return $this->isTrial() && $this->trial_ends_at && $this->trial_ends_at->isPast();
    }

    public function trialDaysLeft(): int
    {
        if (!$this->isTrial() || !$this->trial_ends_at) {
            return 0;
        }
        return max(0, (int) now()->startOfDay()->diffInDays($this->trial_ends_at->startOfDay(), false));
    }

    public function trialHoursLeft(): int
    {
        if (!$this->isTrial() || !$this->trial_ends_at) {
            return 0;
        }
        return max(0, (int) now()->diffInHours($this->trial_ends_at, false));
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'Pendente',
            'active' => 'Ativo',
            'suspended' => 'Suspenso',
            'cancelled' => 'Cancelado',
            'terminated' => 'Encerrado',
            'fraud' => 'Fraude',
            default => ucfirst($this->status),
        };
    }

    public function getStatusBadgeAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'warning',
            'active' => 'success',
            'suspended' => 'danger',
            'cancelled' => 'secondary',
            'terminated' => 'dark',
            'fraud' => 'danger',
            default => 'secondary',
        };
    }

    public function getBillingCycleLabelAttribute(): string
    {
        return match ($this->billing_cycle) {
            'monthly' => 'Mensal',
            'quarterly' => 'Trimestral',
            'semiannually' => 'Semestral',
            'annually' => 'Anual',
            'biennially' => 'Bienal',
            'triennially' => 'Trienal',
            'lifetime' => 'Vitalício',
            default => ucfirst($this->billing_cycle),
        };
    }
}
