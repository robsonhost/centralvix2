<?php

namespace App\Mail;

use App\Models\Invoice;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class InvoiceMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public readonly Invoice $invoice) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Fatura #' . $this->invoice->invoice_number . ' - ' . config('app.name'),
        );
    }

    public function content(): Content
    {
        $client = $this->invoice->client;
        $fallback = route('client.invoices.show', $this->invoice);
        $actionUrl = app(\App\Services\AutoLoginService::class)
            ->linkForEmail($client, $fallback, 'invoice', $this->invoice->id) ?? $fallback;

        return new Content(
            view: 'emails.invoice',
            with: ['actionUrl' => $actionUrl],
        );
    }
}
