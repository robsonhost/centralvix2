<?php

namespace App\Mail;

use App\Models\EmailCampaign;
use App\Models\EmailCampaignRecipient;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class CampaignMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public EmailCampaign $campaign,
        public EmailCampaignRecipient $recipient,
        public ?string $fromName = null,
        public ?string $replyTo = null,
        public bool $includeUnsubscribe = true,
    ) {}

    public function envelope(): Envelope
    {
        $from = null;
        $fromAddress = config('mail.from.address');
        if ($this->fromName && $fromAddress) {
            $from = new \Illuminate\Mail\Mailables\Address($fromAddress, $this->fromName);
        }

        $replyTo = [];
        if ($this->replyTo && filter_var($this->replyTo, FILTER_VALIDATE_EMAIL)) {
            $replyTo[] = new \Illuminate\Mail\Mailables\Address($this->replyTo);
        }

        return new Envelope(
            from: $from,
            replyTo: $replyTo,
            subject: $this->campaign->subject,
        );
    }

    public function content(): Content
    {
        return new Content(
            htmlString: $this->buildHtml(),
        );
    }

    private function buildHtml(): string
    {
        $body = $this->campaign->body;

        // Personalização simples.
        $name = $this->recipient->name ?: 'cliente';
        $body = str_replace(['{{nome}}', '{{name}}'], e($name), $body);

        $html = $body;

        if ($this->includeUnsubscribe) {
            $unsubUrl = route('email.unsubscribe', $this->recipient->token);
            $html .= '<hr style="margin-top:32px;border:none;border-top:1px solid #e2e8f0">'
                . '<p style="font-size:12px;color:#94a3b8;text-align:center;margin-top:12px">'
                . 'Você está recebendo este e-mail porque é nosso cliente. '
                . '<a href="' . $unsubUrl . '" style="color:#94a3b8">Descadastrar</a>.'
                . '</p>';
        }

        // Pixel de rastreamento de abertura.
        $pixel = route('email.open', $this->recipient->token);
        $html .= '<img src="' . $pixel . '" width="1" height="1" alt="" style="display:none">';

        return $html;
    }

    public function attachments(): array
    {
        return [];
    }
}
