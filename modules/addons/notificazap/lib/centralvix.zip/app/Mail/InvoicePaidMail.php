<?php

namespace App\Mail;

use App\Models\Invoice;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class InvoicePaidMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Invoice $invoice) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Pagamento Confirmado - Fatura #' . $this->invoice->invoice_number,
        );
    }

    public function content(): Content
    {
        $client = $this->invoice->client;
        $fallback = route('client.invoices.show', $this->invoice);
        $viewUrl = app(\App\Services\AutoLoginService::class)
            ->linkForEmail($client, $fallback, 'invoice', $this->invoice->id) ?? $fallback;

        return new Content(
            view: 'emails.invoice-paid',
            with: ['viewUrl' => $viewUrl],
        );
    }

    public function attachments(): array
    {
        return [];
    }
}
