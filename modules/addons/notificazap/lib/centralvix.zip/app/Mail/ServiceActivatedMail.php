<?php

namespace App\Mail;

use App\Models\Service;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ServiceActivatedMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Service $service, public ?string $plaintextPassword = null) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Serviço Ativado: ' . $this->service->name,
        );
    }

    public function content(): Content
    {
        return new Content(view: 'emails.service-activated');
    }

    public function attachments(): array
    {
        return [];
    }
}
