<?php

namespace App\Mail;

use App\Models\Ticket;
use App\Models\TicketReply;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class TicketMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public readonly Ticket $ticket,
        public readonly ?TicketReply $reply = null,
        public readonly string $type = 'opened' // opened | replied | closed
    ) {}

    public function envelope(): Envelope
    {
        $subject = match ($this->type) {
            'opened'  => 'Ticket #' . $this->ticket->id . ' aberto — ' . $this->ticket->subject,
            'replied' => 'Resposta no ticket #' . $this->ticket->id . ' — ' . $this->ticket->subject,
            'closed'  => 'Ticket #' . $this->ticket->id . ' fechado',
            default   => 'Atualização no ticket #' . $this->ticket->id,
        };

        return new Envelope(subject: $subject . ' — ' . config('app.name'));
    }

    public function content(): Content
    {
        return new Content(view: 'emails.ticket');
    }
}
