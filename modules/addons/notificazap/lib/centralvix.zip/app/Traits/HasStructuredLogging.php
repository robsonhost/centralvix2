<?php

namespace App\Traits;

use App\Helpers\LogContext;
use Illuminate\Support\Facades\Log;

/**
 * Has Structured Logging Trait
 * 
 * Requirements: 65.1, 65.2
 * 
 * Provides convenient methods for structured logging across services.
 * 
 * Usage:
 * ```
 * class WHMService {
 *     use HasStructuredLogging;
 *     
 *     public function suspendAccount($server, $username) {
 *         $this->logWhm('info', 'Suspending account', [
 *             'server_id' => $server->id,
 *             'username' => $username
 *         ]);
 *     }
 * }
 * ```
 */
trait HasStructuredLogging
{
    /**
     * Log to the API channel
     *
     * @param string $level Log level (debug, info, warning, error, critical)
     * @param string $message Log message
     * @param array $context Additional context
     * @return void
     */
    protected function logApi(string $level, string $message, array $context = []): void
    {
        Log::channel('api')->$level($message, LogContext::api($context));
    }

    /**
     * Log to the WHM channel
     *
     * @param string $level Log level (debug, info, warning, error, critical)
     * @param string $message Log message
     * @param array $context Additional context
     * @return void
     */
    protected function logWhm(string $level, string $message, array $context = []): void
    {
        Log::channel('whm')->$level($message, LogContext::whm($context));
    }

    /**
     * Log to the Billing channel
     *
     * @param string $level Log level (debug, info, warning, error, critical)
     * @param string $message Log message
     * @param array $context Additional context
     * @return void
     */
    protected function logBilling(string $level, string $message, array $context = []): void
    {
        Log::channel('billing')->$level($message, LogContext::billing($context));
    }

    /**
     * Log to the Security channel
     *
     * @param string $level Log level (debug, info, warning, error, critical)
     * @param string $message Log message
     * @param array $context Additional context
     * @return void
     */
    protected function logSecurity(string $level, string $message, array $context = []): void
    {
        Log::channel('security')->$level($message, LogContext::security($context));
    }

    /**
     * Log operation with duration measurement
     *
     * @param string $channel Channel name (api, whm, billing, security)
     * @param string $level Log level
     * @param string $message Log message
     * @param float $startTime Start time from microtime(true)
     * @param array $context Additional context
     * @return void
     */
    protected function logWithDuration(
        string $channel,
        string $level,
        string $message,
        float $startTime,
        array $context = []
    ): void {
        $contextWithDuration = LogContext::withDuration($startTime, $context);
        Log::channel($channel)->$level($message, $contextWithDuration);
    }

    /**
     * Log exception to specified channel
     *
     * @param string $channel Channel name
     * @param string $message Log message
     * @param \Throwable $exception Exception to log
     * @param array $context Additional context
     * @return void
     */
    protected function logException(
        string $channel,
        string $message,
        \Throwable $exception,
        array $context = []
    ): void {
        $exceptionContext = LogContext::exception($exception, $context);
        Log::channel($channel)->error($message, $exceptionContext);
    }
}
