<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * Sentry Facade for easy access to SentryService
 * 
 * @method static void captureException(\Throwable $exception, array $context = [])
 * @method static void captureMessage(string $message, array $context = [])
 * @method static void logCritical(string $message, array $context = [])
 * @method static void logError(string $message, array $context = [])
 * @method static void addContext(array $context)
 * @method static void setUser($id, ?string $email = null, array $additional = [])
 * @method static void setCompanyContext(int $companyId, ?string $companyName = null)
 * @method static void addBreadcrumb(string $message, string $category = 'default', array $data = [], string $level = 'info')
 * @method static bool isEnabled()
 * @method static void flush()
 *
 * @see \App\Services\Logging\SentryService
 */
class Sentry extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return \App\Services\Logging\SentryService::class;
    }
}
