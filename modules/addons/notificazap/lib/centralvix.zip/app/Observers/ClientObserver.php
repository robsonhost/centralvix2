<?php

namespace App\Observers;

use App\Models\Client;
use App\Services\CacheService;

/**
 * ClientObserver - Automatically invalidate clients cache when changed
 */
class ClientObserver
{
    protected CacheService $cacheService;

    public function __construct(CacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    /**
     * Handle the Client "created" event.
     */
    public function created(Client $client): void
    {
        $this->invalidateCache($client);
    }

    /**
     * Handle the Client "updated" event.
     */
    public function updated(Client $client): void
    {
        $this->invalidateCache($client);
    }

    /**
     * Handle the Client "deleted" event.
     */
    public function deleted(Client $client): void
    {
        $this->invalidateCache($client);
    }

    /**
     * Invalidate relevant caches
     */
    private function invalidateCache(Client $client): void
    {
        $this->cacheService->invalidateClientsList($client->company_id);
    }
}
