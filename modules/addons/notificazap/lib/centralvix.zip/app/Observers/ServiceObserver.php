<?php

namespace App\Observers;

use App\Models\Service;
use App\Services\CacheService;

/**
 * ServiceObserver - Automatically invalidate services cache when changed
 */
class ServiceObserver
{
    protected CacheService $cacheService;

    public function __construct(CacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    /**
     * Handle the Service "created" event.
     */
    public function created(Service $service): void
    {
        $this->invalidateCache($service);
    }

    /**
     * Handle the Service "updated" event.
     */
    public function updated(Service $service): void
    {
        $this->invalidateCache($service);
    }

    /**
     * Handle the Service "deleted" event.
     */
    public function deleted(Service $service): void
    {
        $this->invalidateCache($service);
    }

    /**
     * Invalidate relevant caches
     */
    private function invalidateCache(Service $service): void
    {
        $this->cacheService->invalidateServicesList($service->company_id);
    }
}
