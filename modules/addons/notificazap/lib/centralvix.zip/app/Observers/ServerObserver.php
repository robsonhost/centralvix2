<?php

namespace App\Observers;

use App\Models\Server;
use App\Services\CacheService;

/**
 * ServerObserver - Automatically invalidate servers cache when changed
 */
class ServerObserver
{
    protected CacheService $cacheService;

    public function __construct(CacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    /**
     * Handle the Server "created" event.
     */
    public function created(Server $server): void
    {
        $this->invalidateCache($server);
    }

    /**
     * Handle the Server "updated" event.
     */
    public function updated(Server $server): void
    {
        $this->invalidateCache($server);
    }

    /**
     * Handle the Server "deleted" event.
     */
    public function deleted(Server $server): void
    {
        $this->invalidateCache($server);
    }

    /**
     * Invalidate relevant caches
     */
    private function invalidateCache(Server $server): void
    {
        $this->cacheService->invalidateServersList($server->company_id);
        
        // Also invalidate WHM packages cache for this server
        $this->cacheService->invalidateWhmPackages($server->company_id, $server->id);
    }
}
