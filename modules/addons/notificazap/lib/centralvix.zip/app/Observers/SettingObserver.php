<?php

namespace App\Observers;

use App\Models\Setting;
use App\Services\CacheService;

/**
 * SettingObserver - Automatically invalidate settings cache when changed
 */
class SettingObserver
{
    protected CacheService $cacheService;

    public function __construct(CacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    /**
     * Handle the Setting "created" event.
     */
    public function created(Setting $setting): void
    {
        $this->invalidateCache($setting);
    }

    /**
     * Handle the Setting "updated" event.
     */
    public function updated(Setting $setting): void
    {
        $this->invalidateCache($setting);
    }

    /**
     * Handle the Setting "deleted" event.
     */
    public function deleted(Setting $setting): void
    {
        $this->invalidateCache($setting);
    }

    /**
     * Invalidate relevant caches
     */
    private function invalidateCache(Setting $setting): void
    {
        $this->cacheService->invalidateSettings($setting->company_id);
        cache()->forget("company_settings_{$setting->company_id}");
    }
}
