<?php

namespace App\Observers;

use App\Models\Invoice;
use App\Models\RechargeOrder;
use App\Services\RechargeService;
use Illuminate\Support\Facades\Log;

/**
 * Observa Invoices para creditar automaticamente o saldo do cliente
 * sempre que a fatura referente a uma recarga for marcada como paga
 * (independente do gateway que confirmou o pagamento).
 */
class InvoiceRechargeObserver
{
    public function updated(Invoice $invoice): void
    {
        if (! $invoice->wasChanged('status')) {
            return;
        }

        if ($invoice->status !== 'paid') {
            return;
        }

        $order = RechargeOrder::where('invoice_id', $invoice->id)->first();
        if (! $order || $order->status === 'paid') {
            return;
        }

        try {
            app(RechargeService::class)->markPaid(
                $order,
                $invoice->payment_gateway,
                $invoice->transaction_id,
            );
        } catch (\Throwable $e) {
            Log::error('Falha ao creditar recarga após pagamento de fatura', [
                'invoice_id' => $invoice->id,
                'order_id'   => $order->id,
                'error'      => $e->getMessage(),
            ]);
        }
    }
}
