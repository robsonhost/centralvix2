<?php

namespace App\Observers;

use App\Models\Product;
use App\Services\CacheService;

/**
 * ProductObserver - Automatically invalidate products cache when changed
 */
class ProductObserver
{
    protected CacheService $cacheService;

    public function __construct(CacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    /**
     * Handle the Product "created" event.
     */
    public function created(Product $product): void
    {
        $this->invalidateCache($product);
    }

    /**
     * Handle the Product "updated" event.
     */
    public function updated(Product $product): void
    {
        $this->invalidateCache($product);
    }

    /**
     * Handle the Product "deleted" event.
     */
    public function deleted(Product $product): void
    {
        $this->invalidateCache($product);
    }

    /**
     * Invalidate relevant caches
     */
    private function invalidateCache(Product $product): void
    {
        $this->cacheService->invalidateProducts($product->company_id);
    }
}
