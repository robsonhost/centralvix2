<?php

namespace App\Observers;

use App\Models\Invoice;
use App\Services\CacheService;

/**
 * InvoiceObserver - Automatically invalidate invoices cache when changed
 */
class InvoiceObserver
{
    protected CacheService $cacheService;

    public function __construct(CacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    /**
     * Handle the Invoice "created" event.
     */
    public function created(Invoice $invoice): void
    {
        $this->invalidateCache($invoice);
    }

    /**
     * Handle the Invoice "updated" event.
     */
    public function updated(Invoice $invoice): void
    {
        $this->invalidateCache($invoice);
    }

    /**
     * Handle the Invoice "deleted" event.
     */
    public function deleted(Invoice $invoice): void
    {
        $this->invalidateCache($invoice);
    }

    /**
     * Invalidate relevant caches
     */
    private function invalidateCache(Invoice $invoice): void
    {
        $this->cacheService->invalidateInvoicesList($invoice->company_id);
    }
}
