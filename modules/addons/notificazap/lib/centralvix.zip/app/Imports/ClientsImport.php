<?php

namespace App\Imports;

use App\Models\Client;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ClientsImport implements ToCollection, WithHeadingRow
{
    protected $companyId;
    public $imported = 0;
    public $skipped = 0;
    public $errors = 0;

    public function __construct($companyId)
    {
        $this->companyId = $companyId;
    }

    public function collection(Collection $rows)
    {
        foreach ($rows as $row) {
            try {
                // Validar dados mínimos - a coluna 'email' no Excel vira 'email' no array
                if (empty($row['email'])) {
                    $this->skipped++;
                    continue;
                }

                // Verificar se já existe
                $existingClient = Client::where('email', $row['email'])->first();
                if ($existingClient) {
                    $this->skipped++;
                    continue;
                }

                // Criar cliente
                Client::create([
                    'uuid' => Str::uuid(),
                    'company_id' => $this->companyId,
                    'client_code' => $row['codigo'] ?? 'CLI-' . strtoupper(Str::random(8)),
                    'type' => $row['tipo'] ?? 'individual',
                    'firstname' => $row['nome'] ?? 'Cliente',
                    'lastname' => $row['sobrenome'] ?? 'Importado',
                    'email' => $row['email'],
                    'phone' => $row['telefone'] ?? null,
                    'mobile' => $row['celular'] ?? null,
                    'whatsapp' => $row['whatsapp'] ?? null,
                    'cpf' => $row['cpf'] ?? null,
                    'cnpj' => $row['cnpj'] ?? null,
                    'company_name' => $row['empresa'] ?? null,
                    'address' => $row['endereco'] ?? null,
                    'address_number' => $row['numero'] ?? null,
                    'address_complement' => $row['complemento'] ?? null,
                    'neighborhood' => $row['bairro'] ?? null,
                    'city' => $row['cidade'] ?? null,
                    'state' => $row['estado'] ?? null,
                    'zip' => $row['cep'] ?? null,
                    'country' => $row['pais'] ?? 'BR',
                    'status' => $this->getStatusValue($row['status'] ?? 'Ativo'),
                    'currency' => 'BRL',
                    'language' => 'pt_BR',
                ]);

                $this->imported++;

            } catch (\Exception $e) {
                $this->errors++;
                \Log::error('Erro ao importar cliente: ' . $e->getMessage());
            }
        }
    }

    private function getStatusValue($label): string
    {
        $values = [
            'Ativo' => 'active',
            'Inativo' => 'inactive',
            'Suspenso' => 'suspended',
            'Fechado' => 'closed',
            'Banido' => 'banned',
        ];

        return $values[$label] ?? 'inactive';
    }
}
