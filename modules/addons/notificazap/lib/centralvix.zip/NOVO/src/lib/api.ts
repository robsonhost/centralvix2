// API client para integração com backend Laravel
// Configure a URL base via .env: VITE_API_URL=https://api.seudominio.com/api
// Default ('/api') funciona quando o front é servido pelo mesmo domínio do Laravel.

export const API_URL: string =
  (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, "") ?? "/api";

const TOKEN_KEY = "ssh_token";
const USER_KEY = "ssh_user";

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(token: string | null) {
  if (typeof window === "undefined") return;
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}
export function getStoredUser<T = any>(): T | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try { return JSON.parse(raw) as T; } catch { return null; }
}
export function setStoredUser(user: unknown | null) {
  if (typeof window === "undefined") return;
  if (user) localStorage.setItem(USER_KEY, JSON.stringify(user));
  else localStorage.removeItem(USER_KEY);
}

export class ApiError extends Error {
  status: number;
  errors?: Record<string, string[]>;
  payload?: any;
  constructor(message: string, status: number, payload?: any) {
    super(message);
    this.status = status;
    this.payload = payload;
    this.errors = payload?.errors;
  }
}

type ApiInit = Omit<RequestInit, "body"> & { body?: any; auth?: boolean };

export async function apiFetch<T = any>(path: string, init: ApiInit = {}): Promise<T> {
  const { body, auth = true, headers, ...rest } = init;
  const finalHeaders: Record<string, string> = {
    Accept: "application/json",
    ...(headers as Record<string, string> | undefined),
  };
  if (body !== undefined && !(body instanceof FormData)) {
    finalHeaders["Content-Type"] = "application/json";
  }
  if (auth) {
    const token = getToken();
    if (token) finalHeaders.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(`${API_URL}${path}`, {
    ...rest,
    headers: finalHeaders,
    body:
      body === undefined
        ? undefined
        : body instanceof FormData
          ? body
          : JSON.stringify(body),
    credentials: "include",
  });

  const text = await res.text();
  const data = text ? safeJson(text) : null;

  if (!res.ok) {
    const message =
      data?.message ||
      (data?.errors && firstErrorMessage(data.errors)) ||
      `Erro ${res.status}`;
    throw new ApiError(message, res.status, data);
  }
  return data as T;
}

function safeJson(s: string) { try { return JSON.parse(s); } catch { return null; } }
function firstErrorMessage(errors: Record<string, string[]>) {
  const k = Object.keys(errors)[0];
  return k ? errors[k]?.[0] : undefined;
}

// ===== Endpoints =====
export type AuthUser = {
  id: number | string;
  name: string;
  email: string;
  whatsapp?: string;
  [k: string]: any;
};
export type AuthResponse = { token: string; user: AuthUser };

export const auth = {
  login: (payload: { email: string; password: string; otp?: string }) =>
    apiFetch<AuthResponse>("/auth/login", { method: "POST", body: payload, auth: false }),
  register: (payload: {
    name: string;
    email: string;
    whatsapp: string;
    country_code?: string;
    telegram?: string;
    referral_code?: string;
    password: string;
    password_confirmation: string;
  }) =>
    apiFetch<AuthResponse>("/auth/register", { method: "POST", body: payload, auth: false }),
  me: () => apiFetch<AuthUser>("/auth/me"),
  logout: () => apiFetch<{ ok: true }>("/auth/logout", { method: "POST" }),
};

export const dashboard = {
  stats: () => apiFetch<{
    balance: number;
    sms_today: number;
    active_numbers: number;
    countries: number;
  }>("/dashboard/stats"),
  numbers: () => apiFetch<Array<{
    id: number | string;
    number: string;
    country: string;
    service: string;
    status: string;
    created_at: string;
  }>>("/dashboard/numbers"),
  messages: () => apiFetch<Array<{
    id: number | string;
    number: string;
    from: string;
    text: string;
    received_at: string;
  }>>("/dashboard/messages"),
};
