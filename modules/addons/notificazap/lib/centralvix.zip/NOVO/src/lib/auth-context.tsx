import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { auth as authApi, getStoredUser, getToken, setStoredUser, setToken, type AuthUser } from "@/lib/api";

type AuthState = {
  user: AuthUser | null;
  loading: boolean;
  login: (email: string, password: string, otp?: string) => Promise<AuthUser>;
  register: (data: Parameters<typeof authApi.register>[0]) => Promise<AuthUser>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
};

const AuthCtx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const cached = getStoredUser<AuthUser>();
    if (cached) setUser(cached);
    if (getToken()) {
      authApi.me()
        .then((u) => { setUser(u); setStoredUser(u); })
        .catch(() => { setToken(null); setStoredUser(null); setUser(null); })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login: AuthState["login"] = async (email, password, otp) => {
    const r = await authApi.login({ email, password, otp });
    setToken(r.token);
    setStoredUser(r.user);
    setUser(r.user);
    return r.user;
  };

  const register: AuthState["register"] = async (data) => {
    const r = await authApi.register(data);
    setToken(r.token);
    setStoredUser(r.user);
    setUser(r.user);
    return r.user;
  };

  const logout = async () => {
    try { await authApi.logout(); } catch { /* ignore */ }
    setToken(null);
    setStoredUser(null);
    setUser(null);
  };

  const refresh = async () => {
    try {
      const u = await authApi.me();
      setUser(u); setStoredUser(u);
    } catch {
      setToken(null); setStoredUser(null); setUser(null);
    }
  };

  return (
    <AuthCtx.Provider value={{ user, loading, login, register, logout, refresh }}>
      {children}
    </AuthCtx.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthCtx);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de <AuthProvider>");
  return ctx;
}
