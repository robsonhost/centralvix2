import { Link } from "@tanstack/react-router";
import logoSrc from "@/assets/star-solution-logo.png";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link to="/" className={`flex items-center ${className}`} aria-label="Star Solution">
      <img
        src={logoSrc}
        alt="Star Solution"
        className="h-10 w-auto md:h-12 select-none drop-shadow-[0_4px_20px_rgba(14,165,233,0.35)]"
        draggable={false}
      />
    </Link>
  );
}
