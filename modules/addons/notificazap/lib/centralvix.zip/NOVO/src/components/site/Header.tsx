import { Link } from "@tanstack/react-router";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle";
import { ArrowRight } from "lucide-react";

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Logo />
        <nav className="hidden items-center gap-7 md:flex">
          <a href="#numeros" className="text-sm font-medium text-foreground/80 transition hover:text-primary-glow">Números</a>
          <a href="#servicos" className="text-sm font-medium text-foreground/80 transition hover:text-primary-glow">Serviços</a>
          <a href="#canais" className="text-sm font-medium text-foreground/80 transition hover:text-primary-glow">Bots</a>
          <a href="#showcase" className="text-sm font-medium text-foreground/80 transition hover:text-primary-glow">Como é</a>
          <a href="#faq" className="text-sm font-medium text-foreground/80 transition hover:text-primary-glow">FAQ</a>
        </nav>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link to="/login" className="hidden rounded-lg px-3.5 py-2 text-sm font-semibold text-foreground/90 hover:text-primary-glow sm:inline-flex">Entrar</Link>
          <Link to="/registro" className="btn-primary inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-semibold">
            Criar conta <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </header>
  );
}
