import { Logo } from "./Logo";
import { Send, MessageCircle } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-white/5 bg-surface">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-5 lg:px-8">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm text-muted-foreground">
            Chip virtual e números para receber SMS de WhatsApp, Telegram, Google e mais. App, Bot do Telegram e Bot do WhatsApp em uma só conta.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <a href="#" className="inline-flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-foreground/80 hover:border-primary"><Send className="h-3.5 w-3.5" /> Bot Telegram</a>
            <a href="#" className="inline-flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-foreground/80 hover:border-primary"><MessageCircle className="h-3.5 w-3.5" /> Bot WhatsApp</a>
          </div>
        </div>
        <div>
          <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Produto</h4>
          <ul className="mt-4 space-y-2.5 text-sm text-foreground/80">
            <li><a href="#servicos" className="hover:text-primary-glow">Serviços</a></li>
            <li><a href="#numeros" className="hover:text-primary-glow">Números</a></li>
            <li><a href="#showcase" className="hover:text-primary-glow">App e Bot</a></li>
            <li><a href="#faq" className="hover:text-primary-glow">FAQ</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Canais</h4>
          <ul className="mt-4 space-y-2.5 text-sm text-foreground/80">
            <li><a href="#" className="hover:text-primary-glow">Bot Telegram</a></li>
            <li><a href="#" className="hover:text-primary-glow">Bot WhatsApp</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Legal</h4>
          <ul className="mt-4 space-y-2.5 text-sm text-foreground/80">
            <li><a href="#" className="hover:text-primary-glow">Termos de Uso</a></li>
            <li><a href="#" className="hover:text-primary-glow">Privacidade</a></li>
            <li><a href="#" className="hover:text-primary-glow">Suporte</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5 py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} StarSolutionHub · Plataforma de números virtuais e recebimento de SMS.
      </div>
    </footer>
  );
}
