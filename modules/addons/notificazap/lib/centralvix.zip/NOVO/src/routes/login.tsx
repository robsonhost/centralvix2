import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Logo } from "@/components/site/Logo";
import { Eye, EyeOff, Mail, Lock, ShieldCheck, RefreshCw, Loader2, ArrowLeft, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { ApiError } from "@/lib/api";
import heroImg from "@/assets/login-hero-neon.jpg";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — StarSolutionHub" },
      { name: "description", content: "Acesse sua conta StarSolutionHub e gerencie seus números virtuais, SMS e bots." },
    ],
  }),
  component: LoginPage,
});

const loginSchema = z.object({
  email: z.string().trim().email("Informe um e-mail válido").max(255),
  password: z.string().min(6, "A senha deve ter ao menos 6 caracteres").max(128),
  captcha: z.string().min(1, "Digite o código exibido"),
});

function genCaptcha() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 5; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [show, setShow] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [captchaInput, setCaptchaInput] = useState("");
  const [captcha, setCaptcha] = useState<string>("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  // CAPTCHA gerado apenas no client → sem mismatch de hidratação
  useEffect(() => { setCaptcha(genCaptcha()); }, []);

  function refreshCaptcha() {
    setCaptcha(genCaptcha());
    setCaptchaInput("");
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = loginSchema.safeParse({ email, password, captcha: captchaInput });
    if (!parsed.success) {
      const fe: Record<string, string> = {};
      parsed.error.issues.forEach((i) => { fe[i.path[0] as string] = i.message; });
      setErrors(fe);
      toast.error("Verifique os campos destacados");
      return;
    }
    if (captchaInput.trim().toUpperCase() !== captcha) {
      setErrors({ captcha: "Código incorreto, tente novamente" });
      refreshCaptcha();
      return;
    }
    setErrors({});
    setSubmitting(true);
    try {
      await login(email, password);
      toast.success("Bem-vindo de volta!");
      navigate({ to: "/painel" });
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.errors) {
          const fe: Record<string, string> = {};
          Object.entries(err.errors).forEach(([k, v]) => { fe[k] = (v as string[])[0]; });
          setErrors(fe);
        }
        toast.error(err.message);
        refreshCaptcha();
      } else {
        toast.error("Não foi possível conectar à API. Verifique VITE_API_URL.");
        refreshCaptcha();
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#f8fafc] dark:bg-background">
      {/* Decorative blue blocks */}
      <div aria-hidden className="pointer-events-none absolute -left-32 -top-40 h-[520px] w-[520px] rounded-[80px] rotate-12 bg-[image:var(--gradient-primary)] opacity-90 blur-[2px]" />
      <div aria-hidden className="pointer-events-none absolute -left-20 bottom-[-180px] h-[360px] w-[360px] rounded-[60px] -rotate-6 bg-gradient-to-tr from-[#0ea5e9] to-[#38bdf8] opacity-80" />
      <div aria-hidden className="pointer-events-none absolute right-0 top-0 hidden h-screen w-[48%] bg-[image:linear-gradient(180deg,rgba(14,165,233,0.0),rgba(14,165,233,0.0))] lg:block" />

      <div className="relative mx-auto grid min-h-screen max-w-[1400px] grid-cols-1 gap-0 lg:grid-cols-[1fr_1fr]">
        {/* LEFT — Card */}
        <section className="flex items-center justify-center px-4 py-10 sm:px-10 lg:py-16">
          <div className="w-full max-w-[460px]">
            <div className="mb-5 flex items-center justify-between">
              <Link to="/" className="inline-flex items-center gap-2 text-sm text-[#64748b] hover:text-[#0f172a] dark:hover:text-foreground">
                <ArrowLeft className="h-4 w-4" /> Voltar ao site
              </Link>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-[#bae6fd] bg-white/70 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#0284c7] shadow-sm backdrop-blur">
                <Sparkles className="h-3 w-3" /> Acesso seguro
              </span>
            </div>

            <div className="rounded-3xl border border-white bg-white p-7 shadow-[0_30px_80px_-30px_rgba(14,165,233,0.45)] sm:p-9">
              <div className="mb-5 flex flex-col items-center text-center">
                <Logo />
                <h1 className="mt-5 font-display text-4xl tracking-tight text-[#0f172a]">Login</h1>
                <p className="mt-1.5 text-sm text-[#64748b]">
                  Insira suas credenciais abaixo
                </p>
              </div>

              <form className="space-y-4" onSubmit={onSubmit} noValidate>
                <Field label="E-mail" icon={<Mail className="h-4 w-4" />} error={errors.email}>
                  <input
                    type="email" autoComplete="email" value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="voce@email.com"
                    className="w-full bg-transparent text-sm text-[#0f172a] outline-none placeholder:text-[#94a3b8]"
                  />
                </Field>

                <Field
                  label="Senha" icon={<Lock className="h-4 w-4" />} error={errors.password}
                  right={
                    <button type="button" onClick={() => setShow(!show)} className="text-[#64748b] hover:text-[#0f172a]" aria-label="Mostrar senha">
                      {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  }
                >
                  <input
                    type={show ? "text" : "password"} autoComplete="current-password" value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-transparent text-sm text-[#0f172a] outline-none placeholder:text-[#94a3b8]"
                  />
                </Field>

                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 text-[#64748b]">
                    <input
                      type="checkbox"
                      checked={remember}
                      onChange={(e) => setRemember(e.target.checked)}
                      className="h-4 w-4 rounded border-[#cbd5e1] accent-[#0ea5e9]"
                    />
                    Lembrar-me
                  </label>
                  <a href="#" className="font-semibold text-[#0ea5e9] hover:underline">Esqueci a senha</a>
                </div>

                {/* CAPTCHA */}
                <div className="rounded-2xl border border-[#e2e8f0] bg-[#f1f5f9] p-4">
                  <div className="flex items-center gap-2 text-sm font-bold text-[#0f172a]">
                    <ShieldCheck className="h-4 w-4 text-[#0ea5e9]" />
                    Confirmação de segurança
                  </div>
                  <p className="mt-0.5 text-xs text-[#64748b]">
                    Digite os caracteres exibidos ao lado.
                  </p>
                  <div className="mt-3 flex items-center gap-2">
                    <div
                      aria-label="Código CAPTCHA"
                      className="select-none rounded-lg border border-[#bae6fd] bg-[image:repeating-linear-gradient(45deg,#bae6fd_0_8px,#e0f2fe_8px_16px)] px-3 py-2 font-mono text-lg font-extrabold tracking-[0.45em] text-[#0369a1] shadow-inner"
                      style={{ minWidth: 110, textAlign: "center", letterSpacing: "0.35em" }}
                    >
                      {captcha || "•••••"}
                    </div>
                    <button
                      type="button"
                      onClick={refreshCaptcha}
                      className="rounded-lg border border-[#cbd5e1] bg-white p-2 text-[#64748b] hover:text-[#0284c7]"
                      aria-label="Gerar novo código"
                    >
                      <RefreshCw className="h-4 w-4" />
                    </button>
                    <input
                      value={captchaInput}
                      onChange={(e) => setCaptchaInput(e.target.value.toUpperCase())}
                      placeholder="Digite o código"
                      maxLength={6}
                      className={`flex-1 rounded-lg border bg-white px-3 py-2 text-sm uppercase tracking-widest text-[#0f172a] outline-none transition focus:border-[#0ea5e9] focus:ring-2 focus:ring-[#7dd3fc] ${errors.captcha ? "border-destructive" : "border-[#cbd5e1]"}`}
                    />
                  </div>
                  {errors.captcha && <p className="mt-1.5 text-xs text-destructive">{errors.captcha}</p>}
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[image:linear-gradient(135deg,#0ea5e9,#38bdf8)] py-3 text-sm font-bold uppercase tracking-wider text-white shadow-[0_15px_30px_-10px_rgba(14,165,233,0.6)] transition hover:translate-y-[-1px] hover:shadow-[0_20px_40px_-10px_rgba(14,165,233,0.7)] disabled:opacity-60"
                >
                  {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
                  {submitting ? "Entrando…" : "Entrar"}
                </button>

                <Link
                  to="/registro"
                  className="block rounded-xl border-2 border-[#0ea5e9] bg-white py-2.5 text-center text-sm font-bold uppercase tracking-wider text-[#0284c7] transition hover:bg-[#f0f9ff]"
                >
                  Criar conta
                </Link>

                <div className="flex items-center gap-3 text-[11px] uppercase tracking-widest text-[#64748b]">
                  <div className="h-px flex-1 bg-[#cbd5e1]" /> ou <div className="h-px flex-1 bg-[#cbd5e1]" />
                </div>

                <button
                  type="button"
                  onClick={() => toast.info("Login com Google em breve")}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-[#cbd5e1] bg-white py-2.5 text-sm font-semibold text-[#0f172a] transition hover:bg-[#f1f5f9]"
                >
                  <GoogleIcon /> Entrar com Google
                </button>
              </form>
            </div>

            <p className="mt-5 text-center text-xs text-[#64748b]">
              Protegido por 2FA e sessão criptografada • © StarSolutionHub
            </p>
          </div>
        </section>

        {/* RIGHT — Hero image */}
        <section className="relative hidden lg:block">
          <div className="absolute inset-4 overflow-hidden rounded-[36px] shadow-[0_40px_80px_-30px_rgba(14,165,233,0.55)]">
            <img
              src={heroImg}
              alt="Jovem sorrindo segurando smartphone em frente a um painel neon azul da Star Solution Hub"
              className="h-full w-full object-cover"
              width={1024}
              height={1408}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[rgba(2,132,199,0.55)] via-transparent to-transparent" />
            <div className="absolute left-6 top-6 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5 text-[11px] font-bold uppercase tracking-widest text-white backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> Online · 184 países
            </div>
            <div className="absolute bottom-8 left-8 right-8 text-white">
              <h2 className="font-display text-3xl leading-tight drop-shadow-md">
                Seus SMS, no controle.
              </h2>
              <p className="mt-1.5 max-w-[28ch] text-sm text-white/85">
                Receba códigos de verificação em segundos — pelo painel, Telegram ou WhatsApp.
              </p>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function Field({
  label, icon, right, error, children,
}: { label: React.ReactNode; icon?: React.ReactNode; right?: React.ReactNode; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-[#64748b]">{label}</label>
      <div className={`flex items-center gap-2 rounded-xl border bg-white px-3 py-2.5 transition-colors focus-within:border-[#0ea5e9] focus-within:ring-2 focus-within:ring-[#7dd3fc] ${error ? "border-destructive" : "border-[#cbd5e1]"}`}>
        {icon && <span className="text-[#94a3b8]">{icon}</span>}
        <div className="flex-1">{children}</div>
        {right}
      </div>
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
      <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.4-1.6 4.1-5.5 4.1-3.3 0-6-2.7-6-6.1S8.7 6 12 6c1.9 0 3.2.8 3.9 1.5l2.7-2.6C16.9 3.4 14.7 2.5 12 2.5 6.8 2.5 2.6 6.7 2.6 12s4.2 9.5 9.4 9.5c5.4 0 9-3.8 9-9.2 0-.6-.1-1.1-.2-1.6H12z" />
    </svg>
  );
}
