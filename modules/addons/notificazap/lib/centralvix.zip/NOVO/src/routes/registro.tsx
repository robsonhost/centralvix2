import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Logo } from "@/components/site/Logo";
import {
  Eye, EyeOff, Mail, Lock, User, Phone, Gift, ShieldCheck, MessageCircle, Send, Check, X, Loader2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { ApiError } from "@/lib/api";


export const Route = createFileRoute("/registro")({
  head: () => ({
    meta: [
      { title: "Criar conta — StarSolutionHub" },
      { name: "description", content: "Cadastre-se grátis na StarSolutionHub e ative seu primeiro chip virtual em segundos." },
    ],
  }),
  component: RegisterPage,
});

const countries = [
  { code: "+55", flag: "🇧🇷", name: "Brasil" },
  { code: "+351", flag: "🇵🇹", name: "Portugal" },
  { code: "+1", flag: "🇺🇸", name: "EUA" },
  { code: "+44", flag: "🇬🇧", name: "Reino Unido" },
  { code: "+34", flag: "🇪🇸", name: "Espanha" },
  { code: "+49", flag: "🇩🇪", name: "Alemanha" },
];

const schema = z.object({
  name: z.string().trim().min(2, "Informe seu nome").max(80),
  email: z.string().trim().email("E-mail inválido").max(255),
  whatsapp: z.string().regex(/^\d{8,15}$/, "Número inválido (somente dígitos, com DDD)"),
  telegram: z.string().trim().max(64).optional().or(z.literal("")),
  ref: z.string().trim().max(32).optional().or(z.literal("")),
  password: z.string().min(8, "Mínimo 8 caracteres")
    .regex(/[A-Z]/, "Inclua uma letra maiúscula")
    .regex(/[a-z]/, "Inclua uma letra minúscula")
    .regex(/\d/, "Inclua um número"),
  terms: z.literal(true, { errorMap: () => ({ message: "Aceite os termos para continuar" }) }),
});

function strength(pw: string) {
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw)) s++;
  if (/[a-z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}

function RegisterPage() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [show, setShow] = useState(false);
  const [country, setCountry] = useState("+55");
  const [form, setForm] = useState({
    name: "", email: "", whatsapp: "", telegram: "", ref: "", password: "",
  });
  const [terms, setTerms] = useState(false);
  const [waOptIn, setWaOptIn] = useState(true);
  const [tgOptIn, setTgOptIn] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const upd = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...form, [k]: e.target.value });

  const pwScore = useMemo(() => strength(form.password), [form.password]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const cleanWa = form.whatsapp.replace(/\D/g, "");
    const parsed = schema.safeParse({ ...form, whatsapp: cleanWa, terms });
    if (!parsed.success) {
      const fe: Record<string, string> = {};
      parsed.error.issues.forEach((i) => { fe[i.path[0] as string] = i.message; });
      setErrors(fe);
      toast.error("Revise os campos destacados");
      return;
    }
    setErrors({});
    setSubmitting(true);
    try {
      await register({
        name: form.name,
        email: form.email,
        whatsapp: cleanWa,
        country_code: country,
        telegram: form.telegram || undefined,
        referral_code: form.ref || undefined,
        password: form.password,
        password_confirmation: form.password,
      });
      toast.success("Conta criada! Redirecionando para o painel…");
      navigate({ to: "/painel" });
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.errors) {
          const fe: Record<string, string> = {};
          Object.entries(err.errors).forEach(([k, v]) => {
            // mapeia campos do Laravel de volta pros nomes do form
            const map: Record<string, string> = { referral_code: "ref", password_confirmation: "password" };
            fe[map[k] ?? k] = (v as string[])[0];
          });
          setErrors(fe);
        }
        toast.error(err.message);
      } else {
        toast.error("Não foi possível conectar à API. Verifique VITE_API_URL.");
      }
    } finally {
      setSubmitting(false);
    }
  }


  return (
    <main className="min-h-screen hero-bg">
      <div className="grid-bg pointer-events-none absolute inset-x-0 top-0 h-screen opacity-30" />
      <div className="relative mx-auto max-w-7xl px-4 py-8 lg:px-8">
        <div className="mb-8 flex items-center justify-between">
          <Logo />
          <Link to="/login" className="text-sm text-muted-foreground hover:text-foreground">
            Já tenho conta →
          </Link>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1fr_1.15fr]">
          {/* LEFT — Value props */}
          <aside className="hidden flex-col gap-4 lg:flex">
            <div className="chip"><span className="h-1.5 w-1.5 rounded-full bg-success" /> Cadastro grátis · 30s</div>
            <h1 className="font-display text-5xl leading-[1.05] text-foreground">
              Sua infra de <span className="text-gradient">números virtuais</span> começa aqui.
            </h1>
            <p className="text-muted-foreground">
              Receba SMS de 180+ países, com bots no Telegram e WhatsApp, painel web e API.
            </p>

            <div className="mt-2 grid gap-3">
              <Bullet icon={ShieldCheck} title="Anti-fraude e 2FA">Sessões criptografadas e alertas em tempo real.</Bullet>
              <Bullet icon={MessageCircle} title="Notificações no WhatsApp">Receba cada código direto no seu Zap.</Bullet>
              <Bullet icon={Send} title="Bot no Telegram">Pedir, pagar e receber, tudo em um chat.</Bullet>
            </div>

            <div className="surface-card mt-4 p-5">
              <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Confiado por times de</div>
              <div className="mt-3 grid grid-cols-3 gap-3 text-center font-display text-sm text-foreground/70">
                <div>Growth</div><div>QA / SaaS</div><div>E-commerce</div>
                <div>Afiliados</div><div>Web3</div><div>Agências</div>
              </div>
            </div>
          </aside>

          {/* RIGHT — Form */}
          <section>
            <div className="glass-card p-7 sm:p-9">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-2xl text-foreground sm:text-3xl">Criar conta</h2>
                <span className="chip">PASSO 1 / 2</span>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                Use seu e-mail corporativo. O código de ativação é enviado por e-mail e WhatsApp.
              </p>

              <form className="mt-6 grid gap-4 sm:grid-cols-2" onSubmit={onSubmit} noValidate>
                <Field className="sm:col-span-2" label="Nome completo" icon={<User className="h-4 w-4" />} error={errors.name}>
                  <input value={form.name} onChange={upd("name")} placeholder="Como devemos te chamar"
                    className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground/60" />
                </Field>

                <Field className="sm:col-span-2" label="E-mail" icon={<Mail className="h-4 w-4" />} error={errors.email}>
                  <input type="email" value={form.email} onChange={upd("email")} placeholder="voce@empresa.com"
                    className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground/60" />
                </Field>

                <Field className="sm:col-span-2" label="WhatsApp" icon={<Phone className="h-4 w-4" />} error={errors.whatsapp}
                  left={
                    <select value={country} onChange={(e) => setCountry(e.target.value)}
                      className="-ml-1 rounded-md bg-transparent py-1 pr-1 text-sm outline-none">
                      {countries.map((c) => (
                        <option key={c.code} value={c.code} className="bg-surface text-foreground">
                          {c.flag} {c.code}
                        </option>
                      ))}
                    </select>
                  }>
                  <input inputMode="tel" value={form.whatsapp}
                    onChange={(e) => setForm({ ...form, whatsapp: e.target.value.replace(/[^\d\s()-]/g, "") })}
                    placeholder="(11) 99999-9999"
                    className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground/60" />
                </Field>

                <Field label="Usuário do Telegram (opcional)" icon={<Send className="h-4 w-4" />} error={errors.telegram}>
                  <input value={form.telegram} onChange={upd("telegram")} placeholder="@seuusuario"
                    className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground/60" />
                </Field>

                <Field label="Código de indicação (opcional)" icon={<Gift className="h-4 w-4" />} error={errors.ref}>
                  <input value={form.ref} onChange={upd("ref")} placeholder="ex: AMIGO10"
                    className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground/60" />
                </Field>

                <div className="sm:col-span-2">
                  <Field label="Senha" icon={<Lock className="h-4 w-4" />} error={errors.password}
                    right={
                      <button type="button" onClick={() => setShow(!show)} className="text-muted-foreground hover:text-foreground" aria-label="Mostrar senha">
                        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    }>
                    <input type={show ? "text" : "password"} value={form.password} onChange={upd("password")}
                      placeholder="Mín. 8 caracteres, com maiúscula e número"
                      className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground/60" />
                  </Field>
                  <PwMeter score={pwScore} pw={form.password} />
                </div>

                <div className="sm:col-span-2 grid gap-2 rounded-xl border border-border bg-surface/60 p-3">
                  <CheckRow checked={waOptIn} onChange={setWaOptIn}>
                    <MessageCircle className="h-4 w-4 text-[#25D366]" />
                    Receber códigos e alertas pelo <strong>WhatsApp</strong>
                    <span className="ml-1 rounded-md bg-success/15 px-1.5 py-0.5 text-[10px] font-bold text-success">RECOMENDADO</span>
                  </CheckRow>
                  <CheckRow checked={tgOptIn} onChange={setTgOptIn}>
                    <Send className="h-4 w-4 text-[#229ED9]" />
                    Ativar bot do <strong>Telegram</strong> para esta conta
                  </CheckRow>
                  <CheckRow checked={terms} onChange={setTerms} error={errors.terms}>
                    Li e aceito os <a href="#" className="font-semibold text-primary-glow underline">Termos</a> e a{" "}
                    <a href="#" className="font-semibold text-primary-glow underline">Política de Privacidade</a>
                    <span className="text-destructive"> *</span>
                  </CheckRow>
                </div>

                <button type="submit" disabled={submitting}
                  className="btn-primary sm:col-span-2 inline-flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold uppercase tracking-wider disabled:opacity-60">
                  {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
                  {submitting ? "Criando conta…" : "Criar conta grátis"}
                </button>


                <p className="sm:col-span-2 text-center text-xs text-muted-foreground">
                  Ao continuar você concorda em receber o código de ativação por e-mail e WhatsApp.
                </p>
              </form>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}

function Field({
  label, icon, right, left, error, className = "", children,
}: {
  label: React.ReactNode; icon?: React.ReactNode; right?: React.ReactNode; left?: React.ReactNode;
  error?: string; className?: string; children: React.ReactNode;
}) {
  return (
    <div className={className}>
      <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">{label}</label>
      <div className={`flex items-center gap-2 rounded-xl border bg-input/40 px-3 py-2.5 transition-colors focus-within:border-primary focus-within:ring-2 focus-within:ring-[color-mix(in_oklab,var(--primary)_25%,transparent)] ${error ? "border-destructive" : "border-border"}`}>
        {icon && <span className="text-muted-foreground">{icon}</span>}
        {left}
        <div className="flex-1">{children}</div>
        {right}
      </div>
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}

function Bullet({ icon: Icon, title, children }: { icon: any; title: string; children: React.ReactNode }) {
  return (
    <div className="surface-card flex items-start gap-3 p-4">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-[image:var(--gradient-primary)] text-primary-foreground">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <div className="font-bold text-foreground">{title}</div>
        <div className="text-sm text-muted-foreground">{children}</div>
      </div>
    </div>
  );
}

function CheckRow({
  checked, onChange, error, children,
}: { checked: boolean; onChange: (v: boolean) => void; error?: string; children: React.ReactNode }) {
  return (
    <>
      <label className="flex cursor-pointer items-center gap-2 text-sm text-foreground/90">
        <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)}
          className="h-4 w-4 rounded border-border accent-[var(--primary)]" />
        <span className="inline-flex flex-wrap items-center gap-1">{children}</span>
      </label>
      {error && <p className="-mt-1 pl-6 text-xs text-destructive">{error}</p>}
    </>
  );
}

function PwMeter({ score, pw }: { score: number; pw: string }) {
  const labels = ["muito fraca", "fraca", "média", "boa", "forte", "excelente"];
  const colors = ["bg-destructive", "bg-destructive", "bg-yellow-500", "bg-yellow-400", "bg-success", "bg-success"];
  const checks = [
    { ok: pw.length >= 8, t: "8+ caracteres" },
    { ok: /[A-Z]/.test(pw), t: "Maiúscula" },
    { ok: /[a-z]/.test(pw), t: "Minúscula" },
    { ok: /\d/.test(pw), t: "Número" },
  ];
  return (
    <div className="mt-2">
      <div className="flex gap-1">
        {[0, 1, 2, 3, 4].map((i) => (
          <div key={i} className={`h-1 flex-1 rounded ${i < score ? colors[score] : "bg-border"}`} />
        ))}
      </div>
      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
        <span className="font-bold uppercase tracking-wider">{pw ? labels[score] : "defina sua senha"}</span>
        {checks.map((c) => (
          <span key={c.t} className={`inline-flex items-center gap-1 ${c.ok ? "text-success" : ""}`}>
            {c.ok ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />} {c.t}
          </span>
        ))}
      </div>
    </div>
  );
}
