import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import {
  ArrowRight, ArrowUpRight, CheckCircle2, ChevronDown, Globe2,
  ShieldCheck, Zap, CreditCard, Activity, Smartphone, Send, MessageCircle,
  Lock, Headphones, Cpu, Wallet, Sparkles, Star, LogIn, Download, QrCode, BarChart3, Server,
} from "lucide-react";
import { useState } from "react";
import phoneSms from "@/assets/star-phone-sms.png";
import starPanel from "@/assets/star-panel.png";
import starBot from "@/assets/star-bot.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "StarSolutionHub — Chip virtual e SMS para WhatsApp, Telegram e mais" },
      { name: "description", content: "Compre chips virtuais e receba SMS em segundos. Bot do Telegram e Bot do WhatsApp. Mais de 180 países e pagamento via Pix." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <Hero />
      <LogosStrip />
      <StatsBand />
      <Showcase />
      <Services />
      <Channels />
      <NumbersGlobal />
      <HowItWorks />
      <PricingPayments />
      <Testimonials />
      <Faq />
      <FinalCta />
      <Footer />
    </div>
  );
}

/* ============================== HERO ============================== */
function Hero() {
  return (
    <section className="hero-bg relative overflow-hidden">
      <div className="grid-bg absolute inset-0 -z-0 opacity-60 [mask-image:radial-gradient(60%_60%_at_50%_30%,black,transparent)]" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 pb-20 pt-20 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:px-8 lg:pt-28">
        <div>
          <span className="chip">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> +180 países · entrega em segundos
          </span>
          <h1 className="mt-5 text-5xl font-display text-foreground sm:text-6xl lg:text-7xl">
            Chip <span className="text-gradient">virtual</span> pra receber<br /> SMS em segundos.
          </h1>
          <p className="mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
            Ative WhatsApp, Telegram, Google, Instagram e mais usando números virtuais nacionais e internacionais. Use pelo site, Bot do Telegram ou Bot do WhatsApp.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link to="/registro" className="btn-primary inline-flex items-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold">
              Quero meu chip virtual <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/login" className="btn-outline inline-flex items-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold">
              <LogIn className="h-4 w-4" /> Já tenho conta
            </Link>
          </div>
          <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> Reembolso se SMS não chegar</span>
            <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> Sem mensalidade</span>
            <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> Pix instantâneo</span>
          </div>
        </div>

        {/* Hero phone image */}
        <div className="relative">
          <div className="absolute -inset-10 -z-10 rounded-[2rem] bg-[image:var(--gradient-primary)] opacity-25 blur-3xl" />
          <div className="absolute right-6 top-6 z-10 hidden rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-[11px] text-muted-foreground backdrop-blur lg:block">
            <div className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-emerald-400" /> SMS recebido agora</div>
            <div className="mt-1 font-mono text-foreground">WhatsApp · 874 312</div>
          </div>
          <div className="absolute -left-2 bottom-6 z-10 hidden rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-[11px] text-muted-foreground backdrop-blur lg:block">
            <div className="flex items-center gap-2"><Globe2 className="h-3.5 w-3.5 text-primary-glow" /> 🇺🇸 +1 415 ••• 22-18</div>
            <div className="mt-1 font-mono text-foreground">Telegram · 551 902</div>
          </div>
          <div className="relative rounded-[2rem] border border-white/10 bg-gradient-to-b from-surface-2/60 to-surface/40 p-3 shadow-[0_30px_80px_-30px_rgba(14,165,233,0.35)] backdrop-blur-sm lg:p-4">
            <img
              src={phoneSms}
              alt="Celular recebendo SMS de verificação de WhatsApp, Telegram e Google"
              width={1024}
              height={1024}
              className="relative mx-auto w-full rounded-3xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================== SHOWCASE — phone, bot, painel ============================== */
function Showcase() {
  return (
    <section id="showcase" className="bg-surface/40 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="chip">Como é por dentro</span>
          <h2 className="mt-3 text-3xl font-display sm:text-4xl">
            Veja o <span className="text-gradient">site</span> e os <span className="text-gradient">Bots</span> de verdade
          </h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Dois jeitos de comprar e receber SMS — escolha o seu. Mesma carteira, mesmo histórico.
          </p>
        </div>

        {/* Painel showcase */}
        <div className="mt-16 grid items-center gap-10 lg:grid-cols-[1fr_1.15fr]">
          <div>
            <span className="chip"><Smartphone className="h-3 w-3" /> Site / Web</span>
            <h3 className="mt-3 text-2xl font-display sm:text-3xl">Sua área do cliente, <span className="text-gradient">simples e direta</span></h3>
            <p className="mt-3 text-sm text-muted-foreground">
              Carteira, números ativos, SMS recebidos e histórico — tudo em uma única tela. Compra em 1 clique, sem cadastrar cartão.
            </p>
            <ul className="mt-5 space-y-2 text-sm text-foreground/85">
              {[
                "Saldo, recargas via Pix e cupons em um só lugar",
                "Estoque ao vivo de cada serviço e país",
                "Histórico completo e exportação CSV",
                "Indicação com bônus automático",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-400" /> {t}</li>
              ))}
            </ul>
            <Link to="/registro" className="btn-primary mt-7 inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold">
              Criar minha conta <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="relative">
            <div className="absolute -inset-8 -z-10 rounded-[2rem] bg-primary/15 blur-3xl" />
            <img
              src={starPanel}
              alt="Área do cliente StarSolutionHub com carteira, números ativos e SMS recebidos"
              width={1600}
              height={1024}
              loading="lazy"
              className="w-full rounded-2xl border border-white/10 shadow-[0_30px_80px_-30px_rgba(79,70,229,0.6)]"
            />
          </div>
        </div>

        {/* Bot + App */}
        <div className="mt-24 grid items-center gap-10 lg:grid-cols-[1.15fr_1fr]">
          <div className="relative order-2 lg:order-1">
            <div className="absolute -inset-8 -z-10 rounded-[2rem] bg-sky-400/15 blur-3xl" />
            <img
              src={starBot}
              alt="Bot do Telegram da StarSolutionHub com menu para comprar número e receber SMS"
              width={900}
              height={1280}
              loading="lazy"
              className="mx-auto w-full max-w-sm drop-shadow-[0_30px_60px_rgba(34,158,217,0.35)]"
            />
          </div>
          <div className="order-1 lg:order-2">
            <span className="chip"><Send className="h-3 w-3" /> Bot do Telegram</span>
            <h3 className="mt-3 text-2xl font-display sm:text-3xl">Pediu, pagou, <span className="text-gradient">recebeu</span> — tudo no chat</h3>
            <p className="mt-3 text-sm text-muted-foreground">
              Sem abrir site, sem app extra. Pelo Telegram você navega no catálogo, compra o número, paga com Pix e recebe o SMS direto no chat.
            </p>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {[
                { i: QrCode, t: "Pix gerado no chat" },
                { i: MessageCircle, t: "Bot WhatsApp separado" },
                { i: Download, t: "Receba pelo Telegram" },
                { i: ShieldCheck, t: "Login com 2FA opcional" },
              ].map((c) => (
                <div key={c.t} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3">
                  <div className="grid h-9 w-9 place-items-center rounded-lg bg-[image:var(--gradient-primary)]"><c.i className="h-4 w-4 text-white" /></div>
                  <span className="text-sm">{c.t}</span>
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#" className="btn-outline inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold">
                <Send className="h-4 w-4" /> Abrir no Telegram
              </a>
              <a href="#" className="btn-outline inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold">
                <MessageCircle className="h-4 w-4" /> Bot WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function DashboardPreview() {
  return (
    <div className="surface-card overflow-hidden p-0">
      <div className="flex items-center gap-2 border-b border-white/5 bg-white/[0.02] px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/70" />
        <div className="ml-3 flex-1 truncate rounded-md border border-white/10 bg-black/30 px-3 py-1 text-[11px] text-muted-foreground">starsolutionhub.com / minha conta</div>
      </div>
      <div className="grid gap-3 p-4 sm:grid-cols-3">
        {[
          { label: "Saldo", value: "R$ 142,80", icon: Wallet, tone: "from-indigo-500/30 to-indigo-500/0" },
          { label: "Números ativos", value: "12", icon: Smartphone, tone: "from-emerald-500/30 to-emerald-500/0" },
          { label: "SMS hoje", value: "284", icon: Activity, tone: "from-fuchsia-500/30 to-fuchsia-500/0" },
        ].map((k) => (
          <div key={k.label} className={`rounded-xl border border-white/10 bg-gradient-to-br ${k.tone} p-3`}>
            <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-muted-foreground">
              {k.label}<k.icon className="h-3.5 w-3.5" />
            </div>
            <div className="mt-1 text-xl font-display">{k.value}</div>
          </div>
        ))}
      </div>
      <div className="px-4 pb-4">
        <div className="mb-2 flex items-center justify-between text-xs text-muted-foreground">
          <span className="uppercase tracking-widest">SMS recebidos · 24h</span>
          <span className="text-emerald-400">▲ 18%</span>
        </div>
        <Spark />
        <div className="mt-4 space-y-2">
          {[
            { app: "WhatsApp BR", code: "874 312", country: "🇧🇷", time: "agora" },
            { app: "Telegram", code: "551 902", country: "🇺🇸", time: "1m" },
            { app: "Instagram", code: "204 778", country: "🇵🇹", time: "3m" },
          ].map((r) => (
            <div key={r.code} className="flex items-center justify-between rounded-lg border border-white/5 bg-white/[0.03] px-3 py-2 text-sm">
              <div className="flex items-center gap-3">
                <span>{r.country}</span>
                <span className="font-medium">{r.app}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="rounded-md bg-emerald-400/10 px-2 py-0.5 font-mono text-xs text-emerald-300">{r.code}</span>
                <span className="text-[11px] text-muted-foreground">{r.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Spark() {
  const points = [4, 9, 6, 12, 8, 14, 10, 18, 13, 22, 17, 24, 19, 28];
  const max = Math.max(...points);
  const path = points.map((p, i) => `${(i / (points.length - 1)) * 100},${100 - (p / max) * 100}`).join(" ");
  return (
    <div className="rounded-xl border border-white/10 bg-black/30 p-3">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="h-24 w-full">
        <defs>
          <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#818cf8" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#818cf8" stopOpacity="0" />
          </linearGradient>
        </defs>
        <polyline points={path} fill="none" stroke="#a5b4fc" strokeWidth="1.5" />
        <polygon points={`0,100 ${path} 100,100`} fill="url(#g)" />
      </svg>
    </div>
  );
}

/* ============================== LOGOS STRIP ============================== */
function LogosStrip() {
  const items = ["WhatsApp", "Telegram", "Google", "Instagram", "TikTok", "Facebook", "Discord", "Twitter / X"];
  return (
    <section className="border-y border-white/5 bg-surface/60 py-6">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-3 text-sm text-muted-foreground">
          <span className="text-xs uppercase tracking-[0.22em]">Ativações em</span>
          {items.map((i) => (
            <span key={i} className="font-display text-base text-foreground/70">{i}</span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== STATS ============================== */
function StatsBand() {
  const stats = [
    { v: "1.2M+", l: "SMS entregues / mês" },
    { v: "+180", l: "Países disponíveis" },
    { v: "99.9%", l: "Uptime do painel" },
    { v: "<3s", l: "Tempo médio de SMS" },
  ];
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.l} className="surface-card p-6">
            <div className="font-display text-4xl text-gradient">{s.v}</div>
            <div className="mt-1 text-sm text-muted-foreground">{s.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ============================== SERVICES (catálogo) ============================== */
function Services() {
  const items = [
    { name: "WhatsApp Brasil Plus", price: "R$ 7,50", stock: "835", tone: "emerald" },
    { name: "Telegram Plus", price: "R$ 6,10", stock: "412", tone: "sky" },
    { name: "Google / Gmail", price: "R$ 4,20", stock: "617", tone: "red" },
    { name: "Instagram", price: "R$ 1,90", stock: "1.205", tone: "fuchsia" },
    { name: "TikTok", price: "R$ 2,00", stock: "1.885", tone: "rose" },
    { name: "Facebook", price: "R$ 2,40", stock: "740", tone: "blue" },
    { name: "Discord", price: "R$ 1,70", stock: "990", tone: "violet" },
    { name: "Twitter / X", price: "R$ 3,10", stock: "508", tone: "slate" },
  ];
  return (
    <section id="servicos" className="bg-surface/40 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <span className="chip">Catálogo</span>
            <h2 className="mt-3 text-3xl font-display sm:text-4xl">Compre em 1 clique. <span className="text-gradient">Sem cadastro de cartão.</span></h2>
            <p className="mt-2 max-w-xl text-sm text-muted-foreground">Preços fixos por número. Reembolso automático se o SMS não chegar. Estoque ao vivo direto do painel.</p>
          </div>
          <Link to="/registro" className="btn-outline inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold">
            Ver catálogo completo <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((s) => (
            <div key={s.name} className="surface-card group p-5 transition hover:border-primary/40">
              <div className="flex items-start justify-between">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-white/5 text-sm font-display">{s.name.charAt(0)}</div>
                <span className="text-[10px] uppercase tracking-widest text-emerald-400">{s.stock} disp.</span>
              </div>
              <div className="mt-4 text-sm text-muted-foreground">{s.name}</div>
              <div className="mt-1 flex items-baseline justify-between">
                <div className="font-display text-2xl">{s.price}</div>
                <ArrowRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary-glow" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== CHANNELS ============================== */
function Channels() {
  const items = [
    {
      icon: Send,
      title: "Bot do Telegram",
      tag: "@numbersystemsms_bot",
      desc: "Acesse o catálogo, compre números e receba o código direto no chat do Telegram.",
      cta: "Abrir no Telegram",
    },
    {
      icon: MessageCircle,
      title: "Bot do WhatsApp",
      tag: "Conversa nativa",
      desc: "Tudo pelo WhatsApp: solicitar número, receber código e recarregar via Pix.",
      cta: "Iniciar conversa",
    },
  ];
  return (
    <section id="canais" className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="chip">2 bots · 1 conta</span>
          <h2 className="mt-3 text-3xl font-display sm:text-4xl">Use onde for melhor pra você</h2>
          <p className="mt-2 text-sm text-muted-foreground">Painel, Telegram e WhatsApp — saldo e histórico sincronizados em tempo real.</p>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:max-w-4xl lg:mx-auto">
          {items.map((c) => (
            <div key={c.title} className="glass-card group relative overflow-hidden p-6">
              <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/20 blur-3xl" />
              <c.icon className="h-7 w-7 text-primary-glow" />
              <div className="mt-5 flex items-center gap-2">
                <h3 className="text-xl font-display">{c.title}</h3>
                <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] uppercase tracking-widest text-muted-foreground">{c.tag}</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{c.desc}</p>
              <a href="#" className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary-glow">
                {c.cta} <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== DASHBOARD SHOWCASE ============================== */
function DashboardShowcase() {
  const features = [
    { icon: BarChart3, title: "Métricas em tempo real", text: "Compras, SMS recebidos, taxa de entrega e países por período." },
    { icon: Server, title: "API REST + Webhooks", text: "Integre seu sistema. Receba callback do SMS no seu endpoint." },
    { icon: ShieldCheck, title: "2FA e auditoria", text: "Login com 2FA, sessões ativas, IP e log de cada ação." },
    { icon: Cpu, title: "Automação", text: "Compra em lote, regras de retry e roteamento por país automaticamente." },
  ];
  return (
    <section id="painel" className="bg-surface/40 py-20">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div className="surface-card overflow-hidden p-0">
          <div className="flex items-center justify-between border-b border-white/5 bg-white/[0.02] px-4 py-3 text-xs text-muted-foreground">
            <span className="uppercase tracking-widest">Painel · Histórico de consumo</span>
            <span className="font-mono">14 dias</span>
          </div>
          <div className="p-5">
            <div className="grid grid-cols-3 gap-3">
              <Kpi label="Compras" value="284" trend="+12%" />
              <Kpi label="Aprovadas" value="271" trend="+9%" tone="emerald" />
              <Kpi label="Reembolsadas" value="13" trend="-3%" tone="rose" />
            </div>
            <div className="mt-4"><Spark /></div>
            <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
              {["WhatsApp 41%", "Telegram 22%", "Google 18%", "Outros 19%"].map((b) => (
                <div key={b} className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2">
                  <span>{b.split(" ")[0]}</span>
                  <span className="text-muted-foreground">{b.split(" ")[1]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <span className="chip">Painel completo</span>
          <h2 className="mt-3 text-3xl font-display sm:text-4xl">
            Um <span className="text-gradient">cockpit profissional</span> pra operar SMS em escala
          </h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Pensado pra quem opera de verdade: gestor de saldo, indicações, favoritos, status dos serviços, exportação CSV e atalhos pra compra rápida.
          </p>
          <div className="mt-7 grid gap-4 sm:grid-cols-2">
            {features.map((f) => (
              <div key={f.title} className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
                <f.icon className="h-5 w-5 text-primary-glow" />
                <h3 className="mt-3 text-sm font-bold">{f.title}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Kpi({ label, value, trend, tone = "indigo" }: { label: string; value: string; trend: string; tone?: string }) {
  const toneCls = tone === "emerald" ? "text-emerald-300" : tone === "rose" ? "text-rose-300" : "text-indigo-300";
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="mt-1 font-display text-xl">{value}</div>
      <div className={`text-[11px] ${toneCls}`}>{trend}</div>
    </div>
  );
}

/* ============================== NUMBERS GLOBAL ============================== */
function NumbersGlobal() {
  const countries = [
    { f: "🇧🇷", n: "Brasil", c: "+55" },
    { f: "🇺🇸", n: "EUA", c: "+1" },
    { f: "🇵🇹", n: "Portugal", c: "+351" },
    { f: "🇲🇽", n: "México", c: "+52" },
    { f: "🇦🇷", n: "Argentina", c: "+54" },
    { f: "🇨🇴", n: "Colômbia", c: "+57" },
    { f: "🇪🇸", n: "Espanha", c: "+34" },
    { f: "🇬🇧", n: "Reino Unido", c: "+44" },
    { f: "🇩🇪", n: "Alemanha", c: "+49" },
    { f: "🇫🇷", n: "França", c: "+33" },
    { f: "🇮🇳", n: "Índia", c: "+91" },
    { f: "🇮🇩", n: "Indonésia", c: "+62" },
  ];
  return (
    <section id="numeros" className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="chip"><Globe2 className="h-3 w-3" /> Cobertura global</span>
          <h2 className="mt-3 text-3xl font-display sm:text-4xl">Números de <span className="text-gradient">+180 países</span></h2>
          <p className="mt-2 text-sm text-muted-foreground">Estoque renovado o tempo todo. Selecione país, app e finalize em 1 clique.</p>
        </div>
        <div className="mt-10 grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {countries.map((c) => (
            <div key={c.n} className="surface-card flex items-center gap-3 p-4">
              <span className="text-2xl">{c.f}</span>
              <div>
                <div className="text-sm font-semibold">{c.n}</div>
                <div className="text-xs text-muted-foreground">{c.c}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== HOW IT WORKS ============================== */
function HowItWorks() {
  const steps = [
    { n: "01", icon: Wallet, title: "Crie sua conta e adicione saldo", text: "Pix, PicPay ou criptomoeda. Aprovação automática em segundos." },
    { n: "02", icon: Smartphone, title: "Escolha o app e o país", text: "Mais de 180 países e dezenas de plataformas com estoque ao vivo." },
    { n: "03", icon: Zap, title: "Receba o SMS em segundos", text: "Código aparece no painel, Telegram ou WhatsApp em até 3s." },
  ];
  return (
    <section className="bg-surface/40 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="chip">Como funciona</span>
          <h2 className="mt-3 text-3xl font-display sm:text-4xl">3 passos. <span className="text-gradient">Sem segredo.</span></h2>
        </div>
        <div className="relative mt-12 grid gap-5 md:grid-cols-3">
          {steps.map((s) => (
            <div key={s.n} className="surface-card relative p-6">
              <div className="absolute right-5 top-5 font-display text-3xl text-white/5">{s.n}</div>
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-[image:var(--gradient-primary)]">
                <s.icon className="h-5 w-5 text-white" />
              </div>
              <h3 className="mt-5 text-lg font-display">{s.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== PRICING / PAYMENTS ============================== */
function PricingPayments() {
  return (
    <section className="py-20">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[1fr_1.2fr] lg:px-8">
        <div className="glass-card relative overflow-hidden p-8">
          <div className="absolute -right-16 -bottom-16 h-56 w-56 rounded-full bg-primary/30 blur-3xl" />
          <span className="chip">Pagamentos</span>
          <h2 className="mt-3 text-3xl font-display">Recarga simples,<br /> liberação <span className="text-gradient">instantânea</span></h2>
          <p className="mt-3 text-sm text-muted-foreground">A partir de R$ 5,00. Sem mensalidade, sem fidelidade. Você gasta apenas com os números que usar.</p>
          <div className="mt-6 grid grid-cols-3 gap-2">
            {[
              { l: "Pix", icon: Zap },
              { l: "PicPay", icon: CreditCard },
              { l: "Cripto", icon: Lock },
            ].map((p) => (
              <div key={p.l} className="rounded-lg border border-white/10 bg-white/[0.03] p-3 text-center">
                <p.icon className="mx-auto h-5 w-5 text-primary-glow" />
                <div className="mt-1.5 text-xs font-semibold">{p.l}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {[
            { icon: ShieldCheck, t: "Reembolso garantido", d: "Se o SMS não chegar, o saldo volta automaticamente." },
            { icon: Headphones, t: "Suporte humano", d: "Atendimento via chat, Telegram e WhatsApp todos os dias." },
            { icon: Activity, t: "Estoque ao vivo", d: "Veja a quantidade disponível antes de comprar." },
            { icon: Sparkles, t: "Programa de indicação", d: "Ganhe bônus por cada amigo cadastrado." },
          ].map((f) => (
            <div key={f.t} className="surface-card p-5">
              <f.icon className="h-5 w-5 text-primary-glow" />
              <div className="mt-3 text-sm font-bold">{f.t}</div>
              <div className="text-xs text-muted-foreground">{f.d}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== TESTIMONIALS ============================== */
function Testimonials() {
  const items = [
    { name: "Carlos Lima", role: "Operador SMS", t: "Já usei várias plataformas, essa é a mais rápida que testei. Em 1s o número aparece no meu painel." },
    { name: "Juliana Calisto", role: "Agência digital", t: "Atendo várias contas e o painel facilita muito. O bot do WhatsApp salvou minha vida." },
    { name: "Fernando Gomes", role: "Dev fullstack", t: "API REST decente, webhook funciona. Subi a integração no mesmo dia. Recomendo." },
    { name: "Marizete Lins", role: "Social media", t: "Crio várias contas pra clientes e nunca tive problema. Reembolso quando falha é automático." },
    { name: "Letícia Burba", role: "Afiliada", t: "Saldo barato, suporte responde rápido e tem app no celular. Não preciso de mais nada." },
    { name: "Lucas Scavello", role: "Mídia paga", t: "Uso números internacionais pra cupons. Estoque sempre cheio e preço justo." },
  ];
  return (
    <section className="bg-surface/40 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <span className="chip">Reputação</span>
          <h2 className="mt-3 text-3xl font-display sm:text-4xl">Quem usa, <span className="text-gradient">recomenda.</span></h2>
        </div>
        <div className="mt-12 grid gap-4 md:grid-cols-3">
          {items.map((t) => (
            <div key={t.name} className="surface-card p-6">
              <div className="flex gap-0.5 text-amber-400">
                {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
              </div>
              <p className="mt-3 text-sm text-foreground/90">"{t.t}"</p>
              <div className="mt-5 flex items-center gap-3 border-t border-white/5 pt-4">
                <div className="grid h-9 w-9 place-items-center rounded-full bg-[image:var(--gradient-primary)] font-display text-sm text-white">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-bold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== FAQ ============================== */
const faqItems = [
  { q: "Quanto tempo o número fica ativo?", a: "O número virtual permanece ativo por até 19 minutos para receber SMS. Após esse período não recebe novos códigos, mas a conta criada no app permanece ativa por meses." },
  { q: "Posso receber vários códigos no mesmo número?", a: "Sim. Dentro da janela de 19 minutos você pode receber quantos SMS quiser, desde que sejam do mesmo aplicativo escolhido." },
  { q: "Tem reembolso se o SMS não chegar?", a: "Sim. A cobrança só é efetivada após o primeiro SMS. Se o código não chegar, o saldo volta automaticamente sem precisar abrir chamado." },
  { q: "Quais formas de pagamento vocês aceitam?", a: "Pix, PicPay e criptomoedas (USDT, BTC). Recargas a partir de R$ 5,00 com liberação instantânea." },
  { q: "Tem API para integrar no meu sistema?", a: "Sim. Oferecemos API REST autenticada por token e webhooks para receber callbacks de SMS no seu endpoint." },
  { q: "Como funcionam o Bot do Telegram e do WhatsApp?", a: "Você conecta sua conta a um dos bots e passa a comprar números, receber SMS e recarregar saldo direto pelo chat, com a mesma carteira do painel." },
  { q: "Posso escolher DDDs específicos?", a: "Não. Os números são fornecidos pelas operadoras e a seleção de DDDs específicos não é possível na maioria dos países." },
  { q: "Vocês guardam meus dados pessoais?", a: "Não. Seus dados não são vinculados aos números virtuais. As informações cadastrais existem apenas para fins fiscais e podem ser apagadas a qualquer momento." },
];

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="py-20">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[1fr_1.6fr] lg:px-8">
        <div>
          <span className="chip">FAQ</span>
          <h2 className="mt-3 text-3xl font-display sm:text-4xl">
            Tirando as <span className="text-gradient">dúvidas</span> antes de você perguntar.
          </h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Não encontrou? Fale com o suporte pelo painel, Telegram ou WhatsApp — respondemos em minutos.
          </p>
        </div>
        <div className="space-y-2.5">
          {faqItems.map((it, i) => (
            <div key={it.q} className="surface-card overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
              >
                <span className="flex items-center gap-3">
                  <span className="font-display text-sm text-primary-glow">{String(i + 1).padStart(2, "0")}</span>
                  <span className="text-sm font-semibold">{it.q}</span>
                </span>
                <ChevronDown className={`h-5 w-5 shrink-0 text-primary-glow transition ${open === i ? "rotate-180" : ""}`} />
              </button>
              {open === i && (
                <div className="border-t border-white/5 bg-black/20 px-5 py-4 text-sm text-muted-foreground">{it.a}</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== FINAL CTA ============================== */
function FinalCta() {
  return (
    <section className="px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="glass-card relative overflow-hidden p-10 sm:p-14">
          <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-primary/40 blur-3xl" />
          <div className="absolute -left-32 -bottom-32 h-96 w-96 rounded-full bg-fuchsia-500/20 blur-3xl" />
          <div className="relative grid gap-10 md:grid-cols-[1.4fr_1fr] md:items-center">
            <div>
              <h2 className="text-3xl font-display sm:text-5xl">
                Pronto pra escalar<br /> seu <span className="text-gradient">SMS virtual?</span>
              </h2>
              <p className="mt-4 max-w-xl text-sm text-muted-foreground">
                Crie sua conta em 30 segundos, recarregue com Pix e comece a usar pelo painel, Telegram ou WhatsApp.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link to="/registro" className="btn-primary inline-flex items-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold">
                  Criar conta grátis <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/login" className="btn-outline inline-flex items-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold">
                  <LogIn className="h-4 w-4" /> Já tenho conta
                </Link>
              </div>
            </div>
            <div className="grid gap-3">
              {[
                { i: Send, t: "App + Bot Telegram", s: "Compra e SMS no chat" },
                { i: MessageCircle, t: "Bot do WhatsApp", s: "Conversa nativa BR" },
                { i: Server, t: "API REST + Webhooks", s: "Para devs e times" },
              ].map((c) => (
                <div key={c.t} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.04] p-4">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-[image:var(--gradient-primary)]">
                    <c.i className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <div className="text-sm font-bold">{c.t}</div>
                    <div className="text-xs text-muted-foreground">{c.s}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
