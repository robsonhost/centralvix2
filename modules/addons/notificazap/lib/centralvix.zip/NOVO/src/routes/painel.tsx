import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { dashboard, ApiError } from "@/lib/api";
import { Logo } from "@/components/site/Logo";
import { Activity, Wallet, Globe2, MessageSquare, LogOut, RefreshCw } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/painel")({
  head: () => ({
    meta: [
      { title: "Painel — StarSolutionHub" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: PainelPage,
});

type Stats = Awaited<ReturnType<typeof dashboard.stats>>;
type NumRow = Awaited<ReturnType<typeof dashboard.numbers>>[number];
type MsgRow = Awaited<ReturnType<typeof dashboard.messages>>[number];

function PainelPage() {
  const { user, loading, logout } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<Stats | null>(null);
  const [nums, setNums] = useState<NumRow[]>([]);
  const [msgs, setMsgs] = useState<MsgRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/login" });
  }, [loading, user, navigate]);

  async function load() {
    setBusy(true); setErr(null);
    try {
      const [s, n, m] = await Promise.allSettled([
        dashboard.stats(),
        dashboard.numbers(),
        dashboard.messages(),
      ]);
      if (s.status === "fulfilled") setStats(s.value);
      if (n.status === "fulfilled") setNums(n.value);
      if (m.status === "fulfilled") setMsgs(m.value);
      const firstErr = [s, n, m].find((r) => r.status === "rejected") as PromiseRejectedResult | undefined;
      if (firstErr) {
        const e = firstErr.reason;
        setErr(e instanceof ApiError ? e.message : "Falha ao carregar dados");
      }
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => { if (user) load(); }, [user]);

  if (loading || !user) {
    return <div className="grid min-h-screen place-items-center text-muted-foreground">Carregando…</div>;
  }

  return (
    <main className="min-h-screen hero-bg">
      <header className="sticky top-0 z-20 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 lg:px-8">
          <Link to="/"><Logo /></Link>
          <div className="flex items-center gap-3">
            <span className="hidden text-sm text-muted-foreground sm:inline">Olá, <strong className="text-foreground">{user.name}</strong></span>
            <button onClick={load} disabled={busy} className="btn-outline inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-bold">
              <RefreshCw className={`h-3.5 w-3.5 ${busy ? "animate-spin" : ""}`} /> Atualizar
            </button>
            <button
              onClick={async () => { await logout(); toast.success("Sessão encerrada"); navigate({ to: "/login" }); }}
              className="btn-primary inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-bold"
            >
              <LogOut className="h-3.5 w-3.5" /> Sair
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
        <h1 className="font-display text-3xl text-foreground sm:text-4xl">
          Painel <span className="text-gradient">do cliente</span>
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">Saldo, números ativos e SMS recebidos em tempo real.</p>

        {err && (
          <div className="mt-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
            {err} — verifique se a URL da API Laravel está configurada em <code>VITE_API_URL</code>.
          </div>
        )}

        <section className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Kpi icon={Wallet} label="Saldo" value={stats ? `R$ ${Number(stats.balance ?? 0).toFixed(2)}` : "—"} />
          <Kpi icon={MessageSquare} label="SMS hoje" value={stats?.sms_today?.toString() ?? "—"} />
          <Kpi icon={Activity} label="Números ativos" value={stats?.active_numbers?.toString() ?? "—"} />
          <Kpi icon={Globe2} label="Países" value={stats?.countries?.toString() ?? "—"} />
        </section>

        <section className="mt-8 grid gap-6 lg:grid-cols-2">
          <Card title="Meus números">
            {nums.length === 0 ? (
              <Empty>Nenhum número alugado.</Empty>
            ) : (
              <ul className="divide-y divide-border">
                {nums.map((n) => (
                  <li key={n.id} className="flex items-center justify-between py-3 text-sm">
                    <div>
                      <div className="font-mono text-foreground">{n.number}</div>
                      <div className="text-xs text-muted-foreground">{n.country} · {n.service}</div>
                    </div>
                    <span className="chip">{n.status}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card title="Mensagens recebidas">
            {msgs.length === 0 ? (
              <Empty>Nenhuma mensagem ainda.</Empty>
            ) : (
              <ul className="space-y-3">
                {msgs.map((m) => (
                  <li key={m.id} className="rounded-lg border border-border bg-surface px-3 py-2 text-sm">
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span className="font-mono">{m.number}</span>
                      <span>{new Date(m.received_at).toLocaleString("pt-BR")}</span>
                    </div>
                    <div className="mt-1 text-foreground">{m.text}</div>
                    <div className="mt-1 text-[11px] text-muted-foreground">de {m.from}</div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </section>
      </div>
    </main>
  );
}

function Kpi({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="surface-card p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Icon className="h-3.5 w-3.5 text-primary-glow" /> {label}
      </div>
      <div className="mt-1 font-display text-2xl text-foreground">{value}</div>
    </div>
  );
}
function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="surface-card p-5">
      <h2 className="mb-3 font-display text-lg text-foreground">{title}</h2>
      {children}
    </div>
  );
}
function Empty({ children }: { children: React.ReactNode }) {
  return <div className="rounded-lg border border-dashed border-border bg-surface/50 p-6 text-center text-sm text-muted-foreground">{children}</div>;
}
