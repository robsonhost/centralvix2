# Documentação do Projeto — Meu Número Virtual (Clone Front-end)

> Guia completo para usar com Cursor e integrar ao Laravel / cPanel.

---

## 1. Visão geral

Front-end clonado do site **meunumerovirtual.com**, construído em:

- **TanStack Start v1** (React 19 + file-based routing)
- **Vite 7** (build)
- **Tailwind CSS v4** (via `src/styles.css`, sem `tailwind.config.js`)
- **TypeScript estrito**
- **Bun** ou **npm** como gerenciador

Páginas implementadas (somente UI, sem backend):

| Rota         | Arquivo                       | Descrição |
|--------------|-------------------------------|-----------|
| `/`          | `src/routes/index.tsx`        | Landing completa (hero, features, processo, FAQ, depoimentos, app, bot Telegram, CTA) |
| `/login`     | `src/routes/login.tsx`        | Login + Google + CAPTCHA + painel lateral |
| `/registro`  | `src/routes/registro.tsx`     | Cadastro com Nome, E-mail, WhatsApp, Indicação, CAPTCHA, checkboxes |

---

## 2. Estrutura de pastas

```
src/
├── routes/
│   ├── __root.tsx          # Layout raiz (head, meta, fontes)
│   ├── index.tsx           # Landing
│   ├── login.tsx
│   └── registro.tsx
├── components/site/
│   ├── Logo.tsx            # Logo "meu número virtual" (somente texto)
│   ├── Header.tsx          # Header com nav + botões Login/Cadastrar
│   └── Footer.tsx
├── assets/                 # Imagens originais baixadas do site
│   ├── header-img.png
│   ├── right-phones.png
│   ├── center-phones.png
│   ├── mockup-mac.png
│   ├── multi-phones.png
│   ├── bot.png
│   └── login-hero.jpg
├── styles.css              # Tailwind v4 + tokens HSL (tema roxo)
├── router.tsx
└── routeTree.gen.ts        # AUTO-GERADO — não editar
```

---

## 3. Comandos

```bash
bun install        # ou npm install
bun run dev        # dev server (http://localhost:8080)
bun run build      # build de produção em .output/public/
bun run start      # preview do build
```

---

## 4. Design System (tema)

Tokens HSL definidos em `src/styles.css` (`@theme`). Tudo é semântico, **nunca** use cores hardcoded (`text-white`, `bg-[#...]`).

Variáveis principais:

- `--primary` (roxo da marca)
- `--background`, `--foreground`
- `--card`, `--border`, `--muted`
- `--accent`

Classes utilitárias customizadas:
- `.btn-primary` — botão roxo gradiente
- `.btn-outline` — botão borda
- `.surface-card` — card com fundo + borda + sombra

Fonte: **Plus Jakarta Sans** (carregada via `<link>` em `__root.tsx`).

---

## 5. Formulários (campos para integração)

### `/login` — `src/routes/login.tsx`
```ts
{
  email: string,
  password: string,
  captcha: string   // validar com texto exibido
}
```

### `/registro` — `src/routes/registro.tsx`
```ts
{
  nome: string,
  email: string,
  whatsapp: string,       // com DDD
  indicacao?: string,     // opcional
  password: string,       // mín. 6 caracteres
  captcha: string,
  aceitaTermos: boolean,  // OBRIGATÓRIO
  receberWhatsApp: boolean,
  receberEmails: boolean
}
```

> Hoje os `onSubmit` apenas previnem o default. Substitua pelas chamadas reais à API.

---

## 6. Integração com Laravel (passo a passo)

### A) Backend Laravel — rotas sugeridas

```php
// routes/api.php
Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/login',    [AuthController::class, 'login']);
Route::post('/auth/google',   [AuthController::class, 'google']);
Route::get ('/captcha',       [CaptchaController::class, 'generate']);
```

### B) Front consome via fetch

Crie `src/lib/api.ts`:
```ts
const API = import.meta.env.VITE_API_URL ?? '/api';

export async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const r = await fetch(`${API}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
```

E em `login.tsx` / `registro.tsx` troque o `onSubmit`:
```ts
const onSubmit = async (e) => {
  e.preventDefault();
  await apiPost('/auth/login', { email, password, captcha });
  // redirect, etc.
};
```

### C) Deploy 100% estático em `public/` do Laravel

1. `bun run build` → gera `.output/public/`.
2. Copie o conteúdo para `laravel/public/app/` (ou raiz).
3. Renomeie `index.html` → `resources/views/app.blade.php` e ajuste caminhos com `{{ asset('...') }}`.
4. Rota catch-all:
   ```php
   Route::get('/{any?}', fn () => view('app'))->where('any', '.*');
   ```

---

## 7. Deploy direto no cPanel (sem Laravel ainda)

1. `bun run build`
2. Suba o conteúdo de `.output/public/` para `public_html/`
3. Crie `.htaccess`:
   ```apache
   <IfModule mod_rewrite.c>
     RewriteEngine On
     RewriteBase /
     RewriteCond %{REQUEST_FILENAME} -f [OR]
     RewriteCond %{REQUEST_FILENAME} -d
     RewriteRule ^ - [L]
     RewriteRule . /index.html [L]
   </IfModule>
   ```

---

## 8. Prompts úteis para o Cursor

Cole no Cursor quando for integrar:

```
Implemente em src/routes/login.tsx a chamada real ao endpoint
POST {VITE_API_URL}/auth/login enviando { email, password, captcha }.
Em caso de sucesso, armazene o token em cookie HttpOnly (via backend)
e redirecione com useNavigate({ to: '/' }). Em erro, mostre toast.
```

```
Em src/routes/registro.tsx, faça POST para /auth/register enviando todos
os campos do formulário. Valide WhatsApp com regex BR (DDD + 9 dígitos).
Adicione react-hook-form + zod para validação.
```

```
Crie src/lib/api.ts conforme a seção 6.B da DOCUMENTACAO.md e refatore
login.tsx e registro.tsx para usá-lo.
```

---

## 9. Pontos de atenção

- **NÃO** edite `src/routeTree.gen.ts` — é regenerado pelo Vite.
- **NÃO** use `react-router-dom` — o roteador é `@tanstack/react-router`.
- Para adicionar nova rota, basta criar `src/routes/nome.tsx` com `createFileRoute('/nome')`.
- Imagens estão em `src/assets/` — para trocar, basta substituir o arquivo.
- O CAPTCHA atual é só visual (gerado no client). Substitua por um real do backend.

---

## 10. Próximos passos sugeridos

1. Conectar `/login` e `/registro` ao Laravel.
2. Adicionar página `/dashboard` autenticada (números virtuais do usuário).
3. Painel de admin para gerenciar serviços.
4. Integração Telegram bot + WhatsApp API.
5. Pagamento (Stripe/Mercado Pago/PIX).

---

Qualquer dúvida durante a integração no Cursor, mencione esta documentação e ele entenderá a estrutura.
