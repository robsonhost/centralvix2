# Integração Front-end ↔ Laravel

Toda a comunicação com o backend passa por `src/lib/api.ts`.

## 1. Configurar a URL da API

Crie um arquivo `.env` na raiz do projeto baseado em `.env.example`:

```
VITE_API_URL=https://api.seudominio.com/api
```

Reinicie o `bun run dev` após criar/alterar. Se omitido, o default é `/api` (front e back no mesmo domínio).

## 2. Autenticação (token Bearer / Laravel Sanctum)

- Após `POST /auth/login` ou `POST /auth/register`, o front espera a resposta:
  ```json
  { "token": "...", "user": { "id": 1, "name": "...", "email": "..." } }
  ```
- O token é guardado em `localStorage` (`ssh_token`) e enviado automaticamente no header `Authorization: Bearer <token>` para chamadas autenticadas.
- `GET /auth/me` é chamado ao carregar para revalidar a sessão.
- `POST /auth/logout` invalida no servidor.

### Exemplo Laravel (`routes/api.php`)

```php
Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/login',    [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/auth/me',          [AuthController::class, 'me']);
    Route::post('/auth/logout',     [AuthController::class, 'logout']);
    Route::get('/dashboard/stats',     [DashboardController::class, 'stats']);
    Route::get('/dashboard/numbers',   [DashboardController::class, 'numbers']);
    Route::get('/dashboard/messages',  [DashboardController::class, 'messages']);
});
```

### Exemplo de controller de login

```php
public function login(Request $request) {
    $data = $request->validate([
        'email' => 'required|email',
        'password' => 'required',
        'otp' => 'nullable|string',
    ]);
    if (!Auth::attempt(['email'=>$data['email'],'password'=>$data['password']])) {
        return response()->json(['message' => 'Credenciais inválidas'], 401);
    }
    $user = $request->user();
    $token = $user->createToken('web')->plainTextToken;
    return response()->json(['token' => $token, 'user' => $user]);
}
```

## 3. Campos do registro enviados pelo front

```json
{
  "name": "...",
  "email": "...",
  "whatsapp": "11999999999",
  "country_code": "+55",
  "telegram": "@user",          // opcional
  "referral_code": "AMIGO10",   // opcional
  "password": "...",
  "password_confirmation": "..."
}
```

Validation Laravel sugerida:

```php
$request->validate([
    'name' => 'required|string|max:80',
    'email' => 'required|email|unique:users,email',
    'whatsapp' => 'required|string|max:20',
    'country_code' => 'nullable|string|max:6',
    'telegram' => 'nullable|string|max:64',
    'referral_code' => 'nullable|string|max:32',
    'password' => 'required|string|min:8|confirmed',
]);
```

Erros de validação retornados pelo Laravel (`422` com `{ message, errors: { campo: [msg] } }`) são automaticamente mapeados nos campos do formulário.

## 4. Endpoints do Painel

`GET /dashboard/stats` → `{ balance, sms_today, active_numbers, countries }`
`GET /dashboard/numbers` → `[{ id, number, country, service, status, created_at }]`
`GET /dashboard/messages` → `[{ id, number, from, text, received_at }]`

## 5. CORS

No `config/cors.php` do Laravel libere o domínio do front:

```php
'paths' => ['api/*', 'sanctum/csrf-cookie'],
'allowed_origins' => ['https://seusite.com', 'http://localhost:3000'],
'supports_credentials' => true,
```

## 6. Rotas do front

- `/` — landing
- `/login` — chama `auth.login`
- `/registro` — chama `auth.register`
- `/painel` — protegida (redireciona para `/login` se sem token); consome `dashboard.*`
