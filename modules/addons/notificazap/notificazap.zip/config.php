<?php
/*
 * @ https://EasyToYou.eu - IonCube v14 Decoder Online
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 10/08/2022
 */

// Decoded file for php version 74.
define("NZVERSAODOMODULO", "4.2");
define("NZURLSERVIDORWHATSAPP", "https://srv.notifica.click");
define("NZSITEMODULESPAY", "https://painel.modulespay.com.br");
define("NZTOKENGERAL", "oGzRlDH1P5Gcvr4HHkO0GNSroBeP1rsL");
define("NZARQUIVOLOG", "https://painel.modulespay.com.br/knowledgebase/15/Historico-de-Atualizacoes.html");
define("NZLINKVERSAO", "https://painel.modulespay.com.br/versao/v_notificazap.txt");
define("NZLINKDOWNLOAD", "https://painel.modulespay.com.br/dl.php?type=d&id=19");

?>