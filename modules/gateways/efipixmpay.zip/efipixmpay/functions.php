<?php
/*
 * @ https://EasyToYou.eu - IonCube v14 Decoder Online
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 10/08/2022
 */

// Decoded file for php version 74.
class efipixmpay
{
    private $licenseKey;
    private $baseDir;
    private $dias;
    private $whmcsUrl = "https://painel.modulespay.com.br/";
    private $UrlApiEfi = "https://pix.api.efipay.com.br";
    private $secret_key = "WHMCS@EFIPAYPIX#MPAY";
    private $license_file = "efipixlicense.dat";
    private $iv_secreto = "973sc41dcJtXuJJf04EG";
    private $apiKey = "5OTj74MgvYhIsl4d6SOmTZLaUMGPKSkKhaYcpkP79RuGoh8yICUO2e2RVlxp09lL8ML5A8cRgRgOqz1bfUvDpwVPwxszHAqIFreYVWKsAOwJsqO8QRtRTyv1";
    private $verifyfilepath = "modules/servers/licensing/check.efipay.php";
    public function __construct($licenseKey = "")
    {
        $this->licenseKey = $licenseKey;
        $this->baseDir = __DIR__;
        $this->dias = 5;
    }
    public function checkLicense()
    {
        if (empty($this->licenseKey)) {
            return NULL;
        }
        $local_data = [];
        if (file_exists($this->baseDir . "/" . $this->license_file)) {
            try {
                $encrypted = file_get_contents($this->baseDir . "/" . $this->license_file);
                $iv = substr(hash("sha256", $this->iv_secreto), 0, 16);
                $decrypted = openssl_decrypt($encrypted, "AES-256-CBC", $this->secret_key, 0, $iv);
                $local_data = explode("|", $decrypted);
            } catch (Exception $e) {
                error_log("Erro na leitura do arquivo de licença: " . $e->getMessage());
            }
        } else {
            $this->CriarArquivo($this->baseDir . "/" . $this->license_file);
        }
        $need_check = true;
        if (count($local_data) === 2) {
            $stored_date = DateTime::createFromFormat("Y-m-d", $local_data[1]);
            $current_date = new DateTime();
            if ($current_date <= $stored_date) {
                $need_check = false;
            }
        }
        $hmac_url = $this->obterDominioSemSubdominio();
        $hmac = $this->cleanDomain($hmac_url);
        if ($need_check) {
            $server_ip = $_SERVER["SERVER_ADDR"] ?? $_SERVER["LOCAL_ADDR"] ?? gethostbyname(gethostname());
            $iv = substr(hash("sha256", $this->iv_secreto), 0, 16);
            $licensekey_enc = openssl_encrypt($this->licenseKey, "AES-256-CBC", $this->secret_key, 0, $iv);
            $ip_enc = openssl_encrypt($server_ip, "AES-256-CBC", $this->secret_key, 0, $iv);
            $dir_enc = openssl_encrypt($this->baseDir, "AES-256-CBC", $this->secret_key, 0, $iv);
            $key = openssl_encrypt($this->apiKey, "AES-256-CBC", $this->secret_key, 0, $iv);
            $domain = openssl_encrypt($hmac, "AES-256-CBC", $this->secret_key, 0, $iv);
            $data = http_build_query(["licensekey" => $licensekey_enc, "ip" => $ip_enc, "dir" => $dir_enc, "apikey" => $key, "domain" => $domain]);
            if (!$this->is_server_online($this->whmcsUrl)) {
                return ["status" => "Invalid", "data" => date("Y-m-d"), "erro" => "Servidor de licenças offline: " . $this->whmcsUrl];
            }
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $this->whmcsUrl . $this->verifyfilepath);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_TIMEOUT, 30);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($curl);
            $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            if ($httpCode === 200) {
                $result = json_decode($response, true);
                if ($result["status"] === "Active") {
                    $new_data = $this->licenseKey . "|" . $this->adicionarDias(date("Y-m-d"), $this->dias);
                    $encrypted = openssl_encrypt($new_data, "AES-256-CBC", $this->secret_key, 0, $iv);
                    file_put_contents($this->baseDir . "/" . $this->license_file, $encrypted, LOCK_EX);
                    chmod($this->baseDir . "/" . $this->license_file, 384);
                }
                return ["status" => $result["status"], "data" => date("Y-m-d"), "erro" => $result["erro"]];
            }
            return ["status" => "Invalid", "data" => date("Y-m-d"), "erro" => "Falha na verificação remota: HTTP Code " . $httpCode];
        }
        return ["status" => "Active", "data" => date("Y-m-d"), "erro" => ""];
    }
    private function adicionarDias($data, $dias)
    {
        $date = new DateTime($data);
        $date->modify("+" . $dias . " days");
        return $date->format("Y-m-d");
    }
    private function is_server_online($url)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $result !== false && 200 <= $httpCode && $httpCode < 400;
    }
    public function ArquivoExiste($filePath)
    {
        return file_exists($filePath);
    }
    public function redirect($link, $timeout = 1000)
    {
        echo "<script type=\"text/javascript\">\r\n        setTimeout(function () {\r\n            window.location.href = \"" . $link . "\";\r\n            }, " . $timeout . ");\r\n            </script>";
    }
    public function validateExpirationDate($date)
    {
        $currentDate = date("Ymd");
        $invoiceDate = trim(str_replace("-", "", $date));
        return $currentDate < $invoiceDate ? $date : date("Y-m-d");
    }
    public function getLicenseMessage($status, $error)
    {
        $site = "https://www.modulespay.com.br";
        $email = "contato@modulespay.com.br";
        $messages = ["Active" => "<div class=\"alert alert-success\"><h4 class=\"alert-heading\">Licença está ativa.</h4></div>", "Invalid" => "<div class=\"alert alert-warning\"><h4 class=\"alert-heading\">Licença inválida <p>::) " . $error . "</p></h4>Entre em contato em <a href=\"" . $site . "\" target=\"_blank\">" . $site . "</a> ou pelo e-mail " . $email . ".</div>", "Expired" => "<div class=\"alert alert-warning\"><h4 class=\"alert-heading\">Licença Expirada ::) " . $error . "</h4>Contate o suporte.</div>", "Suspended" => "<div class=\"alert alert-warning\"><h4 class=\"alert-heading\">Licença Suspensa ::) " . $error . "</h4>Regularize em <a href=\"" . $site . "\" target=\"_blank\">" . $site . "</a>.</div>", "Default" => "<div class=\"alert alert-warning\"><h4 class=\"alert-heading\">Resposta Inválida.</h4>Contate o suporte.</div>"];
        return $messages[$status] ?? $messages["Default"];
    }
    public function pegaVersaoModulo($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, false);
    }
    public function PegaCPFCNPJ($doc, $userId)
    {
        $cpfCnpjData = WHMCS\Database\Capsule::table("tblcustomfieldsvalues")->where("fieldid", $doc)->where("relid", $userId)->value("value");
        return $cpfCnpjData ?? NULL;
    }
    public function cpf_ou_cnpj($cpfCnpj)
    {
        $taxId = preg_replace("/\\D/", "", $cpfCnpj);
        if (strlen($taxId) === 11) {
            return "cpf";
        }
        if (strlen($taxId) === 14) {
            return "cnpj";
        }
        return "invalid";
    }
    public function validador_cpf_cnpj($cpfCnpj)
    {
        $taxId = preg_replace("/\\D/", "", $cpfCnpj);
        if (11 < strlen($taxId)) {
            return $this->valida_cnpj($taxId);
        }
        return $this->valida_cpf($taxId);
    }
    private function valida_cpf($cpf)
    {
        $cpf = str_pad(preg_replace("/\\D/", "", $cpf), 11, "0", STR_PAD_LEFT);
        if (strlen($cpf) != 11 || preg_match("/(\\d)\\1{10}/", $cpf)) {
            return false;
        }
        for ($t = 9; $t < 11; $t++) {
            $sum = 0;
            for ($i = 0; $i < $t; $i++) {
                $sum += $cpf[$i] * ($t + 1 - $i);
            }
            $digit = $sum * 10 % 11;
            if ($cpf[$t] != ($digit == 10 ? 0 : $digit)) {
                return false;
            }
        }
        return true;
    }
    private function valida_cnpj($cnpj)
    {
        $cnpj = str_pad(preg_replace("/\\D/", "", $cnpj), 14, "0", STR_PAD_LEFT);
        if (strlen($cnpj) != 14 || preg_match("/(\\d)\\1{13}/", $cnpj)) {
            return false;
        }
        for ($t = 12; $t < 14; $t++) {
            $sum = 0;
            $pos = $t - 7;
            for ($i = 0; $i < $t; $i++) {
                $sum += $cnpj[$i] * $pos--;
                if ($pos < 2) {
                    $pos = 9;
                }
            }
            $digit = $sum % 11 < 2 ? 0 : 11 - $sum % 11;
            if ($cnpj[$t] != $digit) {
                return false;
            }
        }
        return true;
    }
    public function exibe_botao($imagem, $imagempadrao)
    {
        return !empty($imagem) ? $imagem : $imagempadrao;
    }
    public function verify_Table()
    {
        try {
            if (!WHMCS\Database\Capsule::schema()->hasTable("mod_efimpay")) {
                WHMCS\Database\Capsule::schema()->create("mod_efimpay", function ($table) {
                    $table->increments("id");
                    $table->integer("cliente_id");
                    $table->integer("fatura_id");
                    $table->string("txid");
                    $table->string("transacao");
                    $table->string("barcode");
                    $table->string("qrcode");
                    $table->text("qrcode_image");
                    $table->string("link");
                    $table->string("billet_link");
                    $table->string("pdf");
                    $table->decimal("valor", 11, 2);
                    $table->enum("tipo", ["boleto", "pix", "cartao"]);
                    $table->date("duedate");
                    $table->date("paiddate");
                    $table->string("status");
                    $table->enum("notenviado", ["N", "S"])->default("N");
                });
            }
        } catch (Exception $e) {
            logModuleCall("verify_Table", "create_table_error", $e->getMessage(), "N/A", "N/A");
        }
    }
    public function criptografar($key)
    {
        $encryption_key = base64_decode("modulespay@efipixmpay#cripto");
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length("aes-256-cbc"));
        $encrypted = openssl_encrypt($key, "aes-256-cbc", $encryption_key, 0, $iv);
        return base64_encode($encrypted . "::" . $iv);
    }
    public function descriptografar($key)
    {
        $encryption_key = base64_decode("modulespay@efipixmpay#cripto");
        list($encrypted_data, $iv) = explode("::", base64_decode($key), 2);
        return openssl_decrypt($encrypted_data, "aes-256-cbc", $encryption_key, 0, $iv);
    }
    public function Converter_DataBrasil($data)
    {
        return date("d/m/Y", strtotime($data));
    }
    public function Converter_DataBrComHoras($data)
    {
        return date("d/m/Y H:i:s", strtotime($data));
    }
    public function Converter_DataEUA($data)
    {
        return date("Y/m/d", strtotime($data));
    }
    public function _obfuscated_43616C63756C61725F4469666572656EC3A7615F456E7472655F447561735F4461746173_($vencimento, $data_atual)
    {
        $primeiraData = new DateTime($vencimento);
        $segundaData = new DateTime($data_atual);
        $intervalo = $primeiraData->diff($segundaData);
        return (int) $intervalo->format("%R%a");
    }
    public function deletar_arquivo_Remoto($file)
    {
        if (!empty($file) && file_exists($file) && unlink($file)) {
            return true;
        }
        return false;
    }
    public function ApiGetAcessToken($autorizacao, $certificado)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/oauth/token", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "POST", CURLOPT_POSTFIELDS => "{\"grant_type\": \"client_credentials\"}", CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_HTTPHEADER => ["Authorization: Basic " . $autorizacao, "Content-Type: application/json"]]);
        $response = curl_exec($curl);
        curl_close($curl);
        $returnAuth = json_decode($response, true);
        return $returnAuth;
    }
    public function CadastrarWebhook($url, $chave, $access_token, $certificado)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/v2/webhook/" . $chave, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "PUT", CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_POSTFIELDS => "{\r\n                \"webhookUrl\": \"" . $url . "\"\r\n            }", CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $access_token, "Content-Type: application/json", "x-skip-mtls-checking: true"]]);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }
    public function ListarWebhook($autorizacao, $datainicio, $datafim, $certificado, $access_token)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/v2/webhook/?inicio=" . $datainicio . "&fim=" . $datafim, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $access_token, "Content-Type: application/json"]]);
        $response = curl_exec($curl);
        curl_close($curl);
        $returnAuth = json_decode($response, true);
        return $returnAuth;
    }
    public function DeleteWebhook($chave, $autorizacao, $certificado, $access_token)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/v2/webhook/" . $chave, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "DELETE", CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $access_token, "Content-Type: application/json"]]);
        $response = curl_exec($curl);
        curl_close($curl);
        $returnAuth = json_decode($response, true);
        return $returnAuth;
    }
    public function WebhookExiste($chave, $access_token, $certificado)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/v2/webhook/" . $chave, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $access_token, "Content-Type: application/json"]]);
        $response = json_decode(curl_exec($curl), true);
        curl_close($curl);
        return $response;
    }
    public function GerarPixComVencimento($txid, $body, $access_token, $certificado)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/v2/cobv/" . $txid, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "PUT", CURLOPT_POSTFIELDS => json_encode($body), CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $access_token, "Content-Type: application/json"]]);
        $responsePix = json_decode(curl_exec($curl), true);
        curl_close($curl);
        return $responsePix;
    }
    public function ModificarDadosdoPix($txid, $body, $access_token, $certificado)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/v2/cobv/" . $txid, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "PATCH", CURLOPT_POSTFIELDS => json_encode($body), CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $access_token, "Content-Type: application/json"]]);
        $responsePix = json_decode(curl_exec($curl), true);
        curl_close($curl);
        return $responsePix;
    }
    public function GerarPixLocation($idlocationPix, $certificado, $access_token)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/v2/loc/" . $idlocationPix . "/qrcode", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $access_token]]);
        $response = json_decode(curl_exec($curl), true);
        curl_close($curl);
        return $response;
    }
    public function PegarStatusDoPix($txid, $certificado, $access_token)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [CURLOPT_URL => $this->UrlApiEfi . "/v2/cobv/" . $txid, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_SSLCERT => $certificado, CURLOPT_SSLCERTPASSWD => "", CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $access_token, "Content-Type: application/json"]]);
        $response = json_decode(curl_exec($curl), true);
        curl_close($curl);
        return $response;
    }
    public function formatValue($value)
    {
        return number_format((float) $value, 2, ".", "");
    }
    public function obterCamposPersonalizados()
    {
        $fields = [];
        try {
            $sqlFields = WHMCS\Database\Capsule::table("tblcustomfields")->select("id", "fieldname")->get();
            foreach ($sqlFields as $field) {
                $fields[$field->id] = $field->fieldname;
            }
        } catch (Exception $e) {
            logActivity("Erro ao obter campos personalizados: " . $e->getMessage());
        }
        return $fields;
    }
    public function listar_arquivos_diretorio($diretorio)
    {
        $fields = [];
        if (!is_dir($diretorio) || !is_readable($diretorio)) {
            return "<p>Diretório inválido ou inacessível.</p>";
        }
        $arquivos = scandir($diretorio);
        foreach ($arquivos as $file) {
            if ($file !== "." && $file !== ".." && is_file($diretorio . DIRECTORY_SEPARATOR . $file)) {
                $fields[] = $file;
            }
        }
        return $fields;
    }
    public function salvarQrCodeComoPng($qrcode, $nomeArquivo)
    {
        $diretorioDestino = $this->baseDir . "/pix";
        $outputFilePath = $diretorioDestino . "/" . $nomeArquivo;
        $decodedData = base64_decode(str_replace("data:image/png;base64,", "", $qrcode));
        if (!is_dir($diretorioDestino) && !mkdir($diretorioDestino, 493, true)) {
            logActivity("Não foi possível criar o diretório: " . $diretorioDestino);
            return false;
        }
        $result = file_put_contents($outputFilePath, $decodedData);
        if ($result !== false) {
            return true;
        }
        return false;
    }
    public function alert_msg($msg)
    {
        echo "<script type=\"text/javascript\">alert(\"" . $msg . "\");</script>";
    }
    public function generateRandomStringWithPrefix($prefix)
    {
        $characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        $charactersLength = strlen($characters);
        $randomLength = rand(26, 35) - strlen($prefix);
        if ($randomLength <= 0) {
            throw new Exception("Prefixo muito longo! Deve ser menor que 26 caracteres.");
        }
        $randomString = "";
        for ($i = 0; $i < $randomLength; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $prefix . $randomString;
    }
    public function somenteNumeros($input): string
    {
        return preg_replace("/\\D/", "", $input);
    }
    public function GetProductNameByInvoiceId($invoiceId)
    {
        $invoiceItem = WHMCS\Database\Capsule::table("tblinvoiceitems")->where("invoiceid", $invoiceId)->whereIn("type", ["Hosting", "Domain"])->first();
        if (!$invoiceItem) {
            $invoiceItens = WHMCS\Database\Capsule::table("tblinvoiceitems")->where("invoiceid", $invoiceId)->first();
            if ($invoiceItens) {
                return $invoiceItens->description;
            }
            return "naoexiste";
        }
        return $invoiceItem->description;
    }
    public function Proximo_Dia_Util($data)
    {
        $feriadosFixos = ["01-01", "04-21", "05-01", "09-07", "10-12", "11-02", "11-15", "12-25"];
        $dia = date("d", strtotime($data));
        $mes = date("m", strtotime($data));
        $ano = date("Y", strtotime($data));
        $final = $data;
        while (in_array(date("N", strtotime($final)), [6, 7]) || in_array($mes . "-" . $dia, $feriadosFixos)) {
            $final = date("Y-m-d", strtotime($final . " +1 day"));
            $dia = date("d", strtotime($final));
            $mes = date("m", strtotime($final));
        }
        return $final;
    }
    public function formatarValorCentavoReais($value)
    {
        return number_format($value / 100, 2, ".", "");
    }
    public function formatarValorReaisCentavos($value)
    {
        $value = preg_replace("/[^\\d,.-]/", "", str_replace(",", ".", $value));
        return (int) round($value * 100);
    }
    public function gerarTxidPix($invoice)
    {
        $tamanhoString = strlen($invoice . "EFIMPAY");
        $x = 26 - $tamanhoString;
        $y = 35 - $tamanhoString;
        $tamanho = rand($x, $y);
        $caracteres = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $txid = substr(str_shuffle(str_repeat($caracteres, ceil($tamanho / strlen($caracteres)))), 0, $tamanho);
        return $invoice . "EFIMPAY" . $txid;
    }
    public function ValidarDatas($dataVencimento, $dataAtual)
    {
        $vencimento = new DateTime($dataVencimento);
        $data = new DateTime($dataAtual);
        $validade = $vencimento < $data;
        return $validade;
    }
    public function CompararDatas($data1, $data2)
    {
        $data1 = new DateTime($data1);
        $data2 = new DateTime($data2);
        $comparar = $data1 != $data2;
        return $comparar;
    }
    public function calcularMultaJurosDescontos($valorPago, $valorReal, $valordastaxas, $dataVencimento, $dataPagamento)
    {
        $valorEsperado = (float) $valorReal + (float) $valordastaxas;
        $valorPago = (float) $valorPago;
        $vencimento = new DateTime($dataVencimento);
        $pagamento = new DateTime($dataPagamento);
        if ($pagamento <= $vencimento) {
            if ($valorPago < $valorEsperado) {
                return number_format($valorPago - $valorEsperado, 2, ".", "");
            }
        } else if ($valorEsperado < $valorPago) {
            return number_format($valorPago - $valorEsperado, 2, ".", "");
        }
        return 0;
    }
    public function Get_DadosClientWHMCS($client)
    {
        $addressParts = explode(",", $client->address1);
        $endereco = trim($addressParts[0] ?? $client->address1);
        $endnumero = trim($addressParts[1] ?? "S/N");
        return ["clie_enderecocompleto" => $endereco . ", " . $endnumero . ", " . $client->address2, "clie_endereco" => trim($addressParts[0] ?? $client->address1), "clie_enderecoNum" => trim($addressParts[1] ?? "S/N"), "clie_nomecompleto" => $client->firstname . " " . $client->lastname];
    }
    public function converterParaNegativo($valor)
    {
        $valor = floatval($valor);
        return 0 < $valor ? -1 * $valor : $valor;
    }
    public function preparePixBody($pixefi, $invoice, $client, $cpfCnpj, $gatewaySettings, $valordaInvoice, $dataVencimento)
    {
        $dadosdoclient = $this->Get_DadosClientWHMCS($client);
        $body = ["calendario" => ["dataDeVencimento" => $dataVencimento, "validadeAposVencimento" => (int) $gatewaySettings["efipixmpay_tempoexpiracao"]], "devedor" => ["logradouro" => $dadosdoclient["clie_enderecocompleto"], "cidade" => $client->city, "uf" => $client->state, "nome" => $dadosdoclient["clie_nomecompleto"]], "valor" => ["original" => (string) $valordaInvoice], "chave" => $gatewaySettings["efipixmpay_chavepix"], "infoAdicionais" => [["nome" => "Serviço", "valor" => $this->getInvoiceItemsShortDescriptions($invoice->id)]]];
        if ($this->cpf_ou_cnpj($cpfCnpj) == "cnpj") {
            $body["devedor"]["cnpj"] = preg_replace("/\\D/", "", $cpfCnpj);
        } else {
            $body["devedor"]["cpf"] = preg_replace("/\\D/", "", $cpfCnpj);
        }
        if (!empty($gatewaySettings["efipixmpay_multaporatraso"])) {
            $multas = ["modalidade" => 2, "valorPerc" => $this->formatValue($gatewaySettings["efipixmpay_multaporatraso"])];
            $body["valor"]["multa"] = $multas;
        }
        if (!empty($gatewaySettings["efipixmpay_jurosporatraso"])) {
            $juroscobrado = ["modalidade" => 3, "valorPerc" => $gatewaySettings["efipixmpay_jurosporatraso"] == "on" ? $this->formatValue("1.00") : "0.00"];
            $body["valor"]["juros"] = $juroscobrado;
        }
        if (!empty($gatewaySettings["efipixmpay_descontoantecipado"])) {
            $dias = (int) $gatewaySettings["efipixmpay_descontoantecipado"];
            $percentualdesc = (float) $gatewaySettings["efipixmpay_percentualdescontoantecipado"];
            $datalimite = date("Y-m-d", strtotime("-" . $dias . " days", strtotime($dataVencimento)));
            $dataLimiteDesconto = $pixefi->ValidarDatas($datalimite, date("Y-m-d"));
            $descontoaplicado = ["modalidade" => 2, "descontoDataFixa" => [["data" => $datalimite, "valorPerc" => $this->formatValue($gatewaySettings["efipixmpay_percentualdescontoantecipado"])]]];
            $body["valor"]["desconto"] = $descontoaplicado;
        }
        return $body;
    }
    public function createNewPix($pixefi, $invoice, $client, $gatewaySettings, $valordaInvoice, $dataVencimento, $accessToken)
    {
        $cpfCnpj = $this->PegaCPFCNPJ($gatewaySettings["efipixmpay_campocpfcnpj"], $client->id);
        if (empty($cpfCnpj)) {
            logActivity("[EFI PIX MPAY] CPF/CNPJ vazio para o cliente: " . $client->firstname . " " . $client->lastname);
        } else {
            $certPath = ROOTDIR . "/modules/gateways/efipixmpay/certs/" . $gatewaySettings["efipixmpay_certificado"];
            $body = $this->preparePixBody($pixefi, $invoice, $client, $cpfCnpj, $gatewaySettings, $valordaInvoice, $dataVencimento);
            $txid = $this->gerarTxidPix($invoice->id);
            $responsePix = $this->GerarPixComVencimento($txid, $body, $accessToken, $certPath);
            return $responsePix;
        }
    }
    public function updateExistingPix($pixefi, $dadosdopix, $invoice, $client, $valordaInvoice, $accessToken, $gatewaySettings, $dataVencimento)
    {
        $cpfCnpj = $this->PegaCPFCNPJ($gatewaySettings["efipixmpay_campocpfcnpj"], $client->id);
        $cpfCnpj = preg_replace("/\\D/", "", $cpfCnpj);
        $certPath = ROOTDIR . "/modules/gateways/efipixmpay/certs/" . $gatewaySettings["efipixmpay_certificado"];
        $responseLoc = NULL;
        $body = $this->preparePixBody($pixefi, $invoice, $client, $cpfCnpj, $gatewaySettings, $valordaInvoice, $dataVencimento);
        $responsePix = $this->ModificarDadosdoPix($txid, $body, $accessToken, $certPath);
        if (!empty($responsePix["loc"]["id"])) {
            $idLocationPix = $responsePix["loc"]["id"];
            $responseLoc = $this->GerarPixLocation($idLocationPix, $certPath, $accessToken);
            $PixCopiaCola = $responseLoc["qrcode"];
            $imagemQrcode = $responseLoc["imagemQrcode"];
            $linkvisual = $responseLoc["linkVisualizacao"];
            $this->UpdateInsertTbl_Efi(["iddainvoice" => $invoice->id, "clientId" => $invoice->userid, "txid" => $responsePix["txid"], "qrcode" => $PixCopiaCola, "qrcode_image" => $imagemQrcode, "link" => $linkvisual, "valor" => $pixefi->formatValue($responsePix["valor"]["original"]), "tipo" => "pix", "duedate" => $responsePix["calendario"]["dataDeVencimento"], "status" => $responsePix["status"]]);
        }
        if (isset($responsePix["status"]) && $responsePix["status"] != "ATIVA") {
            return $responsePix["status"];
        }
        return $responseLoc;
    }
    public function UpdateTbl_Efi_Status($id, $status)
    {
        WHMCS\Database\Capsule::table("mod_efimpay")->where("fatura_id", $id)->update(["status" => $status]);
    }
    public function UpdateInsertTbl_Efi($dados)
    {
        $update = [];
        $update["fatura_id"] = $dados["iddainvoice"];
        $update["cliente_id"] = $dados["clientId"];
        if (isset($dados["txid"]) && !empty($dados["txid"])) {
            $update["txid"] = $dados["txid"];
        }
        if (isset($dados["qrcode"]) && !empty($dados["qrcode"])) {
            $update["qrcode"] = $dados["qrcode"];
        }
        if (isset($dados["qrcode_image"]) && !empty($dados["qrcode_image"])) {
            $update["qrcode_image"] = $dados["qrcode_image"];
        }
        if (isset($dados["link"]) && !empty($dados["link"])) {
            $update["link"] = $dados["link"];
        }
        if (isset($dados["valor"]) && !empty($dados["valor"])) {
            $update["valor"] = $dados["valor"];
        }
        if (isset($dados["duedate"]) && !empty($dados["duedate"])) {
            $update["duedate"] = $dados["duedate"];
        }
        if (isset($dados["transacao"]) && !empty($dados["transacao"])) {
            $update["transacao"] = $dados["transacao"];
        }
        if (isset($dados["barcode"]) && !empty($dados["barcode"])) {
            $update["barcode"] = $dados["barcode"];
        }
        if (isset($dados["billet_link"]) && !empty($dados["billet_link"])) {
            $update["billet_link"] = $dados["billet_link"];
        }
        if (isset($dados["pdf"]) && !empty($dados["pdf"])) {
            $update["pdf"] = $dados["pdf"];
        }
        if (isset($dados["barcode"]) && !empty($dados["barcode"])) {
            $update["barcode"] = $dados["barcode"];
        }
        if (isset($dados["tipo"]) && !empty($dados["tipo"])) {
            $update["tipo"] = $dados["tipo"];
        }
        if (isset($dados["barcode"]) && !empty($dados["barcode"])) {
            $update["barcode"] = $dados["barcode"];
        }
        if (isset($dados["paiddate"]) && !empty($dados["paiddate"])) {
            $update["paiddate"] = $dados["paiddate"];
        }
        if (isset($dados["status"]) && !empty($dados["status"])) {
            $update["status"] = $dados["status"];
        }
        if (isset($dados["notenviado"]) && !empty($dados["notenviado"])) {
            $update["notenviado"] = $dados["notenviado"];
        }
        if (0 < WHMCS\Database\Capsule::table("mod_efimpay")->where("fatura_id", "=", $dados["iddainvoice"])->count()) {
            unset($update["fatura_id"]);
            unset($update["client_id"]);
            WHMCS\Database\Capsule::table("mod_efimpay")->where("fatura_id", "=", $dados["iddainvoice"])->update($update);
        } else {
            WHMCS\Database\Capsule::table("mod_efimpay")->insert($update);
        }
    }
    public function getInvoice_Unpaid($invoiceId)
    {
        return WHMCS\Database\Capsule::table("tblinvoices")->where("id", $invoiceId)->where("status", "Unpaid")->first();
    }
    public function configureWebhook($webhookUrl, $accessToken, $certPath, $chavepix)
    {
        $cert_existe = $this->WebhookExiste($chavepix, $accessToken, $certPath);
        if (!isset($cert_existe["criacao"])) {
            $this->CadastrarWebhook($webhookUrl, $chavepix, $accessToken, $certPath);
        }
    }
    public function calculateInvoiceValues($pixefi, $valor, $data, $dataVencida, $gatewaySettings)
    {
        $taxaFixa = !empty($gatewaySettings["efipixmpay_taxafixa"]) ? $this->formatValue($gatewaySettings["efipixmpay_taxafixa"]) : 0;
        $taxaPerc = !empty($gatewaySettings["efipixmpay_taxapercentual"]) ? $gatewaySettings["efipixmpay_taxapercentual"] : 0;
        $valorTaxa = $taxaPerc != 0 ? $this->formatValue($valor * $taxaPerc / 100) : 0;
        $totalTaxas = $this->formatValue($taxaFixa + $valorTaxa);
        $juros = 0;
        $valordaInvoice = $this->formatValue($valor);
        if ($dataVencida) {
            $diasAtraso = (int) $this->_obfuscated_43616C63756C61725F4469666572656EC3A7615F456E7472655F447561735F4461746173_($data, date("Y-m-d"));
            $taxaMulta = !empty($gatewaySettings["efipixmpay_multaporatraso"]) ? $gatewaySettings["efipixmpay_multaporatraso"] : 0;
            $multa = $taxaMulta != 0 ? $valor * $taxaMulta / 100 : 0;
            $valorjuros = $gatewaySettings["efipixmpay_jurosporatraso"] === "on" ? (float) ($valor * 0 * $diasAtraso / 100) : 0;
            $jurosmulta = $this->formatValue($juros + $multa);
            $dataVencimento = $this->Proximo_Dia_Util(date("Y-m-d"));
        } else {
            $dataVencimento = $this->Proximo_Dia_Util($data);
        }
        return [$valordaInvoice, $dataVencimento, $totalTaxas, $jurosmulta];
    }
    public function processInvoice($pixefi, $invoice, $client, $gatewaySettings, $valordaInvoice, $dataVencimento, $accessToken)
    {
        $tblEfi = WHMCS\Database\Capsule::table("mod_efimpay")->where("fatura_id", $invoice->id)->first();
        if ($tblEfi) {
            $resultado = $this->updateExistingPix($pixefi, $tblEfi, $valordaInvoice, $dataVencimento, $accessToken, $gatewaySettings, $invoice, $client);
        } else {
            $resultado = $this->createNewPix($pixefi, $invoice, $client, $gatewaySettings, $valordaInvoice, $dataVencimento, $accessToken);
        }
        return $resultado;
    }
    public function getInvoiceItemsShortDescriptions($invoiceId)
    {
        $items = WHMCS\Database\Capsule::table("tblinvoiceitems")->where("invoiceid", $invoiceId)->get();
        if ($items->isEmpty()) {
            return false;
        }
        $shortDescriptions = "Fatura #" . $invoiceId;
        foreach ($items as $item) {
            $shortDescriptions .= " - " . $item->description . " (R\$ " . $item->amount . ")";
        }
        return substr($shortDescriptions, 0, 200);
    }
    public function getWebhookUrlByKey($data, $keyToCheck)
    {
        if (isset($data["webhooks"]) && is_array($data["webhooks"])) {
            foreach ($data["webhooks"] as $webhook) {
                if (isset($webhook["chave"]) && $webhook["chave"] === $keyToCheck) {
                    return isset($webhook["webhookUrl"]) ? $webhook["webhookUrl"] : false;
                }
            }
        }
        return false;
    }
    public function logGatewayAction($action, $data = [])
    {
        $logDirBase = __DIR__ . "/logs";
        $currentDate = date("Y-m-d");
        $logDir = $logDirBase . "/" . $currentDate;
        $logFile = $logDir . "/logs.log";
        if (!file_exists($logDirBase)) {
            mkdir($logDirBase, 493, true);
        }
        if (!file_exists($logDir)) {
            mkdir($logDir, 493, true);
        }
        $timestamp = date("Y-m-d H:i:s");
        $logMessage = "[" . $timestamp . "] Ação: " . $action;
        if (!empty($data)) {
            $logMessage .= " | Dados: " . json_encode($data, JSON_PRETTY_PRINT);
        }
        $logMessage .= PHP_EOL;
        file_put_contents($logFile, $logMessage, FILE_APPEND);
    }
    public function verificarArquivoExiste($arquivo)
    {
        if (!file_exists($arquivo)) {
            return false;
        }
        return true;
    }
    public function CriarArquivo($arquivo)
    {
        if (!file_exists($arquivo)) {
            $handle = @fopen($arquivo, "w");
            if ($handle === false) {
                throw new Exception("Erro ao tentar criar o arquivo de licença.");
            }
            fclose($handle);
            chmod($arquivo, 384);
            return true;
        }
        return false;
    }
    public function clienteTemCredito($clientId)
    {
        $cliente = WHMCS\Database\Capsule::table("tblclients")->where("id", $clientId)->where("credit", "<>", "0.00")->count();
        return $cliente;
    }
    public function PegarCreditoCliente($clientId)
    {
        $cliente = WHMCS\Database\Capsule::table("tblclients")->where("id", $clientId)->value("credit");
        return (float) $cliente;
    }
    public function aplicarCreditoNaInvoice($valorCredito, $valorFatura)
    {
        $credito = floatval($valorCredito);
        $valorFatura = floatval($valorFatura);
        if (0 < $credito || 0 < $valorFatura) {
            $valorDescontado = min($credito, $valorFatura);
            $novoValor = $valorFatura - $valorDescontado;
            return $novoValor;
        }
        return $valorFatura;
    }
    public function naoArredondar($valor, $casasDecimais = 2)
    {
        $fator = pow(10, $casasDecimais);
        return floor($valor * $fator) / $fator;
    }
    public function obterDominioSemSubdominio()
    {
        !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off" or $isSecure = !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off" || isset($_SERVER["SERVER_PORT"]) && $_SERVER["SERVER_PORT"] == 443;
        $protocol = $isSecure ? "https://" : "http://";
        $host = $_SERVER["HTTP_HOST"];
        $host = preg_replace("/^www\\./i", "", $host);
        $url = $protocol . $host;
        $url = rtrim($url, "/");
        return strtolower($url);
    }
    public function cleanDomain($url)
    {
        $url = preg_replace("#^https?://#i", "", $url);
        $url = preg_replace("/^www\\./i", "", $url);
        $url = rtrim($url, "/");
        $url = strtolower($url);
        return $url;
    }
}

?>